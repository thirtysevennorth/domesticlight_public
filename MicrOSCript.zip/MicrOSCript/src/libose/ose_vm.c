#include "../../lib/libose/ose_vm.c"
