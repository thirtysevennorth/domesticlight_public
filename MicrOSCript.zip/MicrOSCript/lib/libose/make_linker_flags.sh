#!/bin/sh

macos_file="ose_linker_flags_macos.mk"
linux_file="ose_linker_flags_linux.mk"

make clean &> /dev/null
DEFINES='-DOSE_CONF_PROVIDE_TYPE_DOUBLE -DOSE_CONF_PROVIDE_TYPE_TIMETAG' CFILES='sys/ose_load.c' make debug &> /dev/null

# macOS
printf "LD_UNDEF_FLAGS=" > "$macos_file"
nm libose.a | egrep '[CT] _(ose|osevm)_' | awk -v out_file="$macos_file" '{printf "-Wl,-U,"$3" " >> out_file}'

# Linux
printf "LD_UNDEF_FLAGS=" > "$linux_file"
nm libose.a | egrep '[CT] _(ose|osevm)_' | awk -v out_file="$linux_file" '{printf "-Wl,-u,"$3" " >> out_file}'
