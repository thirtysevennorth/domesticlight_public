/*
  Copyright (c) 2019-23 John MacCallum Permission is hereby
  granted, free of charge, to any person obtaining a copy of this
  software and associated documentation files (the "Software"), to
  deal in the Software without restriction, including without
  limitation the rights to use, copy, modify, merge, publish,
  distribute, sublicense, and/or sell copies of the Software, and
  to permit persons to whom the Software is furnished to do so,
  subject to the following conditions:

  The above copyright notice and this permission notice shall be
  included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
  OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
  OTHER DEALINGS IN THE SOFTWARE.
*/

/**
 * @file ose_stackops.h
 * 
 * @brief contains functions that manipulate the structure
 * and contents of an OSE bundle and its elements
 *
 * An OSE bundle is simply an OSC bundle that has been organized in
 * a particular way, as described in ose_context.h. The functions in
 * this file assume that the #ose_bundle that is passed as their
 * first argument was created using the function
 * #ose_newBundleFromCBytes.
 *
 * The satisfaction of the preconditions stated in the documentation
 * is the responsibility of the caller, and result in undefined
 * behavior if they are not met.
 *
 * - Elements vs Items
 * - Notation
 */

#ifndef OSE_STACKOPS_H
#define OSE_STACKOPS_H

#ifdef __cplusplus
extern "C" {
#endif

#include "ose.h"
#include "ose_util.h"
#include "ose_errno.h"

/**
 * 
 */
#define OSE_START_BUNDLE(B) {                               \
    ose_pushBundle(B);                                      \
    int32_t ose_stackops_reserved_o___ =                    \
        ose_getLastBundleElemOffset(B);                     \
    int32_t ose_stackops_reserved_bs___ = ose_readSize(B);

/**
 * 
 */
#define OSE_END_BUNDLE(B)                                   \
    int32_t ose_stackops_reserved_nbs___ = ose_readSize(B); \
    ose_writeInt32(B, ose_stackops_reserved_o___,           \
                   OSE_BUNDLE_HEADER_LEN +                  \
                   (ose_stackops_reserved_nbs___ -          \
                    ose_stackops_reserved_bs___));          \
}

/**
 * @name C to OSC
 * @{
 */

/**
 * @brief Append a message containing a 32-bit signed int.
 */
void ose_pushInt32(ose_bundle B, int32_t v);

/**
 * @brief Append a message containing a float.
 */
void ose_pushFloat(ose_bundle B, float v);

/**
 * @brief Append a message containing a string.
 */
void ose_pushString(ose_bundle B,
                    const char * const v);

/**
 * @brief Append a message containing a blob.
 */
void ose_pushBlob(ose_bundle B,
                  int32_t size,
                  const char * const blob);

#ifdef OSE_PROVIDE_TYPE_SYMBOL
/**
 * @brief Append a message containing a symbol.
 */
void ose_pushSymbol(ose_bundle B, const char * const v);
#endif

#ifdef OSE_PROVIDE_TYPE_DOUBLE
/**
 * @brief Append a message containing a double.
 */
void ose_pushDouble(ose_bundle B, double v);
#endif

#ifdef OSE_PROVIDE_TYPE_INT8
/**
 * @brief Append a message containing a signed char.
 */
void ose_pushInt8(ose_bundle B, int8_t v);
#endif

#ifdef OSE_PROVIDE_TYPE_UINT8
/**
 * @brief Append a message containing an unsigned char.
 */
void ose_pushUInt8(ose_bundle B, uint8_t v);
#endif

#ifdef OSE_PROVIDE_TYPE_UINT32
/**
 * @brief Append a message containing an unsigned 32-bit int.
 */
void ose_pushUInt32(ose_bundle B, uint32_t v);
#endif

#ifdef OSE_PROVIDE_TYPE_INT64
/**
 * @brief Append a message containing a signed 64-bit int.
 */
void ose_pushInt64(ose_bundle B, int64_t v);
#endif

#ifdef OSE_PROVIDE_TYPE_UINT64
/**
 * @brief Append a message containing an unsigned 64-bit int.
 */
void ose_pushUInt64(ose_bundle B, uint64_t v);
#endif

#ifdef OSE_PROVIDE_TYPE_TIMETAG
/**
 * @brief Append a message containing a timetag.
 */
void ose_pushTimetag(ose_bundle B, uint32_t sec, uint32_t fsec);
#endif

#ifdef OSE_PROVIDE_TYPE_TRUE
/**
 * @brief Append message containing true to `B`.
 */
void ose_pushTrue(ose_bundle B);
#endif

#ifdef OSE_PROVIDE_TYPE_FALSE
/**
 * @brief Append message containing false to `B`.
 */
void ose_pushFalse(ose_bundle B);
#endif

#ifdef OSE_PROVIDE_TYPE_NULL
/**
 * @brief Append message containing NULL to `B`.
 */
void ose_pushNull(ose_bundle B);
#endif

#ifdef OSE_PROVIDE_TYPE_INFINITUM
/**
 * @brief Append a message containing an infinitum.
 */
void ose_pushInfinitum(ose_bundle B);
#endif

/**
 * @brief Append a message containing a pointer.
 */
void ose_pushAlignedPtr(ose_bundle B, const void *v);

/**
 * @brief Append a message.
 *
 * @param B the bundle
 * @param address the address of the message
 * @param addresslen the address length not including NULL padding
 * @param n the number of arguments
 * @param ... `n` arguments (typetag, data)
 * 
 * @see ose_writeMessage
 */
void ose_pushMessage(ose_bundle B,
                     const char * const address,
                     int32_t addresslen,
                     int32_t n,
                     ...);

/** @} */ // C to OSC

/**
 * @name OSC to C
 * @{
 */

/**
 * @brief Get the address of the last element.
 * 
 * @returns a pointer to the address
 *
 * @pre `B` must not be empty.
 *
 * @note If the last element of `B` is a bundle, this function
 * returns a pointer to the bundle ID, "#bundle".
 */
char *ose_peekAddress(const ose_bundle B);

/**
 * @brief Get the type of the last item of the last element.
 *
 * @returns the typetag of the last item of the last element
 * @retval #OSETT_NOTYPETAG if the message has no data/payload
 *
 * @pre `B` must not be empty.
 * @pre The last element should be a message.
 *
 * @warning This function does no typechecking to ensure that the
 * last element is actually a message.
 */
char ose_peekMessageArgType(const ose_bundle B);

/**
 * @brief Get the type of the last element.
 *
 * @returns the type of the last element
 * @retval #OSETT_BUNDLE
 * @retval #OSETT_MESSAGE
 *
 * @pre `B` must not be empty.
 *
 * @warning It is undefined behavior to call this function on an
 * empty bundle.
 */
char ose_peekType(const ose_bundle B);

/**
 * @brief Get the value of the last int stored in the last message.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 *
 * @warning This function does no type or bounds checking.
 */
int32_t ose_peekInt32(ose_constbundle B);

/**
 * @brief Get the value of the last float stored in the last message.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 *
 * @warning This function does no type or bounds checking.
 */
float ose_peekFloat(ose_constbundle B);

/**
 * @brief Get a pointer to the last string without removing it.
 *
 * @returns a pointer to the location in the bundle where the string
 * is
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The last item of the last message must be a NULL-terminated
 * string.
 *
 * @note The string should not be modified unless you know what you
 * are doing.
 *
 * @warning This function does no type or bounds checking.
 */
char *ose_peekString(ose_constbundle B);

/**
 * @brief Get a pointer to the last blob without removing it.
 *
 * @returns a pointer to the location in the bundle where the blob
 * is
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The last item of the last message must be a valid OSC blob.
 *
 * @note The blob should not be modified unless you know what you
 * are doing.
 *
 * @warning This function does no type or bounds checking.
 */
char *ose_peekBlob(ose_constbundle B);

#ifdef OSE_PROVIDE_TYPE_SYMBOL
/**
 * @brief Get a pointer to the last symbol stored in the last
 * message.
 *
 * @returns a pointer to the location in the bundle where the symbol
 * is
 *
 * @pre `B` must not be empty
 * @pre the last element must be a message
 * @pre the last item of the last message must be a NULL-terminated
 * string
 * 
 * @note The string should not be modified unless you know what you
 * are doing.
 *
 * @warning This function does no type or bounds checking.
 */
char *ose_peekSymbol(const ose_bundle B);
#endif

#ifdef OSE_PROVIDE_TYPE_DOUBLE
/**
 * @brief Get the last double without removing it.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * 
 * @warning This function does no type or bounds checking.
 */
double ose_peekDouble(const ose_bundle B);
#endif

#ifdef OSE_PROVIDE_TYPE_INT8
/**
 * @brief Get the last signed char without removing it.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * 
 * @warning This function does no type or bounds checking.
 */
int8_t ose_peekInt8(const ose_bundle B);
#endif

#ifdef OSE_PROVIDE_TYPE_UINT8
/**
 * @brief Get the last unsigned char without removing it.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * 
 * @warning This function does no type or bounds checking.
 */
uint8_t ose_peekUInt8(const ose_bundle B);
#endif

#ifdef OSE_PROVIDE_TYPE_UINT32
/**
 * @brief Get the last unsigned 32-bit int without removing it.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * 
 * @warning This function does no type or bounds checking.
 */
uint32_t ose_peekUInt32(const ose_bundle B);
#endif

#ifdef OSE_PROVIDE_TYPE_INT64
/**
 * @brief Get the last 64-bit int without removing it.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * 
 * @warning This function does no type or bounds checking.
 */
int64_t ose_peekInt64(const ose_bundle B);
#endif

#ifdef OSE_PROVIDE_TYPE_UINT64
/**
 * @brief Get the last unsigned int without removing it.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * 
 * @warning This function does no type or bounds checking.
 */
uint64_t ose_peekUInt64(const ose_bundle B);
#endif

#ifdef OSE_PROVIDE_TYPE_TIMETAG
/**
 * @brief Get the last timetag without removing it.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * 
 * @warning This function does no type or bounds checking.
 */
struct ose_timetag ose_peekTimetag(const ose_bundle B);
#endif

/**
 * @brief Get the last aligned pointer without removing it.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The last item of the last message must be a valid aligned
 * pointer, written using #ose_pushAlignedPtr, or
 * #ose_writeAlignedPtr.
 *
 * @warning This function does no type or bounds checking.
 */
const void *ose_peekAlignedPtr(ose_bundle B);

/**
 * @brief Get the last int and remove it from the bundle.
 * 
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 *
 * @warning This function does no type or bounds checking.
 */
int32_t ose_popInt32(ose_bundle B);

/**
 * @brief Get the last float and remove it from the bundle.
 * 
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 *
 * @warning This function does no type or bounds checking.
 */
float ose_popFloat(ose_bundle B);

/**
 * @brief Get the last string and remove it from the bundle.
 *
 * @param B the bundle
 * @param buf a pointer to an array large enough to store a copy of
 * the string
 * @returns the length of the string not including the NULL byte
 * 
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The last item of the last message must be a NULL-terminated
 * string.
 *
 * @warning This function does no type or bounds checking.
 */
int32_t ose_popString(ose_bundle B, char *buf);

/**
 * @brief Get the last blob and remove it from the bundle.
 *
 * @param B the bundle
 * @param buf a pointer to an array large enough to store a copy of
 * the blob payload, i.e. not including the 4 byte size
 * @returns the size of the blob (not including the 4 byte size, or
 * any padding)
 *
 * @warning This function does no type or bounds checking.
 */
int32_t ose_popBlob(ose_bundle B, char *buf);

#ifdef OSE_PROVIDE_TYPE_SYMBOL
/**
 * @brief Get the last symbol and remove it from the bundle.
 *
 * @param B the bundle
 * @param buf a pointer to an array large enough to store a copy of
 * the symbol
 * @returns the length of the symbol not including the NULL byte
 *
 * @warning This function does no type or bounds checking.
 */
int32_t ose_popSymbol(ose_bundle B, char *buf);
#endif

#ifdef OSE_PROVIDE_TYPE_DOUBLE
/**
 * @brief Get the last double and remove it from the bundle.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 *
 * @warning This function does no type or bounds checking.
 */
double ose_popDouble(ose_bundle B);
#endif

#ifdef OSE_PROVIDE_TYPE_INT8
/**
 * @brief Get the last char and remove it from the bundle.
 * 
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 *
 * @warning This function does no type or bounds checking.
 */
int8_t ose_popInt8(ose_bundle B);
#endif

#ifdef OSE_PROVIDE_TYPE_UINT8
/**
 * @brief Get the last unsigned char and remove it from the bundle.
 * 
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 *
 * @warning This function does no type or bounds checking.
 */
uint8_t ose_popUInt8(ose_bundle B);
#endif

#ifdef OSE_PROVIDE_TYPE_UINT32
/**
 * @brief Get the last unsigned 32-bit int and remove it from the
 * bundle.
 * 
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 *
 * @warning This function does no type or bounds checking.
 */
uint32_t ose_popUInt32(ose_bundle B);
#endif

#ifdef OSE_PROVIDE_TYPE_INT64
/**
 * @brief Get the last 64-bit int and remove it from the bundle.
 * 
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 *
 * @warning This function does no type or bounds checking.
 */
int64_t ose_popInt64(ose_bundle B);
#endif

#ifdef OSE_PROVIDE_TYPE_UINT64
/**
 * @brief Get the last unsigned 64-bit int and remove it from the
 * bundle.
 * 
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 *
 * @warning This function does no type or bounds checking.
 */
uint64_t ose_popUInt64(ose_bundle B);
#endif

#ifdef OSE_PROVIDE_TYPE_TIMETAG
/**
 * @brief Get the last timetag and remove it from the bundle.
 * 
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 *
 * @warning This function does no type or bounds checking.
 */
struct ose_timetag ose_popTimetag(ose_bundle B);
#endif

/** @} */ // OSC to C

/**
 * @name Stack Operations
 * @{
 */

/**
 * @brief Drop the last element.
 *
 * @pre `B` must not be empty.
 */
void ose_drop(ose_bundle B);

/**
 * @brief Drop the last two elements.
 *
 * @pre `B` must contain at least two elements.
 */
void ose_2drop(ose_bundle B);

/**
 * @brief Duplicate the last element.
 *
 * @pre `B` must not be empty.
 */
void ose_dup(ose_bundle B);

/**
 * @brief Duplicate the last two elements.
 *
 * @pre `B` must contain at least two elements.
 */
void ose_2dup(ose_bundle B);

/**
 * @brief Drop the second to last element.
 *
 * @pre `B` must contain at least two elements.
 */
void ose_nip(ose_bundle B);

/**
 * @brief Move the third to last element to the end.
 * 
 * @pre `B` must contain at least three elements.
 */
void ose_rot(ose_bundle B);

/**
 * @brief Move the last element to the third from the end.
 *
 * @pre `B` must contain at least three elements.
 */
void ose_rrot(ose_bundle B);

/**
 * @brief Copy the second from the last item _over_ the last.
 *
 * @ `B` must contain at least two elements.
 */
void ose_over(ose_bundle B);

/**
 * @brief Copy the second to last pair of elements _over_ the last
 * pair.
 * 
 * @pre `B` must contain at least four elements.
 */
void ose_2over(ose_bundle B);

/**
 * @brief Copy an element at an index to the end.
 * 
 * @details The last element, a message containing an int,
 * will be removed, and the value of the int will be used to
 * index an element of `B`. Indexes are 0-based, counting
 * from the end, with 0 being the last element after the
 * removal of the message. The element that corresponds to
 * the index will be copied to the end.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last element must be a message containing an int.
 * @pre The int must be in the range @f$[0, K-2]@f$ (inclusive),
 * where @f$K@f$ is the total number of elements in the bundle at
 * the time the function is called.
 *
 * @note When the index is 0, the operation is equivalent to
 * #ose_dup, and when it is 1, it is equivalent to
 * #ose_over.
 * 
 * @see ose_pickBottom
 * @see ose_pickMatch
 */
void ose_pick(ose_bundle B);

/**
 * @brief Move an element at an index to the end.
 *
 * @details The last element, a message containing an int,
 * will be removed, and the value of the int will be used to
 * index an element of `B`. Indexes are 0-based, counting
 * from the end, with 0 being the last element after the
 * removal of the message. The element that corresponds to
 * the index will be moved to the end.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last element must be a message containing an int.
 * @pre The int must be in the range @f$[0, K-2]@f$ (inclusive),
 * where @f$K@f$ is the total number of elements in the bundle at
 * the time the function is called.
 *
 * @note When the index is 0, this is a no-op (excepting
 * that the message containing the index is dropped), when
 * it is 1, it is equivalent to #ose_swap, and when it is 2,
 * it is equivalent to #ose_rot.
 *
 * @see ose_rollBottom
 * @see ose_rollMatch
 */
void ose_roll(ose_bundle B);

/**
 * @brief Copy the first element to the end.
 *
 * @pre `B` must not be empty.
 *
 * @see ose_pick
 * @see ose_pickMatch
 */
void ose_pickBottom(ose_bundle B);

/**
 * @brief Move the first element to the end.
 *
 * @pre `B` must not be empty.
 *
 * @note If `B` contains only one element, this is a no-op,
 * with two elements, it is equivalent to #ose_swap, and
 * with three elements, it is equivalent to #ose_rot.
 * 
 * @see ose_roll
 * @see ose_rollMatch
 */
void ose_rollBottom(ose_bundle B);

/**
 * @brief Copy the first element with an address that matches the
 * string at the end of the bundle to the end.
 *
 * The last element of `B` must be a message containing one string.
 * Addresses are compared starting at the beginning of the bundle,
 * and the first address that matches is copied, halting the
 * matching process. Matching is done by simple string
 * comparison---no pattern matching is performed.
 * 
 */
int32_t ose_pickMatch_impl(ose_bundle B);
void ose_pickMatch(ose_bundle B);
int32_t ose_pickPMatch_impl(ose_bundle B);
void ose_pickPMatch(ose_bundle B);

/**
 * @brief Copy the first element with an address that matches the
 * string at the end of the bundle to the end.
 *
 * The last element of `B` must be a message containing one string.
 * Addresses are compared starting at the beginning of the bundle,
 * and the first address that matches is copied, halting the
 * matching process. Matching is done by simple string
 * comparison---no pattern matching is performed.
 * 
 */
int32_t ose_rollMatch_impl(ose_bundle B);
void ose_rollMatch(ose_bundle B);
int32_t ose_rollPMatch_impl(ose_bundle B);
void ose_pickPMatch(ose_bundle B);

/**
 * @brief Swap the last two elements.
 * 
 * @pre `B` must contain at least two elements.
 */
void ose_swap(ose_bundle B);

/**
 * @brief Swap elements the last two elements with the previous two.
 * 
 * @pre `B` must contain at least four elements.
 */
void ose_2swap(ose_bundle B);

/**
 * @brief Copy the last element to the third from last position.
 *
 * @pre `B` must contain at least two elements.
 */
void ose_tuck(ose_bundle B);

/** @} */ // Stack Operations

/**
 * @name Grouping / Ungrouping
 * @{
 */

/**
 * @brief Collect all bundle elements into a single bundle.
 */
void ose_bundleAll(ose_bundle B);

/**
 * @brief Collect elements at the start of the bundle together.
 *
 * @details The last element, a message containing an int,
 * will be removed, and the value of the int will be used to
 * count elements starting from the beginning of the bundle.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last element must be a message containing an int.
 * @pre The int must be in the range @f$[0, K-1]@f$ (inclusive),
 * where @f$K@f$ is the total number of elements in the bundle at
 * the time the function is called.
 *
 * @note The collection operation is performed _after_ removing
 * the message containing the number of elements to collect, i.e.
 * the message containing that value cannot be included.
 *
 * @note A value of 0 will produce an empty bundle at the start
 * of `B`.
 */
void ose_bundleFromBottom(ose_bundle B);

/**
 * @brief Collect elements at the end of the bundle together.
 *
 * @details The last element, a message containing an int,
 * will be removed, and the value of the int will be used to
 * count elements starting from the end of the bundle.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last element must be a message containing an int.
 * @pre The int must be in the range @f$[0, K-1]@f$ (inclusive),
 * where @f$K@f$ is the total number of elements in the bundle at
 * the time the function is called.
 *
 * @note The collection operation is performed _after_ removing
 * the message containing the number of elements to collect, i.e.
 * the message containing that value cannot be included.
 *
 * @note A value of 0 will produce an empty bundle at the end
 * of `B`.
 */
void ose_bundleFromTop(ose_bundle B);

/**
 * @brief Clear all elements.
 */
void ose_clear(ose_bundle B);

/**
 * @brief Pop the last item off the last element and push it onto
 * the end of the bundle as a new element.
 *
 * @pre `B` must not be empty.
 *
 * @note The last element of the bundle may be empty, in which case
 * the element will be dropped.
 *
 * @see ose_popAll
 * @see ose_popAllDrop
 * @see ose_popAllBundle
 * @see ose_popAllDropBundle
 */
void ose_pop(ose_bundle B);

/**
 * @brief Pop each item off the last element of the bundle.
 *
 * @details After all items have been popped off the
 * element, the empty element, a message with no data, or an
 * empty bundle, is left as the final element of the bundle.
 *
 * @pre `B` must not be empty.
 *
 * @note The last element of the bundle may be empty, in
 * which case this function is a no-op.
 *
 * @see ose_pop
 * @see ose_popAllDrop
 * @see ose_popAllBundle
 * @see ose_popAllDropBundle
 */
void ose_popAll(ose_bundle B);

/**
 * @brief Pop each item off the last element of the bundle,
 * and drop the empty element.
 *
 * @details Unlike #ose_popAll, the empty element is not
 * left at the end of the bundle.
 *
 * @pre `B` must not be empty.
 *
 * @note The last element of the bundle may be empty, in
 * which case it is simply dropped.
 *
 * @see ose_pop
 * @see ose_popAll
 * @see ose_popAllBundle
 * @see ose_popAllDropBundle
 */
void ose_popAllDrop(ose_bundle B);

/**
 * @brief Pop each item off the last element of the bundle, and
 * bundle them together.
 *
 * @details Like #ose_popAll, but all elements created from
 * the items of the last element are bundled together.
 * 
 * @pre `B` must not be empty.
 *
 * @note The last element of the bundle may be empty, in
 * which case it is simply bundled.
 *
 * @see ose_pop
 * @see ose_popAll
 * @see ose_popAllDrop
 * @see ose_popAllDropBundle
 */
void ose_popAllBundle(ose_bundle B);

/**
 * @brief Pop each item off the last element of the bundle, drop the
 * empty element, and bundle all new elements together.
 *
 * @details The combined behavior of #ose_popAllDrop and
 * #ose_popAllBundle.
 *
 * @pre `B` must not be empty.
 *
 * @note The last element of the bundle may be empty, in
 * which case it is dropped and an empty bundle is created
 * in its place.
 *
 * @see ose_pop
 * @see ose_popAll
 * @see ose_popAllBundle
 * @see ose_popAllDrop
 */
void ose_popAllDropBundle(ose_bundle B);

/**
 * @brief Reverse the items of the last element of the bundle.
 *
 * @pre `B` must not be empty.
 */
void ose_reverse(ose_bundle B);

/**
 * @brief Push the last element of the bundle onto the element below
 * it.
 *
 * @details The behavior of this function depends on the
 * types and number of elements at the end of the bundle as
 * follows:
 * 
 * - the bundle is empty: an empty bundle is created
 * - there is only one element: it is pushed into a bundle
 * - both elements are messages: append the payload of the last to
 *   the one below it.
 * - the second to last element is a bundle: the last element is
 *   pushed into it.
 * - the second to last element is a message, and the last element
 *   is a bundle: the last element becomes a blob appended to the
 *   message.
 */
void ose_push(ose_bundle B);

/**
 * @brief Split an element in two.
 *
 * @details The last element of the bundle, a message
 * containing an int @f$v@f$, will be removed. The second to
 * last element will have @f$v@f$ items removed counting
 * from the end, which will be contained in a new element of
 * the same type.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last element must be a message containing an int.
 * @pre The int must be in the range @f$[1,K]@f$ (inclusive), where
 * @f$K@f$ is the number of items in the second to last element.
 *
 * @see ose_decatenateElemFromStart
 */
void ose_decatenateElemFromEnd(ose_bundle B);

/**
 * @brief Split an element in two.
 *
 * @details The last element of the bundle, a message
 * containing an int @f$v@f$, will be removed. The second to
 * last element will have @f$v@f$ items removed counting
 * from the start, which will be contained in a new element of
 * the same type.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last element must be a message containing an int.
 * @pre The int must be in the range @f$[1,K]@f$ (inclusive), where
 * @f$K@f$ is the number of items in the second to last element.
 *
 * @see ose_decatenateElemFromEnd
 */
void ose_decatenateElemFromStart(ose_bundle B);

/**
 * @brief Concatenate the last two elements.
 *
 * @details This function behaves identically to #ose_push, unless the two
 * elements are both bundles, in which case the elements of the last
 * are pushed onto the second to last.
 *
 * @see ose_push
 */
void ose_concatenateElems(ose_bundle B);

/**
 * @brief Unpack the last element.
 *
 * @details Each item of the last element is "unpacked" to
 * the top level of `B`. This is a similar operation to the
 * #ose_popAll functions, but the resulting order of new
 * elements is the opposite.
 *
 * @pre `B` must not be empty.
 *
 * @see ose_unpackDrop
 */
void ose_unpack(ose_bundle B);

/**
 * @brief Unpack the last element and drop it.
 *
 * @details Each item of the last element is "unpacked" to
 * the top level of `B`. This is a similar operation to the
 * #ose_popAll functions, but the resulting order of new
 * elements is the opposite. Unlike #ose_unpack,
 * #ose_unpackDrop drops the empty element.
 *
 * @pre `B` must not be empty.
 *
 * @see ose_unpack
 */
void ose_unpackDrop(ose_bundle B);

/** @} */ // Grouping / Ungrouping

/**
 * @name Queries
 * @{
 */

/**
 * @brief Get the number of elements.
 *
 * @details Creates a new message containing the number of
 * elements in `B` as an int.
 *
 * @see ose_countItems
 */
void ose_countElems(ose_bundle B);

/**
 * @brief Get the number of items in the last element.
 *
 * @details Creates a new message containing the number of
 * items in the last element of `B` as an int.
 *
 * @pre `B` must not be empty.
 *
 * @see ose_countElems
 */
void ose_countItems(ose_bundle B);

/**
 * @brief Get the length in bytes of the last item of the
 * last element, excluding NULL-padding.
 *
 * @details Creates a new message containing the number of
 * bytes in the last item of the last element of `B`,
 * excluding NULL-padding.
 *
 * @pre `B` must not be empty.
 *
 * @see ose_lengthsItems
 * @see ose_sizeItem
 */
void ose_lengthItem(ose_bundle B);

/**
 * @brief Get the lengths in bytes of all items of the last element
 * as a list, excluding NULL-padding.
 *
 * @details Creates a new message containing a list of the
 * numbers of bytes of all items of the last element of `B`,
 * excluding NULL-padding.
 *
 * @pre `B` must not be empty.
 * 
 * @see ose_lengthItem
 * @see ose_sizesItems
 */
void ose_lengthsItems(ose_bundle B);

/**
 * @brief Get the size of the last element in bytes, including
 * NULL-padding, and excluding the size field.
 *
 * @details Creates a new message containing the result as a
 * single int.
 *
 * @pre `B` must not be empty.
 *
 * @see ose_sizeItem
 * @see ose_lengthElem
 */
void ose_sizeElem(ose_bundle B);

/**
 * @brief Get the size of the last item of the last element,
 * including NULL-padding.
 *
 * @details Creates a new message containing the number of
 * bytes in the last item of the last element of `B`,
 * including NULL-padding.
 *
 * @pre `B` must not be empty.
 *
 * @see ose_lengthItem
 * @see ose_sizesItems
 */
void ose_sizeItem(ose_bundle B);

/**
 * @brief Get the sizes of all elements as a list, including
 * NULL-padding.
 *
 * @details Creates a new message containing a list of the
 * numbers of bytes of all items of the last element of `B`,
 * including NULL-padding.
 *
 * @pre `B` must not be empty.
 *
 * @note The size of a blob does not include the size field.
 *
 * @see ose_sizeElem
 */
void ose_sizesElems(ose_bundle B);

/**
 * @brief Get the sizes of all items of the last element as a list,
 * including NULL-padding.
 *
 * @details Creates a new message containing a list of the
 * numbers of bytes of all items of the last element of `B`,
 * excluding NULL-padding.
 *
 * @pre `B` must not be empty.
 *
 * @see ose_sizeItem
 * @see ose_lengthsItems
 */
void ose_sizesItems(ose_bundle B);

/**
 * @brief Get the address(es) of the last element of the bundle.
 *
 * @details Creates a list of one or more strings containing
 * the addresses of the last element of the bundle. If the
 * last element is a message, the result will be its
 * address. If the last element is a bundle, the result will
 * be a list of the addresses of each element.
 *
 * @pre `B` must not be empty.
 */
void ose_getAddresses(ose_bundle B);

/**
 * @brief Set the bundle's timetag.
 *
 * @details This function moves the contents of an 8-byte blob into
 * the timetag field of the bundle `B`. The message containing the
 * blob is dropped.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The last item of the last message be a blob containing an OSC
 * timetag (#ose_timetag).
 */
void ose_setTimetag(ose_bundle B);

/**
 * @brief Get the bundle's timetag.
 *
 * @details This function creates a new message at the end of `B`
 * containing an 8-byte blob with the contents of the timetag field
 * of `B`. The timetag field is not modified.
 */
void ose_getTimetag(ose_bundle B);

/**
 * @brief Get the typetags of the last element.
 */
void ose_getTypetags(ose_bundle B);

/**
 * @brief Determine whether the last element is a bundle.
 *
 * @details Creates a new message with a single integer with
 * a value of 1 if the last element is a bundle, and a 0
 * otherwise.
 *
 * @pre `B` must not be empty.
 */
void ose_elemIsBundle(ose_bundle B);

/**
 * @brief Get the type signature of the last element of the bundle
 * with no recursion.
 *
 * @see ose_typeof1
 * @see ose_typeof2
 */
void ose_typeof0(ose_bundle B);

/**
 * @brief Get the type signature of the last element of the bundle
 * with one level of recursion.
 *
 * @see ose_typeof0
 * @see ose_typeof2
 */
void ose_typeof1(ose_bundle B);

/**
 * @brief Get the type signature of the last element of the bundle
 * with two levels of recursion.
 *
 * @see ose_typeof0
 * @see ose_typeof1
 */
void ose_typeof2(ose_bundle B);

/** @} */ // Queries

/**
 * @name Operations on Bundle Elements and Items
 * @{
 */

/**
 * @brief Set the typetag of the last item of the last message.
 *
 * @details This function changes the typetag of a message's
 * item without modifying the contents of the data at all.
 *
 * This function simply chages the typetag, it does not
 * make any change to the content of the data itself. This can be
 * thought of as a _reinterpretation_ of the bytes as a different
 * type.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The last element must not be empty.
 *
 * @see ose_setTypetag
 *
 * Similar functionality can be accomplished using
 * #ose_blobToType, however there is an important
 * difference. A blob consists of a size field followed by
 * that number of bytes, and when converting to another type
 * using #ose_blobToType, the size of the blob is removed,
 * while #ose_setTypetag leaves the entire blob including
 * its size intact and simply changes the typetag.
 */
void ose_setTypetag_impl(ose_bundle B, char typetag);

/**
 * @brief Set the typetag of the last item of the last message.
 *
 * @details This function simply chages the typetag, it does not
 * make any change to the content of the data itself. This can be
 * thought of as a _reinterpretation_ of the bytes as a different
 * type.
 * 
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The last element must not be empty.
 *
 * @see ose_setTypetag_impl
 *
 * Similar functionality can be accomplished using
 * #ose_blobToType, however there is an important
 * difference. A blob consists of a size field followed by
 * that number of bytes, and when converting to another type
 * using #ose_blobToType, the size of the blob is removed,
 * while #ose_setTypetag leaves the entire blob including
 * its size intact and simply changes the typetag.
 */
void ose_setTypetag(ose_bundle B);

/**
 * @brief Convert a blob to a bundle element.
 *
 * @details This function removes the last element of the bundle,
 * which must be a message, converts the last item of that message
 * to a bundle element, and pushes it onto the end of the bundle.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The last item must be a blob.
 * @pre The blob size and blob contents together must form a valid
 * bundle element---no alteration to the contents to the blob or its
 * size are made.
 */
void ose_blobToElem(ose_bundle B);

/**
 * @brief Convert a blob to a different type.
 *
 * @details This function converts a blob to a different
 * type by removing its size and changing its typetag.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The last item must be a blob.
 *
 * @see ose_setTypetag_impl
 */
void ose_blobToType_impl(ose_bundle B, char typetag);

/**
 * @brief Convert a blob to a different type.
 *
 * @details This function converts a blob to a different
 * type by removing its size and changing its typetag.
 * 
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The last item must be a blob.
 *
 * @see ose_setTypetag
 */
void ose_blobToType(ose_bundle B);

void ose_toType(ose_bundle B);

/**
 * @brief Cast a value to a 32-bit integer.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The last element must not be empty.
 *
 * @note One of the primary uses of this function is to
 * convert a string representation of a number found as part
 * of an OSC address into an integer. For that reason,
 * strings may begin with a leading slash: "/123" will be
 * converted to the int 123.
 */
void ose_toInt32(ose_bundle B);

/**
 * @brief Cast a value to a 32-bit float.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The last element must not be empty.
 * 
 * @note One of the primary uses of this function is to
 * convert a string representation of a number found as part
 * of an OSC address into an integer. For that reason,
 * strings may begin with a leading slash: "/123" will be
 * converted to the int 123.
 */
void ose_toFloat(ose_bundle B);

/**
 * @brief Cast a value to a string.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The last element must not be empty.
 */
void ose_toString(ose_bundle B);

/**
 * @brief Cast a value to a blob.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The last element must not be empty.
 */
void ose_toBlob(ose_bundle B);


void ose_appendByte(ose_bundle B);
#ifdef OSE_PROVIDE_TYPE_SYMBOL
void ose_toSymbol(ose_bundle B);
#endif
#ifdef OSE_PROVIDE_TYPE_DOUBLE
void ose_toDouble(ose_bundle B);
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
void ose_toInt8(ose_bundle B);
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
void ose_toUInt8(ose_bundle B);
#endif
#ifdef OSE_PROVIDE_TYPE_INT16
void ose_toInt16(ose_bundle B);
#endif
#ifdef OSE_PROVIDE_TYPE_UINT16
void ose_toUInt16(ose_bundle B);
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
void ose_toUInt32(ose_bundle B);
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
void ose_toInt64(ose_bundle B);
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
void ose_toUInt64(ose_bundle B);
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
void ose_toTimetag(ose_bundle B);
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
void ose_toTrue(ose_bundle B);
#endif
#ifdef OSE_PROVIDE_TYPE_FALSE
void ose_toFalse(ose_bundle B);
#endif
#ifdef OSE_PROVIDE_TYPE_NULL
void ose_toNull(ose_bundle B);
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
void ose_toInfinitum(ose_bundle B);
#endif

/**
 * @brief Concatenate two blobs.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The last two items of the message must be blobs.
 *
 * @note This function does not include any NULL padding between
 * the blobs.
 */
void ose_concatenateBlobs(ose_bundle B);

/**
 * @brief Concatenate two strings.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The last two items of the message must be strings.
 * 
 * @note This function does not include any NULL padding between
 * the strings.
 *
 */
void ose_concatenateStrings(ose_bundle B);

/**
 * @brief Exchange the last string of a message with the address.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The last item of the message must be a string.
 */
void ose_swapStringToAddress(ose_bundle B);

/**
 * @brief Move the last string of a message to the address.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The last item of the message must be a string.
 */
void ose_moveStringToAddress(ose_bundle B);

void ose_decatenateBlobFromEnd_impl(ose_bundle B, int32_t n);
void ose_decatenateBlobFromEnd(ose_bundle B);
void ose_decatenateBlobFromStart_impl(ose_bundle B, int32_t n);
void ose_decatenateBlobFromStart(ose_bundle B);
void ose_decatenateStringFromEnd_impl(ose_bundle B, int32_t n);
void ose_decatenateStringFromEnd(ose_bundle B);
void ose_decatenateStringFromStart_impl(ose_bundle B, int32_t n);
void ose_decatenateStringFromStart(ose_bundle B);

/**
 * @brief Convert the last element into a blob.
 *
 * @pre `B` must not be empty.
 */
void ose_elemToBlob(ose_bundle B);

/**
 * @brief Convert the last item of the last element into a blob.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The message must not be empty.
 */
void ose_itemToBlob(ose_bundle B);

/**
 * @brief Join two strings with a separator (string) between them.
 *
 * @details Takes three messages, each with a single string,
 * and combines them into a single string. The separator is
 * the string in the last message.
 *
 * @pre `B` must contain at least three elements.
 * @pre The last three elements must be messages.
 * @pre The last three messages must each contain exactly one string.
 *
 * This function is equivalent to
 * \code{.c}
 * 	ose_swap(B);
 * 	ose_push(B);
 * 	ose_push(B);
 * 	ose_concatenateStrings(B);
 * 	ose_concatenateStrings(B);
 * \endcode
 */
void ose_joinStrings(ose_bundle B);
void ose_splitStringFromEnd(ose_bundle B);
void ose_splitStringFromStart(ose_bundle B);
void ose_swap4Bytes(ose_bundle B);
void ose_swap8Bytes(ose_bundle B);
void ose_swapNBytes(ose_bundle B);
void ose_trimStringEnd(ose_bundle B);
void ose_trimStringStart(ose_bundle B);

/** @} */ // Operations on Bundle Elements and Items

/**
 * @name Matching, Selecting, Routing, and Assignment
 * @{
 */

/**
 * @brief Compare two strings.
 *
 * @details Does a simple string comparison on the strings
 * contained in the last two messages. It leaves the last
 * two messages in place and creates a new message with a
 * single non-zero int if the strings are identical, or 0
 * otherwise.
 * 
 * @pre `B` must contain at least two elements.
 * @pre The last two elements must be messages.
 * @pre the last two messages must each contain exactly one
 * string.
 */
void ose_match(ose_bundle B);

/**
 * @brief Compare two strings using pattern matching.
 *
 * @details Performs a string comparison using pattern
 * matching on the strings contained in the last two
 * messages. The string in the last message is called the
 * _address_, and the string in the second to last message
 * is called the _pattern_. Only the pattern may contain
 * wildcards.
 *
 * Two new messages are created at the end of `B`, each of
 * which contains a single integer. The first will be
 * non-zero if the pattern was matched in its entirety, and
 * 0 otherwise, and the second will be non-zero if the
 * address was matched in its entirety and zero otherwise.
 *
 * The address is left untouched by the operation, but the
 * pattern is modified: the portion that matched is removed,
 * and the portion that is unmatched remains (which may be
 * an empty string).
 *
 * @pre `B` must contain at least two elements.
 * @pre The last two elements must be messages.
 * @pre the last two messages must each contain exactly one
 * string.
 */
void ose_pmatch(ose_bundle B);
void ose_replace(ose_bundle B);
void ose_assign(ose_bundle B);
void ose_lookup(ose_bundle B);
void ose_plookup(ose_bundle B);

/**
 * @brief Route messages in a bundle with patterns that match an
 * address.
 *
 * @details The last element is a message that contains a
 * string called the _address_. The second to last element
 * is a bundle that contains elements whose addresses are
 * _patterns_. The message is dropped, and all _patterns_
 * that match the _address_, fully or partially, are copied
 * into a newly created bundle. The portions of the patterns
 * that matched are stripped.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last element must be a message containing a single string.
 * @pre The second to last element must be a bundle.
 *
 * @see ose_routeWithDelegation
 * @see ose_select1
 * @see ose_selectWithDelegation
 * @see ose_gather
 */
void ose_route1(ose_bundle B);

/**
 * @brief Route all messages in a bundle with patterns that match
 * one or more addresses.
 *
 * @details The last element is a message containing one or
 * more strings called _addresses_. The second to last
 * element is a bundle that contains elements whose
 * addresses are _patterns_. Both elements are dropped, and
 * a new bundle created. The new bundle will consist of one
 * bundle for each address containing all elements from the
 * original bundle that matched that address, with the part
 * of their patterns that matched removed, and a final
 * bundle, the delegation bundle, that contains all elements
 * from the original bundle that did not match any of the
 * addresses.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last element must be a message containing one or more
 * strings.
 * @pre The second to last element must be a bundle.
 * 
 * @see ose_route1
 * @see ose_select1
 * @see ose_selectWithDelegation
 * @see ose_gather
 */
void ose_routeWithDelegation(ose_bundle B);

/**
 * @brief Select messages in a bundle with patterns that match an
 * address.
 *
 * @details The last element is a message that contains a
 * string called the _address_. The second to last element
 * is a bundle that contains elements whose addresses are
 * _patterns_. The message is dropped, and all _patterns_
 * that match the _address_, fully or partially, are copied
 * into a newly created bundle, unmodified. 
 *
 * @pre `B` must contain at least two elements.
 * @pre The last element must be a message containing a single string.
 * @pre The second to last element must be a bundle.
 *
 * @see ose_route1
 * @see ose_routeWithDelegation
 * @see ose_selectWithDelegation
 * @see ose_gather
 */
void ose_select1(ose_bundle B);

/**
 * @brief Route all messages in a bundle with patterns that match
 * one or more addresses.
 *
 * @details The last element is a message containing one or
 * more strings called _addresses_. The second to last
 * element is a bundle that contains elements whose
 * addresses are _patterns_. Both elements are dropped, and
 * a new bundle created. The new bundle will consist of one
 * bundle for each address containing all elements from the
 * original bundle that matched that address, unmodified,
 * and a final bundle, the delegation bundle, that contains
 * all elements from the original bundle that did not match
 * any of the addresses.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last element must be a message containing one or more
 * strings.
 * @pre The second to last element must be a bundle.
 * 
 * @see ose_select1
 * @see ose_route1
 * @see ose_routeWithDelegation
 * @see ose_gather
 */
void ose_selectWithDelegation(ose_bundle B);

/**
 * @brief Gather messages from a bundle that match one or
 * more strings.
 *
 * @details The last element must be a message containing one or
 * more strings, and the second to last element must be a
 * bundle. These two elements are removed, and each message in the
 * bundle that matches a string in the message is placed in a new
 * bundle. All messages that were unmatched are placed in a second
 * bundle.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last element must be a message containing one or more
 * strings.
 * @pre The second to last element must be a bundle.
 *
 * @see ose_route1
 * @see ose_routeWithDelegation
 * @see ose_select1
 * @see ose_selectWithDelegation
 */
void ose_gather(ose_bundle B);

/**
 * @brief Copy the nth item of an element.
 *
 * @details The last element must be a message with one or more
 * integers representing the positions of the items in the second to
 * last element to copy to the end of the bundle. The last element
 * will be removed. Indexes are 0-based counting from the beginning
 * of the element.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last element must be a message.
 * @pre The last element (message) must contain at least one item.
 * @pre All items of the last element (message) must be integers.
 * @pre All integer values in the last element (message)
 * must be in the range @f$[0,K-1]@f$, where @f$K@f$ is the
 * number of items in the second to last element.
 */
void ose_nth(ose_bundle B);

/** @} */ // Matching, Selecting, Routing, and Assignment

/**
 * @name Element and Item Creation
 * @{
 */

/**
 * @brief Create an empty blob of a given size.
 *
 * @details The last element, a message containing the size
 * of the blob to be created, will be removed, and a new
 * message containing a single blob of that size will be
 * created.
 *
 * @pre `B` must not be empty.
 * @pre The last element must be a message.
 * @pre The last element must contain a single non-negative integer.
 */
void ose_makeBlob(ose_bundle B);

/**
 * @brief Create an empty bundle.
 */
void ose_pushBundle(ose_bundle B);

/** @} */ // Element and Item Creation

/**
 * @name Arithmetic
 * @{
 */

/**
 * @brief Add the number in the last message to the number in the
 * previous message.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last two elements must be messages.
 * @pre The last two elements must each contain exactly one
 * numerical value.
 * @pre The items that the last two elements contain must be
 * of the same type as each other.
 */
void ose_add(ose_bundle B);

/**
 * @brief Subtract the number in the second to last message from the
 * number in the last message.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last two elements must be messages.
 * @pre The last two elements must each contain exactly one
 * numerical value.
 * @pre The items that the last two elements contain must be
 * of the same type as each other.
 */
void ose_sub(ose_bundle B);

/**
 * @brief Multiply the number in the last message by the number in the
 * previous message.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last two elements must be messages.
 * @pre The last two elements must each contain exactly one
 * numerical value.
 * @pre The items that the last two elements contain must be
 * of the same type as each other.
 */
void ose_mul(ose_bundle B);

/**
 * @brief Divide the number in the second to last message by the
 * number in the last message.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last two elements must be messages.
 * @pre The last two elements must each contain exactly one
 * numerical value.
 * @pre The items that the last two elements contain must be
 * of the same type as each other.
 */
void ose_div(ose_bundle B);

/**
 * @brief Take the number in the last message modulo the number in
 * the second to last message.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last two elements must be messages.
 * @pre The last two elements must each contain exactly one
 * numerical value.
 * @pre The items that the last two elements contain must be
 * of the same type as each other.
 */
void ose_mod(ose_bundle B);

/**
 * @brief Raise the number in the last message to the power of the
 * number in the second to last message.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last two elements must be messages.
 * @pre The last two elements must each contain exactly one
 * numerical value.
 * @pre The items that the last two elements contain must be
 * of the same type as each other.
 */
void ose_pow(ose_bundle B);

/**
 * @brief Flip the sign of the number in the last message of
 * the bundle.
 *
 * @pre `B` must contain at least one element.
 * @pre The last element must be a message.
 * @pre The last element must contain exactly one numerical value.
 */
void ose_neg(ose_bundle B);

/**
 * @brief Compare the numbers in the last two messages for equality.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last two elements must be messages.
 *
 * @note This is a test for equality of all bits from the typetag
 * string through the payload, so, for example, two equivalent
 * values of different types, say the int 10 and the float 10.0 are
 * not considered equal.
 */
void ose_eql(ose_bundle B);

/**
 * @brief Compare the numbers in the last two messages for
 * non equality.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last two elements must be messages.
 *
 * @note This is a test for equality of all bits from the typetag
 * string through the payload, so, for example, two equivalent
 * values of different types, say the int 10 and the float 10.0 are
 * not considered equal.
 */
void ose_neq(ose_bundle B);

/**
 * @brief Test whether the number in the last message is less than
 * or equal to the number in the second to last message.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last two elements must be messages.
 * @pre The last two elements must each contain exactly one
 * numerical value.
 * @pre The items that the last two elements contain must be
 * of the same type as each other.
 */
void ose_lte(ose_bundle B);

/**
 * @brief Test whether the number in the last message is less than
 * to the number in the second to last message.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last two elements must be messages.
 * @pre The last two elements must each contain exactly one
 * numerical value.
 * @pre The items that the last two elements contain must be
 * of the same type as each other.
 */
void ose_lt(ose_bundle B);

/**
 * @brief Test whether the numbers in the last two messages are both
 * non-zero.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last two elements must be messages.
 * @pre The last two elements must each contain exactly one
 * numerical value.
 * @pre The items that the last two elements contain must be
 * of the same type as each other.
 */
void ose_and(ose_bundle B);

/**
 * @brief Test whether at least one of the numbers in the last two
 * messages is non-zero.
 *
 * @pre `B` must contain at least two elements.
 * @pre The last two elements must be messages.
 * @pre The last two elements must each contain exactly one
 * numerical value.
 * @pre The items that the last two elements contain must be
 * of the same type as each other.
 */
void ose_or(ose_bundle B);

/** @} */ // Arithmetic

#ifdef __cplusplus
}
#endif

#endif
