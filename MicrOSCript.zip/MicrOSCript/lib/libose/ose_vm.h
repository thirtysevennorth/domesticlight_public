/*
  Copyright (c) 2019-23 John MacCallum Permission is hereby granted,
  free of charge, to any person obtaining a copy of this software
  and associated documentation files (the "Software"), to deal in
  the Software without restriction, including without limitation the
  rights to use, copy, modify, merge, publish, distribute,
  sublicense, and/or sell copies of the Software, and to permit
  persons to whom the Software is furnished to do so, subject to the
  following conditions:

  The above copyright notice and this permission notice shall be
  included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
  DEALINGS IN THE SOFTWARE.
*/

/**
 * @file ose_vm.h
 *
 * @brief the OSE virtual machine
 */

#ifndef OSE_VM_H
#define OSE_VM_H

#include "ose_context.h"
#include "osevm_lib.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @name Built-in Addresses
 * @{
 */
#define OSEVM_ADDR_INPUT 	"/_i"
#define OSEVM_ADDR_STACK 	"/_s"
#define OSEVM_ADDR_ENV 		"/_e"
#define OSEVM_ADDR_CONTROL 	"/_c"
#define OSEVM_ADDR_DUMP 	"/_d"
#define OSEVM_ADDR_STDLIB 	"/_l"
#define OSEVM_ADDR_HOST 	"/_x"
#define OSEVM_ADDR_CACHE    "/_0"
/** @} */ // Built-in Addresses

/**
 * @name Cache Offsets
 * @{
 */
/* number of 32-bit ints available in the cache message */
#define OSEVM_CACHE_SIZE 30
#define OSEVM_CACHE_MSG_SIZE OSE_CONTEXT_MESSAGE_OVERHEAD	\
	+ 4 + 4 + 32 + (OSEVM_CACHE_SIZE * 4)
#define OSEVM_CACHE_OFFSET_0 OSE_BUNDLE_HEADER_LEN	\
	+ OSE_CONTEXT_BUNDLE_OFFSET			\
	+ OSE_BUNDLE_HEADER_LEN				\
	+ 4 + 4 + 32 /* size, address, typetags */
#define OSEVM_CACHE_OFFSET_1 	OSEVM_CACHE_OFFSET_0 + 4
#define OSEVM_CACHE_OFFSET_2 	OSEVM_CACHE_OFFSET_1 + 4
#define OSEVM_CACHE_OFFSET_3 	OSEVM_CACHE_OFFSET_2 + 4
#define OSEVM_CACHE_OFFSET_4 	OSEVM_CACHE_OFFSET_3 + 4
#define OSEVM_CACHE_OFFSET_5 	OSEVM_CACHE_OFFSET_4 + 4
#define OSEVM_CACHE_OFFSET_6 	OSEVM_CACHE_OFFSET_5 + 4
#define OSEVM_CACHE_OFFSET_7 	OSEVM_CACHE_OFFSET_6 + 4
#define OSEVM_CACHE_OFFSET_8 	OSEVM_CACHE_OFFSET_7 + 4
#define OSEVM_CACHE_OFFSET_9 	OSEVM_CACHE_OFFSET_8 + 4
#define OSEVM_CACHE_OFFSET_10 	OSEVM_CACHE_OFFSET_9 + 4
#define OSEVM_CACHE_OFFSET_11 	OSEVM_CACHE_OFFSET_10 + 4
#define OSEVM_CACHE_OFFSET_12 	OSEVM_CACHE_OFFSET_11 + 4
#define OSEVM_CACHE_OFFSET_13 	OSEVM_CACHE_OFFSET_12 + 4
#define OSEVM_CACHE_OFFSET_14 	OSEVM_CACHE_OFFSET_13 + 4
#define OSEVM_CACHE_OFFSET_15 	OSEVM_CACHE_OFFSET_14 + 4

#define OSEVM_CACHE_POINTER 		OSEVM_CACHE_OFFSET_0
#define OSEVM_CACHE_FLAGS 			OSEVM_CACHE_OFFSET_1
#define OSEVM_CACHE_OFFSET_INPUT 	OSEVM_CACHE_OFFSET_2
#define OSEVM_CACHE_OFFSET_STACK 	OSEVM_CACHE_OFFSET_3
#define OSEVM_CACHE_OFFSET_ENV 		OSEVM_CACHE_OFFSET_4
#define OSEVM_CACHE_OFFSET_CONTROL 	OSEVM_CACHE_OFFSET_5
#define OSEVM_CACHE_OFFSET_DUMP 	OSEVM_CACHE_OFFSET_6
/** @} */ // Cache Offsets

#ifdef OSEVM_HAVE_SIZES

/**
 * @name VM Bundle Offsets
 * @{
 */
#define OSEVM_INPUT_CONTEXT_MESSAGE_OFFSET          \
    OSE_BUNDLE_HEADER_LEN + OSEVM_CACHE_MSG_SIZE
#define OSEVM_INPUT_BUNDLE_OFFSET                                   \
    OSEVM_INPUT_CONTEXT_MESSAGE_OFFSET + OSE_CONTEXT_BUNDLE_OFFSET

#define OSEVM_STACK_CONTEXT_MESSAGE_OFFSET              \
    OSEVM_INPUT_CONTEXT_MESSAGE_OFFSET                  \
    + OSE_CONTEXT_MESSAGE_OVERHEAD + OSEVM_INPUT_SIZE
#define OSEVM_STACK_BUNDLE_OFFSET                                   \
    OSEVM_STACK_CONTEXT_MESSAGE_OFFSET + OSE_CONTEXT_BUNDLE_OFFSET

#define OSEVM_ENV_CONTEXT_MESSAGE_OFFSET                \
    OSEVM_STACK_CONTEXT_MESSAGE_OFFSET                  \
	+ OSE_CONTEXT_MESSAGE_OVERHEAD + OSEVM_STACK_SIZE
#define OSEVM_ENV_BUNDLE_OFFSET                                     \
    OSEVM_ENV_CONTEXT_MESSAGE_OFFSET + OSE_CONTEXT_BUNDLE_OFFSET

#define OSEVM_CONTROL_CONTEXT_MESSAGE_OFFSET        \
    OSEVM_ENV_CONTEXT_MESSAGE_OFFSET                \
	+ OSE_CONTEXT_MESSAGE_OVERHEAD + OSEVM_ENV_SIZE
#define OSEVM_CONTROL_BUNDLE_OFFSET                                     \
    OSEVM_CONTROL_CONTEXT_MESSAGE_OFFSET + OSE_CONTEXT_BUNDLE_OFFSET

#define OSEVM_DUMP_CONTEXT_MESSAGE_OFFSET               \
    OSEVM_CONTROL_CONTEXT_MESSAGE_OFFSET                \
	+ OSE_CONTEXT_MESSAGE_OVERHEAD + OSEVM_CONTROL_SIZE
#define OSEVM_DUMP_BUNDLE_OFFSET                                    \
    OSEVM_DUMP_CONTEXT_MESSAGE_OFFSET + OSE_CONTEXT_BUNDLE_OFFSET
/** @} */ // VM Bundle Offsets

/**
 * @name Components of the VM
 * @{
 */

/**
 * @brief Get the input bundle.
 */
#define OSEVM_INPUT(osevm)                      \
    ose_makeBundle(ose_getBundlePtr(osevm)      \
                   + OSEVM_INPUT_BUNDLE_OFFSET)
/**
 * @brief Get the stack bundle.
 */
#define OSEVM_STACK(osevm)                      \
    ose_makeBundle(ose_getBundlePtr(osevm)      \
                   + OSEVM_STACK_BUNDLE_OFFSET)
/**
 * @brief Get the environment bundle.
 */
#define OSEVM_ENV(osevm)                        \
    ose_makeBundle(ose_getBundlePtr(osevm)      \
                   + OSEVM_ENV_BUNDLE_OFFSET)
/**
 * @brief Get the control bundle.
 */
#define OSEVM_CONTROL(osevm)                        \
    ose_makeBundle(ose_getBundlePtr(osevm)          \
                   + OSEVM_CONTROL_BUNDLE_OFFSET)
/**
 * @brief Get the dump bundle.
 */
#define OSEVM_DUMP(osevm)                       \
    ose_makeBundle(ose_getBundlePtr(osevm)      \
                   + OSEVM_DUMP_BUNDLE_OFFSET)
/** @} */ // Components of the VM

/**
 * @brief Initialize the VM.
 *
 * @param bundle an OSE bundle created with #ose_newBundleFromCBytes
 * @returns an OSE bundle initialized as a VM
 *
 * @pre `bundle` must have been created with ose_newBundleFromCBytes.
 *
 * @note This version of the function is available when the sizes
 * of the component bundles of the VM have been defined at
 * compile-time.
 */
ose_bundle osevm_init(ose_bundle bundle);

#else

#define OSEVM_INPUT(osevm)                                      \
    ose_makeBundle(ose_getBundlePtr(osevm)                      \
                   + ose_readInt32(osevm,                       \
                                   OSEVM_CACHE_OFFSET_INPUT))
#define OSEVM_STACK(osevm)                                      \
    ose_makeBundle(ose_getBundlePtr(osevm)                      \
                   + ose_readInt32(osevm,                       \
                                   OSEVM_CACHE_OFFSET_STACK))
#define OSEVM_ENV(osevm)                                    \
    ose_makeBundle(ose_getBundlePtr(osevm)                  \
                   + ose_readInt32(osevm,                   \
                                   OSEVM_CACHE_OFFSET_ENV))
#define OSEVM_CONTROL(osevm)                                    \
    ose_makeBundle(ose_getBundlePtr(osevm)                      \
                   + ose_readInt32(osevm,                       \
                                   OSEVM_CACHE_OFFSET_CONTROL))
#define OSEVM_DUMP(osevm)                                       \
    ose_makeBundle(ose_getBundlePtr(osevm)                      \
                   + ose_readInt32(osevm,                       \
                                   OSEVM_CACHE_OFFSET_DUMP))

ose_bundle osevm_init(ose_bundle bundle,
                      int32_t input_size,
                      int32_t stack_size,
                      int32_t env_size,
                      int32_t control_size,
                      int32_t dump_size);
#endif

/**
 * @name Cache Getters and Setters
 * @{
 */
#define OSEVM_GET_FLAGS(osevm)                  \
    ose_readInt32(osevm, OSEVM_CACHE_FLAGS)
#define OSEVM_SET_FLAGS(osevm, flags)               \
	ose_writeInt32(osevm, OSEVM_CACHE_FLAGS, flags)

#define OSEVM_GET_CACHE_VALUE(osevm, idx)                       \
	(ose_assert((idx) < OSEVM_CACHE_SIZE),                      \
	 ose_readInt32(osevm, OSEVM_CACHE_OFFSET_0 + (4 * (idx))))
#define OSEVM_SET_CACHE_VALUE(osevm, idx, val)                          \
	(ose_assert((idx) < OSEVM_CACHE_SIZE),                              \
	 ose_writeInt32(osevm, OSEVM_CACHE_OFFSET_0 + (4 * (idx)), val))
/** @} */ // Cache Getters and Setters

/************************************************************
 * Hooks
 ************************************************************/
/**
 * @name Hooks
 * @{
 */
#ifndef OSEVM_ASSIGN
#define OSEVM_ASSIGN osevm_assignStackToEnv
#else
extern void OSEVM_ASSIGN (ose_bundle osevm);
#endif

#ifndef OSEVM_LOOKUP
#define OSEVM_LOOKUP osevm_lookupInEnv_impl
#else
extern void OSEVM_LOOKUP (ose_bundle osevm);
#endif

#ifndef OSEVM_FUNCALL
#define OSEVM_FUNCALL osevm_funcall
#else
extern void OSEVM_FUNCALL (ose_bundle osevm);
#endif

#ifndef OSEVM_QUOTE
#define OSEVM_QUOTE osevm_quote
#else
extern void OSEVM_QUOTE (ose_bundle osevm);
#endif

#ifndef OSEVM_COPYREGISTERTOELEM
#define OSEVM_COPYREGISTERTOELEM osevm_copyRegisterToElem
#else
extern void OSEVM_COPYREGISTERTOELEM (ose_bundle osevm);
#endif

#ifndef OSEVM_APPENDELEMTOREGISTER
#define OSEVM_APPENDELEMTOREGISTER osevm_appendElemToRegister
#else
extern void OSEVM_APPENDELEMTOREGISTER (ose_bundle osevm);
#endif

#ifndef OSEVM_REPLACEREGISTERWITHELEM
#define OSEVM_REPLACEREGISTERWITHELEM osevm_replaceRegisterWithElem
#else
extern void OSEVM_REPLACEREGISTERWITHELEM (ose_bundle osevm);
#endif

#ifndef OSEVM_MOVEELEMTOREGISTER
#define OSEVM_MOVEELEMTOREGISTER osevm_moveElemToRegister
#else
extern void OSEVM_MOVEELEMTOREGISTER (ose_bundle osevm);
#endif

#ifndef OSEVM_TOTYPE
#define OSEVM_TOTYPE osevm_toType
#else
extern void OSEVM_TOTYPE (ose_bundle osevm);
#endif

#ifndef OSEVM_TOINT32
#define OSEVM_TOINT32 osevm_toInt32
#else
extern void OSEVM_TOINT32 (ose_bundle osevm);
#endif

#ifndef OSEVM_TOFLOAT
#define OSEVM_TOFLOAT osevm_toFloat
#else
extern void OSEVM_TOFLOAT (ose_bundle osevm);
#endif

#ifndef OSEVM_TOSTRING
#define OSEVM_TOSTRING osevm_toString
#else
extern void OSEVM_TOSTRING (ose_bundle osevm);
#endif

#ifndef OSEVM_TOBLOB
#define OSEVM_TOBLOB osevm_toBlob
#else
extern void OSEVM_TOBLOB (ose_bundle osevm);
#endif

#ifdef OSE_PROVIDE_TYPE_SYMBOL
#ifndef OSEVM_TOSYMBOL
#define OSEVM_TOSYMBOL osevm_toSymbol
#else
extern void OSEVM_TOSYMBOL (ose_bundle osevm);
#endif
#endif

#ifdef OSE_PROVIDE_TYPE_DOUBLE
#ifndef OSEVM_TODOUBLE
#define OSEVM_TODOUBLE osevm_toDouble
#else
extern void OSEVM_TODOUBLE (ose_bundle osevm);
#endif
#endif

#ifdef OSE_PROVIDE_TYPE_INT8
#ifndef OSEVM_TOINT8
#define OSEVM_TOINT8 osevm_toInt8
#else
extern void OSEVM_TOINT8 (ose_bundle osevm);
#endif
#endif

#ifdef OSE_PROVIDE_TYPE_UINT8
#ifndef OSEVM_TOUINT8
#define OSEVM_TOUINT8 osevm_toUInt8
#else
extern void OSEVM_TOUINT8 (ose_bundle osevm);
#endif
#endif

#ifdef OSE_PROVIDE_TYPE_INT16
#ifndef OSEVM_TOINT16
#define OSEVM_TOINT16 osevm_toInt16
#else
extern void OSEVM_TOINT16 (ose_bundle osevm);
#endif
#endif

#ifdef OSE_PROVIDE_TYPE_UINT16
#ifndef OSEVM_TOUINT16
#define OSEVM_TOUINT16 osevm_toUInt16
#else
extern void OSEVM_TOUINT16 (ose_bundle osevm);
#endif
#endif

#ifdef OSE_PROVIDE_TYPE_UINT32
#ifndef OSEVM_TOUINT32
#define OSEVM_TOUINT32 osevm_toUInt32
#else
extern void OSEVM_TOUINT32 (ose_bundle osevm);
#endif
#endif

#ifdef OSE_PROVIDE_TYPE_INT64
#ifndef OSEVM_TOINT64
#define OSEVM_TOINT64 osevm_toInt64
#else
extern void OSEVM_TOINT64 (ose_bundle osevm);
#endif
#endif

#ifdef OSE_PROVIDE_TYPE_UINT64
#ifndef OSEVM_TOUINT64
#define OSEVM_TOUINT64 osevm_toUInt64
#else
extern void OSEVM_TOUINT64 (ose_bundle osevm);
#endif
#endif

#ifdef OSE_PROVIDE_TYPE_TIMETAG
#ifndef OSEVM_TOTIMETAG
#define OSEVM_TOTIMETAG osevm_toTimetag
#else
extern void OSEVM_TOTIMETAG (ose_bundle osevm);
#endif
#endif

#ifdef OSE_PROVIDE_TYPE_TRUE
#ifndef OSEVM_TOTRUE
#define OSEVM_TOTRUE osevm_toTrue
#else
extern void OSEVM_TOTRUE (ose_bundle osevm);
#endif
#endif

#ifdef OSE_PROVIDE_TYPE_FALSE
#ifndef OSEVM_TOFALSE
#define OSEVM_TOFALSE osevm_toFalse
#else
extern void OSEVM_TOFALSE (ose_bundle osevm);
#endif
#endif

#ifdef OSE_PROVIDE_TYPE_NULL
#ifndef OSEVM_TONULL
#define OSEVM_TONULL osevm_toNull
#else
extern void OSEVM_TONULL (ose_bundle osevm);
#endif
#endif

#ifdef OSE_PROVIDE_TYPE_INFINITUM
#ifndef OSEVM_TOINFINITUM
#define OSEVM_TOINFINITUM osevm_toInfinitum
#else
extern void OSEVM_TOINFINITUM (ose_bundle osevm);
#endif
#endif

#ifndef OSEVM_APPENDBYTE
#define OSEVM_APPENDBYTE osevm_appendByte
#else
extern void OSEVM_APPENDBYTE (ose_bundle osevm);
#endif

void osevm_respondToString(ose_bundle osevm);
#ifndef OSEVM_RESPONDTOSTRING
#define OSEVM_RESPONDTOSTRING osevm_respondToString
#else
extern void OSEVM_RESPONDTOSTRING (ose_bundle osevm);
#endif

void osevm_preInput(ose_bundle osevm);
#ifndef OSEVM_PREINPUT
#define OSEVM_PREINPUT osevm_preInput
#else
extern void OSEVM_PREINPUT (ose_bundle osevm);
#endif

void osevm_postInput(ose_bundle osevm);
#ifndef OSEVM_POSTINPUT
#define OSEVM_POSTINPUT osevm_postInput
#else
extern void OSEVM_POSTINPUT (ose_bundle osevm);
#endif

void osevm_popInputToControl(ose_bundle osevm);
#ifndef OSEVM_POPINPUTTOCONTROL
#define OSEVM_POPINPUTTOCONTROL osevm_popInputToControl
#else
extern void OSEVM_POPINPUTTOCONTROL (ose_bundle osevm);
#endif

void osevm_postControl(ose_bundle osevm);
#ifndef OSEVM_POSTCONTROL
#define OSEVM_POSTCONTROL osevm_postControl
#else
extern void OSEVM_POSTCONTROL (ose_bundle osevm);
#endif

#define OSEVM_EVALTYPE_ADDR "/type/%c/evalType"
#define OSEVM_EVALTYPE_ADDR_LEN sizeof(OSEVM_EVALTYPE_ADDR)
void osevm_evalType(ose_bundle osevm);
#ifndef OSEVM_EVALTYPE
#define OSEVM_EVALTYPE osevm_evalType
#else
extern void OSEVM_EVALTYPE (ose_bundle osevm);
#endif

int32_t osevm_callTypeHook(ose_bundle bundle,
                           const char typetag,
                           const int32_t msg_offset,
                           const int32_t item_offset,
                           const int32_t addrlen,
                           const char * const addr);

int32_t osevm_getPayloadItemLength_hook(ose_bundle bundle,
                                        const char typetag,
                                        const int32_t msg_offset,
                                        const int32_t item_offset);

int32_t osevm_getPayloadItemSize_hook(ose_bundle bundle,
                                      const char typetag,
                                      const int32_t msg_offset,
                                      const int32_t item_offset);

int32_t osevm_pprintPayloadItem_hook(ose_bundle bundle,
                                     const char typetag,
                                     const int32_t msg_offset,
                                     const int32_t item_offset);
/** @} */ // Hooks

/**
 * @brief Copy the contents of an OSC bundle into the input bundle
 * of the VM.
 *
 * @details This function copies the elements contained in `bundle`
 * into the input bundle of `osevm`. Since the VM processes input
 * elements backwards, i.e. starting with the last element, this
 * function _reverses the order_ of the elements contained in
 * `bundle`.
 *
 * @param osevm the VM
 * @param size the size in bytes of `bundle`
 * @param bundle an OSC bundle containing the messages to copy to
 * the input
 */
void osevm_inputMessages(ose_bundle osevm,
			 int32_t size, const char * const bundle);

/**
 * @brief Copy a single OSC element into the input bundle of the VM.
 *
 * @param osevm the VM
 * @param size the size in bytes of `message`
 * @param message the message to copy
 */
void osevm_inputMessage(ose_bundle osevm,
			int32_t size, const char * const message);

/**
 * @brief Run the VM.
 *
 * @details This function runs the VM until every element of the
 * input bundle has been processed and it is empty.
 * 
 * @param bundle the VM
 */
void osevm_run(ose_bundle bundle);

/**
 * @brief Step the VM.
 *
 * @details This function executes a single step of the VM,
 * returning a value indicating whether it has more steps to perform
 * or not.
 *
 * @param osevm the VM
 * @retval #OSETT_TRUE if there are more steps to perform
 * @retval #OSETT_FALSE if the input has been fully processed
 */
char osevm_step(ose_bundle osevm);
#ifdef OSEVM_HAVE_SIZES
/**
 * @brief Compute the size requirements of the VM given a list of
 * sizes of each of additional VM bundle to be created at runtime.
 *
 * @details This function will compute the total size requirements
 * of the VM that can be used to allocate sufficient memory. The
 * list of sizes here is a list of sizes _in addition_ to those that
 * the VM creates (the input, stack, environment, etc). 
 *
 * @param n the number of additional bundle sizes
 * @param ... a list of additional bundle sizes
 */
int32_t osevm_computeSizeReqs(int n, ...);
#else
int32_t osevm_computeSizeReqs(int32_t input_size,
			      int32_t stack_size,
			      int32_t env_size,
			      int32_t control_size,
			      int32_t dump_size,
			      int n, ...);
#endif

#ifdef __cplusplus
}
#endif

#endif
