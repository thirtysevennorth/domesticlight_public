/*
  Copyright (c) 2019-23 John MacCallum Permission is hereby granted,
  free of charge, to any person obtaining a copy of this software
  and associated documentation files (the "Software"), to deal in
  the Software without restriction, including without limitation the
  rights to use, copy, modify, merge, publish, distribute,
  sublicense, and/or sell copies of the Software, and to permit
  persons to whom the Software is furnished to do so, subject to the
  following conditions:

  The above copyright notice and this permission notice shall be
  included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
  DEALINGS IN THE SOFTWARE.
*/

/**
 * @file ose_util.h
 * 
 * @brief contains basic utilities for reading, writing, and
 * querying an OSC bundle
 *
 * @details
 *
 * The satisfaction of the preconditions stated in the documentation
 * is the responsibility of the caller, and result in undefined
 * behavior if they are not met.
 */

#ifndef OSE_UTIL_H
#define OSE_UTIL_H

#ifdef __cplusplus
extern "C" {
#endif

#include <inttypes.h>
#include <stdarg.h>
#include "ose.h"

/**
 * @brief Pad a number of bytes to the nearest multiple of 4.
 *
 * @details This function is suitable to pad OSC strings, as it will
 * handle an empty string correctly by returning a pading of 4
 * bytes. It is not suitable for calculating the size of a blob,
 * however, #ose_getBlobPaddingForNBytes should be used instead.
 *
 * @param n number of bytes to pad
 * @returns the closest multiple of 4 greater than n
 *
 * @see ose_getBlobPaddingForNBytes
 */
#define ose_pnbytes(n) (((n) + 4) & 0xfffffffc)

/**
 * @brief Get the padded length of a string.
 *
 * @param s string to compute the length of
 * @returns the length of `s` padded to a multiple of 4 bytes
 *
 * @note A string of length 0 will be padded to a length of 4 bytes.
 */
int32_t ose_pstrlen(const char * const s);

/**
 * @brief Determine whether a given character is a valid OSC
 * address character.
 *
 * @param c the character to check
 * @retval #true
 * @retval #false
 */
bool ose_isAddressChar(char c);

/**
 * @brief Determine whether a given character is a typetag
 * known to the system.
 *
 * @param typetag the character to check
 * @retval #true
 * @retval #false
 */
bool ose_isKnownTypetag(char typetag);

/**
 * @brief Determine whether a given character is a string type.
 *
 * @param typetag the character to check
 * @retval #true
 * @retval #false
 */
bool ose_isStringType(char typetag);

/**
 * @brief Determine whether a given character is an integer type.
 *
 * @param typetag the character to check
 * @retval #true
 * @retval #false
 */
bool ose_isIntegerType(char typetag);

/**
 * @brief Determine whether a given character is a floating
 * point type.
 *
 * @param typetag the character to check
 * @retval #true
 * @retval #false
 */
bool ose_isFloatType(char typetag);

/**
 * @brief Determine whether a given character is a numeric type.
 *
 * @param typetag the character to check
 * @retval #true
 * @retval #false
 */
bool ose_isNumericType(char typetag);

/**
 * @brief Determine whether a given character is a unit type.
 *
 * @details A unit type is a type that can only take on one
 * value, such as #OSETT_TRUE, #OSETT_FALSE, #OSETT_NULL,
 * and #OSETT_INFINITUM. These types have no data allocated
 * in the data section of an OSC message.
 *
 * @param typetag the character to check
 * @retval #true
 * @retval #false
 */
bool ose_isUnitType(char typetag);

/**
 * @brief Determine whether a given character is either
 * #OSETT_TRUE or #OSETT_FALSE.
 *
 * @param typetag the character to check
 * @retval #true
 * @retval #false
 */
bool ose_isBoolType(char typetag);

/**
 * @brief Determine whether the data pointed to contains a bundle
 * or not.
 *
 * @param B the bundle
 * @retval #true
 * @retval #false
 */
bool ose_isBundle(ose_constbundle B);

/**
 * @brief Determine whether a bundle contains any elements.
 *
 * @param B the bundle
 * @retval #true
 * @retval #false
 *
 * @pre `B` or its underlying pointer must not be NULL.
 */
bool ose_bundleIsEmpty(ose_constbundle B);

/**
 * @brief Get the number of elements in a bundle.
 *
 * @param B the bundle
 * @returns the number of elements in `B`
 *
 * @pre `B` or its underlying pointer must not be NULL.
 */
int32_t ose_getBundleElemCount(ose_constbundle B);

/**
 * @brief Get the number of items in a bundle element.
 *
 * @param B the bundle
 * @param offset the offset of the bundle element in bytes
 * from the beginning of `B`
 * @returns the number of items in the bundle element
 *
 * @pre `B` must not be empty.
 * @pre `offset` must point to a valid bundle element in `B`.
 */
int32_t ose_getBundleElemElemCount(ose_constbundle B,
                                   int32_t offset);

/**
 * @brief Determine whether a bundle has a minimum number of
 * elements.
 *
 * @param B the bundle
 * @param n the minimum number of elements
 * @retval #true
 * @retval #false
 *
 * @pre `n` must be non-zero.
 */
bool ose_bundleHasAtLeastNElems(ose_constbundle B,
                                int32_t n);

/**
 * @brief Get the type of a bundle element.
 *
 * @param B the bundle
 * @param offset the offset of the bundle element in bytes
 * from the beginning of `B`
 * @retval #OSETT_MESSAGE if the element is a message
 * @retval #OSETT_BUNDLE if the element is a bundle
 *
 * @pre `B` must not be empty.
 * @pre `offset` must point to a valid bundle element in `B`.
 */
char ose_getBundleElemType(ose_constbundle B, int32_t offset);

/* 
   The following read/write functions are normally defined
   as macros that simply read or write a value at an
   offset. For debugging purposes, a function is generated
   that contains a number of assertions to catch cases where
   the functions are being called with bogus arguments.
*/
#ifdef OSE_DEBUG
char ose_readByte(ose_constbundle B, int32_t offset);
int32_t ose_writeByte(ose_bundle B, int32_t offset, char i);
#else

/**
 * @brief Read a byte at an offset.
 *
 * @param b the bundle
 * @param o the offset
 * @returns the value
 *
 * @pre `b` or its underlying pointer must not be NULL.
 * @pre `o` must be within `b`.
 */
#define ose_readByte(b, o) (ose_getBundlePtr(b)[o])

/**
 * @brief Write a byte at an offset.
 *
 * @param b the bundle
 * @param o the offset
 * @param v the value to write
 * @returns the number of bytes written
 *
 * @pre `b` or its underlying pointer must not be NULL.
 * @pre `o` must be within `b`.
 */
#define ose_writeByte(b, o, v) (ose_getBundlePtr(b)[o] = v, 1)
#endif

#ifdef OSE_DEBUG
int32_t ose_readInt32(ose_constbundle B, int32_t offset);
int32_t ose_writeInt32(ose_bundle B, int32_t offset, int32_t i);
#else

/**
 * @brief Read a 32-bit int at an offset.
 * 
 * @param b the bundle
 * @param o the offset
 * @returns the value
 *
 * @pre `b` or its underlying pointer must not be NULL.
 * @pre `o` must be within `b`.
 * @pre `o + 4` must be within `b`.
 */
#define ose_readInt32(b, o)                                 \
    (ose_ntohl(*((int32_t *)(ose_getBundlePtr(b) + o))))

/**
 * @brief Write a 32-bit int at an offset.
 * 
 * @param b the bundle
 * @param o the offset
 * @param v the value to write
 * @returns the number of bytes written
 *
 * @pre `b` or its underlying pointer must not be NULL.
 * @pre `o` must be within `b`.
 * @pre `o + 4` must be within `b`.
 */
#define ose_writeInt32(b, o, v)                                 \
    (*((int32_t *)(ose_getBundlePtr(b) + o)) = ose_htonl(v), 4)
#endif

/**
 * @brief Read a 32-bit float at an offset.
 * 
 * @param B the bundle
 * @param offset the offset
 * @returns the value
 *
 * @pre `B` or its underlying pointer must not be NULL.
 * @pre `offset` must be within `B`.
 * @pre `offset + 4` must be within `B`.
 */
float ose_readFloat(ose_constbundle B, int32_t offset);

/**
 * @brief Write a 32-bit float at an offset.
 * 
 * @param B the bundle
 * @param offset the offset
 * @param f the value to write
 * @returns the number of bytes written
 *
 * @pre `B` or its underlying pointer must not be NULL.
 * @pre `offset` must be within `B`.
 * @pre `offset + 4` must be within `B`.
 */
int32_t ose_writeFloat(ose_bundle B, int32_t offset, float f);

/* read/write string */
#ifdef OSE_DEBUG
const char *ose_readString(ose_bundle B, int32_t offset);
int32_t ose_getStringLen(ose_constbundle B, int32_t offset);
int32_t ose_getPaddedStringLen(ose_constbundle B,
                               int32_t offset);
int32_t ose_writeString(ose_bundle B,
                        int32_t offset,
                        const char * const s,
                        int32_t slen,
                        int32_t slen_padded);
#else

/**
 * @brief Read a string at an offset.
 *
 * @param b the bundle
 * @param o the offset
 * @returns a pointer to the string
 *
 * @pre `b` or its underlying pointer must not be NULL.
 * @pre `o` must be within `b`.
 *
 * @note The string is not copied and must not be altered,
 * unless you know what you are doing.
 */
#define ose_readString(b, o) (ose_getBundlePtr(b) + o)

/**
 * @brief Get the length of a string at an offset.
 *
 * @param b the bundle
 * @param o the offset
 * @returns the length of the string not including the NULL byte
 *
 * @pre `b` or its underlying pointer must not be NULL.
 * @pre `o` must be within `b`.
 * @pre `o` must point to a NULL-terminated string.
 */
#define ose_getStringLen(b, o) (strlen(ose_getBundlePtr(b) + o))

/**
 * @brief Get the padded length of a string at an offset.
 * 
 * @param b the bundle
 * @param o the offset
 * @returns the length of the string including the NULL byte
 * and any additional padding
 *
 * @pre `b` or its underlying pointer must not be NULL.
 * @pre `o` must be within `b`.
 * @pre `o` must point to a NULL-terminated string.
 */
#define ose_getPaddedStringLen(b, o)            \
    (ose_pstrlen(ose_getBundlePtr(b) + o))

/**
 * @brief Read a byte at an offset.
 *
 * @param b the bundle
 * @param o the offset
 * @param s the string
 * @param slen the string length in bytes, not including the
 * NULL byte or any padding
 * @param slen_padded the string length in bytes including
 * NULL padding to a multiple of 4 bytes (see #ose_pstrlen)
 *
 * @pre `b` or its underlying pointer must not be NULL.
 * @pre `o` must be within `b`.
 * @pre `s` must not be NULL.
 * @pre `slen` must be non-negative.
 * @pre `slen_padded` must be greater than `slen`.
 */
#define ose_writeString(b, o, s, slen, slen_padded)         \
    (memcpy(ose_getBundlePtr(b) + o, s, slen), slen_padded)
#endif

/* read/write blob */
#ifdef OSE_DEBUG
const char *ose_readBlob(ose_bundle B, int32_t offset);
int32_t ose_readBlobSize(ose_constbundle B, int32_t offset);
#else

/**
 * @brief Read a blob at an offset.
 *
 * @param b the bundle
 * @param o the offset
 * @returns a pointer to the blob
 *
 * @pre `b` or its underlying pointer must not be NULL.
 * @pre `o` must be within `b`.
 *
 * @note The blob is not copied and must not be altered,
 * unless you know what you are doing.
 * 
 * @note The pointer returned points to the size field of
 * the blob. The blob contents are 4 bytes after that.
 */
#define ose_readBlob(b, o) (ose_readString(b, o))

/**
 * @brief Get the size of a blob.
 *
 * @param b the bundle
 * @param o the offset
 * @returns the size of the blob
 *
 * @pre `b` or its underlying pointer must not be NULL.
 * @pre `o` must be within `b`.
 * @pre `o` must point to the size field of a blob.
 *
 * @note The size returned is the size of the payload of the
 * blob, i.e. it does not include the 4-byte size.
 */
#define ose_readBlobSize(b, o) (ose_readInt32(b, o))
#endif

/**
 * @brief Add a value to a 32-bit OSC integer in a bundle at
 * an offset.
 *
 * @param b the bundle
 * @param offset the offset
 * @param amt the amount to add
 *
 * @pre `b` or its underlying pointer must not be NULL.
 * @pre `o` must be within `b`.
 * @pre `o` must point to an OSC integer.
 */
#define ose_addToInt32(b, offset, amt)                      \
    ose_writeInt32((b),                                     \
                   (offset),                                \
                   ose_readInt32((b), (offset)) + (amt))



/**
 * @brief Get the number of bytes required to pad a blob size to a
 * multiple of 4 bytes.
 * 
 * @param n number of bytes in the blob
 * @returns the number of additional
 * bytes required for n to be a multiple of 4
 *
 * @pre `n` must be non-negative.
 *
 * @note This function behaves differently from #ose_pnbytes
 * in that it will return 0 for a blob size of 0.
 */
int32_t ose_getBlobPaddingForNBytes(int32_t n);

/**
 * @brief Get the padded size of a blob at an offset.
 *
 * @param B the bundle
 * @param offset the offset
 * @returns the size of the blob including NULL padding
 *
 * @pre `B` or its underlying pointer must not be NULL.
 * @pre `offset` must be within `B`.
 * @pre `offset` must point to the size field of a valid OSC
 * blob in `B`.
 */
int32_t ose_getPaddedBlobSize(ose_constbundle B,
                              int32_t offset);

/**
 * @brief Get a pointer to the payload of a blob at an
 * offset.
 *
 * @details The offset must point to the beginning of the
 * blob---that is, the size field, not the payload. This
 * function will return a pointer that is at `offset + 4`
 * bytes into `B`.
 *
 * @param B the bundle
 * @param offset the offset of the blob
 * @returns a pointer to the payload of the blob
 *
 * @pre `B` or its underlying pointer must not be NULL.
 * @pre `offset` must be within `B`.
 * @pre `offset` must point to the size field of a valid OSC
 * blob in `B`.
 */
const char *ose_readBlobPayload(ose_constbundle B,
                                int32_t offset);

/**
 * @brief Write a blob at an offset.
 *
 * @param B the bundle
 * @param offset the offset
 * @param blobsize the blob size not including the 4 byte
 * size
 * @param blob the contents of the blob
 *
 * @pre `B` or its underlying pointer must not be NULL.
 * @pre `offset` must be within `B`.
 * @pre `blobsize` must be non-negative.
 * @pre `offset + blobsize + 4` must be within `B`.
 *
 * @note `blob` may be NULL, in which case the number of
 * bytes specified by `blobsize` will be set to 0.
 */
int32_t ose_writeBlob(ose_bundle B,
                      int32_t offset,
                      int32_t blobsize,
                      const char * const blob);

#ifdef OSE_PROVIDE_TYPE_SYMBOL
#define ose_readSymbol(b, o) ose_readString((b), (o))
#define ose_writeSymbol(b, o, s) ose_writeString((b), (o), (s))
#endif
#ifdef OSE_PROVIDE_TYPE_DOUBLE
double ose_readDouble(ose_constbundle B, int32_t offset);
int32_t ose_writeDouble(ose_bundle B, int32_t offset, double f);
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
#define ose_readInt8(b, o) ose_readInt32((b), (o))
#define ose_writeInt8(b, o, i) ose_writeInt32((b), (o), (i))
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
#define ose_readUInt8(b, o) ose_readInt32((b), (o))
#define ose_writeUInt8(b, o, i) ose_writeInt32((b), (o), (i))
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
uint32_t ose_readUInt32(ose_constbundle B, int32_t offset);
int32_t ose_writeUInt32(ose_bundle B,
                        int32_t offset,
                        uint32_t i);
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
int64_t ose_readInt64(ose_constbundle B, int32_t offset);
int32_t ose_writeInt64(ose_bundle B, int32_t offset, int64_t i);
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
uint64_t ose_readUInt64(ose_constbundle B, int32_t offset);
int32_t ose_writeUInt64(ose_bundle B,
                        int32_t offset,
                        uint64_t i);
#endif

/**
 * @brief Read a timetag at an offset.
 *
 * @param B the bundle
 * @param offset the offset
 * @returns the timetag
 *
 * @pre `B` or its underlying pointer must not be NULL.
 * @pre `offset` must be within `B`.
 * @pre `offset` must point to a valid OSC timetag.
 *
 * @see ose_timetag
 */
struct ose_timetag ose_readTimetag(ose_constbundle B,
                                   int32_t offset);

/**
 * @brief Write a timetag at an offset.
 *
 * @param B the bundle
 * @param offset the offset
 * @param sec the seconds portion of the timetag
 * @param fsec the fractions of a second portion of the
 * timetag
 *
 * @pre `B` or its underlying pointer must not be NULL.
 * @pre `offset` must be within `B`.
 * @pre `offset + 8` must be within `B`.
 */
int32_t ose_writeTimetag(ose_bundle B,
                         int32_t offset,
                         uint32_t sec,
                         uint32_t fsec);

/**
 * @brief Read a pointer at an offset.
 *
 * @details An aligned pointer is a pointer that has been
 * stored in a blob with the natural alignmet of the
 * hardware. This function reads that pointer from the blob
 * and returns it.
 *
 * @param B the bundle
 * @param offset the offset
 * @returns the pointer
 *
 * @pre `B` or its underlying pointer must not be NULL.
 * @pre `offset` must be within `B`.
 * @pre `offset` must point to a blob that has been
 * writen using #ose_writeAlignedPtr.
 */
const void *ose_readAlignedPtr(ose_constbundle B,
                         const int32_t offset);

/**
 * @brief Write a pointer at an offset.
 *
 * @details This function writes the value of a pointer into
 * a blob at a natural alignment boundary for the hardware.
 *
 * @param B the bundle
 * @param offset the offset
 * @param ptr the pointer
 *
 * @pre `B` or its underlying pointer must not be NULL.
 * @pre `offset` must be within `B`.
 * @pre `offset + ` #OSE_INTPTR2 must be within `B`.
 */
int32_t ose_writeAlignedPtr(ose_bundle B,
                            const int32_t offset,
                            const void *ptr);

/**
 * @brief Align a pointer to the natural alignment of the
 * hardware.
 *
 * @details This function re-aligns a pointer stored in a
 * blob to the natural alignment of the hardware.
 *
 * @param B the bundle
 * @param offset the offset
 *
 * @pre `B` or its underlying pointer must not be NULL.
 * @pre `offset` must be within `B`.
 * @pre `offset + sizeof(` #OSE_INTPTR2 `)` must be within `B`.
 * @pre `offset` must point to the contents of a blob that
 * is `sizeof(` #OSE_INTPTR2 `)` bytes long, into which a pointer has
 * been written using #ose_writeAlignedPtr.
 */
void ose_alignPtr(ose_bundle B, const int32_t offset);

/**
 * @brief Drop the last element in the bundle.
 * 
 * The offset passed to this function must be that of the last
 * element in the bundle.
 *
 * @param B The bundle.
 * @param offset the offset of the last element in bytes from the
 * beginning of the bundle.
 *
 * @pre `B` must not be empty.
 * @pre `offset` must be within `B`.
 * @pre `offset` must point to a valid bundle element within `B`.
 */
void ose_dropAtOffset(ose_bundle B, int32_t offset);

/**
 * @brief Get the offset in bytes of the last bundle element.
 * 
 * @details This function returns the offset in bytes of the
 * size field of the last bundle element. If the bundle is
 * empty, the bundle header size (#OSE_BUNDLE_HEADER_LEN) is
 * returned.
 * 
 * @param B the bundle
 * @returns the offset of the last element in bytes
 *
 * @note A return value equal to #OSE_BUNDLE_HEADER_LEN is
 * ambiguous---it can indicate that the bundle has either 0
 * or 1 elements.
 */
int32_t ose_getLastBundleElemOffset(ose_constbundle B);

/**
 * @brief Get the offset in bytes of the address of an
 * element.
 *
 * @details This function returns the offset in bytes of the
 * address of a message or a bundle (a bundle's address is
 * always `\#bundle`).
 *
 * @param B the bundle
 * @param elemoffset the offset of the element
 * @returns `elemoffset + 4`
 *
 * @pre `B` must not be empty.
 * @pre `elemoffset + 4` must be within `B`
 *
 */
int32_t ose_getBundleElemAddressOffset(ose_constbundle B,
                                       int32_t elemoffset);

/**
 * @brief Get the offset in bytes of the typetag / timetag
 * field of an element.
 *
 * @details This function returns the offset in bytes of the
 * _typetag_ section of a message, or the _timetag_ section
 * of a bundle.
 *
 * @param B the bundle
 * @param elemoffset the offset of the element
 * @returns the offset of the typetag / timetag section
 *
 * @pre `B` must not be empty.
 * @pre `elemoffset + 4` must be within `B`
 */
int32_t ose_getBundleElemTTOffset(ose_constbundle B,
                                  int32_t elemoffset);

/**
 * @brief Get the offset in bytes of the payload of an
 * element.
 *
 * @details The payload of a bundle begins with the first
 * bundle element it contains, and with a message, it is
 * just after the typetag section.
 *
 * @param B the bundle
 * @param elemoffset the offset of the element
 * @returns the offset of the payload section
 *
 * @pre `B` must not be empty.
 * @pre `elemoffset + 4` must be within `B`
 */
int32_t ose_getBundleElemPayloadOffset(ose_constbundle B,
                                       int32_t elemoffset);

/**
 * @brief Get the offset of the first element whose address
 * matches a string, using simple string comparison.
 * 
 * @param B bundle containing elements to test
 * @param addr address to test against the elements of the bundle
 * @returns the offset in bytes of the first match, or 0 if no
 * match was found
 *
 * @pre `addr` must not be NULL.
 *
 * @see ose_getFirstOffsetForPMatch
 * @see ose_getFirstOffsetForFullPMatch
 */
int32_t ose_getFirstOffsetForMatch(ose_constbundle B,
                                   const char * const addr);

/**
 * @brief Get the offset of the first element whose pattern
 * matches a string, using OSC @subpage patternmatching
 * "pattern matching".
 * 
 * @param B bundle containing elements to test
 * @param addr address to test against the elements of the bundle
 * @returns the offset in bytes of the first match, or 0 if no
 * match was found
 *
 * @pre `addr` must not be NULL.
 * 
 * @note This function will report a match if only part of
 * the address in the bundle matched addr, for example: the
 * address "/foo" will match the pattern "/foo/bar" in the
 * bundle.
 *
 * @see ose_getFirstOffsetForMatch
 * @see ose_getFirstOffsetForFullPMatch
 */
int32_t ose_getFirstOffsetForPMatch(ose_constbundle B,
                                    const char * const addr);

/**
 * @brief Get the offset of the first element whose address
 * fully matches a string, using OSC pattern matching syntax.
 * 
 * @param B bundle containing elements to test
 * @param addr address to test against the elements of the bundle
 * @returns the offset in bytes of the first match, or 0 if no
 * match was found
 *
 * @pre `addr` must not be NULL.
 * 
 * @see ose_getFirstOffsetForMatch
 * @see ose_getFirstOffsetForPMatch
 */
int32_t ose_getFirstOffsetForFullPMatch(ose_constbundle B,
                                        const char * const addr);

/**
 *
 */
int32_t ose_getPayloadItemSize_hook(ose_constbundle B,
                                    const char typetag,
                                    const int32_t msg_offset,
                                    const int32_t item_offset);

/**
 * @brief Calculate the size of a typed OSC item.
 * 
 * @details Returns the full size that a given item occupies, including
 * any padding, size field, etc. 
 * 
 * String sizes include any NULL padding (a string of 4 bytes will
 * return a value of 8), and blobs include their size field and any
 * NULL padding (a blob of size 0 will return a value of 4, and a
 * blob of size 1 will return a value of 8.
 * 
 * @param B the bundle
 * @param typetag the typetag of the data
 * @param msg_offset the offset in bytes of the beginning of the 
 * message
 * @param item_offset the offset in bytes from the beginning of
 * the bundle to where the item is
 * @returns the size of the item in bytes
 *
 * @pre `B` must not be empty.
 * @pre `msg_offset` must be within `B`.
 * @pre `msg_offset` must point to the size field of a valid
 * OSC message
 * @pre `item_offset` must be within `B`.
 * @pre `item_offset` must point to a valid item in a
 * message of type `typetag`
 */
int32_t ose_getPayloadItemSize(ose_constbundle B,
                               char typetag,
                               int32_t msg_offset,
                               int32_t item_offset);

/**
 *
 */
int32_t ose_getPayloadItemLength_hook(ose_constbundle B,
                                      const char typetag,
                                      const int32_t msg_offset,
                                      const int32_t item_offset);
/**
 * @brief Calculate the length of a typed OSC item.
 * 
 * @details Returns the length of an OSC item, not including
 * padding or NULL bytes, or size fields for types that
 * require them.
 * 
 * String lengths do not include any NULL padding (a string
 * of 4 bytes will return a value of 4), and blobs include
 * do not include their size field and any NULL padding (a
 * blob of size 0 will return a value of 0, and a blob of
 * size 1 will return a value of 1.
 * 
 * @param B the bundle
 * @param typetag the type tag of the data
 * @param msg_offset the offset in bytes of the beginning of the 
 * message
 * @param item_offset the offset in bytes from the beginning of
 * the bundle to where the item is
 *
 * @pre `B` must not be empty.
 * @pre `msg_offset` must be within `B`.
 * @pre `msg_offset` must point to the size field of a valid
 * OSC message
 * @pre `item_offset` must be within `B`.
 * @pre `item_offset` must point to a valid item in a
 * message of type `typetag`
 */
int32_t ose_getPayloadItemLength(ose_constbundle B,
                                 char typetag,
                                 int32_t msg_offset,
                                 int32_t item_offset);

/**
 * @brief Get the offset of the nth payload item of a message.
 * 
 * @details This function gives the offset in bytes of the
 * nth item of a message at offset o. In addition, it also
 * provides the offset of the nth typetag, the total number
 * of typetags, and the offsets of the first typetag and
 * first payload item.
 * 
 * This function counts from the end furthest from the beginning of
 * the element, with n=1 being the last item of the element.
 * 
 * The number of typetags includes the leading comma of the typetag
 * string.
 * 
 * When n=1, lto and lpo contain the offsets of the typetag and
 * payload items furthest from the beginning of the bundle element.
 * 
 * When n is equal to the number of typetags including the leading
 * comma, to == lto and po == lpo.
 * 
 * @param B the bundle
 * @param n the index of the item to get
 * @param msg_offset the offset of the message `B`
 * @param typetags_offset the offset of the first typetag
 * (the comma)
 * @param num_typetags the total number of typetags
 * @param last_typetag_offset the offset of the last (nth) typetag
 * @param payload_offset the offset of the first payload item
 * @param last_payload_item_offset the offset of the last
 * (nth) payload item
 *
 * @pre `B` must not be empty.
 * @pre `msg_offset` must be within `B`.
 * @pre `msg_offset` must point to the size field of a valid message.
 * @pre `n` must be within the range @f$[1,K]@f$ where
 * @f$K@f$ is the number of items in the message.
 * @pre None of the pointer arguments may be NULL.
 */
void ose_getNthPayloadItem(ose_constbundle B,
                           int32_t n,
                           int32_t msg_offset,
                           int32_t *typetags_offset,
                           int32_t *num_typetags,
                           int32_t *last_typetag_offset,
                           int32_t *payload_offset,
                           int32_t *last_payload_item_offset);

/**
 * @brief Write a message with arguments into a bundle at an offset.
 *
 * Typetag          | Number of Args| Arg Types 		  	| Arg Description 		|
 * --				| --			| --					| --					|
 * #OSETT_INT32     | 1             | `int32_t` 			|        				|
 * #OSETT_FLOAT     | 1             | `float`   			|		          		|
 * #OSETT_STRING    | 1             | `char*`   			|                 		|
 * #OSETT_BLOB 		| 2 			| `int32_t`, `char*` 	| blob size, blob data 	|
 * #OSETT_SYMBOL 	| 1 			| `char*` 				| 						|
 * #OSETT_DOUBLE 	| 1 			| `double` 				|						|
 * #OSETT_INT8 		| 1 			| `int8_t` 				| 						|
 * #OSETT_UINT8 	| 1 			| `uint8_t` 			| 						|
 * #OSETT_UINT32 	| 1 			| `uint_32` 			| 						|
 * #OSETT_INT64 	| 1 			| `int64_t` 			| 						|
 * #OSETT_UINT64 	| 1 			| `uint64_t` 			| 						|
 * #OSETT_TIMETAG 	| 2 			| `int32_t`, `int32_t` 	| seconds, fractions of a second |
 * #OSETT_TRUE 		| 0 			| 						| 						|
 * #OSETT_FALSE 	| 0 			| 						| 						|
 * #OSETT_NULL 		| 0 			| 						| 						|
 * #OSETT_INFINITUM | 0 			| 						| 						|
 * user-defined 	| 2 			| `int32_t`, `char*` 	| size, data 			|
 * 
 * @param B the bundle
 * @param offset the offset into the bundle where the message will
 * be written
 * @param address a C string that will be copied to the
 * address of the message
 * @param addresslen The length in bytes of
 * the address, not ncluding the NULL byte
 * @param n The number of
 * OSC arguments for the message
 * @param ... The argument list,
 * which consists of a type tag followed by 0 or more values,
 * depending on the type (see table below).
 *
 * @pre `offset` must be within `B`.
 * @pre `B` must be large enough to accomodate the size of
 * the message that will be written (see
 * #ose_computeMessageSize).
 * @pre `address` must not be NULL.
 * @pre `addresslen` must be non-negative.
 * @pre `n` must be non-negative.
 * @pre The variable length argument list must correspond to
 * the table above.
 *
 * @see ose_computeMessageSize
 *
 * Example:
 * @code{.c}
 * ose_writeMessage(bundle, "/foo",
 *  OSE_BUNDLE_HEADER_LEN,
 * 	4, 
 * 	4,
 * 	OSETT_INT32, 33,
 * 	OSETT_FLOAT, 33.3,
 * 	OSETT_STRING, THIRTY-THREE,
 * 	OSETT_BLOB, 3, (char []){3, 3, 3});
 * @endcode
 */
int32_t ose_writeMessage(ose_bundle B,
                         int32_t offset,
                         const char * const address,
                         int32_t addresslen,
                         int32_t n, ...);

/**
 * @brief Write a message with arguments into a bundle at an offset.
 *
 * @see #ose_writeMessage.
*/
int32_t ose_vwriteMessage(ose_bundle B,
                          int32_t offset,
                          const char * const address,
                          int32_t addresslen,
                          int32_t n,
                          va_list ap);

/**
 * @brief Compute the size of a message.
 *
 * @details This function computes the number of bytes a
 * message written by #ose_writeMessage will require,
 * including the 4-byte size of the message.
 *
 * @see ose_writeMessage
 */
int32_t ose_computeMessageSize(ose_bundle B,
                               const char * const address,
                               const int32_t addresslen,
                               const int32_t n,
                               ...);

/**
 * @brief Compute the size of a message.
 *
 * @see ose_computeMessageSize
 */
int32_t ose_vcomputeMessageSize(ose_bundle B,
                                const char * const address,
                                const int32_t addresslen,
                                const int32_t n,
                                va_list ap);

int32_t ose_printTypeof0(ose_constbundle B,
                         const int32_t offset,
                         char *buf,
                         int32_t buflen);
int32_t ose_printTypeof1(ose_constbundle B,
                         const int32_t offset,
                         char *buf,
                         int32_t buflen);
int32_t ose_printTypeof2(ose_constbundle B,
                         const int32_t offset,
                         char *buf,
                         int32_t buflen);

int ose_typechk0(ose_constbundle B,
                 const char * const pattern);
int ose_typechk1(ose_constbundle B,
                 const char * const pattern);
int ose_typechk2(ose_constbundle B,
                 const char * const pattern);

#define OSE_SLIP_END 0300
#define OSE_SLIP_ESC 0333
#define OSE_SLIP_ESC_END 0334
#define OSE_SLIP_ESC_ESC 0335

struct ose_SLIPBuf
{
    unsigned char *buf;
    int32_t buflen, count, state;
    int havenullbyte;
};
struct ose_SLIPBuf ose_initSLIPBuf(unsigned char *buf,
                                   int32_t buflen);
int ose_SLIPDecode(unsigned char c, struct ose_SLIPBuf *s);
/* -1 error */
/* >0 length */
int32_t ose_SLIPEncode(const unsigned char * const src,
                       int32_t srclen,
                       unsigned char *dest,
                       int32_t destlen);

#ifdef __cplusplus
}
#endif

#endif
