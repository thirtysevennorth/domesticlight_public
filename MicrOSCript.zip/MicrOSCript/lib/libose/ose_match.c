/*
  Written by John MacCallum, The Center for New Music and Audio
  Technologies, University of California, Berkeley.	 Copyright
  (c) 2009, The Regents of the University of California
  (Regents).  Permission to use, copy, modify, distribute, and
  distribute modified versions of this software and its
  documentation without fee and without a signed licensing
  agreement, is hereby granted, provided that the above copyright
  notice, this paragraph and the following two paragraphs appear
  in all copies, modifications, and distributions.

  IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT,
  INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
  INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE
  AND ITS DOCUMENTATION, EVEN IF REGENTS HAS BEEN ADVISED OF THE
  POSSIBILITY OF SUCH DAMAGE.

  REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT
  NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
  FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE AND ACCOMPANYING
  DOCUMENTATION, IF ANY, PROVIDED HEREUNDER IS PROVIDED "AS
  IS". REGENTS HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT,
  UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
*/

#include "ose.h"
#include "ose_match.h"
#include "ose_assert.h"
#include <string.h>
#include <stdio.h>
#include <inttypes.h>

#define OSE_MATCH_REPETITION

/* #define OSE_MATCH_LOGSTATE */
#define OSE_MATCH_CHAR_CLASS_CAN_BE_NEGATIVE

static int32_t ose_match_findEndOfCharClass(const char * const pattern,
                                        int32_t po);
static int32_t ose_match_charClass(const char * const pattern,
                               const char * const address);

#define OSE_MATCH_CHAR_CLASS_NOMATCH 1

#define OSE_MATCH_PUSH_IMPL(P, A)								\
	{															\
		sp++;													\
		if((sp - stack) >= OSE_MATCH_BACKTRACK_LIMIT)			\
		{														\
			return OSE_MATCH_ERROR_BACKTRACK_LIMIT_EXCEEDED;	\
		}														\
		ose_assert(sp - stack <									\
				   (sizeof(stack) / sizeof(struct state)));		\
		sp->p = P;												\
		sp->a = A;												\
	}
#define OSE_MATCH_RETURN_SUCCESS_IMPL(R) return R;
#define OSE_MATCH_RETURN_FAILURE_IMPL(R)		\
	return R;

#ifdef OSE_MATCH_LOGSTATE
#define OSE_MATCH_PRINTSTATE(p, a, po, ao)		\
	ose_match_printState(p, a, po, ao);
static void ose_match_printState(const char * const pattern,
								 const char * const address,
								 int32_t po,
								 int32_t ao)
{
	for(int32_t i = 0; i < strlen(pattern); i++)
	{
		if(i == po)
		{
			fprintf(stderr, "v ");
		}
		else
		{
			fprintf(stderr, "  ");
		}
	}
	fprintf(stderr, "\n");
	for(int32_t i = 0; i < strlen(pattern); i++)
	{
		fprintf(stderr, "%c ", pattern[i]);
	}
	fprintf(stderr, "\n");
	for(int32_t i = 0; i < strlen(address); i++)
	{
		fprintf(stderr, "%c ", address[i]);
	}
	fprintf(stderr, "\n");
	for(int32_t i = 0; i < strlen(address); i++)
	{
		if(i == ao)
		{
			fprintf(stderr, "^ ");
		}
		else
		{
			fprintf(stderr, "  ");
		}
	}
	fprintf(stderr, "\n");
}

#define OSE_MATCH_PUSH(P, A)					\
	OSE_MATCH_PUSH_IMPL(P, A);					\
	fprintf(stderr, "PUSH{%c(%d); %c(%d);}\n",	\
			pattern[P], P, address[A], A);		\

#define OSE_MATCH_RETURN_SUCCESS(R)							\
	{														\
		switch(R)											\
		{													\
		case 1:												\
			fprintf(stderr, "return: ADDRESS complete\n");	\
			break;											\
		case 2:												\
			fprintf(stderr, "return: PATTERN complete\n");	\
			break;											\
		case 3:												\
			fprintf(stderr, "return: BOTH complete\n");		\
			break;											\
		default:											\
			break;											\
		}													\
		OSE_MATCH_RETURN_SUCCESS_IMPL(R);					\
	}

#define OSE_MATCH_RETURN_FAILURE(R)						\
	{													\
		if(R >= 0x100){									\
			fprintf(stderr, "return: ERROR: %s\n",		\
					ose_match_errstr(R));				\
		}else{											\
			fprintf(stderr, "return: NO MATCH (%d)\n",	\
					__LINE__);							\
		}												\
		OSE_MATCH_RETURN_FAILURE_IMPL(R);				\
	}


#else

#define OSE_MATCH_PUSH(P, A) OSE_MATCH_PUSH_IMPL(P, A)
#define OSE_MATCH_RETURN_SUCCESS(R)				\
	OSE_MATCH_RETURN_SUCCESS_IMPL(R)
#define OSE_MATCH_RETURN_FAILURE(R)				\
	OSE_MATCH_RETURN_FAILURE_IMPL(R)
#define OSE_MATCH_PRINTSTATE(p, a, po, ao) ;

#endif
#define OSE_MATCH_POP() sp--;

enum ose_match_retval ose_match_pattern(const char * const pattern,
                                        const char * const address,
                                        int32_t *pattern_offset,
                                        int32_t *address_offset)
{
	struct state {int32_t p,a;} stack[OSE_MATCH_BACKTRACK_LIMIT];
	struct state *sp = stack;
#ifdef OSE_MATCH_REPETITION
	int32_t opening_bracket = 0;
	int32_t opening_brace = 0;
	int32_t have_matched_repetition = 0;
#endif
	
	ose_assert(pattern);
	ose_assert(address);
	ose_assert(pattern_offset);
	ose_assert(address_offset);

    if(pattern[0] == '#')
    {
        OSE_MATCH_RETURN_FAILURE(OSE_MATCH_NOMATCH);
    }
	
	*pattern_offset = 0;
	*address_offset = 0;

	sp->p = sp->a = 0;

	while(1)
	{
		char p;
		char a;
		
#ifdef OSE_MATCH_LOGSTATE
		fprintf(stderr, "stackptr: %ld: ", (long)(sp - stack));
#endif
		
		if(sp < stack)
		{
			
#ifdef OSE_MATCH_LOGSTATE
			fprintf(stderr, "fail\n");
#endif
			
			OSE_MATCH_RETURN_FAILURE(OSE_MATCH_NOMATCH);
		}
        p = pattern[sp->p];
		a = address[sp->a];
#ifdef OSE_MATCH_LOGSTATE
		fprintf(stderr, "sp{%c(%d); %c(%d);}\n",
				pattern[sp->p], sp->p,
				address[sp->a], sp->a); 
#endif

		*pattern_offset = sp->p;
		*address_offset = sp->a;

		OSE_MATCH_PRINTSTATE(pattern, address, sp->p, sp->a);

		if(a == '\0')
		{
			while(pattern[sp->p] == '*'
#ifdef OSE_MATCH_REPETITION
				  || pattern[sp->p] == '#'
#endif
				)
			{
				sp->p++;
			}
			*pattern_offset = sp->p;
			p = pattern[sp->p];

			if(p == '\0')
			{
				OSE_MATCH_RETURN_SUCCESS(
					(OSE_MATCH_PATTERN_COMPLETE
					 | OSE_MATCH_ADDRESS_COMPLETE));
			}
			else if(p == '/')
			{
				OSE_MATCH_RETURN_SUCCESS(
					OSE_MATCH_ADDRESS_COMPLETE);
			}
			else
			{
				OSE_MATCH_POP();
				continue;
			}
		}
		if(a == '/')
		{
			if(p == '/')
			{
#ifdef OSE_MATCH_DESCENDANTS
				if(pattern[sp->p + 1] != '/')
				{
					sp->p++;
					sp->a++;
					continue;
				}
#else
				int32_t pp = sp->p;
				int32_t aa = sp->a;
				sp = stack;
				sp->p = pp + 1;
				sp->a = aa + 1;
				continue;
#endif
			}
			else if(p == '\0')
			{
				OSE_MATCH_RETURN_SUCCESS(
					OSE_MATCH_PATTERN_COMPLETE);
			}
			else if(p == '*')
			{
				while(pattern[sp->p] == '*')
				{
					sp->p++;
				}
				continue;
			}
            else if(p == '#')
            {
                if(have_matched_repetition
                   || pattern[sp->p + 1] != '#')
                {
                    have_matched_repetition = 0;
                    if(pattern[sp->p + 2] == '#')
                    {
                        sp->p += 2;
                    }
                    else
                    {
                        sp->p++;
                    }
                    continue;
                }
                else
                {
                    OSE_MATCH_POP();
                    continue;
                }
            }
			else
			{
				OSE_MATCH_POP();
				continue;
			}
		}
#ifdef OSE_MATCH_ALLOW_STAR_IN_ADDRESS
		if(a == '*'
		   && sp->a > 0
		   && address[sp->a - 1] == '/'
		   && (address[sp->a + 1] == '/'
			   || address[sp->a + 1] == '\0'))
		{
			while(address[sp->a] != '/'
				  && address[sp->a] != '\0')
			{
				sp->a++;
			}
			while(pattern[sp->p] != '/'
				  && pattern[sp->p] != '\0')
			{
				sp->p++;
			}
			continue;
		}
#endif

		switch(p)
		{
		case '/':
#ifdef OSE_MATCH_DESCENDANTS
			if(pattern[sp->p + 1] == '/')
			{
				int32_t p = sp->p + 2;
				int32_t a = sp->a + 1;
				while(address[a] != 0)
				{
					while(address[a] != '/' && address[a] != 0)
					{
						a++;
					}
					if(address[a]){
						sp->p = p;
						sp->a = a + 1;
						OSE_MATCH_PUSH(p, a + 1);
						a++;
					}
				}
				OSE_MATCH_POP();
			
			}
			else
			{
				OSE_MATCH_POP();
			}
#else
			/* we already checked to see if a is a '/' or a '\0',
			   so just pop and continue; */
			OSE_MATCH_POP();
#endif
			break;
		case '\0':
			/* we know a is not a '/' or a '\0', */
			/* so just pop and continue; */
			OSE_MATCH_POP();
			break;
		case '?':
			sp->p++;
			sp->a++;
			break;
		case '[':
		{
			int32_t ret = ose_match_charClass(pattern + sp->p,
                                          address + sp->a);
			switch(ret)
			{
			case 0:
            {
                int32_t pp = ose_match_findEndOfCharClass(pattern,
                                                      sp->p);
                if(pattern[pp] == '#')
                {
                    if(have_matched_repetition
                       || pattern[pp + 1] != '#')
                    {
                        if(pattern[pp + 1] == '#')
                        {
                            sp->p = pp + 2;
                        }
                        else
                        {
                        	sp->p = pp + 1;
                        }
                        break;
                    }
                }
                    
				OSE_MATCH_POP();
            }
				break;
			case 1:
#ifdef OSE_MATCH_REPETITION
				opening_bracket = sp->p;
#endif
                sp->a++;
				sp->p = ose_match_findEndOfCharClass(pattern,
                                                     sp->p);
				break;
			default:

				OSE_MATCH_RETURN_FAILURE(ret);
			}
		}
		break;
		case '{':
		{
#ifdef OSE_MATCH_REPETITION
			opening_brace = sp->p;
#endif
			int32_t rest = sp->p;
			while(pattern[rest] != '}')
			{
				if(pattern[rest] == '/'
				   || pattern[rest] == '\0')
				{
					OSE_MATCH_RETURN_FAILURE(
						OSE_MATCH_ERROR_UNMATCHED_LEFT_CURLY_BRACE);
				}
				rest++;
			}
			rest++;
			sp->p++;
			int32_t p1 = sp->p, p2 = sp->p;
			int32_t aa = sp->a;
            /* int32_t havematch = 0; */
            
            if(pattern[rest] == '#'
               && pattern[rest + 1] != '#')
            {
                if(pattern[rest + 1] == '#')
                {
                	OSE_MATCH_PUSH(rest + 2, aa);
                }
                else
                {
                    OSE_MATCH_PUSH(rest + 1, aa);
                }
            }
            else
            {
				OSE_MATCH_POP();
            }
			while(pattern[p2] != '/' && pattern[p2] != '\0')
			{
				if(pattern[p2] == '/')
				{
					OSE_MATCH_RETURN_FAILURE(
						OSE_MATCH_ERROR_UNMATCHED_LEFT_CURLY_BRACE);
				}
				else if(pattern[p2] == ','
						|| pattern[p2] == '}')
				{
					if(!strncmp(pattern + p1,
								address + aa,
								p2 - p1))
					{
                        /* havematch = 1; */
						OSE_MATCH_PUSH(rest, aa + (p2 - p1));
                        if(pattern[rest] == '#')
                        {
                            if(pattern[rest + 1] == '#')
                            {
                                OSE_MATCH_PUSH(rest + 2,
                                               aa + (p2 - p1));
                            }
                            else
                            {
                                OSE_MATCH_PUSH(rest + 1,
                                               aa + (p2 - p1));
                            }
                        }
					}
					p1 = p2 + 1;
				}
				if(pattern[p2] == '}')
				{
					break;
				}
				p2++;
			}
		}
		break;
		case '}':
			OSE_MATCH_RETURN_FAILURE(
				OSE_MATCH_ERROR_UNMATCHED_RIGHT_CURLY_BRACE);
		case ']':
			OSE_MATCH_RETURN_FAILURE(
				OSE_MATCH_ERROR_UNMATCHED_RIGHT_SQUARE_BRACKET);
		case '*':
		{
			while(pattern[sp->p + 1] == '*')
			{
				/* avoid all kinds of extra backtracking with */
				/* multiple stars */
				sp->p++;
			}
			if(pattern[sp->p + 1] == '\0'
			   || pattern[sp->p + 1] == '/')
			{
				sp->p++;
				while(address[sp->a] != '/'
					  && address[sp->a] != '\0')
				{
					sp->a++;
				}
			}
			else
			{
				int32_t pp = sp->p + 1;
				int32_t aa = sp->a;
				OSE_MATCH_POP();
				int32_t here = aa;
				while(address[aa] != '/'
					  && address[aa] != '\0')
				{
					aa++;
				}
				aa--;
				while(aa != here)
				{
					OSE_MATCH_PUSH(pp, aa);
					aa--;
				}
				OSE_MATCH_PUSH(pp, aa);
			}
		}
		break;
#ifdef OSE_MATCH_REPETITION
		case '#':
			have_matched_repetition = 1;
			if(sp->p > 0)
			{
				if(pattern[sp->p - 1] == '}')
				{
                    int32_t aa = sp->a;
                    sp->a++;
                    sp->p++;
                    OSE_MATCH_PUSH(opening_brace, aa);
				}
				else if(pattern[sp->p - 1] == ']')
				{
                    int32_t aa = sp->a;
                    sp->a++;
                    sp->p++;
                    OSE_MATCH_PUSH(opening_bracket, aa);
				}
                else if(pattern[sp->p - 1] == '*')
                {
                    /* avoid infinite loop here */
                    int32_t aa = sp->a;
                    int32_t pp = sp->p + 1;
                    if(sp->p + 1 == '#')
                    {
                        pp++;
                        sp->p++;
                    }
                    sp->a++;
                    sp->p++;
                    OSE_MATCH_PUSH(pp, aa);
                }
                else if(pattern[sp->p - 1] == '/')
                {
                    OSE_MATCH_RETURN_FAILURE(
                        OSE_MATCH_ERROR_INVALID_REPETITION);
                }
				else
				{
                    int32_t aa = sp->a;
                    int32_t pp = sp->p - 1;
                    sp->a++;
                    sp->p++;
                    OSE_MATCH_PUSH(pp, aa);
				}
			}
			else
			{
				have_matched_repetition = 0;
                opening_bracket = 0;
                opening_brace = 0;
				sp->p++;
			}
			break;
#endif
		default:
			if(p == a)
			{
				sp->p++;
				sp->a++;
			}
#ifdef OSE_MATCH_REPETITION
			else if(pattern[sp->p + 1] == '#'
					&& pattern[sp->p + 2] != '#')
			{
				sp->p += 2;
				sp->a++;
			}
            else if(pattern[sp->p + 1] == '#'
                    && have_matched_repetition)
            {
                have_matched_repetition = 0;
                if(pattern[sp->p + 2] == '#')
                {
                    sp->p += 3;
                }
                else
                {
                    sp->p += 2;
                }
            }
#endif
			else
			{
				OSE_MATCH_POP();
			}
			break;
		}
/* #ifdef OSE_MATCH_REPETITION */
/* 		if(have_matched_repetition == 0) */
/* 		{ */
/* 			opening_bracket = 0; */
/* 			opening_brace = 0; */
/* 		} */
/* #endif */
	}
	/* unreachable */
}

static int32_t ose_match_findEndOfCharClass(const char * const pattern,
                                        int32_t po)
{
    /* if the first char inside the opening square */
    /* bracket is a closing square bracket, it's */
    /* treated as a normal char, so skip over it */
    if(pattern[po + 1] == ']')
    {
        po += 2;
    }
    while(1)
    {
        if(pattern[po] == ']')
        {
            break;
        }
        /* no need to do this--it will have already failed in the
         * match */
        /* else if(pattern[po] == '/' */
        /*         || pattern[po] == '\0') */
        /* { */
        /*     OSE_MATCH_RETURN_FAILURE( */
        /*         OSE_MATCH_ERROR_UNMATCHED_LEFT_SQUARE_BRACKET); */
        /* } */
        po++;
    }
    po++;
    return po;
}

static int ose_match_charClass(const char * const pattern,
                               const char * const address)
{
	const char *p = pattern;
	p++;
	int val = 1;
	if(*p == '!')
	{
		p++;
		val = 0;
	}
	int matched = !val;

	/* we're on the first character inside the square brackets if
	   it's a - or a ], it gets treated as a normal character */
	if(*p == ']')
	{
		if(*p == *address)
		{
			return val;
		}
	}
	while(*p != ']')
	{
		char c = *p++, c2;
		if(c == '\0' || c == '/')
		{
			return OSE_MATCH_ERROR_UNMATCHED_LEFT_SQUARE_BRACKET;
		}
		if(*p == '-')
		{
			if(p[1] != '\0' && p[1] != '/' && p[1] != ']')
			{
				p++;
				c2 = *p++;
#ifdef OSE_MATCH_CHAR_CLASS_CAN_BE_NEGATIVE
				if((c <= *address && *address <= c2)
				   || (c >= *address && *address >= c2))
				{
#else
					if(c2 < c)
					{
						return OSE_MATCH_ERROR_INVALID_CHAR_CLASS;
					}
					if(c <= *address
					   && *address <= c2)
					{
#endif
						matched = val;
						break;
					}
					continue;
				}
			}
			if(c == *address)
			{
				matched = val;
				break;
			}
		}
		return matched;
	}
