/*
  Copyright (c) 2019-23 John MacCallum Permission is hereby granted,
  free of charge, to any person obtaining a copy of this software and
  associated documentation files (the "Software"), to deal in the
  Software without restriction, including without limitation the
  rights to use, copy, modify, merge, publish, distribute, sublicense,
  and/or sell copies of the Software, and to permit persons to whom
  the Software is furnished to do so, subject to the following
  conditions:

  The above copyright notice and this permission notice shall be
  included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
  ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
  SOFTWARE.
*/

/**
 * @file ose_context.h
 *
 * @brief contains functions that structure an OSC bundle for use
 * with other parts of this library
 */

#ifndef OSE_CONTEXT_H
#define OSE_CONTEXT_H

#ifdef __cplusplus
extern "C" {
#endif

#include <inttypes.h>
#include "ose.h"

/**
 * @brief Bytes passed to #ose_newBundleFromCBytes will be aligned
 * to a boundary that is a multiple of this number of bytes.
 */
#define OSE_CONTEXT_ALIGNMENT 4


#define OSE_CONTEXT_BUNDLE_SIZE_OFFSET -4
#define OSE_CONTEXT_TOTAL_SIZE_OFFSET -8
#define OSE_CONTEXT_PARENT_BUNDLE_OFFSET_OFFSET -12
#define OSE_CONTEXT_STATUS_OFFSET -16
#define OSE_CONTEXT_MEMUSAGE_OFFSET -20

#ifdef OSE_DEBUG
void ose_context_set_status(ose_bundle b, int32_t s);
int32_t ose_context_get_status(ose_bundle b);
#else
#define ose_context_get_status(b)               \
    ose_ntohl(*((int32_t *)(ose_getBundlePtr(b) + \
                            OSE_CONTEXT_STATUS_OFFSET)))

#define ose_context_set_status(b, s)                                \
    *((int32_t *)(ose_getBundlePtr(b) + OSE_CONTEXT_STATUS_OFFSET)) \
    = (s)
#endif

#ifdef OSE_MEMPROFILE
#ifdef OSE_DEBUG
int32_t ose_get_memusage(ose_bundle b);
void ose_reset_memusage(ose_bundle b);
#else
#define ose_get_memusage(b)                                     \
    ose_ntohl(*((int32_t *)(ose_getBundlePtr(b)                 \
                            + OSE_CONTEXT_MEMUSAGE_OFFSET)))
#define ose_reset_memusage(b)                       \
    *((int32_t *)(ose_getBundlePtr(b)               \
                  + OSE_CONTEXT_MEMUSAGE_OFFSET)) = 0;
#endif
#else
#define ose_get_memusage(b) do{}while(0)
#endif



/**
 * @brief The number of bytes between the beginning of a context
 * message and the bundle (blob).
 */
#define OSE_CONTEXT_BUNDLE_OFFSET                   \
    (4          /* size */                          \
     + 4            /* padded address len */        \
     + 8            /* padded typetag str */        \
     + 4            /* int - unused */              \
     + 4            /* int - status */              \
     + 4            /* int - offset to bundle */    \
     + 4            /* int - total size */          \
     + 4)           /* blob size */




#ifdef OSE_DEBUG
int32_t ose_readSize(ose_constbundle bundle);
#else
#define ose_readSize(b)                                       \
    ose_ntohl(*((int32_t *)(ose_getBundlePtr((b)) + OSE_CONTEXT_BUNDLE_SIZE_OFFSET)))
#endif




/** 
 * @brief The overhead in bytes of a context message.
 */
#define OSE_CONTEXT_MESSAGE_OVERHEAD                \
    (OSE_CONTEXT_BUNDLE_OFFSET                      \
     + OSE_BUNDLE_HEADER_LEN    /* bundle header */ \
     + 4)           /* blob size */




/**
 * @brief The size of the status message.
 */
#define OSE_CONTEXT_STATUS_MESSAGE_SIZE 16




/**
 * @brief Maximum overhead used by the system.
 */
#define OSE_CONTEXT_MAX_OVERHEAD                \
    (OSE_CONTEXT_ALIGNMENT                      \
     * 2                                        \
     + OSE_BUNDLE_HEADER_LEN                    \
     + OSE_CONTEXT_MESSAGE_OVERHEAD             \
     + OSE_CONTEXT_STATUS_MESSAGE_SIZE          \
     + OSE_CONTEXT_MESSAGE_OVERHEAD)




/**
 * @brief Initializes a newly created bundle with a context message.
 *
 * @param bundle The bundle.
 * @param size The number of bytes available for this context message
 * @param address The address of this context message.
 * @returns The size available for the bundle minus 
 * the ovehead of the message.
 */
int32_t ose_init(ose_bundle bundle,
                 int32_t size,
                 const char * const address);





/**
 * @brief Pushes a new context message onto the current bundle.
 *
 * @param bundle The bundle.
 * @param size The number of bytes available for this context message
 * @param address The address of this context message.
 * @returns The size available for the bundle minus 
 * the ovehead of the message.
 */
int32_t ose_pushContextMessage(ose_bundle bundle,
                               int32_t size,
                               const char * const address);
void ose_dropContextMessage(ose_bundle bundle);





/**
 * @brief Returns the number of unused bytes in the bundle.
 *
 * @param bundle The bundle.
 * @returns The number of unused bytes in the bundle.
 */
int32_t ose_spaceAvailable(ose_constbundle bundle);




/**
 * @brief Returns the offset of the context message for a given address
 *
 * @param bundle The bundle to look for the context message in.
 * @param address The address of the context message to look for.
 * @returns The offset if found, or -1 otherwise.
 */
int32_t ose_getContextMessageOffset(ose_bundle bundle,
                                    const char * const address);





/**
 * @brief Enter a new bundle context.
 *
 * @param bundle The current bundle.
 * @param offset The offsetof the context message containing
 * the bundle to enter.
 * @returns The requested bundle.
 */
ose_bundle ose_enterBundleAtOffset(ose_bundle bundle,
                                   int32_t offset);




/**
 * @brief Enter a new bundle context.
 *
 * @param bundle The current bundle.
 * @param address The address of the context message containing
 * the bundle to enter.
 * @returns The requested bundle.
 */
ose_bundle ose_enter(ose_bundle bundle,
                     const char * const address);





/**
 * @brief Exit a bundle context and move one level up.
 *
 * @param bundle The current bundle.
 * @returns The bundle one level up.
 */
ose_bundle ose_exit(ose_bundle bundle);





/**
 * @brief Add an amount to the size of a bundle. This function takes
 * care of adjusting the size of the blob of free space, and must be
 * called to ensure that all sizes are updated properly, when using
 * the context machinery in this file, as well as the stack
 * operations in ose_stackops.h.
 *
 * @param bundle The bundle to change the size of.
 * @param amt The amount to add to (or subtract from) the bundle.
 */
void ose_addToSize(ose_bundle bundle, int32_t amt);
void ose_incSize(ose_bundle bundle, int32_t amt);
void ose_decSize(ose_bundle bundle, int32_t amt);





/**
 *@brief Copy the topmost bundle element to a destination at the
 * same level.
 *
 * @param src The source bundle.
 * @param dest The destination bundle.
 */
void ose_copyBundleElemToDest(ose_bundle src, ose_bundle dest);





/**
 * @brief Copy the topmost bundle element to a destination at the
 * same level.
 *
 * @param src The source bundle.
 * @param dest_addr The destination address.
 */
void ose_copyBundleElemToDestAddr(ose_bundle src, const char * const dest_addr);





/**
 * @brief Move the topmost bundle element to a destination at the
 * same level.
 *
 * @param src The source bundle.
 * @param dest The destination bundle.
 */
void ose_moveBundleElemToDest(ose_bundle src, ose_bundle dest);





/**
 * @brief Move the topmost bundle element to a destination at the
 * same level.
 *
 * @param src The source bundle.
 * @param dest_addr The destination address.
 */
void ose_moveBundleElemToDestAddr(ose_bundle src,
                                  const char * const dest_addr);





/**
 * @brief Move the topmost bundle element to a destination at the
 * same level, replacing the first element with the same address if
 * it is a message.  If no message in the destination bundle exists
 * with the same address, this function behaves like
 * #ose_copyBundleElemToDestAddr.
 *
 * @param src The source bundle.
 * @param dest The destination bundle.
 */
void ose_replaceBundleElemInDest(ose_bundle src, ose_bundle dest);





/**
 * @brief Move the topmost bundle element to a destination at the
 * same level, replacing the first element with the same address if
 * it is a message.  If no message in the destination bundle exists
 * with the same address, this function behaves like
 * #ose_copyBundleElemToDestAddr.
 *
 * @param src The source bundle.
 * @param dest_addr The destination address.
 */
void ose_replaceBundleElemInDestAddr(ose_bundle src,
                                     const char * const dest_addr);





/**
 * @brief Push a copy of src onto the top of dest.
 *
 * @param src The source bundle.
 * @param dest The destination bundle.
 */
void ose_copyBundle(ose_constbundle src, ose_bundle dest);





/**
 * @brief Append the contents of the topmost element of src to dest.
 * Equivalent to 
 * @code{.c}
 * #ose_copyBundle(src, dest);
 * #ose_unpackDrop(dest);
 * #ose_drop(src);
 * @endcode
 *
 * @param src The source bundle.
 * @param dest The destination bundle.
 */
void ose_appendBundle(ose_bundle src, ose_bundle dest);




/**
 * @brief Replace the contents of dest with those of the topmost
 * element of src. Equivalent to 
 * @code{.c}
 * #ose_clear(dest);
 * #ose_append(src, dest);
 * @endcode
 */
void ose_replaceBundle(ose_bundle src, ose_bundle dest);
void ose_copyElemAtOffset(int32_t srcoffset,
                          ose_constbundle src,
                          ose_bundle dest);
#define ose_copyElem(src, dest)                             \
    ose_copyElemAtOffset(ose_getLastBundleElemOffset(src),  \
                         src, dest)
#define ose_moveElem(src, dest)                         \
    {                                                   \
        int32_t o = ose_getLastBundleElemOffset(src);   \
        ose_copyElemAtOffset(o, src, dest);             \
        ose_dropAtOffset(src, o);                       \
    }




int32_t ose_routeElemAtOffset(int32_t srcoffset,
                              ose_constbundle src,
                              int32_t prefixlen,
                              ose_bundle dest);





/**
 * @brief Initialize a new bundle from an array of bytes.
 *
 * @param nbytes The number of bytes in the array.
 * @param bytes An array of bytes containing nbytes, preallocated.
 * @returns An initialized ose_bundle.
 *
 * There is no need to dispose of the returned object in a special
 * way.  You may simply free the byte array when you are finished,
 * in accordance with the way it was allocated.
 */
ose_bundle ose_newBundleFromCBytes(int32_t nbytes, char *bytes);

#ifdef __cplusplus
}
#endif

#endif
