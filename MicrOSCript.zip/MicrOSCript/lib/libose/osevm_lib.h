/*
  Copyright (c) 2019-23 John MacCallum Permission is hereby
  granted, free of charge, to any person obtaining a copy of this
  software and associated documentation files (the "Software"), to
  deal in the Software without restriction, including without
  limitation the rights to use, copy, modify, merge, publish,
  distribute, sublicense, and/or sell copies of the Software, and
  to permit persons to whom the Software is furnished to do so,
  subject to the following conditions:

  The above copyright notice and this permission notice shall be
  included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
  OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
  OTHER DEALINGS IN THE SOFTWARE.
*/

/**
 * @file osevm_lib.h
 */

#ifndef OSEVM_LIB_H
#define OSEVM_LIB_H

#ifdef __cplusplus
extern "C" {
#endif

#define OSEVM_WRAP_DECL(name)			\
	void osevm_##name(ose_bundle bundle);

#define OSEVM_WRAP_DEFN(name)                   \
    void osevm_##name(ose_bundle bundle)	\
    {                                           \
        ose_bundle vm_s = OSEVM_STACK(bundle);  \
        enum ose_errno e = OSE_ERR_NONE;        \
        ose_##name(vm_s);                       \
        if((e = ose_errno_get(vm_s)))           \
        {                                       \
            ose_errno_set(bundle, e);           \
            ose_errno_set(vm_s, OSE_ERR_NONE);  \
        }                                       \
    }

#define OSEVM_WRAP_DEFPRED(name)                \
    void osevm_##name(ose_bundle bundle)   \
    {                                           \
        ose_bundle vm_s = OSEVM_STACK(bundle);  \
        int32_t i = ose_popInt32(vm_s);         \
        enum ose_errno e = OSE_ERR_NONE;        \
        if((e = ose_errno_get(vm_s)))           \
        {                                       \
            ose_errno_set(bundle, e);           \
            ose_errno_set(vm_s, OSE_ERR_NONE);  \
        }                                       \
        bool r = ose_##name(i);                 \
        ose_pushInt32(vm_s, r == true ? 1 : 0); \
    }

/**
 * @brief Execute a bundle on the stack.
 *
 * @details This function copies the current execution context
 * (input, control, environment, and the stack), and executes the
 * bundle on top of the stack.
 *
 * @pre The last element on the stack must be a bundle.
 */
void osevm_exec1(ose_bundle osevm);

/**
 * @brief Execute a bundle on the stack
 *
 * @details This function copies the current execution context
 * (input, control, environment, and the stack), and executes the
 * last bundle on the stack with the second to last as the
 * environment.
 *
 * @pre The last two elements on the stack must be bundles.
 */
void osevm_exec2(ose_bundle osevm);

/**
 * @brief Execute a bundle on the stack.
 *
 * @details This function copies the current execution context
 * (input, control, environment, and the stack), and executes the
 * last bundle on the stack with the second to last as the
 * environment, and the third to last as the stack.
 *
 * @pre The last three elements on the stack must be bundles.
 */
void osevm_exec3(ose_bundle osevm);

/**
 * @brief Synonym for #osevm_exec2.
 * @deprecated
 */
void osevm_exec(ose_bundle osevm);

/**
 * @brief Execute one of two bundles, depending on the value of the
 * int in the last message on the stack.
 *
 * @details This function expects three elements on the stack: the
 * last element is the test, which must be a message containing a
 * single integer. If the integer value is non-zero, the second to
 * last bundle will be executed, otherwise the third to last bundle
 * will be executed. The execution of the bundle proceeds according
 * to #osevm_exec1.
 *
 * @pre The stack must contain at least three elements.
 * @pre The last element of the stack must be a message.
 * @pre The last element of the stack must contain exactly one integer.
 * @pre The second to last and third to last elements must be bundles.
 */
void osevm_if(ose_bundle osevm);

/**
 * @brief Execute a bundle repeatedly.
 *
 * @details This function causes a bundle in the second to last
 * position to be executed `n` times, where `n` is an integer in the
 * last message of the bundle.
 *
 * @pre the stack must contain at least two elements.
 * @pre The last element of the stack must be a message.
 * @pre The last message of the stack must contain exactly one
 * non-negative integer.
 * @pre The second to last element of the the stack must be a bundle.
 */
void osevm_dotimes(ose_bundle osevm);

void osevm_copyRegisterToElem(ose_bundle osevm);
void osevm_appendElemToRegister(ose_bundle osevm);
void osevm_replaceRegisterWithElem(ose_bundle osevm);
void osevm_moveElemToRegister(ose_bundle osevm);
void osevm_copyElemToRegister(ose_bundle osevm);
void osevm_apply(ose_bundle osevm);
void osevm_map(ose_bundle osevm);
void osevm_return(ose_bundle osevm);

void osevm_version(ose_bundle osevm);
void osevm_assignStackToRegister(ose_bundle osevm);
void osevm_assignStackToEnv_impl(ose_bundle osevm,
                               ose_bundle env,
                               int replace,
                               int new_msg_first,
                               char bundle_typetag);
void osevm_assignStackToEnv(ose_bundle osevm);
/* 
   This function is the default used by OSEVM_LOOKUP, which can
   be changed with a #define at compile time
*/
void osevm_lookupInEnv_impl(ose_bundle osevm);
/* 
   This is bound into the environment
*/
void osevm_lookupInEnv(ose_bundle osevm);
void osevm_plookupInEnv_impl(ose_bundle osevm);
void osevm_plookupInEnv(ose_bundle osevm);
void osevm_funcall(ose_bundle osevm);
void osevm_makeRegister(ose_bundle osevm);
void osevm_quote(ose_bundle bundle);

OSEVM_WRAP_DECL(toType)
OSEVM_WRAP_DECL(toInt32)
OSEVM_WRAP_DECL(toFloat)
OSEVM_WRAP_DECL(toString)
OSEVM_WRAP_DECL(toBlob)
OSEVM_WRAP_DECL(appendByte)
#ifdef OSE_PROVIDE_TYPE_SYMBOL
OSEVM_WRAP_DECL(toSymbol)
#endif
#ifdef OSE_PROVIDE_TYPE_DOUBLE
OSEVM_WRAP_DECL(toDouble)
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
OSEVM_WRAP_DECL(toInt8)
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
OSEVM_WRAP_DECL(toUInt8)
#endif
#ifdef OSE_PROVIDE_TYPE_INT16
OSEVM_WRAP_DECL(toInt16)
#endif
#ifdef OSE_PROVIDE_TYPE_UINT16
OSEVM_WRAP_DECL(toUInt16)
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
OSEVM_WRAP_DECL(toUInt32)
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
OSEVM_WRAP_DECL(toInt64)
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
OSEVM_WRAP_DECL(toUInt64)
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
OSEVM_WRAP_DECL(toTimetag)
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
OSEVM_WRAP_DECL(toTrue)
#endif
#ifdef OSE_PROVIDE_TYPE_FALSE
OSEVM_WRAP_DECL(toFalse)
#endif
#ifdef OSE_PROVIDE_TYPE_NULL
OSEVM_WRAP_DECL(toNull)
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
OSEVM_WRAP_DECL(toInfinitum)
#endif

#ifdef __cplusplus
}
#endif

#endif
