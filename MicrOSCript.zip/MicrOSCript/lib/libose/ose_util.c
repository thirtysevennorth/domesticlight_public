/*
  Copyright (c) 2019-22 John MacCallum Permission is hereby granted,
  free of charge, to any person obtaining a copy of this software
  and associated documentation files (the "Software"), to deal in
  the Software without restriction, including without limitation the
  rights to use, copy, modify, merge, publish, distribute,
  sublicense, and/or sell copies of the Software, and to permit
  persons to whom the Software is furnished to do so, subject to the
  following conditions:

  The above copyright notice and this permission notice shall be
  included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
  DEALINGS IN THE SOFTWARE.
*/

#include <string.h>

#include "ose.h"
#include "ose_assert.h"
#include "ose_context.h"
#include "ose_util.h"
#include "ose_match.h"
#include "ose_errno.h"

int32_t ose_pstrlen(const char * const s)
{
    ose_assert(s);
    return ose_pnbytes(strlen(s));
}

bool ose_isAddressChar(const char c)
{
    if(c < 32)
    {
        return false;
    }
    switch(c)
    {
    case ' ':
    case '#':
    case '*':
    case ',':
        /* case '/': */
    case '?':
    case '[':
    case ']':
    case '{':
    case '}':
        return false;
    default: return true;
    }
}

bool ose_isKnownTypetag(const char typetag)
{
    switch(typetag)
    {
    case OSETT_ID:
    case OSETT_INT32:
    case OSETT_FLOAT:
    case OSETT_STRING:
    case OSETT_BLOB:
        return true;
#ifdef OSE_PROVIDE_TYPE_SYMBOL
    case OSETT_SYMBOL:
        return true;
#endif
#ifdef OSE_PROVIDE_TYPE_DOUBLE
    case OSETT_DOUBLE:
        return true;
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
    case OSETT_INT8:
        return true;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
    case OSETT_UINT8:
        return true;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
    case OSETT_UINT32:
        return true;
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
    case OSETT_INT64:
        return true;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
    case OSETT_UINT64:
        return true;
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
    case OSETT_TIMETAG:
        return true;
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
    case OSETT_TRUE:
        return true;
#endif
#ifdef OSE_PROVIDE_TYPE_FALSE
    case OSETT_FALSE:
        return true;
#endif
#ifdef OSE_PROVIDE_TYPE_NULL
    case OSETT_NULL:
        return true;
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
    case OSETT_INFINITUM:
        return true;
#endif
    default:
        return false;
    }
}

bool ose_isStringType(const char typetag)
{
    switch(typetag)
    {
    case OSETT_STRING:
#ifdef OSE_PROVIDE_TYPE_SYMBOL
    case OSETT_SYMBOL:
#endif
        return true;
    default:
        return false;
    }
}

bool ose_isIntegerType(const char typetag)
{
    switch(typetag)
    {
    case OSETT_INT32:
#ifdef OSE_PROVIDE_TYPE_INT8
    case OSETT_INT8:
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
    case OSETT_UINT8:
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
    case OSETT_UINT32:
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
    case OSETT_INT64:
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
    case OSETT_UINT64:
#endif
        return true;
    default:
        return false;
    }
}

bool ose_isFloatType(const char typetag)
{
    switch(typetag)
    {
    case OSETT_FLOAT:
#ifdef OSE_PROVIDE_TYPE_DOUBLE
    case OSETT_DOUBLE:
#endif
        return true;
    default:
        return false;
    }
}

bool ose_isNumericType(const char typetag)
{
    if(ose_isIntegerType(typetag)
       || ose_isFloatType(typetag)
#ifdef OSE_PROVIDE_TYPE_TIMETAG
       || typetag == OSETT_TIMETAG
#endif
        )
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool ose_isUnitType(const char typetag)
{
    switch(typetag)
    {
    case OSETT_TRUE:
    case OSETT_FALSE:
#ifdef OSE_PROVIDE_TYPE_NULL
    case OSETT_NULL:
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
    case OSETT_INFINITUM:
#endif
        return true;
    default:
        return false;
    }
}

bool ose_isBoolType(const char typetag)
{
    switch(typetag)
    {
    case OSETT_TRUE:
    case OSETT_FALSE:
        return true;
    default:
        return false;
    }
}

static bool isBundle(const char * const b)
{
    if(b)
    {
        if(b[0] && !strncmp(b, OSE_BUNDLE_ID, OSE_BUNDLE_ID_LEN))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }
}

/**
 * @note The underlying pointer may be NULL, in which case
 * this function will return #false.
 */
bool ose_isBundle(ose_constbundle B)
{
    return isBundle(ose_getBundlePtr(B));
}

bool ose_bundleIsEmpty(ose_constbundle B)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    {
        const int32_t s = ose_readSize(B);
        ose_assert(s >= 0);
        if(s > OSE_BUNDLE_HEADER_LEN)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
}

int32_t ose_getBundleElemCount(ose_constbundle B)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    {
        const int32_t s = ose_readSize(B);
        int32_t o = OSE_BUNDLE_HEADER_LEN;
        int32_t i = 0;
        int32_t ss = 0;
        ose_assert(s >= 0);
        while(o < s)
        {
            ss = ose_readInt32(B, o);
            ose_assert(ss > 0);
            o += ss + 4;
            ++i;
        }
        return i;
    }
}

int32_t ose_getBundleElemElemCount(ose_constbundle B,
                                   const int32_t offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= OSE_BUNDLE_HEADER_LEN);
    ose_assert(offset < ose_readSize(B));
    {
        const char * const b = ose_getBundlePtr(B);
        const char tt = ose_getBundleElemType(B, offset);
        ose_assert(tt == OSETT_BUNDLE || tt == OSETT_MESSAGE);
        if(tt == OSETT_BUNDLE)
        {
            ose_constbundle bb = ose_makeConstBundle(b + offset + 4);
            const int32_t c = ose_getBundleElemCount(bb);
            return c;
        }
        else
        {
            const int32_t tto = ose_getBundleElemTTOffset(B,
                                                          offset);
            ose_assert(tto > offset);
            ose_assert((tto - (offset + 4)) < ose_readInt32(B, offset));
            {
                const int32_t c = strlen(b + tto) - 1;
                return c;
            }
        }
    }
}

bool ose_bundleHasAtLeastNElems(ose_constbundle B,
                                const int32_t n)
{
	ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(n >= 0);
    if(n == 0)
    {
        return true;
    }
    {
        const int32_t s = ose_readSize(B);
        int32_t o = OSE_BUNDLE_HEADER_LEN;
        int32_t i = 0;
        ose_assert(s >= OSE_BUNDLE_HEADER_LEN);
        while(o < s && i < n)
        {
            const int32_t ss = ose_readInt32(B, o);
            ose_assert(ss >= 0);
            o += ss + 4;
            i++;
        }
        return i == n ? true : false;
    }
}

char ose_getBundleElemType(ose_constbundle B,
                           const int32_t offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= OSE_BUNDLE_HEADER_LEN);
    {
        const char * const b = ose_getBundlePtr(B);
        const int32_t s = ose_readSize(B); (void)s;
        ose_assert(s >= OSE_BUNDLE_HEADER_LEN);
        ose_assert(offset + 4 < s);
        if(isBundle(b + offset + 4))
        {
            return OSETT_BUNDLE;
        }
        else
        {
            return OSETT_MESSAGE;
        }
    }
}

#ifdef OSE_DEBUG
char ose_readByte(ose_constbundle B, const int32_t offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset < ose_readSize(B));
    return ose_getBundlePtr(B)[offset];
}
#endif

#ifdef OSE_DEBUG
int32_t ose_writeByte(ose_bundle B,
                      const int32_t offset,
                      const char i)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset < ose_readSize(B));
    ose_getBundlePtr(B)[offset] = i;
    return 1;
}
#endif

#ifdef OSE_DEBUG
int32_t ose_readInt32(ose_constbundle B, const int32_t offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset <= ose_readSize(B) - 4);
    return ose_ntohl(*((int32_t *)(ose_getBundlePtr(B) + offset)));
}
#endif

#ifdef OSE_DEBUG
int32_t ose_writeInt32(ose_bundle B,
                       const int32_t offset,
                       const int32_t i)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset <= ose_readSize(B) - 4);
    *((int32_t *)(ose_getBundlePtr(B) + offset)) = ose_htonl(i);
    return 4;
}
#endif

float ose_readFloat(ose_constbundle B, const int32_t offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset <= ose_readSize(B) - 4);
    {
    	const int32_t i = ose_readInt32(B, offset);
        const char * const p = (char *)&i;
        return *((float *)p);
    }
}

int32_t ose_writeFloat(ose_bundle B,
                       const int32_t offset,
                       const float f)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset <= ose_readSize(B) - 4);
    {
        const char * const p = (char *)&f;
        ose_writeInt32(B, offset, *((int32_t *)p));
        return 4;
    }
}

#ifdef OSE_DEBUG
const char *ose_readString(ose_constbundle B,
                           const int32_t offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset < ose_readSize(B));
#ifdef OSE_DEBUG
    /* if this function is ever included in non-debug builds, this
       inner block should still be removed at compile-time */
    {
        const char * const str = ose_getBundlePtr(B) + offset;
        const int32_t bs = ose_readSize(B);
    	const char * const p = memchr(str, 0, bs - offset);
        ose_assert(p && "string is not NULL-terminated");
    }
#endif 
    return ose_getBundlePtr(B) + offset;
}
#endif

#ifdef OSE_DEBUG
int32_t ose_getStringLen(ose_constbundle B,
                         const int32_t offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset < ose_readSize(B));
    {
        const char * const str = ose_getBundlePtr(B) + offset;
        const int32_t bs = ose_readSize(B);
    	const char * const p = memchr(str, 0, bs - offset);
        ose_assert(p && "string is not NULL-terminated");
        return p - str;
    }
}
#endif

#ifdef OSE_DEBUG
int32_t ose_getPaddedStringLen(ose_constbundle B,
                               const int32_t offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset < ose_readSize(B));
    {
        const char * const str = ose_getBundlePtr(B) + offset;
        const int32_t bs = ose_readSize(B);
    	const char * const p = memchr(str, 0, bs - offset);
        ose_assert(p && "string is not NULL-terminated");
        {
            const int32_t ps = ose_pnbytes(p - str);
            ose_assert(offset + ps <= bs);
            return ps;
        }
    }
}
#endif

#ifdef OSE_DEBUG
int32_t ose_writeString(ose_bundle B,
                        const int32_t offset,
                        const char * const s,
                        const int32_t len,
                        const int32_t plen)
{
    
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset <= ose_readSize(B) - plen);
    ose_assert(s);
    ose_assert(len >= 0);
    ose_assert(plen > len);
    memcpy(ose_getBundlePtr(B) + offset, s, len);
    {
        int32_t i;
        for(i = 0; i < plen - len; i++)
        {
            ose_writeByte(B, offset + len + i, 0);
        }
        return plen;
    }
}
#endif

#ifdef OSE_DEBUG
const char *ose_readBlob(ose_constbundle B, const int32_t offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset <= ose_readSize(B) - 4);
    return ose_getBundlePtr(B);
}

int32_t ose_readBlobSize(ose_constbundle B, const int32_t offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset <= ose_readSize(B) - 4);
    return ose_readInt32(B, offset);
}
#endif

int32_t ose_getBlobPaddingForNBytes(const int32_t n)
{
    ose_assert(n >= 0);
    {
        const int32_t nm4 = n % 4;
        if(nm4 != 0)
        {
            const int32_t r = 4 - (nm4);
            ose_assert(r >= 0);
            return r;
        }
        else
        {
        	return 0;
        }
    }
}

int32_t ose_getPaddedBlobSize(ose_constbundle B,
                              const int32_t offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset <= ose_readSize(B) - 4);
    {
        int32_t s = ose_readBlobSize(B, offset);
        ose_assert(s >= 0);
        {
            const int32_t sm4 = s % 4;
            if(sm4 != 0)
            {
                const int32_t r = s + 4 - sm4;
                ose_assert(r >= 0);
                return r;
            }
            else
            {
                return s;
            }
        }
    }
}

const char *ose_readBlobPayload(ose_constbundle B,
                                const int32_t offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset <= ose_readSize(B) - 4);
    ose_assert(ose_readInt32(B, offset) > 0);
    return ose_getBundlePtr(B) + offset + 4;
}

int32_t ose_writeBlob(ose_bundle B,
                      const int32_t offset,
                      const int32_t blobsize,
                      const char * const blob)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(blobsize >= 0);
    ose_assert(offset <= ose_readSize(B) -
               (blobsize + ose_getBlobPaddingForNBytes(blobsize) + 4));
    ose_assert(blob || !blob);
    {
        int32_t o = offset;
        o += ose_writeInt32(B, o, blobsize);
        if(blobsize == 0)
        {
            return 4;
        }
        if(blob)
        {
            memcpy(ose_getBundlePtr(B) + o, blob, blobsize);
        }
        else
        {
            memset(ose_getBundlePtr(B) + o, 0, blobsize);
        }
        o += blobsize;
        while(o % 4)
        {
            ose_writeByte(B, o, 0);
            o++;
        }
        return o - offset;
    }
}

#ifdef OSE_PROVIDE_TYPE_DOUBLE
double ose_readDouble(ose_constbundle B, const int32_t offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset <= ose_readSize(B) - 8);
    const char * const b = ose_getBundlePtr(B) + offset;
    const int64_t i = ose_ntohll(*((int64_t *)b));
    return *((double *)&i);
}

int32_t ose_writeDouble(ose_bundle B,
                        const int32_t offset,
                        const double f)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset <= ose_readSize(B) - 8);
    char *b = ose_getBundlePtr(B) + offset;
    const int64_t i = *((int64_t *)&f);
    *((int64_t *)b) = ose_htonll(i);
    return 8;
}
#endif

#ifdef OSE_PROVIDE_TYPE_UINT32
uint32_t ose_readUInt32(ose_constbundle B, const int32_t offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset <= ose_readSize(B) - 4);
    return ose_ntohl(*((uint32_t *)(ose_getBundlePtr(B) + offset)));
}

int32_t ose_writeUInt32(ose_bundle B,
                        const int32_t offset,
                        const uint32_t i)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset <= ose_readSize(B) - 4);
    *((uint32_t *)(ose_getBundlePtr(B) + offset)) = ose_htonl(i);
    return 4;
}
#endif

#ifdef OSE_PROVIDE_TYPE_INT64
int64_t ose_readInt64(ose_constbundle B, const int32_t offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset <= ose_readSize(B) - 8);
    return ose_ntohll(*((int64_t *)(ose_getBundlePtr(B) + offset)));
}

int32_t ose_writeInt64(ose_bundle B,
                       const int32_t offset,
                       const int64_t i)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset <= ose_readSize(B) - 8);
    *((int64_t *)(ose_getBundlePtr(B) + offset)) = ose_htonl(i);
    return 8;
}
#endif

#ifdef OSE_PROVIDE_TYPE_UINT64
uint64_t ose_readUInt64(ose_constbundle B, const int32_t offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset <= ose_readSize(B) - 8);
    return ose_ntohll(*((uint64_t *)(ose_getBundlePtr(B) +
                                     offset)));
}

int32_t ose_writeUInt64(ose_bundle B,
                        const int32_t offset,
                        const uint64_t i)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset <= ose_readSize(B) - 8);
    *((uint64_t *)(ose_getBundlePtr(B) + offset)) = ose_htonl(i);
    return 8;
}
#endif

struct ose_timetag ose_readTimetag(ose_constbundle B,
                                   const int32_t offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset <= ose_readSize(B) - 8);
    {
        const char * const b = ose_getBundlePtr(B) + offset;
        struct ose_timetag tt =
            {
                ose_ntohl(*((uint32_t *)b)),
                ose_ntohl(*((uint32_t *)(b + 4)))
            };
        return tt;
    }
}

int32_t ose_writeTimetag(ose_bundle B,
                         const int32_t offset,
                         const uint32_t sec,
                         const uint32_t fsec)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(offset <= ose_readSize(B) - 8);
    char *b = ose_getBundlePtr(B) + offset;
    *((uint32_t *)b) = ose_htonl(sec);
    *((uint32_t *)(b + 4)) = ose_htonl(fsec);
    return 8;
}

const void *ose_readAlignedPtr(ose_constbundle B,
                               const int32_t offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(OSE_INTPTR2 == sizeof(intptr_t) * 2);
    ose_assert(offset <= ose_readSize(B) - OSE_INTPTR2);
    {
        const char * const b = ose_getBundlePtr(B) + offset;
        const int32_t alignment = ose_readInt32(B, offset);
        const intptr_t i = *((intptr_t *)(b + 4 + alignment));
        return (void *)i;
    }
}

int32_t ose_writeAlignedPtr(ose_bundle B,
                            const int32_t offset,
                            const void *ptr)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(OSE_INTPTR2 == sizeof(intptr_t) * 2);
    ose_assert(offset <= ose_readSize(B) - OSE_INTPTR2);
    {
        int32_t a = 0;
        char *b = ose_getBundlePtr(B);
        b += offset;
        memset(b, 0, OSE_INTPTR2);
        while((uintptr_t)(b + 4 + a) % sizeof(intptr_t))
        {
            a++;
        }
        *((int32_t *)b) = ose_htonl(a);
        *((intptr_t *)(b + 4 + a)) = (intptr_t)ptr;
        return OSE_INTPTR2;
    }
}

void ose_alignPtr(ose_bundle B, const int32_t offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(offset >= 0);
    ose_assert(OSE_INTPTR2 == sizeof(intptr_t) * 2);
    ose_assert(offset <= ose_readSize(B) - OSE_INTPTR2);
    {
        char * const b = ose_getBundlePtr(B) + offset;
        const int32_t aold = ose_readInt32(B, offset);
        int32_t anew = 0;
        while((uintptr_t)(b + 4 + anew) % sizeof(intptr_t))
        {
            anew++;
        }
        if(anew != aold)
        {
            *((int32_t *)b) = ose_htonl(anew);
            memmove(b + 4 + anew, b + 4 + aold, sizeof(intptr_t));
        }
    }
}

void ose_dropAtOffset(ose_bundle B, int32_t offset)
{
    char *b;
    ose_assert(ose_isBundle(B));
    ose_assert(ose_bundleHasAtLeastNElems(B, 1));
    b = ose_getBundlePtr(B);
    ose_assert(b);
    ose_assert(offset >= OSE_BUNDLE_HEADER_LEN);
    ose_assert(offset < ose_readSize(B));
    ose_assert(offset % 4 == 0);
    {
        int32_t s = ose_readInt32(B, offset);
        ose_assert(s >= 4);
        ose_assert(offset + s + 4 == ose_readSize(B));
        memset(b + offset, 0, s + 4);
        ose_decSize(B, (s + 4));
    }
}

int32_t ose_getLastBundleElemOffset(ose_constbundle B)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(ose_readSize(B) >= OSE_BUNDLE_HEADER_LEN);
    {
        const int32_t bs = ose_readSize(B);
        if(bs == OSE_BUNDLE_HEADER_LEN)
        {
            return OSE_BUNDLE_HEADER_LEN;
        }
        {
            int32_t o = OSE_BUNDLE_HEADER_LEN;
            int32_t s = ose_readInt32(B, o);
            ose_assert(s >= 0);
            ose_assert(o + s + 4 <= bs);
            while(o + s + 4 < bs)
            {
                o += s + 4;
                s = ose_readInt32(B, o);
                ose_assert(s >= 0);
                ose_assert(o + s + 4 <= bs);
            }
            return o;
        }
    }
}

int32_t ose_getBundleElemAddressOffset(ose_constbundle B,
                                       const int32_t elemoffset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(elemoffset >= OSE_BUNDLE_HEADER_LEN);
    ose_assert(elemoffset < ose_readSize(B) - (4 + OSE_ADDRESS_MIN_PLEN));
    ose_assert(ose_readInt32(B, elemoffset) > 0);
    return elemoffset + 4;
}

int32_t ose_getBundleElemTTOffset(ose_constbundle B,
                                  const int32_t elemoffset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(elemoffset >= OSE_BUNDLE_HEADER_LEN);
    {
        const int32_t ao = ose_getBundleElemAddressOffset(B,
                                                          elemoffset);
        const int32_t to = ao + ose_getPaddedStringLen(B, ao);
        ose_assert(to <= ose_readSize(B) - 4);
        ose_assert(to - elemoffset < ose_readInt32(B, elemoffset) + 4);
        return to;
    }
}

int32_t ose_getBundleElemPayloadOffset(ose_constbundle B,
                                       const int32_t elemoffset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(elemoffset >= OSE_BUNDLE_HEADER_LEN);
    {
        const int32_t to = ose_getBundleElemTTOffset(B, elemoffset);
        int32_t po = 0;
        if(ose_getBundleElemType(B, elemoffset) == OSETT_BUNDLE)
        {
            po = to + OSE_TIMETAG_LEN;
        }
        else
        {
            po = to + ose_getPaddedStringLen(B, to);
        }
        ose_assert(po < ose_readSize(B));
        ose_assert(po - elemoffset < ose_readInt32(B, elemoffset) + 4);
        return po;
    }
}

int32_t ose_getFirstOffsetForMatch(ose_constbundle B,
                                   const char * const addr)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(addr);
    {
        const char * const b = ose_getBundlePtr(B);
        int32_t o = OSE_BUNDLE_HEADER_LEN;
        const int32_t s = ose_readSize(B);
        ose_assert(s >= OSE_BUNDLE_HEADER_LEN);
        while(o < s)
        {
            const int32_t ss = ose_readInt32(B, o);
            ose_assert(ss > 0);
            if(!strcmp(b + o + 4, addr))
            {
                return o;
            }
            o += ss + 4;
        }
        return 0;
    }
}

int32_t ose_getFirstOffsetForPMatch(ose_constbundle B,
                                    const char * const addr)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(addr);
    {
        const char * const b = ose_getBundlePtr(B);
        int32_t o = OSE_BUNDLE_HEADER_LEN;
        const int32_t s = ose_readSize(B);
        ose_assert(s >= OSE_BUNDLE_HEADER_LEN);
        while(o < s)
        {
            const int32_t ss = ose_readInt32(B, o);
            int po, ao;
            int r = 0;
            ose_assert(ss > 0);
            r = ose_match_pattern(b + o + 4, addr, &po, &ao);
            if(r & OSE_MATCH_ADDRESS_COMPLETE)
            {
                return o;
            }
            o += ss + 4;
        }
        return 0;
    }
}

int32_t ose_getFirstOffsetForFullPMatch(ose_constbundle B,
                                        const char * const addr)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(addr);
    {
        const char * const b = ose_getBundlePtr(B);
        int32_t o = OSE_BUNDLE_HEADER_LEN;
        const int32_t s = ose_readSize(B);
        ose_assert(s >= OSE_BUNDLE_HEADER_LEN);
        while(o < s)
        {
            const int32_t ss = ose_readInt32(B, o);
            int po, ao;
            int r = 0;
            ose_assert(ss > 0);
			r = ose_match_pattern(b + o + 4, addr, &po, &ao);
            if(r & OSE_MATCH_ADDRESS_COMPLETE
               && r & OSE_MATCH_PATTERN_COMPLETE)
            {
                return o;
            }
            o += ss + 4;
        }
        return 0;
    }
}

int32_t ose_getPayloadItemSize_hook(ose_constbundle B,
                                    const char typetag,
                                    const int32_t msg_offset,
                                    const int32_t item_offset)
{
    return -1;
}

int32_t ose_getPayloadItemSize(ose_constbundle B,
                               const char typetag,
                               const int32_t msg_offset,
                               const int32_t item_offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    /* ose_assert(ose_isKnownTypetag(typetag)); */
    ose_assert(item_offset >= OSE_BUNDLE_HEADER_LEN);
    ose_assert(item_offset < ose_readSize(B));
    const char * const ptr = ose_getBundlePtr(B) + item_offset;
    switch(typetag)
    {
    case OSETT_ID:
#ifdef OSE_PROVIDE_TYPE_TRUE
    case OSETT_TRUE:
#endif
#ifdef OSE_PROVIDE_TYPE_FALSE
    case OSETT_FALSE:
#endif
#ifdef OSE_PROVIDE_TYPE_NULL
    case OSETT_NULL:
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
    case OSETT_INFINITUM:
#endif
        return 0;
    case OSETT_INT32:
    case OSETT_FLOAT:
#ifdef OSE_PROVIDE_TYPE_INT8
    case OSETT_INT8:
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
    case OSETT_UINT8:
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
    case OSETT_UINT32:
#endif
        return 4;
    case OSETT_STRING:
#ifdef OSE_PROVIDE_TYPE_SYMBOL
    case OSETT_SYMBOL:
#endif
        ose_assert(ptr);
        return ose_pstrlen(ptr);
    case OSETT_BLOB:
        ose_assert(ptr);
        {
            int32_t s = ose_ntohl(*((int32_t *)ptr));
            while(s % 4)
            {
                s++;
            }
            return s + 4;
        }
#ifdef OSE_PROVIDE_TYPE_DOUBLE
    case OSETT_DOUBLE:
        return 8;
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
    case OSETT_INT64:
        return 8;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
    case OSETT_UINT64:
        return 8;
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
    case OSETT_TIMETAG:
        return 8;
#endif
    default:
        return OSE_GETPAYLOADITEMSIZE_HOOK(B,
                                           typetag,
                                           msg_offset,
                                           item_offset);
    }
}

int32_t ose_getPayloadItemLength_hook(ose_constbundle B,
                                      const char typetag,
                                      const int32_t msg_offset,
                                      const int32_t item_offset)
{
    return -1;
}

int32_t ose_getPayloadItemLength(ose_constbundle B,
                                 const char typetag,
                                 const int32_t msg_offset,
                                 const int32_t item_offset)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    /* ose_assert(ose_isKnownTypetag(typetag)); */
    ose_assert(item_offset >= OSE_BUNDLE_HEADER_LEN);
    ose_assert(item_offset < ose_readSize(B));
    const char * const ptr = ose_getBundlePtr(B) + item_offset;
    switch(typetag)
    {
    case OSETT_ID:
#ifdef OSE_PROVIDE_TYPE_TRUE
    case OSETT_TRUE:
#endif
#ifdef OSE_PROVIDE_TYPE_FALSE
    case OSETT_FALSE:
#endif
#ifdef OSE_PROVIDE_TYPE_NULL
    case OSETT_NULL:
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
    case OSETT_INFINITUM:
#endif
        return 0;
    case OSETT_INT32:
    case OSETT_FLOAT:
#ifdef OSE_PROVIDE_TYPE_INT8
    case OSETT_INT8:
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
    case OSETT_UINT8:
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
    case OSETT_UINT32:
#endif
        return 4;
    case OSETT_STRING:
#ifdef OSE_PROVIDE_TYPE_SYMBOL
    case OSETT_SYMBOL:
#endif
        ose_assert(ptr);
        return strlen(ptr);
    case OSETT_BLOB:
        ose_assert(ptr);
        {
            const int32_t s = ose_ntohl(*((int32_t *)ptr));
            return s;
        }
#ifdef OSE_PROVIDE_TYPE_DOUBLE
    case OSETT_DOUBLE:
        return 8;
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
    case OSETT_INT64:
        return 8;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
    case OSETT_UINT64:
        return 8;
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
    case OSETT_TIMETAG:
        return 8;
#endif
    default:
        return OSE_GETPAYLOADITEMLENGTH_HOOK(B,
                                             typetag,
                                             msg_offset,
                                             item_offset);
    }
}

/* n = 1 => rightmost item */
void ose_getNthPayloadItem(ose_constbundle B,
                           const int32_t n,
                           const int32_t msg_offset,
                           int32_t *typetags_offset,
                           int32_t *num_typetags,
                           int32_t *last_typetag_offset,
                           int32_t *payload_offset,
                           int32_t *last_payload_item_offset)
{
    const int32_t o = msg_offset;
    int32_t to, ntt, po, i;
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(n > 0);
    ose_assert(o >= OSE_BUNDLE_HEADER_LEN);
    ose_assert(ose_readSize(B) > OSE_BUNDLE_HEADER_LEN);
    ose_assert(ose_readInt32(B, o) > 0);
    ose_assert(ose_readInt32(B, o) + 4 <= ose_readSize(B));
    to = o + 4 + ose_getPaddedStringLen(B, o + 4);
    ose_assert(to - o <= ose_readInt32(B, o));

    /* first typetag is the typetag id ',' */
    ntt = ose_getStringLen(B, to);
    ose_assert(ntt > n);

    po = to + ose_pnbytes(ntt);
    ose_assert(po - o <= ose_readInt32(B, o));
    
    *typetags_offset = to;
    *payload_offset = po;
    *num_typetags = ntt;
    for(i = 0; i < ntt - n; i++)
    {
        const char c = ose_readByte(B, to);
        // ose_assert(ose_isKnownTypetag(c));
        {
            const int32_t s = ose_getPayloadItemSize(B, c, o, po);
            ose_assert(s >= 0);
            po += s;
            to++;
            ose_assert(po - (o + 4) < ose_readInt32(B, o));
            ose_assert(to < po);
        }
    }
    ose_assert(to < o + ose_readSize(B));
    ose_assert(po < o + ose_readSize(B));
    *last_typetag_offset = to;
    *last_payload_item_offset = po;
}

/**
 * @todo Implement default case for unknown type.
 */
int32_t ose_vcomputeMessageSize(ose_bundle B,
                                const char * const address,
                                const int32_t addresslen,
                                const int32_t n,
                                va_list ap)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(address);
    ose_assert(addresslen >= 0);
    ose_assert(n >= 0);
    {
        const int32_t alenp = ose_pnbytes(addresslen);
        int32_t i;
        char tt;
        int32_t newmsg_size = alenp;
        int32_t newmsg_numtypetags = 1;
        ose_assert(alenp >= OSE_ADDRESS_MIN_PLEN);

        for(i = 0; i < n; i++)
        {
            tt = va_arg(ap, int);
            ++newmsg_numtypetags;
            switch(tt)
            {
            case OSETT_INT32:
                newmsg_size += 4;
                va_arg(ap, int32_t);
                break;
            case OSETT_FLOAT:
                newmsg_size += 4;
                va_arg(ap, double);
                break;
            case OSETT_STRING:
            {
                const char * const p = va_arg(ap, char*);
                ose_assert(p);
                newmsg_size += ose_pstrlen(p);
            }
            break;
            case OSETT_BLOB:
            {
                /* no need for assertions;
                   blobs can be 0 size and NULL pointers */
                const int32_t s = va_arg(ap, int32_t);
                newmsg_size += 4 + s + ose_getBlobPaddingForNBytes(s);
                va_arg(ap, char*);
            }
            break;
            case OSETT_ALIGNEDPTR:
                va_arg(ap, ose_fn);
                newmsg_size += OSE_INTPTR2 + 4;
                break;
#ifdef OSE_PROVIDE_TYPE_DOUBLE
            case OSETT_DOUBLE:
                newmsg_size += 8;
                va_arg(ap, double);
                break;
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
            case OSETT_TIMETAG:
                newmsg_size += 8;
                va_arg(ap, int64_t);
                break;
#endif
            default:
                ose_assert(0 && "unknown typetag");
            }
        }
        newmsg_size += ose_pnbytes(newmsg_numtypetags);
        return newmsg_size + 4;
    }
}

int32_t ose_computeMessageSize(ose_bundle B,
                               const char * const address,
                               const int32_t addresslen,
                               const int32_t n,
                               ...)
{
    va_list ap;
    int32_t ms;
    va_start(ap, n);
    ms = ose_vcomputeMessageSize(B,
                                 address,
                                 addresslen,
                                 n,
                                 ap);
    va_end(ap);
    return ms;
}

/**
 * @todo Implement default case for unknown type.
 */
int32_t ose_vwriteMessage(ose_bundle B,
                          const int32_t offset,
                          const char * const address,
                          const int32_t addresslen,
                          const int32_t n,
                          va_list ap)
{
    ose_assert(ose_getBundlePtr(B));
    ose_assert(ose_isBundle(B));
    ose_assert(address);
    ose_assert(addresslen >= 0);
    ose_assert(n >= 0);
    {
        const int32_t o = offset;
        const int32_t alenp = ose_pnbytes(addresslen);
        const int32_t _tto = o + 4 + alenp;
        const int32_t _plo = _tto + ose_pnbytes(n + 1);
        int32_t tto = _tto;
        int32_t plo = _plo;
        int32_t s, i;
        char tt;
        ose_assert(alenp >= OSE_ADDRESS_MIN_PLEN);
        
        ose_writeString(B, o + 4, address, addresslen, alenp);
        ose_writeByte(B, tto++, OSETT_ID);

        if(!n)
        {
            s = plo - o;
            ose_writeInt32(B, o, s - 4);
            return s;
        }
    
        for(i = 0; i < n; i++)
        {
            tt = va_arg(ap, int);
            switch(tt)
            {
            case OSETT_INT32:
            {
                const int32_t v = va_arg(ap, int32_t);
                ose_writeByte(B, tto++, OSETT_INT32);
                plo += ose_writeInt32(B, plo, v);
                break;
            }
            case OSETT_FLOAT:
            {
                const float v = va_arg(ap, double);
                ose_writeByte(B, tto++, OSETT_FLOAT);
                plo += ose_writeFloat(B, plo, v);
                break;
            }
            case OSETT_STRING:
            {
                const char * const v = va_arg(ap, char*);
                {
                    const int32_t sl = strlen(v);
                    const int32_t psl = ose_pnbytes(sl);
                    ose_writeByte(B, tto++, OSETT_STRING);
                    plo += ose_writeString(B, plo, v, sl, psl);
                }
                break;
            }
            case OSETT_BLOB:
            {
                const int32_t len = va_arg(ap, int);
                const char * const blob = va_arg(ap, char*);
                ose_writeByte(B, tto++, tt);
                {
                    const int32_t wlen = ose_writeBlob(B,
                                                       plo,
                                                       len,
                                                       blob);
                    plo += wlen;
                }
                break;
            }
#ifdef OSE_PROVIDE_TYPE_SYMBOL
            case OSETT_SYMBOL:
            {
                const char * const v = va_arg(ap, char*);
                ose_assert(v);
                const int32_t sl = strlen(v);
                const int32_t psl = ose_pnbytes(sl);
                ose_writeByte(B, tto++, OSETT_STRING);
                plo += ose_writeString(B, plo, v, sl, psl);
                break;
            }
#endif
#ifdef OSE_PROVIDE_TYPE_DOUBLE
            case OSETT_DOUBLE:
            {
                const double v = va_arg(ap, double);
                ose_writeByte(B, tto++, OSETT_DOUBLE);
                plo += ose_writeDouble(B, plo, v);
                break;
            }
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
            case OSETT_INT8:
            {
                const int v = va_arg(ap, int);
                ose_writeByte(B, tto++, OSETT_INT8);
                plo += ose_writeInt8(B, plo, v);
                break;
            }
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
            case OSETT_UINT8:
            {
                const int v = va_arg(ap, int);
                ose_writeByte(B, tto++, OSETT_UINT8);
                plo += ose_writeUInt8(B, plo, v);
                break;
            }
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
            case OSETT_UINT32:
            {
                const uint32_t v = va_arg(ap, uint32_t);
                ose_writeByte(B, tto++, OSETT_UINT32);
                plo += ose_writeUInt32(B, plo, v);
                break;
            }
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
            case OSETT_INT64:
            {
                const int64_t v = va_arg(ap, int64_t);
                ose_writeByte(B, tto++, OSETT_INT64);
                plo += ose_writeInt64(B, plo, v);
                break;
            }
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
            case OSETT_UINT64:
            {
                const uint64_t v = va_arg(ap, uint64_t);
                ose_writeByte(B, tto++, OSETT_UINT64);
                plo += ose_writeUInt64(B, plo, v);
                break;
            }
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
            case OSETT_TIMETAG:
            {
                const int32_t sec = va_arg(ap, int32_t);
                const int32_t fsec = va_arg(ap, int32_t);
                ose_writeByte(B, tto++, OSETT_TIMETAG);
                plo += ose_writeTimetag(B, plo, sec, fsec);
                break;
            }
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
            case OSETT_TRUE:
            {
                ose_writeByte(B, tto++, OSETT_TRUE);
                break;
            }
#endif
#ifdef OSE_PROVIDE_TYPE_FALSE
            case OSETT_FALSE:
            {
                ose_writeByte(B, tto++, OSETT_FALSE);
                break;
            }
#endif
#ifdef OSE_PROVIDE_TYPE_NULL
            case OSETT_NULL:
            {
                ose_writeByte(B, tto++, OSETT_NULL);
                break;
            }
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
            case OSETT_INFINITUM:
            {
                ose_writeByte(B, tto++, OSETT_INFINITUM);
                break;
            }
#endif
            case OSETT_ALIGNEDPTR:
            {
                const ose_fn fn = va_arg(ap, ose_fn);
                ose_writeByte(B, tto++, OSETT_BLOB);
                plo += ose_writeInt32(B, plo, OSE_INTPTR2);
                plo += ose_writeAlignedPtr(B, plo, (void *)fn);
                break;
            }
            default:
                ose_assert(0 && "unknown typetag");
            }
        }

        s = plo - o;
        ose_writeInt32(B, o, s - 4);
        return s;
    }
}

int32_t ose_writeMessage(ose_bundle B,
                         const int32_t offset,
                         const char * const address,
                         const int32_t addresslen,
                         const int32_t n, ...)
{
    va_list ap;
    va_start(ap, n);
    /* int32_t len = ose_vwriteMessage(B, */
    /*                                 offset, */
    /*                                 address, */
    /*                                 addresslen, */
    /*                                 n, */
    /*                                 ap); */
    /* va_end(ap); */
    /* return len; */
    const int32_t ms = ose_vcomputeMessageSize(B,
                                               address,
                                               addresslen,
                                               n,
                                               ap);
    int32_t ms2 = 0;
    va_end(ap);
    ose_incSize(B, ms);
    va_start(ap, n);
    ms2 = ose_vwriteMessage(B,
                            offset,
                            address,
                            addresslen,
                            n,
                            ap);
    va_end(ap);
    ose_assert(ms == ms2);
    return ms;
}

#define INCP(bufp, amt) ((bufp) ? ((bufp) += (amt)) : (bufp))
#define INCL(bufp, bufl, amt) ((bufp) ? ((bufl) -= (amt)) : (bufl))

static int32_t printBoundary(ose_constbundle B,
                             const int32_t offset,
                             char *buf,
                             int32_t buflen)
{
    return snprintf(buf, buflen, "/");
}

static int32_t printBndlType(ose_constbundle B,
                             const int32_t offset,
                             char *buf,
                             int32_t buflen)
{
    return snprintf(buf, buflen, "%c", OSETT_BUNDLE);
}

static int32_t printMsgType(ose_constbundle B,
                            const int32_t offset,
                            char *buf,
                            int32_t buflen)
{
    return snprintf(buf, buflen, "%c", OSETT_MESSAGE);
}

static int32_t printElemType(ose_constbundle B,
                             const int32_t offset,
                             char *buf,
                             int32_t buflen)
{
    const char * const b = ose_getBundlePtr(B);
    if(isBundle(b + offset + 4))
    {
        return printBndlType(B, offset, buf, buflen);
    }
    else
    {
        return printMsgType(B, offset, buf, buflen);
    }
}

static int32_t printMsgTypetags(ose_constbundle B,
                                const int32_t offset,
                                char *buf,
                                int32_t buflen)
{
    int32_t msgsize = ose_readInt32(B, offset);
    int32_t tto = offset + 4 +
        ose_pstrlen(ose_readString(B, offset + 4)) + 1;
    if(tto - (offset + 4) >= msgsize)
    {
        return printBoundary(B, offset, buf, buflen);
    }
    else
    {
        const char * const b = ose_getBundlePtr(B);
        return snprintf(buf, buflen, "/%s", b + tto);
    }
}

int32_t ose_printTypeof0(ose_constbundle B,
                         const int32_t offset,
                         char *buf,
                         int32_t buflen)
{
    ose_assert(ose_isBundle(B));
    /* ose_assert(offset >= 0); */
    /* ose_assert(buf); */
    /* ose_assert(buflen); */
    int32_t nn = 0;
    int32_t n = printBoundary(B, offset, buf, buflen);
    INCP(buf, n);
    INCL(buf, buflen, n);
    nn += n;
    if(ose_readSize(B) <= OSE_BUNDLE_HEADER_LEN)
    {
        return nn + printBndlType(B, offset, buf, buflen);
    }
    if(ose_readSize(B) > OSE_BUNDLE_HEADER_LEN)
    {
    	n = printElemType(B, offset, buf, buflen);
    	nn += n;
    }
    return nn;
}

int32_t ose_printTypeof1(ose_constbundle B,
                         const int32_t offset,
                         char *buf,
                         int32_t buflen)
{
    ose_assert(ose_isBundle(B));
    /* ose_assert(offset >= 0); */
    /* ose_assert(buf); */
    /* ose_assert(buflen); */
    const char * const b = ose_getBundlePtr(B);
    int32_t nn = 0;
    int32_t n = printBoundary(B, offset, buf, buflen);
    INCP(buf, n);
    INCL(buf, buflen, n);
    nn += n;
    if(ose_readSize(B) <= OSE_BUNDLE_HEADER_LEN)
    {
        return nn + printBndlType(B, offset, buf, buflen);
    }
    if(isBundle(b + offset + 4))
    {
        n = printBndlType(B, offset, buf, buflen);
        INCP(buf, n);
        INCL(buf, buflen, n);
        nn += n;

        /* int32_t size = ose_readInt32(B, offset); */
        /* offset could be negative if this is a context bundle */
        int32_t size = ose_ntohl(*((int32_t *)(b + offset)));
        int32_t o = offset + 4 + OSE_BUNDLE_HEADER_LEN;

        if(size >= OSE_BUNDLE_HEADER_LEN)
        {
            n = printBoundary(B, offset, buf, buflen);
            INCP(buf, n);
            INCL(buf, buflen, n);
            nn += n;
        }
        while(o < offset + size + 4)
        {
            n = printElemType(B, o, buf, buflen);
            INCP(buf, n);
            INCL(buf, buflen, n);
            nn += n;
            o += ose_readInt32(B, o) + 4;
        }
    }
    else
    {
        n = printMsgType(B, offset, buf, buflen);
        INCP(buf, n);
        INCL(buf, buflen, n);
        nn += n;
        n = printMsgTypetags(B, offset, buf, buflen);
        INCP(buf, n);
        INCL(buf, buflen, n);
        nn += n;
    }
    return nn;
}

int32_t ose_printTypeof2(ose_constbundle B,
                         const int32_t offset,
                         char *buf,
                         int32_t buflen)
{
    ose_assert(ose_isBundle(B));
    /* ose_assert(offset >= 0); */
    /* ose_assert(buf); */
    /* ose_assert(buflen); */
    const char * const b = ose_getBundlePtr(B);
    int32_t nn = 0;
    int32_t n = printBoundary(B, offset, buf, buflen);
    INCP(buf, n);
    INCL(buf, buflen, n);
    nn += n;
    if(ose_readSize(B) <= OSE_BUNDLE_HEADER_LEN)
    {
        return nn + printBndlType(B, offset, buf, buflen);
    }
    if(isBundle(b + offset + 4))
    {
        n = printBndlType(B, offset, buf, buflen);
        INCP(buf, n);
        INCL(buf, buflen, n);
        nn += n;
        /* int32_t size = ose_readInt32(B, offset); */
        /* offset could be negative if this is a context bundle */
        int32_t size = ose_ntohl(*((int32_t *)(b + offset)));
        int32_t o = offset + 4 + OSE_BUNDLE_HEADER_LEN;
        while(o < offset + size + 4)
        {
            int32_t s = ose_readInt32(B, o);
            if(isBundle(b + o + 4))
            {
                n = ose_printTypeof0(B, o, buf, buflen);
                INCP(buf, n);
                INCL(buf, buflen, n);
                nn += n;
                n = printBoundary(B, offset, buf, buflen);
                INCP(buf, n);
                INCL(buf, buflen, n);
                nn += n;                
                int32_t oo = o + 4 + OSE_BUNDLE_HEADER_LEN;
                while(oo < o + s + 4)
                {
                    n = printElemType(B, oo, buf, buflen);
                    INCP(buf, n);
                    INCL(buf, buflen, n);
                    nn += n;
                    oo += ose_readInt32(B, oo) + 4;
                }
            }
            else
            {
                n = ose_printTypeof0(B, o, buf, buflen);
                INCP(buf, n);
                INCL(buf, buflen, n);
                nn += n;
                n = printMsgTypetags(B, o, buf, buflen);
                INCP(buf, n);
                INCL(buf, buflen, n);
                nn += n;
            }
            o += s + 4;
        }
    }
    else
    {
        n = printMsgType(B, offset, buf, buflen);
        INCP(buf, n);
        INCL(buf, buflen, n);
        nn += n;
        n = printMsgTypetags(B, offset, buf, buflen);
        INCP(buf, n);
        INCL(buf, buflen, n);
        nn += n;
    }
    return nn;
}

int ose_typechk0(ose_constbundle B,
                 const char * const pattern)
{
    ose_assert(ose_isBundle(B));
    ose_assert(pattern);
    char address[256];
    memset(address, 0, 256);
    int32_t o = -4;//ose_getLastBundleElemOffset(B);
    int32_t r, ao, po;
    ose_printTypeof0(B, o, address, 256);
    r = ose_match_pattern(pattern, address, &po, &ao);
    if(r == OSE_MATCH_BOTH_COMPLETE)
    {
        return OSE_ERR_NONE;
    }
    else if(r == OSE_MATCH_ADDRESS_COMPLETE)
    {
        return OSE_ERR_NONE;
    }
    else if(r == OSE_MATCH_PATTERN_COMPLETE)
    {
        /* this would mean that the pattern was just /, and
         * probably won't happen. assert here to catch in
         * debugging */
        ose_assert(0);
        return OSE_ERR_TYPE;
    }
    else
    {
        return OSE_ERR_ELEM_TYPE;
    }
}

int ose_typechk1(ose_constbundle B,
                 const char * const pattern)
{
    ose_assert(ose_isBundle(B));
    ose_assert(pattern);
    char address[256];
    memset(address, 0, 256);
    int32_t o = -4;//ose_getLastBundleElemOffset(B);
    int32_t r, ao, po;
    ose_printTypeof1(B, o, address, 256);
    r = ose_match_pattern(pattern, address, &po, &ao);
    if(r == OSE_MATCH_BOTH_COMPLETE)
    {
        return OSE_ERR_NONE;
    }
    /* if(r == OSE_MATCH_ADDRESS_COMPLETE */
    /*    || address[ao] == 0) */
    /* { */
    /*     /\*  */
    /*        this means the pattern was expecting something */
    /*        that's not there */
    /*     *\/ */
    /*     return OSE_ERR_ELEM_COUNT; */
    /* } */
    /* if(r == OSE_MATCH_PATTERN_COMPLETE */
    /*    || pattern[po] == 0) */
    /* { */
    /*     /\*  */
    /*        this means there's something there that the */
    /*        pattern is not expecting */
    /*     *\/ */
    /*     return OSE_ERR_ELEM_COUNT; */
    /* } */
    /* if(ao > 1) */
    /* { */
    /*     if(address[1] == OSETT_BUNDLE) */
    /*     { */
    /*         return OSE_ERR_ELEM_TYPE; */
    /*     } */
    /*     else */
    /*     { */
    /*         return OSE_ERR_ITEM_TYPE; */
    /*     } */
    /* } */
    /* if(ao == 1) */
    /* { */
    /*     /\*  */
    /*        this means the bundle itself is the wrong type */
    /*     *\/ */
    /*     ose_assert(0); */
    /*     return OSE_ERR_ELEM_TYPE; */
    /* } */

    return OSE_ERR_TYPE;
}

int ose_typechk2(ose_constbundle B,
                 const char * const pattern)
{
    int32_t r, ao, po;
    char address[256];
    char a = 0, p = 0;
    ose_assert(ose_isBundle(B));
    ose_assert(pattern);
    memset(address, 0, 256);
    ose_printTypeof2(B, -4, address, 256);
    ose_assert(address[0] == '/');
    ose_assert(address[1] == '|');
    r = ose_match_pattern(pattern, address, &po, &ao);
    if(r == OSE_MATCH_BOTH_COMPLETE)
    {
        return OSE_ERR_NONE;
    }
    return OSE_ERR_TYPE;
}

struct ose_SLIPBuf ose_initSLIPBuf(unsigned char *buf,
                                   int32_t buflen)
{
    ose_assert(buf);
    ose_assert(buflen);
    {
        struct ose_SLIPBuf sb;
        memset(buf, 0, buflen);
        sb.buf = buf;
        sb.buflen = buflen;
        sb.count = sb.state = 0;
        return sb;
    }
}

int ose_SLIPDecode(unsigned char c, struct ose_SLIPBuf *s)
{
    int state = s->state;
    switch(state)
    {
    case 0:
        s->state = 1;
        if(c == OSE_SLIP_END)
        {
            break;
        }
        /* fall through */
    case 1:
        switch(c)
        {
        case OSE_SLIP_END:
            if(s->count > 0)
            {
                s->state = 0;
                if(s->count % 4 == 0)
                {
                    return 0; /* done */
                }
                else
                {
                    return -1; /* error */
                }
            }
            s->state = 0;
            break;
        case OSE_SLIP_ESC:
            s->state = 2;
            break;
        case 10:
        case 13:
            if(s->havenullbyte == 0)
            {
                /* s->buf[s->count++] = c; */
                s->count++;
                while(s->count % 4)
                {
                    s->count++;
                }
                s->buf[s->count] = OSETT_ID;
                s->count += 4;
                return 0;
            }
            else
            {
                /* fall through */
            }
        case 0:
            s->havenullbyte = 1;
        default:
            if(s->count < s->buflen)
            {
                s->buf[(s->count)++] = c;
            }
            else
            {
                s->state = 3;
            }
            break;
        }
        break;
    case 2:
        switch(c)
        {
        case OSE_SLIP_ESC_END:
            if(s->count < s->buflen)
            {
                s->buf[(s->count)++] = OSE_SLIP_END;
                s->state = 1;
            }
            else
            {
                s->state = 3;
            }
            break;
        case OSE_SLIP_ESC_ESC:
            if(s->count < s->buflen)
            {
                s->buf[(s->count)++] = OSE_SLIP_ESC;
                s->state = 1;
            }
            else
            {
                s->state = 3;
            }
            break;
        default:
            s->state = 3;
        }
        break;
    case 3:
        if(c == OSE_SLIP_END)
        {
            s->count = 0;
            s->state = 0;
        }
        break;
    }
    return 1;
}

/* -1 error */
/* >0 length */
int32_t ose_SLIPEncode(const unsigned char * const src,
                       int32_t srclen,
                       unsigned char *dest,
                       int32_t destlen)
{
    int32_t j = 0, i = 0;
    if(!dest)
    {
        return -1;
    }
    for( ; i < srclen; i++)
    {
        switch(src[i])
        {
        case OSE_SLIP_END:
            if(j + 2 > destlen)
            {
                return -1;
            }
            dest[j++] = OSE_SLIP_ESC;
            dest[j++] = OSE_SLIP_ESC_END;
            break;
        case OSE_SLIP_ESC:
            if(j + 2 > destlen)
            {
                return -1;
            }
            dest[j++] = OSE_SLIP_ESC;
            dest[j++] = OSE_SLIP_ESC_ESC;
            break;
        default:
            if(j + 1 > destlen)
            {
                return -1;
            }
            dest[j++] = src[i];
        }
    }
    if(j + 1 > destlen)
    {
        return -1;
    }
    dest[j++] = OSE_SLIP_END;
    return j;
}
