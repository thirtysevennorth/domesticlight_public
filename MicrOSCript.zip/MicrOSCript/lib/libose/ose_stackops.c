/*
  Copyright (c) 2019-22 John MacCallum Permission is hereby
  granted, free of charge, to any person obtaining a copy of this
  software and associated documentation files (the "Software"), to
  deal in the Software without restriction, including without
  limitation the rights to use, copy, modify, merge, publish,
  distribute, sublicense, and/or sell copies of the Software, and
  to permit persons to whom the Software is furnished to do so,
  subject to the following conditions:

  The above copyright notice and this permission notice shall be
  included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
  OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
  OTHER DEALINGS IN THE SOFTWARE.
*/

#include <string.h>
#include <stdarg.h>
#include <setjmp.h>
#include <math.h>

#include "ose.h"
#include "ose_context.h"
#include "ose_stackops.h"
#include "ose_util.h"
#include "ose_assert.h"
#include "ose_match.h"
#include "ose_errno.h"

#define ose_readInt32_outOfBounds(b, o)                     \
    ose_ntohl(*((int32_t *)(ose_getBundlePtr((b)) + (o))))
#define ose_writeInt32_outOfBounds(b, o, i)                         \
    *((int32_t *)(ose_getBundlePtr((b)) + (o))) = ose_htonl((i))

static void ose_drop_impl(ose_bundle B, int32_t o, int32_t s);
static void ose_dup_impl(ose_bundle B, int32_t o, int32_t s);
static void ose_swap_impl(ose_bundle B,
                          int32_t offset_nm1,
                          int32_t size_nm1,
                          int32_t offset_n,
                          int32_t size_n);
static void ose_rot_impl(ose_bundle B,
                         int32_t onm2,
                         int32_t snm2,
                         int32_t onm1,
                         int32_t snm1,
                         int32_t on,
                         int32_t sn);
static void ose_rrot_impl(ose_bundle B,
                          int32_t onm2,
                          int32_t snm2,
                          int32_t onm1,
                          int32_t snm1,
                          int32_t on,
                          int32_t sn);
static void ose_over_impl(ose_bundle B,
                          int32_t onm1,
                          int32_t snm1,
                          int32_t on,
                          int32_t sn);
void be1(ose_bundle B, int32_t *on, int32_t *sn);
void be2(ose_bundle B,
         int32_t *onm1,
         int32_t *snm1,
         int32_t *on,
         int32_t *sn);
void be3(ose_bundle B,
         int32_t *onm2,
         int32_t *snm2,
         int32_t *onm1,
         int32_t *snm1,
         int32_t *on,
         int32_t *sn);
void be4(ose_bundle B,
         int32_t *onm3,
         int32_t *snm3,
         int32_t *onm2,
         int32_t *snm2,
         int32_t *onm1,
         int32_t *snm1,
         int32_t *on,
         int32_t *sn);

/**************************************************
 * C API
 **************************************************/

static void pushInt32(ose_bundle B, int32_t i, char typetag)
{
    ose_assert(ose_isBundle(B));
    ose_assert(typetag != OSETT_ID);
    const int32_t o = ose_readSize(B);
    ose_assert(o >= OSE_BUNDLE_HEADER_LEN);
    char *b = ose_getBundlePtr(B);
    ose_assert(b);
    const int32_t n = 4 + OSE_ADDRESS_ANONVAL_SIZE + 4 + 4;
    ose_incSize(B, n);
    char *ptr = b + o;
    memset(ptr, 0, n);
    *((int32_t *)ptr) = ose_htonl(n - 4);
    ptr += 4;
    memcpy(ptr, OSE_ADDRESS_ANONVAL, OSE_ADDRESS_ANONVAL_SIZE);
    ptr += OSE_ADDRESS_ANONVAL_SIZE;
    *ptr++ = OSETT_ID;
    *ptr++ = typetag;
    *ptr++ = '\0';
    *ptr++ = '\0';
    *((int32_t *)ptr) = ose_htonl(i);
    ose_assert(ptr - (b + o) < n);
}

/**
 * @f$\fnpushtype{PUSHINT32}{\tti}@f$
 */
void ose_pushInt32(ose_bundle B, int32_t i)
{
    pushInt32(B, i, OSETT_INT32);
}

/**
 * @f$\fnpushtype{PUSHFLOAT}{\ttf}@f$
 */
void ose_pushFloat(ose_bundle B, float f)
{
    char *p = (char *)&f;
    int32_t i = *((int32_t *)p);
    pushInt32(B, i, OSETT_FLOAT);
}

static void pushString(ose_bundle B,
                       const char * const s,
                       char typetag)
{
    ose_assert(ose_isBundle(B));
    ose_assert(s);
    ose_assert(typetag != OSETT_ID);
    char *b = ose_getBundlePtr(B);
    const int32_t o = ose_readSize(B);
    ose_assert(o >= OSE_BUNDLE_HEADER_LEN);
    const int32_t sl = strlen(s);
    const int32_t psl = ose_pnbytes(sl);
    const int32_t n = 4 + OSE_ADDRESS_ANONVAL_SIZE + 4 + psl;
    ose_incSize(B, n);
    char *ptr = b + o;
    memset(ptr, 0, n);
    *((int32_t *)ptr) = ose_htonl(n - 4);
    ptr += 4;
    memcpy(ptr, OSE_ADDRESS_ANONVAL, OSE_ADDRESS_ANONVAL_SIZE);
    ptr += OSE_ADDRESS_ANONVAL_SIZE;
    *ptr++ = OSETT_ID;
    *ptr++ = typetag;
    *ptr++ = '\0';
    *ptr++ = '\0';
    for(int i = 0; i < sl; i++)
    {
        *ptr++ = s[i];
    }
    ose_assert(ptr - (b + o) < n);
}

/**
 * @f$\fnpushtype{PUSHSTRING}{\tts}@f$
 */
void ose_pushString(ose_bundle B, const char * const s)
{
    pushString(B, s, OSETT_STRING);
}

/**
 * @f$\fnpushtype{PUSHBLOB}{\ttb}@f$
 */
void ose_pushBlob(ose_bundle B,
                  int32_t blobsize,
                  const char * const blob)
{
    ose_assert(ose_isBundle(B));
    ose_assert(blobsize >= 0);
    /* blob can be NULL */
    char *b = ose_getBundlePtr(B);
    const int32_t o = ose_readSize(B);
    ose_assert(o >= OSE_BUNDLE_HEADER_LEN);
    int32_t padded_blobsize = blobsize;
    while(padded_blobsize % 4)
    {
        padded_blobsize++;
    }
    const int32_t n =
        4
        + OSE_ADDRESS_ANONVAL_SIZE
        + 4
        + 4
        + padded_blobsize;
    ose_incSize(B, n);
    char *ptr = b + o;
    memset(ptr, 0, n);
    *((int32_t *)ptr) = ose_htonl(n - 4);
    ptr += 4;
    memcpy(ptr, OSE_ADDRESS_ANONVAL, OSE_ADDRESS_ANONVAL_SIZE);
    ptr += OSE_ADDRESS_ANONVAL_SIZE;
    *ptr++ = OSETT_ID;
    *ptr++ = OSETT_BLOB;
    *ptr++ = '\0';
    *ptr++ = '\0';
    *((int32_t *)ptr) = ose_htonl(blobsize);
    ptr += 4;
    if(blobsize)
    {
        ose_assert(blobsize <= n - (ptr - (b + o)));
        if(blob)
        {
            memcpy(ptr, blob, blobsize);
        }
        else
        {
            memset(ptr, 0, blobsize);
        }
        ptr += padded_blobsize;
    }
    ose_assert(ptr - (b + o) == n);
}

#ifdef OSE_PROVIDE_TYPE_SYMBOL
/**
 * @f$\fnpushtype{PUSHSYMBOL}{\ttS}@f$
 */
void ose_pushSymbol(ose_bundle B, const char * const s)
{
    pushString(B, s, OSETT_SYMBOL);
}
#endif

#if defined(OSE_PROVIDE_TYPE_DOUBLE) ||         \
    defined(OSE_PROVIDE_TYPE_INT64) ||          \
    defined(OSE_PROVIDE_TYPE_UINT64)
static void pushInt64(ose_bundle B, int64_t i, char typetag)
{
    ose_assert(ose_isBundle(B));
    ose_assert(typetag != OSETT_ID);
    char *b = ose_getBundlePtr(B);
    const int32_t o = ose_readSize(B);
    ose_assert(o >= OSE_BUNDLE_HEADER_LEN);
    const int32_t n = 4 + OSE_ADDRESS_ANONVAL_SIZE + 4 + 8;
    ose_incSize(B, n);
    char *ptr = b + o;
    memset(ptr, 0, n);
    *((int32_t *)ptr) = ose_htonl(n - 4);
    ptr += 4;
    memcpy(ptr, OSE_ADDRESS_ANONVAL, OSE_ADDRESS_ANONVAL_SIZE);
    ptr += OSE_ADDRESS_ANONVAL_SIZE;
    *ptr++ = OSETT_ID;
    *ptr++ = typetag;
    *ptr++ = '\0';
    *ptr++ = '\0';
    *((int64_t *)ptr) = ose_htonll(i);
    ose_assert(ptr - (b + o) < n);
}
#endif

#ifdef OSE_PROVIDE_TYPE_DOUBLE
/**
 * @f$\fnpushtype{PUSHDOUBLE}{\ttd}@f$
 */
void ose_pushDouble(ose_bundle B, double f)
{
    int64_t i = *((int64_t *)&f);
    pushInt64(B, i, OSETT_DOUBLE);
}
#endif

#ifdef OSE_PROVIDE_TYPE_INT8
/**
 * @f$\fnpushtype{PUSHINT8}{\ttc}@f$
 */
void ose_pushInt8(ose_bundle B, int8_t i)
{
    pushInt32(B, i, OSETT_INT8);
}
#endif

#ifdef OSE_PROVIDE_TYPE_UINT8
/**
 * @f$\fnpushtype{PUSHUINT8}{\ttC}@f$
 */
void ose_pushUInt8(ose_bundle B, uint8_t i)
{
    pushInt32(B, i, OSETT_UINT8);
}
#endif

#ifdef OSE_PROVIDE_TYPE_UINT32
/**
 * @f$\fnpushtype{PUSHUINT32}{\ttk}@f$
 */
void ose_pushUInt32(ose_bundle B, uint32_t i)
{
    pushInt32(B, i, OSETT_UINT32);
}
#endif

#ifdef OSE_PROVIDE_TYPE_INT64
/**
 * @f$\fnpushtype{PUSHINT64}{\tth}@f$
 */
void ose_pushInt64(ose_bundle B, int64_t i)
{
    pushInt64(B, i, OSETT_INT64);
}
#endif

#ifdef OSE_PROVIDE_TYPE_UINT64
/**
 * @f$\fnpushtype{PUSHUINT64}{\ttH}@f$
 */
void ose_pushUInt64(ose_bundle B, uint64_t i)
{
    pushInt64(B, i, OSETT_UINT64);
}
#endif

#ifdef OSE_PROVIDE_TYPE_TIMETAG
/**
 * @f$
 *	\fn{PUSHTIMETAG}{
 *		\BB\elems{\ldots}, sec, fsec
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\ela{K}{\type{\ttmsg(\type{\tttt})}}\items{
 *				\ita{}{\type{\tttt}}\values{
 *					sec^\prime, fsec^\prime
 *				}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_pushTimetag(ose_bundle B, uint32_t sec, uint32_t fsec)
{
    ose_assert(ose_isBundle(B));
    char *b = ose_getBundlePtr(B);
    const int32_t o = ose_readSize(B);
    ose_assert(o >= OSE_BUNDLE_HEADER_LEN);
    const int32_t n = 4 + OSE_ADDRESS_ANONVAL_SIZE + 4 + 4 + 4;
    ose_incSize(B, n);
    char *ptr = b + o;
    *((int32_t *)ptr) = ose_htonl(n - 4);
    ptr += 4;
    memcpy(ptr, OSE_ADDRESS_ANONVAL, OSE_ADDRESS_ANONVAL_SIZE);
    ptr += OSE_ADDRESS_ANONVAL_SIZE;
    *ptr++ = OSETT_ID;
    *ptr++ = OSETT_TIMETAG;
    *ptr++ = 0;
    *ptr++ = 0;
    *((int32_t *)ptr) = ose_htonl(sec);
    ptr += 4;
    *((int32_t *)ptr) = ose_htonl(fsec);
    ose_assert(ptr - (b + o) < n);
}
#endif

#if defined(OSE_PROVIDE_TYPE_TRUE)              \
    || defined(OSE_PROVIDE_TYPE_FALSE)          \
    || defined(OSE_PROVIDE_TYPE_NULL)           \
    || defined(OSE_PROVIDE_TYPE_INFINITUM)
static void pushUnitType(ose_bundle B, char typetag)
{
    ose_assert(ose_isBundle(B));
    ose_assert(typetag != OSETT_ID);
    char *b = ose_getBundlePtr(B);
    const int32_t o = ose_readSize(B);
    ose_assert(o >= OSE_BUNDLE_HEADER_LEN);
    const int32_t n = 4 + OSE_ADDRESS_ANONVAL_SIZE + 4;
    ose_incSize(B, n);
    char *ptr = b + o;
    memset(ptr, 0, n);
    *((int32_t *)ptr) = ose_htonl(n - 4);
    ptr += 4;
    memcpy(ptr, OSE_ADDRESS_ANONVAL, OSE_ADDRESS_ANONVAL_SIZE);
    ptr += OSE_ADDRESS_ANONVAL_SIZE;
    *ptr++ = OSETT_ID;
    *ptr++ = typetag;
    *ptr++ = '\0';
    *ptr++ = '\0';
    ose_assert(ptr - (b + o) < n);
}
#endif

#ifdef OSE_PROVIDE_TYPE_TRUE
/**
 * @f$\fnpushunittype{PUSHTRUE}{\ttT}@f$
 */
void ose_pushTrue(ose_bundle B)
{
    pushUnitType(B, OSETT_TRUE);
}
#endif

#ifdef OSE_PROVIDE_TYPE_FALSE
/**
 * @f$\fnpushunittype{PUSHFALSE}{F}@f$
 */
void ose_pushFalse(ose_bundle B)
{
    pushUnitType(B, OSETT_FALSE);  
}
#endif

#ifdef OSE_PROVIDE_TYPE_NULL
/**
 * @f$\fnpushunittype{PUSHNULL}{N}@f$
 */
void ose_pushNull(ose_bundle B)
{
    pushUnitType(B, OSETT_NULL);   
}
#endif

#ifdef OSE_PROVIDE_TYPE_INFINITUM
/**
 * @f$\fnpushunittype{PUSHINFINITUM}{I}@f$
 */
void ose_pushInfinitum(ose_bundle B)
{
    pushUnitType(B, OSETT_INFINITUM);  
}
#endif

/**
 * @f$\fnpushtype{PUSHALIGNEDPTR}{\ttb}@f$
 */
void ose_pushAlignedPtr(ose_bundle B, const void *ptr)
{
    ose_pushBlob(B, OSE_INTPTR2, NULL);
    int32_t o = ose_readSize(B);
    o -= OSE_INTPTR2;
    ose_assert(o > OSE_BUNDLE_HEADER_LEN);
    ose_writeAlignedPtr(B, o, ptr);
}

void ose_pushMessage(ose_bundle B,
                     const char * const address,
                     int32_t addresslen,
                     int32_t n, ...)
{
    ose_assert(ose_isBundle(B));
    ose_assert(address);
    ose_assert(addresslen >= 0);
    ose_assert(n >= 0);
    {
        va_list ap;
        int32_t ms, ms2;
        const int32_t o = ose_readSize(B);
        ose_assert(o >= OSE_BUNDLE_HEADER_LEN);
        va_start(ap, n);
        ms = ose_vcomputeMessageSize(B,
                                     address,
                                     addresslen,
                                     n,
                                     ap);
        va_end(ap);
        ose_assert(ms >= 0);
        ose_incSize(B, ms);
        va_start(ap, n);
        ms2 = ose_vwriteMessage(B,
                                o,
                                address,
                                addresslen,
                                n,
                                ap);
        va_end(ap);
        ose_assert(ms == ms2);
    }
}

/**
 * @f$
 *	\fn{PEEKADDRESS}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{}
 *		}
 *	}{
 *		\left[\BBtick, \fnaddress{\ela{}{}}\right]
 *	}
 * @f$
 */
char *ose_peekAddress(const ose_bundle B)
{
    ose_assert(ose_isBundle(B));
    ose_assert(ose_readSize(B) > OSE_BUNDLE_HEADER_LEN);
    {
    	const int32_t o = ose_getLastBundleElemOffset(B);
        ose_assert(o >= OSE_BUNDLE_HEADER_LEN);
        ose_assert((o + 4) < ose_readSize(B));
        return ose_getBundlePtr(B) + o + 4;
    }
}

/**
 * @f$
 *	\fn{PEEKMESSAGEARGTYPE}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{\type{\ttmsg}}\items{
 *				\ldots,
 *				\ita{L}{\type{\ttvar}}
 *			}
 *		}
 *	}{
 *		\left[\BB, \ttvar\right]
 *	}
 * @f$
 */
char ose_peekMessageArgType(const ose_bundle B)
{
    ose_assert(ose_isBundle(B));
    ose_assert(!ose_bundleIsEmpty(B));
    {
        const int32_t o = ose_getLastBundleElemOffset(B);
        ose_assert(o >= OSE_BUNDLE_HEADER_LEN);
        ose_assert((o + 4) < ose_readSize(B));
        {
            const int32_t s = ose_readInt32(B, o);
            ose_assert(s > 0);
            if(s <= 8)
            {
                return OSETT_NOTYPETAG;
            }
            else
            {
                const char * const ptr = ose_getBundlePtr(B);
                ose_assert(ptr);
                ose_assert(strcmp(ose_readString(B, o + 4), OSE_BUNDLE_ID));
                {
                    const int32_t tto =
                        o + 4 + ose_getPaddedStringLen(B, o + 4);
                    ose_assert(tto - o <= s);
                    {
                        const int32_t len = strlen(ptr + tto);
                        ose_assert((tto + len - 1) - o <= s);
                        return ptr[tto + len - 1];
                    }
                }
            }
        }
    }
}

/**
 * @f$
 *    \fn{PEEKTYPE}{
 *        \BB\elems{
 *            \ldots,
 *            \ita{K}{\type{\ttvar}}
 *        }
 *    }{
 *        \left[\BB, \ttvar\right]
 *    }
 * @f$
 */
char ose_peekType(const ose_bundle B)
{
    ose_assert(ose_isBundle(B));
    ose_assert(!ose_bundleIsEmpty(B));
    {
        const int32_t o = ose_getLastBundleElemOffset(B);
        ose_assert(o >= OSE_BUNDLE_HEADER_LEN);
        ose_assert(o < ose_readSize(B));
        return ose_getBundleElemType(B, o);
    }
}

static char *peek_impl(ose_constbundle B,
                       char typetag,
                       int32_t *elemoffset)
{
    ose_assert(ose_isBundle(B));
    ose_assert(!ose_bundleIsEmpty(B));
    {
        const char * const b = ose_getBundlePtr(B);
        int32_t o = ose_getLastBundleElemOffset(B);
        int32_t to, ntt, lto, po, lpo;
        ose_assert(b);
        ose_assert(o >= OSE_BUNDLE_HEADER_LEN);
        ose_assert(o < ose_readSize(B));
        ose_getNthPayloadItem(B, 1, o,
                              &to, &ntt, &lto, &po, &lpo);
        ose_assert(lpo > o);
        ose_assert(lpo < ose_readSize(B));
        *elemoffset = o;
        return (char *)(b + lpo);
    }
}

static char *peek(ose_constbundle B,
                  char typetag)
{
    int32_t eo = 0;
    return peek_impl(B, typetag, &eo);
}

/**
 * @f$\fnpeektypedvalue{PEEKINT32}{\tti}@f$
 */
int32_t ose_peekInt32(ose_constbundle B)
{
    return ose_ntohl(*((int32_t *)peek(B, OSETT_INT32)));
}

/**
 * @f$\fnpeektypedvalue{PEEKFLOAT}{\ttf}@f$
 */
float ose_peekFloat(ose_constbundle B)
{
    int32_t i = ose_ntohl(*((int32_t *)peek(B, OSETT_FLOAT)));
    char *p = (char *)&i;
    return *((float *)p);
}

/**
 * @f$\fnpeektypedvalue{PEEKSTRING}{\tts}@f$
 */
char *ose_peekString(ose_constbundle B)
{
    return peek(B, OSETT_STRING);
}

/**
 * @f$\fnpeektypedvalue{PEEKBLOB}{\ttb}@f$
 */
char *ose_peekBlob(ose_constbundle B)
{
    return peek(B, OSETT_BLOB);
}

#ifdef OSE_PROVIDE_TYPE_SYMBOL
/**
 * @f$\fnpeektypedvalue{PEEKSYMBOL}{\ttS}@f$
 */
char *ose_peekSymbol(const ose_bundle B)
{
    return peek(B, OSETT_SYMBOL);
}
#endif

#ifdef OSE_PROVIDE_TYPE_DOUBLE
/**
 * @f$\fnpeektypedvalue{PEEKDOUBLE}{\ttd}@f$
 */
double ose_peekDouble(const ose_bundle B)
{
    int64_t i = ose_ntohll(*((int64_t *)peek(B, OSETT_DOUBLE)));
    return *((double *)&i);
}
#endif

#ifdef OSE_PROVIDE_TYPE_INT8
/**
 * @f$\fnpeektypedvalue{PEEKINT8}{\ttc}@f$
 */
int8_t ose_peekInt8(const ose_bundle B)
{
    return ose_ntohl(*((int32_t *)peek(B, OSETT_INT8)));
}
#endif

#ifdef OSE_PROVIDE_TYPE_UINT8
/**
 * @f$\fnpeektypedvalue{PEEKUINT8}{\ttC}@f$
 */
uint8_t ose_peekUInt8(const ose_bundle B)
{
    return ose_ntohl(*((uint32_t *)peek(B, OSETT_UINT8)));
}
#endif

#ifdef OSE_PROVIDE_TYPE_UINT32
/**
 * @f$\fnpeektypedvalue{PEEKUINT32}{\ttk}@f$
 */
uint32_t ose_peekUInt32(const ose_bundle B)
{
    return ose_ntohl(*((uint32_t *)peek(B, OSETT_UINT32)));
}
#endif

#ifdef OSE_PROVIDE_TYPE_INT64
/**
 * @f$\fnpeektypedvalue{PEEKINT64}{\tth}@f$
 */
int64_t ose_peekInt64(const ose_bundle B)
{
    return ose_ntohll(*((int64_t *)peek(B, OSETT_INT64)));
}
#endif

#ifdef OSE_PROVIDE_TYPE_UINT64
/**
 * @f$\fnpeektypedvalue{PEEKUINT64}{\ttH}@f$
 */
uint64_t ose_peekUInt64(const ose_bundle B)
{
    return ose_ntohll(*((uint64_t *)peek(B, OSETT_UINT64)));
}
#endif

#ifdef OSE_PROVIDE_TYPE_TIMETAG
/**
 * @f$\fnpeektypedvalue{PEEKTIMETAG}{\tttt}@f$
 */
struct ose_timetag ose_peekTimetag(const ose_bundle B)
{
    struct ose_timetag t =
        *((struct ose_timetag *)peek(B, OSETT_TIMETAG));
    t.sec = ose_ntohl(t.sec);
    t.fsec = ose_ntohl(t.fsec);
    return t;
}
#endif

/**
 * @f$\fnpeektypedvalue{PEEKALIGNEDPTR}{\ttb}@f$
 */
const void *ose_peekAlignedPtr(ose_bundle B)
{
    int32_t o = ose_getLastBundleElemOffset(B);
    int32_t to, ntt, lto, po, lpo;
    ose_getNthPayloadItem(B, 1, o, &to, &ntt, &lto, &po, &lpo);
    ose_alignPtr(B, lpo + 4);
    return ose_readAlignedPtr(B, lpo + 4);
}

/* no peek functions for unit types */

/**
 * @f$\fnpoptypedvalue{POPINT32}{\tti}@f$
 */
int32_t ose_popInt32(ose_bundle B)
{
    ose_assert(ose_isBundle(B));
    {
        int32_t eo = 0;
        const int32_t i = ose_ntohl(*((int32_t *)peek_impl(B,
                                                           OSETT_INT32,
                                                           &eo)));
        ose_assert(eo >= OSE_BUNDLE_HEADER_LEN);
        ose_assert(eo < ose_readSize(B));
        ose_dropAtOffset(B, eo);
        return i;
    }
}

/**
 * @f$\fnpoptypedvalue{POPFLOAT}{\ttf}@f$
 */
float ose_popFloat(ose_bundle B)
{
    ose_assert(ose_isBundle(B));
    {
        int32_t eo = 0;
        const int32_t i = ose_ntohl(*((int32_t *)peek_impl(B,
                                                           OSETT_FLOAT,
                                                           &eo)));
        const char *p = (char *)&i;
        const float f = *((float *)p);
        ose_assert(eo >= OSE_BUNDLE_HEADER_LEN);
        ose_assert(eo < ose_readSize(B));
        ose_dropAtOffset(B, eo);
        return f;
    }
}

/**
 * @f$\fnpoptypedvalue{POPSTRING}{\tts}@f$
 */
int32_t ose_popString(ose_bundle B, char *buf)
{
    ose_assert(ose_isBundle(B));
    ose_assert(buf);
    {
        int32_t eo = 0;
        const char * const ptr = peek_impl(B, OSETT_STRING, &eo);
        ose_assert(ptr);
        ose_assert(eo >= OSE_BUNDLE_HEADER_LEN);
        ose_assert(eo < ose_readSize(B));
        {
            const int32_t len = strlen(ptr);
            strncpy(buf, ptr, len);
            ose_dropAtOffset(B, eo);
            return len;
        }
    }
}

/**
 * @f$\fnpoptypedvalue{POPBLOB}{\ttb}@f$
 */
int32_t ose_popBlob(ose_bundle B, char *buf)
{
    ose_assert(ose_isBundle(B));
    ose_assert(buf);
    {
        int32_t eo = 0;
        const char *ptr = peek_impl(B, OSETT_BLOB, &eo);
        ose_assert(ptr);
        ose_assert(eo >= OSE_BUNDLE_HEADER_LEN);
        ose_assert(eo < ose_readSize(B));
        {
            int32_t bloblen = ose_ntohl(*((int32_t *)ptr));
            ose_assert(bloblen >= 0);
            memcpy(buf, ptr + 4, bloblen);
            ose_dropAtOffset(B, eo);
            return bloblen;
        }
    }
}

#ifdef OSE_PROVIDE_TYPE_SYMBOL
/**
 * @f$\fnpoptypedvalue{POPSYMBOL}{\ttS}@f$
 */
int32_t ose_popSymbol(ose_bundle B, char *buf)
{
    char *ptr = ose_peekSymbol(B);
    int32_t len = strlen(ptr);
    strncpy(buf, ptr, len);
    ose_drop(B);
    return len;
}
#endif

#ifdef OSE_PROVIDE_TYPE_DOUBLE
/**
 * @f$\fnpoptypedvalue{POPDOUBLE}{\ttd}@f$
 */
double ose_popDouble(ose_bundle B)
{
    double f = ose_peekDouble(B);
    ose_drop(B);
    return f;
}
#endif

#ifdef OSE_PROVIDE_TYPE_INT8
/**
 * @f$\fnpoptypedvalue{POPINT8}{\ttc}@f$
 */
int8_t ose_popInt8(ose_bundle B)
{
    int8_t i = ose_peekInt8(B);
    ose_drop(B);
    return i;
}
#endif

#ifdef OSE_PROVIDE_TYPE_UINT8
/**
 * @f$\fnpoptypedvalue{POPUINT8}{\ttC}@f$
 */
uint8_t ose_popUInt8(ose_bundle B)
{
    uint8_t i = ose_peekUInt8(B);
    ose_drop(B);
    return i;
}
#endif

#ifdef OSE_PROVIDE_TYPE_UINT32
/**
 * @f$\fnpoptypedvalue{POPUINT32}{\ttk}@f$
 */
uint32_t ose_popUInt32(ose_bundle B)
{
    uint32_t i = ose_peekUInt32(B);
    ose_drop(B);
    return i;
}
#endif

#ifdef OSE_PROVIDE_TYPE_INT64
/**
 * @f$\fnpoptypedvalue{POPINT64}{\tth}@f$
 */
int64_t ose_popInt64(ose_bundle B)
{
    int64_t i = ose_peekInt64(B);
    ose_drop(B);
    return i;
}
#endif

#ifdef OSE_PROVIDE_TYPE_UINT64
/**
 * @f$\fnpoptypedvalue{POPUINT64}{\ttH}@f$
 */
uint64_t ose_popUInt64(ose_bundle B)
{
    uint64_t i = ose_peekUInt64(B);
    ose_drop(B);
    return i;
}
#endif

#ifdef OSE_PROVIDE_TYPE_TIMETAG
/**
 * @f$\fnpoptypedvalue{POPTIMETAG}{\tttt}@f$
 */
struct ose_timetag ose_popTimetag(ose_bundle B)
{
    struct ose_timetag t = ose_peekTimetag(B);
    ose_drop(B);
    return t;
}
#endif

/**
 * @f$
 *	\fn{SETTIMETAG}{
 *		\BB\elems{
 *			\timetag\mid
 *			\ldots,
 *			\ela{K}{\type{\ttmsg(\type{\ttb})}}\items{
 *				\ita{}{\type{\ttb}}\values{\valv{}{}}
 *			}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\timetag = \valv{}{}\mid,
 *			\ldots
 *		}
 *	}
 * @f$, where @f$\timetag@f$ is the timetag field of the bundle,
 * and @f$\ela{}{}@f$ has been removed.
 */
void ose_setTimetag(ose_bundle B)
{
    if(ose_bundleHasAtLeastNElems(B, 2) == false)
    {
        ose_errno_set(B, OSE_ERR_ELEM_COUNT);
        return;
    }
    int32_t onm1, snm1, on, sn;
    be2(B, &onm1, &snm1, &on, &sn);
    if(!strncmp(ose_readString(B, on + 4),
                OSE_BUNDLE_ID, OSE_BUNDLE_ID_LEN))
    {
        /* top elem must be a message */
        ose_errno_set(B, OSE_ERR_ELEM_TYPE);
        return;
    }
    if(strncmp(ose_readString(B, onm1 + 4),
               OSE_BUNDLE_ID, OSE_BUNDLE_ID_LEN))
    {
        /* elem below the top must be a bundle */
        ose_errno_set(B, OSE_ERR_ELEM_TYPE);
        return;
    }
    int32_t to, ntt, lto, po, lpo;
    ose_getNthPayloadItem(B, 1, on, &to, &ntt, &lto, &po, &lpo);
    if(ose_readByte(B, lto) != OSETT_BLOB
       || ose_readInt32(B, lpo) != OSE_TIMETAG_LEN)
    {
        ose_errno_set(B, OSE_ERR_ITEM_TYPE);
        return;
    }
    char *b = ose_getBundlePtr(B);
    memcpy(b + onm1 + 4 + OSE_BUNDLE_ID_LEN,
           b + lpo + 4,
           OSE_TIMETAG_LEN);
}

void ose_getTimetag(ose_bundle B)
{
    if(ose_bundleHasAtLeastNElems(B, 1) == false)
    {
        ose_errno_set(B, OSE_ERR_ELEM_COUNT);
        return;
    }
    int32_t o = ose_getLastBundleElemOffset(B);
    if(strncmp(ose_readString(B, o + 4),
               OSE_BUNDLE_ID, OSE_BUNDLE_ID_LEN))
    {
        ose_errno_set(B, OSE_ERR_ELEM_TYPE);
        return;
    }
    char *b = ose_getBundlePtr(B);
    ose_pushBlob(B,
                 OSE_TIMETAG_LEN,
                 b + o + 4 + OSE_BUNDLE_ID_LEN);
}

/* no pop functions for unit types */

/**************************************************
 * Stack Operations
 **************************************************/

/**
 * @f$
 *    \fn{2DROP}{
 *        \BB\elems{
 *            \ldots,
 *            \ela{K-1}{},
 *            \elb{K}{}
 *        }
 *    }{
 *        \BBtick\elems{
 *            \ldots
 *        }
 *    }
 * @f$, where @f$\ela{K-1}{}@f$ and @f$\elb{K}{}@f$ 
 * have been removed.
 */
void ose_2drop(ose_bundle B)
{
    int32_t onm1, snm1, on, sn;
    char *b;
    ose_assert(ose_isBundle(B));
    b = ose_getBundlePtr(B);
    ose_assert(b);
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    be2(B, &onm1, &snm1, &on, &sn);
    ose_assert(snm1 >= 4);
    ose_assert(sn >= 4);
    ose_assert(onm1 >= OSE_BUNDLE_HEADER_LEN);
    ose_assert(onm1 + snm1 + 4 == on);
    ose_assert(on + sn + 4 == ose_readSize(B));
    {
        const int32_t ss = sn + snm1 + 8;
        memset(b + onm1, 0, ss);
        ose_decSize(B, ss);
    }
}

/**
 * @f$
 *    \fn{2DUP}{
 *        \BB\elems{
 *            \ldots,
 *            \ela{K-1}{},
 *            \elb{K}{}
 *        }
 *    }{
 *        \BBtick\elems{
 *            \ldots,
 *            \ela{K-1}{},
 *            \elb{K}{},
 *            \ela{K+1}{},
 *            \elb{K+2}{}
 *        }
 *    }
 * @f$
 */
void ose_2dup(ose_bundle B)
{
    int32_t onm1, snm1, on, sn;
    char *b;
    ose_assert(ose_isBundle(B));
    b = ose_getBundlePtr(B);
    ose_assert(b);
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    be2(B, &onm1, &snm1, &on, &sn);
    ose_assert(snm1 >= 4);
    ose_assert(sn >= 4);
    ose_assert(onm1 >= OSE_BUNDLE_HEADER_LEN);
    ose_assert(onm1 + snm1 + 4 == on);
    ose_assert(on + sn + 4 == ose_readSize(B));
    {
        const int32_t ss = snm1 + sn + 8;
        ose_incSize(B, ss);
        memcpy(b + on + sn + 4, b + onm1, ss);
    }
}

/**
 * @f$
 *    \fn{2OVER}{
 *        \BB\elems{
 *            \ldots,
 *            \ela{K-3}{},
 *            \elb{K-2}{},
 *            \elc{K-1}{},
 *            \eld{K}{}
 *        }
 *    }{
 *        \BBtick\elems{
 *            \ldots,
 *            \ela{K-3}{},
 *            \elb{K-2}{},
 *            \elc{K-1}{},
 *            \eld{K}{},
 *            \ela{K+1}{},
 *            \elb{K+2}{}
 *        }
 *    }
 * @f$
 */
void ose_2over(ose_bundle B)
{
    int32_t onm3, snm3, onm2, snm2, onm1, snm1, on, sn;
    char *b;
    ose_assert(ose_isBundle(B));
    b = ose_getBundlePtr(B);
    ose_assert(b);
    ose_assert(ose_bundleHasAtLeastNElems(B, 4));
    be4(B, &onm3, &snm3, &onm2, &snm2, &onm1, &snm1, &on, &sn);
    ose_assert(snm3 >= 4);
    ose_assert(snm2 >= 4);
    ose_assert(snm1 >= 4);
    ose_assert(sn >= 4);
    ose_assert(onm3 >= OSE_BUNDLE_HEADER_LEN);
    ose_assert(onm3 + snm3 + 4 == onm2);
    ose_assert(onm2 + snm2 + 4 == onm1);
    ose_assert(onm1 + snm1 + 4 == on);
    ose_assert(on + sn + 4 == ose_readSize(B));
    {
        const int32_t ss = snm3 + snm2 + 8;
        ose_incSize(B, ss);
        memcpy(b + on + sn + 4, b + onm3, ss);
    }
}

/**
 * @f$
 *    \fn{2SWAP}{
 *        \BB\elems{
 *            \ldots,
 *            \ela{K-3}{},
 *            \elb{K-2}{},
 *            \elc{K-1}{},
 *            \eld{K}{}
 *        }
 *    }{
 *        \BBtick\elems{
 *            \ldots,
 *            \elc{K-3}{},
 *            \eld{K-2}{},
 *            \ela{K-1}{},
 *            \elb{K}{}
 *        }
 *    }
 * @f$
 */
void ose_2swap(ose_bundle B)
{
    int32_t onm3, snm3, onm2, snm2, onm1, snm1, on, sn;
    char *b;
    ose_assert(ose_isBundle(B));
    b = ose_getBundlePtr(B);
    ose_assert(b);
    ose_assert(ose_bundleHasAtLeastNElems(B, 4));
    be4(B, &onm3, &snm3, &onm2, &snm2, &onm1, &snm1, &on, &sn);
    ose_assert(snm3 >= 4);
    ose_assert(snm2 >= 4);
    ose_assert(snm1 >= 4);
    ose_assert(sn >= 4);
    ose_assert(onm3 >= OSE_BUNDLE_HEADER_LEN);
    ose_assert(onm3 + snm3 + 4 == onm2);
    ose_assert(onm2 + snm2 + 4 == onm1);
    ose_assert(onm1 + snm1 + 4 == on);
    ose_assert(on + sn + 4 == ose_readSize(B));
    {
        const int32_t ss = snm3 + snm2 + 8;
        ose_incSize(B, ss);
        memcpy(b + on + sn + 4, b + onm3, ss);
        memmove(b + onm3, b + onm1, snm3 + snm2 + snm1 + sn + 16);
        memset(b + on + sn + 4, 0, ss);
        ose_decSize(B, ss);
    }
}

static void ose_drop_impl(ose_bundle B, int32_t o, int32_t s)
{
    char *b;
    ose_assert(ose_isBundle(B));
    ose_assert(ose_bundleHasAtLeastNElems(B, 1));
    ose_assert(o >= OSE_BUNDLE_HEADER_LEN);
    ose_assert(s >= 4);
    b = ose_getBundlePtr(B);
    ose_assert(b);
    memset(b + o, 0, s + 4);
    ose_decSize(B, (s + 4));
}

/**
 * @f$
 *    \fn{DROP}{
 *        \BB\elems{
 *            \ldots,
 *            \ela{K}{}
 *        }
 *    }{
 *        \BBtick\elems{
 *            \ldots
 *        }
 *    }
 * @f$, where @f$\ela{K}{}@f$ has been removed.
 */
void ose_drop(ose_bundle B)
{
    int32_t o, s;
    ose_assert(ose_isBundle(B));
    ose_assert(ose_bundleHasAtLeastNElems(B, 1));
    be1(B, &o, &s);
    ose_assert(o >= OSE_BUNDLE_HEADER_LEN);
    ose_assert(s >= 4);
    ose_assert(o + s + 4 == ose_readSize(B));
    ose_drop_impl(B, o, s);
}

static void ose_dup_impl(ose_bundle B, int32_t o, int32_t s)
{
    char *b;
    ose_assert(ose_isBundle(B));
    ose_assert(ose_bundleHasAtLeastNElems(B, 1));
    b = ose_getBundlePtr(B);
    ose_assert(o >= OSE_BUNDLE_HEADER_LEN);
    ose_assert(s >= 4);
    ose_assert(o + s + 4 == ose_readSize(B));
    ose_incSize(B, s + 4);
    memcpy(b + o + s + 4, b + o, s + 4);
}

/**
 * @f$
 *    \fn{DUP}{
 *        \BB\elems{
 *            \ldots,
 *            \ela{K}{}
 *        }
 *    }{
 *        \BBtick\elems{
 *            \ldots,
 *            \ela{K}{},
 *            \ela{K+1}{}
 *        }
 *    }
 * @f$
 */
void ose_dup(ose_bundle B)
{
    int32_t o, s;
    ose_assert(ose_isBundle(B));
    ose_assert(ose_bundleHasAtLeastNElems(B, 1));
    be1(B, &o, &s);
    ose_assert(o >= OSE_BUNDLE_HEADER_LEN);
    ose_assert(s >= 4);
    ose_assert(o + s + 4 == ose_readSize(B));
    ose_dup_impl(B, o, s);
}

/**
 * @f$
 *    \fn{NIP}{
 *        \BB\elems{
 *            \ldots,
 *            \ela{K-1}{},
 *            \elb{K}{}
 *        }
 *    }{
 *        \BBtick\elems{
 *            \ldots,
 *            \elb{K-1}{}
 *        }
 *    }
 * @f$, where @f$A@f$ has been removed.
 */
void ose_nip(ose_bundle B)
{
    int32_t onm1, snm1, on, sn;
    ose_assert(ose_isBundle(B));
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    be2(B, &onm1, &snm1, &on, &sn);
    ose_assert(sn >= 4);
    ose_assert(snm1 >= 4);
    ose_assert(onm1 + snm1 + 4 == on);
    ose_assert(on + sn + 4 == ose_readSize(B));
    ose_swap_impl(B, onm1, snm1, on, sn);
    ose_drop_impl(B, onm1 + sn + 4, snm1);
}

static void ose_rrot_impl(ose_bundle B,
                          int32_t onm2,
                          int32_t snm2,
                          int32_t onm1,
                          int32_t snm1,
                          int32_t on,
                          int32_t sn)
{
    char *b;
    int32_t fs;
    ose_assert(ose_isBundle(B));
    ose_assert(ose_bundleHasAtLeastNElems(B, 3));
    ose_assert(sn >= 4);
    ose_assert(snm1 >= 4);
    ose_assert(snm2 >= 4);
    ose_assert(onm2 + snm2 + 4 == onm1);
    ose_assert(onm1 + snm1 + 4 == on);
    ose_assert(on + sn + 4 == ose_readSize(B));
    b = ose_getBundlePtr(B);
    ose_assert(b);
    fs = ose_readInt32_outOfBounds(B, on + sn + 4);
    ose_writeInt32_outOfBounds(B, on + sn + 4, 0);
    memmove(b + onm2 + sn + 4, b + onm2, snm2 + snm1 + sn + 12);
    memcpy(b + onm2, b + on + sn + 4, sn + 4);
    memset(b + on + sn + 4, 0, sn + 4);
    ose_writeInt32_outOfBounds(B, on + sn + 4, fs);
    ose_incSize(B, 0);
}

/**
 * @f$
 *    \fn{RROT}{
 *        \BB\elems{
 *            \ldots,
 *            \ela{K-2}{},
 *            \elb{K-1}{},
 *            \elc{K}{}
 *        }
 *    }{
 *        \BBtick\elems{
 *            \ldots,
 *            \elc{K-2}{},
 *            \ela{K-1}{},
 *            \elb{K}{}
 *        }
 *    }
 * @f$
 */
void ose_rrot(ose_bundle B)
{
    int32_t onm2, snm2, onm1, snm1, on, sn;
    ose_assert(ose_isBundle(B));
    ose_assert(ose_bundleHasAtLeastNElems(B, 3));
    be3(B, &onm2, &snm2, &onm1, &snm1, &on, &sn);
    ose_assert(sn >= 4);
    ose_assert(snm1 >= 4);
    ose_assert(snm2 >= 4);
    ose_assert(onm2 + snm2 + 4 == onm1);
    ose_assert(onm1 + snm1 + 4 == on);
    ose_assert(on + sn + 4 == ose_readSize(B));
    ose_rrot_impl(B, onm2, snm2, onm1, snm1, on, sn);
}

static void ose_over_impl(ose_bundle B,
                          int32_t onm1,
                          int32_t snm1,
                          int32_t on,
                          int32_t sn)
{
    char *b;
    ose_assert(ose_isBundle(B));
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    ose_assert(sn >= 4);
    ose_assert(snm1 >= 4);
    ose_assert(onm1 + snm1 + 4 == on);
    ose_assert(on + sn + 4 == ose_readSize(B));
    b = ose_getBundlePtr(B);
    ose_assert(b);
    ose_incSize(B, snm1 + 4);
    memcpy(b + on + sn + 4, b + onm1, snm1 + 4);
}

/**
 * @f$
 *  \fn{OVER}{
 *      \BB\elems{
 *          \ldots,
 *          \ela{K-1}{},
 *          \elb{K}{}
 *      }
 *  }{
 *      \BBtick\elems{
 *          \ldots,
 *          \ela{K-1}{},
 *          \elb{K}{},
 *          \ela{K+1}{}
 *      }
 *  }
 * @f$
 */
void ose_over(ose_bundle B)
{
    int32_t onm1, snm1, on, sn;
    ose_assert(ose_isBundle(B));
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    be2(B, &onm1, &snm1, &on, &sn);
    ose_assert(sn >= 4);
    ose_assert(snm1 >= 4);
    ose_assert(onm1 + snm1 + 4 == on);
    ose_assert(on + sn + 4 == ose_readSize(B));
    ose_over_impl(B, onm1, snm1, on, sn);
}

static void pick(ose_bundle B,
                 int32_t *o1_out, int32_t *o2_out, int32_t *s_out)
{
    ose_assert(ose_isBundle(B));
    ose_assert(o1_out);
    ose_assert(o2_out);
    ose_assert(s_out);
    {
        const int32_t ridx = ose_popInt32(B);
        char *b = ose_getBundlePtr(B);
        /* get the size after popping ridx */
        const int32_t s = ose_readSize(B);
        const int32_t n = ose_getBundleElemCount(B);
        const int32_t idx = (n - 1) - ridx;
        int32_t eo = OSE_BUNDLE_HEADER_LEN;
        int32_t es;
        int32_t i;
        ose_assert(s > OSE_BUNDLE_HEADER_LEN);
        ose_assert(idx >= 0);
        ose_assert(n > idx);
        ose_assert(idx >= 0);
        for(i = 0; i < idx; ++i)
        {
            es = ose_readInt32(B, eo);
            ose_assert(es > 0);
            ose_assert(eo + es + 4 < s);
            eo += es + 4;
        }
        es = ose_readInt32(B, eo);
        ose_incSize(B, es + 4);
        memcpy(b + s, b + eo, es + 4);
        *o2_out = eo;
        *o1_out = s + es + 4;
        *s_out = es;
    }
}

/**
 * @f$
 * 	\fn{PICK}{
 *  	\BB\elems{
 *			\ldots, 
 *			\ela{K-1-v}{}, 
 *			\ldots,
 *		  	\elb{K}{\type{\ttmsg(\type{\tti})}}\items{
 *		  		\ita{}{\type{\tti}}\values{
 *		  			\valv{}{}
 *		  		}
 *			}
 *		}
 *	}{
 *      \BBtick\elems{
 *          \ldots,
 *          \ela{K-1-v}{},
 *          \ldots,
 *          \elat{K}{}
 *      }
 *  }
 * @f$, where @f$\elb{}{}@f$ has been removed and @f$\ela{}{}@f$
 * copied to the end.
 */
void ose_pick(ose_bundle B)
{
    int32_t o1 = 0, o2 = 0, s = 0;
    ose_assert(ose_isBundle(B));
    pick(B, &o1, &o2, &s);
    ose_assert(s > 0);
}

/**
 * @f$
 *  \fn{PICKBOTTOM}{
 *      \BB\elems{
 *          \ela{1}{},
 *          \ldots
 *      }
 *  }{
 *      \BBtick\elems{
 *          \ela{1}{},
 *          \ldots,
 *          \ela{K}{}
 *      }
 *  }
 * @f$
 */
void ose_pickBottom(ose_bundle B)
{
    ose_assert(ose_isBundle(B));
    ose_assert(ose_readSize(B) > OSE_BUNDLE_HEADER_LEN);
    {
        char *b = ose_getBundlePtr(B);
        int32_t old_bundle_size = ose_readSize(B);
        int32_t es = ose_readInt32(B,
                                   OSE_BUNDLE_HEADER_LEN);
        ose_assert(b);
        ose_assert(es + 4 + OSE_BUNDLE_HEADER_LEN <= old_bundle_size);
        ose_assert(es > 0);
        ose_incSize(B, es + 4);
        memcpy(b + old_bundle_size,
               b + OSE_BUNDLE_HEADER_LEN,
               es + 4);
    }
}

void ose_pickMatch_found_impl(ose_bundle B, int32_t o, int32_t s)
{
    ose_drop(B);
    char *b = ose_getBundlePtr(B);
    s = ose_readSize(B);
    int32_t ss = ose_readInt32(B, o);
    ose_incSize(B, ss + 4);
    memcpy(b + s, b + o, ss + 4);
}

int32_t ose_pickMatch_impl(ose_bundle B)
{
    const char * const addr = ose_peekString(B);
    int32_t o = OSE_BUNDLE_HEADER_LEN;
    int32_t s = ose_readSize(B);
    while(o < s)
    {
        if(!strcmp(addr, ose_readString(B, o + 4)))
        {
            ose_pickMatch_found_impl(B, o, s);
            return 1;
        }
        o += ose_readInt32(B, o) + 4;
    }
    return 0;
}

void ose_pickMatch(ose_bundle B)
{
    ose_pushInt32(B, ose_pickMatch_impl(B));
}

int32_t ose_pickPMatch_impl(ose_bundle B)
{
    const char * const addr = ose_peekString(B);
    int32_t o = OSE_BUNDLE_HEADER_LEN;
    int32_t s = ose_readSize(B);
    while(o < s)
    {
        int po = 0, ao = 0;
        int32_t r = ose_match_pattern(ose_readString(B, o + 4),
                                      addr, &po, &ao);
        if(r & OSE_MATCH_ADDRESS_COMPLETE)
        {
            ose_pickMatch_found_impl(B, o, s);
            return 1;
        }
        o += ose_readInt32(B, o) + 4;
    }
    return 0;
}

void ose_pickPMatch(ose_bundle B)
{
    ose_pushInt32(B, ose_pickPMatch_impl(B));
}

/**
 * @f$
 *	\fn{ROLL}{
 *      \BB\elems{
 *          \ldots,
 *          \ela{K-1-v}{},
 *          \ldots,
 *          \elb{K}{\type{\ttmsg(\type{\tti})}}\items{
 *				\ita{}{\type{\tti}}\values{\valv{}{}}
 *          }
 *      }
 *  }{
 *      \BBtick\elems{
 *          \ldots,
 *          \ela{K-1}{}
 *      }
 *  }
 * @f$, where @f$\elb{}{}@f$ has been removed, and @f$\ela{}{}@f$
 * has been moved to the end.
 */
void ose_roll(ose_bundle B)
{
    ose_assert(ose_isBundle(B));
    {
        char *b = ose_getBundlePtr(B);
        int32_t o = 0, oo = 0, ss = 0;
        ose_assert(b);
        pick(B, &o, &oo, &ss);
        ose_assert(o > oo);
        ose_assert(o >= OSE_BUNDLE_HEADER_LEN);
        ose_assert(oo >= OSE_BUNDLE_HEADER_LEN);
        ose_assert(o <= ose_readSize(B));
        ose_assert(ss > 0);
        memmove(b + oo,
                b + oo + ose_readInt32(B, oo) + 4,
                o - oo);
        memset(b + o, 0, ss + 4);
        ose_decSize(B, ss + 4);
    }
}

/**
 * @f$
 *  \fn{ROLLBOTTOM}{
 *      \BB\elems{
 *          \ela{1}{},
 *          \ldots
 *      }
 *  }{
 *      \BBtick\elems{
 *          \ldots,
 *          \ela{K}{}
 *      }
 *  }
 * @f$
 */
void ose_rollBottom(ose_bundle B)
{
    ose_assert(ose_isBundle(B));
    {
        const int32_t o = OSE_BUNDLE_HEADER_LEN;
        const int32_t s = ose_readSize(B);
        const int32_t ss = ose_readInt32(B, o);
        char *b = ose_getBundlePtr(B);
        ose_assert(b);
        ose_assert(o < s);
        ose_assert(o + ss + 4 <= s);
        ose_incSize(B, ss + 4);
        memcpy(b + s, b + o, ss + 4);
        memmove(b + o, b + o + ss + 4, s);
        memset(b + s, 0, ss + 4);
        ose_decSize(B, ss + 4);
    }
}

int32_t ose_rollMatch_impl(ose_bundle B)
{
    const char * const addr = ose_peekString(B);
    int32_t o = OSE_BUNDLE_HEADER_LEN;
    int32_t s = ose_readSize(B);
    while(o < s)
    {
        if(!strcmp(addr, ose_readString(B, o + 4)))
        {
            ose_drop(B);
            char *b = ose_getBundlePtr(B);
            s = ose_readSize(B);
            int32_t ss = ose_readInt32(B, o);
            ose_incSize(B, ss + 4);
            memcpy(b + s, b + o, ss + 4);
            memmove(b + o,
                    b + o + ss + 4,
                    (s + ss + 4) - (o + ss + 4));
            memset(b + s, 0, ss + 4);
            ose_decSize(B, (ss + 4));
            return 1;
        }
        o += ose_readInt32(B, o) + 4;
    }
    return 0;
}

void ose_rollMatch(ose_bundle B)
{
    ose_pushInt32(B, ose_rollMatch_impl(B));
}

/**
 * @todo Implement
 */
int32_t ose_rollPMatch_impl(ose_bundle B)
{
    return 0;
}

void ose_rollPMatch(ose_bundle B)
{
    ose_pushInt32(B, ose_rollPMatch_impl(B));
}

static void ose_rot_impl(ose_bundle B,
                         int32_t onm2,
                         int32_t snm2,
                         int32_t onm1,
                         int32_t snm1,
                         int32_t on,
                         int32_t sn)
{
    char *b;
    int32_t fs;
    ose_assert(ose_isBundle(B));
    ose_assert(ose_bundleHasAtLeastNElems(B, 3));
    ose_assert(sn >= 4);
    ose_assert(snm1 >= 4);
    ose_assert(snm2 >= 4);
    ose_assert(onm2 + snm2 + 4 == onm1);
    ose_assert(onm1 + snm1 + 4 == on);
    ose_assert(on + sn + 4 == ose_readSize(B));
    b = ose_getBundlePtr(B);
    ose_assert(b);
    fs = ose_readInt32_outOfBounds(B, on + sn + 4);
    ose_writeInt32_outOfBounds(B, on + sn + 4, 0);
    memcpy(b + on + sn + 4, b + onm2, snm2 + 4);
    memmove(b + onm2, b + onm1, snm2 + snm1 + sn + 12);
    memset(b + on + sn + 4, 0, snm2 + 4);
    ose_writeInt32_outOfBounds(B, on + sn + 4, fs);
    ose_incSize(B, 0);
}

/**
 * @f$
 *  \fn{ROT}{
 *      \BB\elems{
 *          \ldots,
 *          \ela{K-2}{},
 *          \elb{K-1}{},
 *          \elc{K}{}
 *      }
 *  }{
 *      \BBtick\elems{
 *          \ldots,
 *          \elb{K-2}{},
 *          \elc{K-1}{},
 *          \ela{K}{}
 *      }
 *  }
 * @f$
 */
void ose_rot(ose_bundle B)
{
    int32_t onm2, snm2, onm1, snm1, on, sn;
    ose_assert(ose_isBundle(B));
    ose_assert(ose_bundleHasAtLeastNElems(B, 3));
    be3(B, &onm2, &snm2, &onm1, &snm1, &on, &sn);
    ose_assert(sn >= 4);
    ose_assert(snm1 >= 4);
    ose_assert(snm2 >= 4);
    ose_assert(onm2 + snm2 + 4 == onm1);
    ose_assert(onm1 + snm1 + 4 == on);
    ose_assert(on + sn + 4 == ose_readSize(B));
    ose_rot_impl(B, onm2, snm2, onm1, snm1, on, sn);
}

static void ose_swap_impl(ose_bundle B,
                          int32_t offset_nm1,
                          int32_t size_nm1,
                          int32_t offset_n,
                          int32_t size_n)
{
    char *b;
    ose_assert(ose_isBundle(B));
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    ose_assert(size_nm1 >= 4);
    ose_assert(size_n >= 4);
    ose_assert(offset_nm1 + size_nm1 + 4 == offset_n);
    ose_assert(offset_n + size_n + 4 == ose_readSize(B));
    ose_assert(ose_spaceAvailable(B) - size_n > size_nm1 ? size_n : size_nm1);
    b = ose_getBundlePtr(B);
    ose_assert(b);
    if(size_nm1 > size_n)
    {
        ose_incSize(B, size_n + 4);
        memmove(b + offset_nm1 + size_n + 4,
                b + offset_nm1,
                size_n + size_nm1 + 8);
        memcpy(b + offset_nm1,
               b + offset_n + size_n + 4,
               size_n + 4);
        memset(b + offset_n + size_n + 4,
               0,
               size_n + 4);
        ose_decSize(B, size_n + 4);
    }
    else
    {
        ose_incSize(B, size_nm1 + 4);
        memcpy(b + offset_n + size_n + 4,
               b + offset_nm1,
               size_nm1 + 4);
        memmove(b + offset_nm1,
                b + offset_n,
                size_nm1 + size_n + 8);
        memset(b + offset_n + size_n + 4,
               0,
               size_nm1 + 4);
        ose_decSize(B, size_nm1 + 4);
    }
}

/**
 * @f$
 *  \fn{SWAP}{
 *      \BB\elems{
 *          \ldots,
 *          \ela{K-1}{},
 *          \elb{K}{}
 *      }
 *  }{
 *      \BBtick\elems{
 *          \ldots,
 *          \elb{K-1}{},
 *          \ela{K}{}
 *      }
 *  }
 * @f$
 */
void ose_swap(ose_bundle B)
{
    int32_t onm1, snm1, on, sn;
    ose_assert(ose_isBundle(B));
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    be2(B, &onm1, &snm1, &on, &sn);
    ose_assert(sn >= 4);
    ose_assert(snm1 >= 4);
    ose_assert(onm1 + snm1 + 4 == on);
    ose_assert(on + sn + 4 == ose_readSize(B));
    ose_swap_impl(B, onm1, snm1, on, sn);
}

/**
 * @f$
 *  \fn{TUCK}{
 *      \BB\elems{
 *          \ldots,
 *          \ela{K-1}{},
 *          \elb{K}{}
 *      }
 *  }{
 *      \BBtick\elems{
 *          \ldots,
 *          \elb{K-1}{},
 *          \ela{K}{},
 *          \elb{K+1}{}
 *      }
 *  }
 * @f$
 */
void ose_tuck(ose_bundle B)
{
    int32_t onm1, snm1, on, sn;
    ose_assert(ose_isBundle(B));
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    be2(B, &onm1, &snm1, &on, &sn);
    ose_assert(sn >= 4);
    ose_assert(snm1 >= 4);
    ose_assert(onm1 + snm1 + 4 == on);
    ose_assert(on + sn + 4 == ose_readSize(B));
    ose_swap_impl(B, onm1, snm1, on, sn);
    ose_over_impl(B, onm1, sn, onm1 + sn + 4, snm1);
}

/**************************************************
 * Grouping / Ungrouping
 **************************************************/

/**
 * @f$
 *   \fn{BUNDLEALL}{
 *      \BB\elems{
 *          \ldots,
 *          \ela{K}{}
 *      }
 *  }{
 *      \BBtick\elems{
 *			\elb{1}{\type{\ttbndl}}\items{
 *				\ldots,
 *				\ela{K}{}
 *			}
 *      }
 *  }
 * @f$
 */
void ose_bundleAll(ose_bundle B)
{
    int32_t s;
    char *b;
    ose_assert(ose_isBundle(B));
    b = ose_getBundlePtr(B);
    ose_assert(b);
    s = ose_readSize(B);
    ose_assert(s >= OSE_BUNDLE_HEADER_LEN);
    
    memmove(b + OSE_BUNDLE_HEADER_LEN + 4 + OSE_BUNDLE_HEADER_LEN,
            b + OSE_BUNDLE_HEADER_LEN,
            s - OSE_BUNDLE_HEADER_LEN);
    ose_writeInt32_outOfBounds(B, OSE_BUNDLE_HEADER_LEN, s);
    memcpy(b + OSE_BUNDLE_HEADER_LEN + 4,
           OSE_BUNDLE_HEADER,
           OSE_BUNDLE_HEADER_LEN);
    ose_incSize(B, 4 + OSE_BUNDLE_HEADER_LEN);
}
/**
 * @f$
 *	\left\{
 *  	\begin{array}{lr}
 *      	\fn{BUNDLEFROMBOTTOM}{
 *          	\BB\elems{
 *              	\ldots,
 *                	\ela{K}{\type{\ttmsg(\type{\tti})}}\items{
 *						\ita{}{\type{\tti}}\values{\valv{}{}}
 *                	}
 *            	}
 *        	}{
 *             	\BBtick\elems{
 *             		\elb{K}{\type{\ttbndl}}\items{},
 *                	\ldots
 *            	}
 *        	}, & v = 0 \\
 *        	\fn{BUNDLEFROMBOTTOM}{
 *             	\BB\elems{
 *                	\elb{1}{},
 *                	\ldots,
 *                	\ela{K}{\type{\ttmsg(\type{\tti})}}\items{
 *						\ita{}{\type{\tti}}\values{\valv{}{}}
 *                	}
 *            	}
 *        	}{
 *          	\BBtick\elems{
 *              	\elc{1}{\type{\ttbndl}}\items{
 *						\elb{1}{}
 *              	}
 *                  \ldots
 *          	}
 *        	}, & v = 1 \\
 *        	\fn{BUNDLEFROMBOTTOM}{
 *             	\BB\elems{
 *                	\elb{1}{},
 *                	\ldots,
 *                	\elc{v}{},
 *                	\ldots,
 *                	\ela{K}{\type{\ttmsg(\type{\tti})}}\items{
 *						\ita{}{\type{\tti}}\values{\valv{}{}}
 *                	}
 *            	}
 *        	}{
 *             	\BBtick\elems{
 *             		\eld{1}{\type{\ttbndl}}\items{
 *						\elb{1}{},
 *						\ldots,
 *						\elc{v}{}
 *             		}
 *                	\ldots
 *            	}
 *        	}, & v > 1
 *    	\end{array}
 *	\right.
 * @f$
 */
void ose_bundleFromBottom(ose_bundle B)
{
    int32_t s, n, o, i;
    char *b;
    ose_assert(ose_isBundle(B));
    b = ose_getBundlePtr(B);
    ose_assert(b);
    s = ose_readSize(B);
    ose_assert(s > OSE_BUNDLE_HEADER_LEN);
    ose_assert(ose_peekType(B) == OSETT_MESSAGE);
    ose_assert(ose_isIntegerType(ose_peekMessageArgType(B)));
    n = ose_popInt32(B);
    s = ose_readSize(B);
    ose_assert(s >= OSE_BUNDLE_HEADER_LEN);
    ose_assert(n >= 0);
    if(!ose_bundleHasAtLeastNElems(B, n))
    {
        ose_errno_set(B, OSE_ERR_ELEM_COUNT);
        return;
    }
    if(ose_readSize(B) == OSE_BUNDLE_HEADER_LEN
       && n == 0)
    {
        ose_pushBundle(B);
    }
    else
    {
        o = OSE_BUNDLE_HEADER_LEN;
        for(i = 0; i < n; i++)
        {
            int32_t ss = ose_readInt32(B, o);
            ose_assert(ss > 0);
            o += ss + 4;
            ose_assert(o <= s);
        }
        memmove(b + OSE_BUNDLE_HEADER_LEN + 4 + OSE_BUNDLE_HEADER_LEN,
                b + OSE_BUNDLE_HEADER_LEN,
                s - OSE_BUNDLE_HEADER_LEN);
        ose_writeInt32(B, OSE_BUNDLE_HEADER_LEN, o);
        memcpy(b + OSE_BUNDLE_HEADER_LEN + 4,
               OSE_BUNDLE_HEADER,
               OSE_BUNDLE_HEADER_LEN);
        ose_incSize(B, 4 + OSE_BUNDLE_HEADER_LEN);
    }
}

/**
 * @f$
 *	\left\{
 *    	\begin{array}{lr}
 *        	\fn{BUNDLEFROMTOP}{
 *             	\BB\elems{
 *                	\ldots,
 *                	\ela{K}{\type{\ttmsg(\type{\tti})}}\items{
 *						\ita{}{\type{\tti}}\values{\valv{}{}}
 *                	}
 *            	}
 *        	}{
 *             	\BBtick\elems{K}{
 *                	\ldots,
 *                	\elb{K}{\type{\ttbndl}}\items{}
 *            	}
 *        	}, & v = 0 \\
 *        	\fn{BUNDLEFROMTOP}{
 *             	\BB\elems{
 *                	\ldots,
 *                	\elb{K-1}{},
 *                	\ela{K}{\type{\ttmsg(\type{\tti})}}\items{
 *						\ita{}{\type{\tti}}\values{\valv{}{}}
 *                	}
 *            	}
 *        	}{
 *             	\BBtick\elems{
 *                	\ldots,
 *                	\elc{K-1}{\type{\ttbndl}}\items{
 *						\itb{}{}
 *                	}
 *            	}
 *        	}, & v = 1 \\
 *        	\fn{BUNDLEFROMTOP}{
 *             	\BB\elems{
 *                	\ldots,
 *                	\elb{K-v}{},
 *                	\ldots,
 *                	\elc{K-1}{},
 *                	\ela{K}{\type{\ttmsg(\type{\tti})}}\items{
 *						\ita{}{\type{\tti}}\values{\valv{}{}}
 *                	}
 *            	}
 *        	}{
 *            	\BBtick\elems{
 *                	\ldots,
 *                	\eld{K-v}{\type{\ttbndl}}\items{
 *						\elb{1}{},
 *						\ldots,
 *						\elc{v}{}
 *                	}
 *            	}
 *        	}, & v > 1
 *    	\end{array}
 *	\right.
 * @f$
 */
void ose_bundleFromTop(ose_bundle B)
{
    char *b;
    int32_t n, nmsgs, o, bndlsize, ss, oo;
    ose_assert(ose_isBundle(B));
    b = ose_getBundlePtr(B);
    ose_assert(b);
    bndlsize = ose_readSize(B);
    ose_assert(bndlsize >= OSE_BUNDLE_HEADER_LEN);
    nmsgs = ose_getBundleElemCount(B) - 1;
    ose_assert(nmsgs >= 0);
    ose_assert(ose_peekType(B) == OSETT_MESSAGE);
    ose_assert(ose_isIntegerType(ose_peekMessageArgType(B)));
    n = ose_popInt32(B);
    if(n == 0)
    {
        ose_pushBundle(B);
    }
    else if(n > nmsgs)
    {
        ose_errno_set(B, OSE_ERR_ELEM_COUNT);
    }
    else
    {
        o = OSE_BUNDLE_HEADER_LEN;
        while(n < nmsgs)
        {
            int32_t s = ose_readInt32(B, o);
            ose_assert(s > 0);
            o += s + 4;
            ose_assert(o <= bndlsize);
            nmsgs--;
        }
        ss = 0;
        oo = o;
        while(nmsgs > 0)
        {
            int32_t s = ose_readInt32(B, o);
            ose_assert(s > 0);
            o += s + 4;
            ose_assert(o <= bndlsize);
            nmsgs--;
            ss += s + 4;
        }
        ose_assert(ss > 0);
        memmove(b + oo + 4 + OSE_BUNDLE_HEADER_LEN,
                b + oo,
                ss);
        ose_writeInt32_outOfBounds(B, oo, ss + OSE_BUNDLE_HEADER_LEN);
        memcpy(b + oo + 4,
               OSE_BUNDLE_HEADER,
               OSE_BUNDLE_HEADER_LEN);
        ose_incSize(B, 4 + OSE_BUNDLE_HEADER_LEN);
    }
}

/**
 * @f$
 * 	\fn{CLEAR}{
 *		\BB\elems{\ldots}
 * 	}{
 *		\BBtick\elems{}
 * 	}
 * @f$
 */
void ose_clear(ose_bundle B)
{
    char *b;
    int32_t s;
    ose_assert(ose_isBundle(B));
    s = ose_readSize(B);
    ose_assert(s >= OSE_BUNDLE_HEADER_LEN);
    b = ose_getBundlePtr(B);
    ose_assert(b);
    memset(ose_getBundlePtr(B) + OSE_BUNDLE_HEADER_LEN,
           0,
           s - OSE_BUNDLE_HEADER_LEN);
    ose_decSize(B, (s - OSE_BUNDLE_HEADER_LEN));
}

/**
 * @f$
 * 	\fnname{POP}\left\{
 * 		\begin{array}{lr}
 * 			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{}\items{}
 *				}
 * 			}{
 *				\BBtick\elems{
 *					\ldots
 *				}
 * 			}, \\
 * 			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{\type{\ttbndl}}\items{
 *						\ldots,
 *						\ita{L}{}
 *					}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\ela{K}{}\items{\ldots},
 *					\ita{K+1}{}
 *				}
 *			}, \\
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{\type{\ttmsg}}\items{
 *						\ldots,
 *						\ita{L}{}
 *					}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\ela{K}{}\items{\ldots},
 *					\elb{K+1}{\type{\ttmsg}}\items{
 *						\ita{}{}
 *					}
 *				}
 *			}
 *		\end{array}
 *	\right.
 * @f$
 */
void ose_pop(ose_bundle B)
{
    int32_t o = ose_getLastBundleElemOffset(B);
    char *b = ose_getBundlePtr(B);
    switch(ose_getBundleElemType(B, o)){
    case OSETT_MESSAGE:
    {
        int32_t tto, ntt, lto, plo, lpo;
        tto = ose_getBundleElemTTOffset(B, o);
        if(ose_readByte(B, tto + 1) == 0)
        {
            ose_dropAtOffset(B, o);
            return;
        }
        ose_getNthPayloadItem(B, 1, o,
                              &tto, &ntt, &lto, &plo, &lpo);
        switch(ose_readByte(B, lto))
        {
        case OSETT_ID:
            ose_pushString(B, b + o + 4);
            ose_swap(B);
            ose_drop(B);
            break;
        default:
        {
            int32_t s = ose_readInt32(B, o);
            int32_t data_size = s - (lpo - (o + 4));
            char tt = ose_readByte(B, lto);
            memmove(b + lpo + 4 + OSE_ADDRESS_ANONVAL_SIZE + 4,
                    b + lpo,
                    data_size);
            *((int32_t *)(b + lpo)) =
                ose_htonl(OSE_ADDRESS_ANONVAL_SIZE
                          + 4
                          + data_size);
            strncpy(b + lpo + 4,
                    OSE_ADDRESS_ANONVAL,
                    OSE_ADDRESS_ANONVAL_SIZE);
            b[lpo + 4 + OSE_ADDRESS_ANONVAL_SIZE] = OSETT_ID;
            b[lpo + 4 + OSE_ADDRESS_ANONVAL_SIZE + 1] = tt;
            b[lpo + 4 + OSE_ADDRESS_ANONVAL_SIZE + 2] = 0;
            b[lpo + 4 + OSE_ADDRESS_ANONVAL_SIZE + 3] = 0;
            b[lto] = 0;
            int32_t n = data_size;
            int32_t nn = 0;
            if(ose_pnbytes(ntt) != ose_pnbytes(ntt - 1))
            {
                nn = 4;
                int32_t tto = lto + 1;
                int32_t x=(lpo
                           + 8
                           + OSE_ADDRESS_ANONVAL_SIZE
                           + data_size);
                memmove(b + tto, b + tto + 4, x);
                memset(b + x - 4, 0, 4);
            }
            ose_addToInt32(B, o, -(n + nn));
            ose_incSize(B, 8 + OSE_ADDRESS_ANONVAL_SIZE - nn);
        }
        }
        break;
    }
    case OSETT_BUNDLE:
    {
        int32_t s = ose_readInt32(B, o);
        if(s <= 16)
        {
            ose_decSize(B, 20);
            memset(b + o, 0, 20);
        }
        else
        {
            int32_t oo = o + 20;
            int32_t ss = ose_readInt32(B, oo);
            while((oo + ss + 4) - (o + 4) < s)
            {
                oo += ss + 4;
                ss = ose_readInt32(B, oo);
            }
            ose_addToInt32(B, o, -(ss + 4));
        }
        break;
    }
    default:
        assert(0 &&
               "found something that is neither a bundle nor a message");
    }
}

static void popAll_bundle(ose_bundle B, const int32_t o)
{
    int32_t s = ose_readInt32(B, o);
    ose_incSize(B, s - OSE_BUNDLE_HEADER_LEN);
    char *b = ose_getBundlePtr(B);
    memcpy(b + o + s + 4,
           b + o + 4 + OSE_BUNDLE_HEADER_LEN,
           s - OSE_BUNDLE_HEADER_LEN);
    int32_t o1 = (o + s + 4) - (OSE_BUNDLE_HEADER_LEN + 4);
    ose_writeInt32(B, o1, OSE_BUNDLE_HEADER_LEN);
    memcpy(b + o1 + 4, OSE_BUNDLE_HEADER, OSE_BUNDLE_HEADER_LEN);

    int32_t bs = ose_readSize(B);
    int32_t o2 = o + s + 4;
    int32_t s2 = 0;
    while(o2 < bs)
    {
        s2 = ose_readInt32(B, o2);
        o1 -= (s2 + 4);
        memcpy(b + o1, b + o2, s2 + 4);
        o2 += s2 + 4;
    }
    memset(b + o + s + 4, 0, s - OSE_BUNDLE_HEADER_LEN);
    ose_decSize(B, (s - OSE_BUNDLE_HEADER_LEN));
}

static void popAll_message(ose_bundle B, int32_t o)
{
    char *b = ose_getBundlePtr(B);
    int32_t s = ose_readInt32(B, o);
    int32_t ao = o + 4;
    int32_t as = ose_getPaddedStringLen(B, ao);
    int32_t to = ao + as;
    int32_t n = strlen(b + to);
    int32_t po = to + ose_pnbytes(n);
    int32_t ps = s - ((po - o) - 4);
    int32_t nbytes = 8
        + as + ps + ((OSE_ADDRESS_ANONVAL_SIZE + 8) * (n - 1));
    ose_incSize(B, nbytes);
    to++;
    int32_t oo = o;
    o += (s + 4 + nbytes) - (4 + as + 4);
    ose_writeInt32(B, o, as + 4);
    memcpy(b + o + 4, b + ao, as);
    ose_writeByte(B, o + 4 + as, OSETT_ID);
    for(int i = 0; i < n - 1; i++)
    {
        char tt = ose_readByte(B, to);
        int32_t is = ose_getPayloadItemSize(B, tt, o, po);
        o -= is;
        memcpy(b + o, b + po, is);
        o -= 4;
        ose_writeByte(B, o, OSETT_ID);
        ose_writeByte(B, o + 1, tt);
#ifdef OSE_USER_ADDRESS_ANONVAL
        o -= OSE_ADDRESS_ANONVAL_SIZE;
        memcpy(b + o, OSE_ADDRESS_ANONVAL, OSE_ADDRESS_ANONVAL_SIZE);
        o -= 4;
#else
        o -= (4 + OSE_ADDRESS_ANONVAL_SIZE);
#endif
        ose_writeInt32(B, o, OSE_ADDRESS_ANONVAL_SIZE + 4 + is);
        to++;
        po += is;
    }
    memmove(b + oo, b + oo + s + 4, nbytes);
    memset(b + oo + s + 4 + nbytes, 0, s + 4);
    ose_decSize(B, (s + 4));
}

/**
 * @f$
 *	\fnname{POPALL}\left\{
 *    	\begin{array}{lr}
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{}\items{}
 *				}
 *			}{
 *				\BB
 *			} \\
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{\type{\ttbndl}}\items{
 *						\ita{1}{},
 *						\ldots,
 *						\itb{L}{}
 *					}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\itb{K}{},
 *					\ldots,
 *					\ita{K+L}{},
 *					\elat{K+L+1}{}\items{}
 *				}
 *			} \\
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{\type{\ttmsg}}\items{
 *						\ita{1}{},
 *						\ldots,
 *						\itb{L}{}
 *					}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\elb{K}{\type{\ttmsg}}\items{
 *						\itb{}{}
 *					},
 *					\ldots,
 *					\elc{K+L}{\type{\ttmsg}}\items{
 *						\ita{}{}
 *					},
 *					\elat{K+L+1}{}\items{}
 *				}
 *			}
 *	  	\end{array}
 *	\right.
 * @f$
 */
void ose_popAll(ose_bundle B)
{
    int32_t o = ose_getLastBundleElemOffset(B);
    if(ose_getBundleElemType(B, o) == OSETT_BUNDLE)
    {
        popAll_bundle(B, o);
    }
    else
    {
        popAll_message(B, o);      
    }
}

/**
 * @f$
 *	\fnname{POPALLDROP}\left\{
 *    	\begin{array}{lr}
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{}\items{}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots
 *				}
 *			} \\
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{\type{\ttbndl}}\items{
 *						\ita{1}{},
 *						\ldots,
 *						\itb{L}{}
 *					}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\itb{K}{},
 *					\ldots,
 *					\ita{K+L}{}
 *				}
 *			} \\
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{\type{\ttmsg}}\items{
 *						\ita{1}{},
 *						\ldots,
 *						\itb{L}{}
 *					}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\elb{K}{\type{\ttmsg}}\items{
 *						\itb{}{}
 *					},
 *					\ldots,
 *					\elc{K+L}{\type{\ttmsg}}\items{
 *						\ita{}{}
 *					}
 *				}
 *			}
 *	  	\end{array}
 *	\right.
 * @f$
 */
void ose_popAllDrop(ose_bundle B)
{
    ose_popAll(B);
    ose_drop(B);
}

/**
 * @f$
 *	\fnname{POPALLDROP}\left\{
 *    	\begin{array}{lr}
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{}\items{}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\elb{K}{\type{\ttbndl}}\items{
 *						\ela{}{}\items{}
 *					}
 *				}
 *			} \\
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{\type{\ttbndl}}\items{
 *						\ita{1}{},
 *						\ldots,
 *						\itb{L}{}
 *					}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\elb{K}{\type{\ttbndl}}\items{
 *						\itb{1}{},
 *						\ldots,
 *						\ita{L}{},
 *						\ela{L+1}{}\items{}
 *					}
 *				}
 *			} \\
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{\type{\ttmsg}}\items{
 *						\ita{1}{},
 *						\ldots,
 *						\itb{L}{}
 *					}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\elb{K}{\type{\ttbndl}}\items{
 *						\elc{1}{\type{\ttmsg}}\items{
 *							\itb{}{}
 *						},
 *						\ldots,
 *						\eld{L}{\type{\ttmsg}}\items{
 *							\ita{}{}
 *						},
 *						\ela{L+1}{}\items{}
 *					}
 *				}
 *			}
 *	  	\end{array}
 *	\right.
 * @f$
 */
void ose_popAllBundle(ose_bundle B)
{
    ose_pushBundle(B);
    ose_swap(B);
    int32_t onm1, snm1, on, sn;
    be2(B, &onm1, &snm1, &on, &sn);
    ose_popAll(B);
    int32_t bs = ose_readSize(B) - onm1 - 4;
    ose_writeInt32(B, onm1, bs);
}

/**
 * @f$
 *	\fnname{POPALLDROPBUNDLE}\left\{
 *    	\begin{array}{lr}
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{}\items{}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\elb{K}{\type{\ttbndl}}\items{}
 *				}
 *			} \\
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{\type{\ttbndl}}\items{
 *						\ita{1}{},
 *						\ldots,
 *						\itb{L}{}
 *					}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\elb{K}{\type{\ttbndl}}\items{
 *						\itb{1}{},
 *						\ldots,
 *						\ita{L}{}
 *					}
 *				}
 *			} \\
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{\type{\ttmsg}}\items{
 *						\ita{1}{},
 *						\ldots,
 *						\itb{L}{}
 *					}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\elb{K}{\type{\ttbndl}}\items{
 *						\elc{1}{\type{\ttmsg}}\items{
 *							\itb{}{}
 *						},
 *						\ldots,
 *						\eld{L}{\type{\ttmsg}}\items{
 *							\ita{}{}
 *						}
 *					}
 *				}
 *			}
 *	  	\end{array}
 *	\right.
 * @f$
 */
void ose_popAllDropBundle(ose_bundle B)
{
    ose_pushBundle(B);
    ose_swap(B);
    int32_t onm1, snm1, on, sn;
    be2(B, &onm1, &snm1, &on, &sn);
    ose_popAllDrop(B);
    int32_t bs = ose_readSize(B) - onm1 - 4;
    ose_writeInt32(B, onm1, bs);
}

/**
 * @f$
 *	\fn{REVERSE}{
 *		\BB\elems{
 *			\ela{0}{},
 *			\ldots,
 *			\elb{K}{}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\elb{0}{},
 *			\ldots,
 *			\ela{K}{}
 *		}
 *	}
 * @f$
 */
void ose_reverse(ose_bundle B)
{
    ose_assert(ose_isBundle(B));
    ose_assert(!ose_bundleIsEmpty(B));
    char *b = ose_getBundlePtr(B);
    int32_t o1 = ose_getLastBundleElemOffset(B);
    int32_t s = ose_readInt32(B, o1);
    int32_t o2 = o1 + s + 4;
    ose_dup_impl(B, o1, s);
    if(ose_peekType(B) == OSETT_MESSAGE)
    {
        int32_t addrsize = ose_pstrlen(b + o1 + 4);
        int32_t tto1 = o1 + 4 + addrsize;
        int32_t ntt = strlen(b + tto1) - 1;
        int32_t tto2 = o2 + 4 + addrsize + ntt + 1;
        int32_t plo1 = tto1 + ose_pstrlen(b + tto1);
        int32_t plo2 = o2 + s + 4;
        int32_t i;
        ++tto1;
        --tto2;
        
        for(i = 0; i < ntt; ++i)
        {
            int32_t tt = ose_readByte(B, tto1);
            int32_t is = ose_getPayloadItemSize(B,
                                                tt,
                                                o1,
                                                plo1);
            ose_writeByte(B, tto2, tt);
            --tto2;
            ++tto1;
            plo2 -= is;
            memcpy(b + plo2, b + plo1, is);
            plo1 += is;
        }
        ose_writeByte(B, tto2, OSETT_ID);
        memcpy(b + o1,
               b + o2,
               s + 4);
        ose_drop_impl(B, o2, s);
    }
    else
    {
        int32_t o1p = o1;
        int32_t o2p = ose_readSize(B);
        o1p += OSE_BUNDLE_HEADER_LEN + 4;
        while(o1p < o2)
        {
            int32_t ss = ose_readInt32(B, o1p);
            o2p -= ss + 4;
            memcpy(b + o2p, b + o1p, ss + 4);
            o1p += ss + 4;
        }
        memcpy(b + o1, b + o2, s + 4);
        memset(b + o2, 0, s + 4);
        ose_decSize(B, s + 4);
    }
}

/**
 * @f$
 *	\fnname{PUSH}\left\{
 *    	\begin{array}{lr}
 *			\fnmapping{
 *				\BB\elems{}
 *			}{
 *				\BBtick\elems{
 *					\ela{}{\type{\ttbndl}}
 *				}
 *			} \\
 *			\fnmapping{
 *				\BB\elems{\ela{}{}}
 *			}{
 *				\BBtick\elems{
 *					\elb{}{\type{\ttbndl}}\items{\ela{}{}}
 *				}
 *			} \\
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K-1}{\type{\ttmsg}}\items{
 *						\ita{1}{},
 *						\ldots,
 *						\itb{L}{}
 *					}
 *					\elb{K}{\type{\ttmsg}}\items{
 *						\itc{1}{},
 *						\ldots,
 *						\itd{M}{}
 *					}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\elat{K-1}{\type{\ttmsg}}\items{
 *						\ita{1}{},
 *						\ldots,
 *						\itb{L}{},
 *						\itc{L+1}{},
 *						\ldots,
 *						\itd{L+M}{}
 *					}
 *				}
 *			} \\
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K-1}{\type{\ttbndl}}\items{
 *						\ldots,
 *						\ita{L}{}
 *					},
 *					\elb{K}{}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\elat{K-1}{\type{\ttbndl}}\items{
 *						\ldots,
 *						\ita{L}{},
 *						\elb{L+1}{}
 *					}
 *				}
 *			} \\
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K-1}{\type{\ttmsg}}\items{
 *						\ldots,
 *						\ita{L}{}
 *					},
 *					\elb{K}{\type{\ttbndl}}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\elat{K-1}{\type{\ttmsg}}\items{
 *						\ldots,
 *						\ita{L}{},
 *						\itb{L+1}{\type{\ttb}}
 *					}
 *				}
 *			}
 *	  	\end{array}
 *  \right.
 * @f$
 */
void ose_push(ose_bundle B)
{
    int32_t s = ose_readSize(B);
    char *b = ose_getBundlePtr(B);
    if(s <= 16)
    {
        ose_incSize(B, 4 + OSE_BUNDLE_HEADER_LEN);
        ose_writeInt32(B, OSE_BUNDLE_HEADER_LEN,
                       OSE_BUNDLE_HEADER_LEN);
        memcpy(b + OSE_BUNDLE_HEADER_LEN + 4,
               OSE_BUNDLE_HEADER, OSE_BUNDLE_HEADER_LEN);
    }
    else if(s == 16 + ose_readInt32(B, 16) + 4)
    {
        ose_incSize(B, OSE_BUNDLE_HEADER_LEN + 4);
        memmove(b + OSE_BUNDLE_HEADER_LEN * 2 + 4,
                b + OSE_BUNDLE_HEADER_LEN, s - OSE_BUNDLE_HEADER_LEN);
        ose_writeInt32(B, OSE_BUNDLE_HEADER_LEN, s);
        memcpy(b + OSE_BUNDLE_HEADER_LEN + 4,
               OSE_BUNDLE_HEADER, OSE_BUNDLE_HEADER_LEN);
        
    }
    else
    {
        int32_t o2 = 16;
        int32_t s2 = ose_readInt32(B, o2);
        int32_t o1 = o2;
        int32_t s1 = s2;
        while(o2 + s2 + 4 < s)
        {
            o1 = o2;
            s1 = s2;
            o2 += s2 + 4;
            s2 = ose_readInt32(B, o2);
        }
        char t1 = ose_getBundleElemType(B, o1);
        char t2 = ose_getBundleElemType(B, o2);
        if(t1 == OSETT_BUNDLE)
        {
            ose_addToInt32(B, o1, s2 + 4);
        }
        else if(t1 == OSETT_MESSAGE)
        {
            if(t2 == OSETT_BUNDLE)
            {
                int32_t tto1 =
                    o1 + 4 +
                    ose_getPaddedStringLen(B, o1 + 4);
                int32_t plo1 = tto1 +
                    ose_getPaddedStringLen(B, tto1);
                int32_t ntt1 = strlen(b + tto1);
                if(ose_pnbytes(ntt1) != ose_pnbytes(ntt1 + 1))
                {
                    memmove(b + plo1 + 4,
                            b + plo1,
                            (s1 - (plo1 - (o1 + 4))) + (s2 + 4));
                    memset(b + plo1, 0, 4);
                    ose_addToInt32(B, o1, 4);
                    ose_incSize(B, 4);
                    o2 += 4;
                    plo1 += 4;
                }
                ose_writeByte(B, tto1 + ntt1, OSETT_BLOB);
                int32_t bloblen = ose_readInt32(B, o2);
                /* no need to ppad since it's already
                   4-byte aligned */
                int32_t pbloblen = bloblen;
                ose_addToInt32(B, o1, pbloblen + 4);
                if(pbloblen > bloblen)
                {
                    ose_incSize(B, 4);
                }
            }
            else if(t2 == OSETT_MESSAGE)
            {
                int32_t o3 = o2 + s2 + 4;
                int32_t tto1 =
                    o1 + 4 +
                    ose_getPaddedStringLen(B, o1 + 4);
                int32_t ntt1 = strlen(b + tto1);
                int32_t plo1 = tto1 + ose_pnbytes(ntt1);
                int32_t tto2 =
                    o2 + 4 +
                    ose_getPaddedStringLen(B, o2 + 4);
                int32_t ntt2 = strlen(b + tto2);
                int32_t plo2 = tto2 + ose_pnbytes(ntt2);
                int32_t oo = o3 + 4;
                memcpy(b + oo, b + o1 + 4, plo1 - (o1 + 4));
                oo += (tto1 - o1) - 4 + ntt1;
                memcpy(b + oo, b + tto2 + 1, ntt2 - 1);
                oo += ntt2 - 1;
                oo = ose_pnbytes(oo);
                memcpy(b + oo, b + plo1, s1 - ((plo1 - o1) - 4));
                oo += s1 - ((plo1 - o1) - 4);
                memcpy(b + oo, b + plo2, s2 - ((plo2 - o2) - 4));
                oo += s2 - ((plo2 - o2) - 4);
                int32_t s3 = (oo - o3) - 4;
                ose_writeInt32_outOfBounds(B, o3, s3);
                memmove(b + o1, b + o3, s3 + 4);
                memset(b + o1 + s3 + 4, 0, s2 + s1 + 8);
                ose_addToSize(B,
                              (s3 + 4) - (s1 + 4 + s2 + 4));
            }
            else
            {
                ose_assert(0 && "found something that is neither \a bundle nor a message");
            }
        }
        else
        {
            ose_assert(0 && "found something that is neither a bundle nor a message");
        }       
    }
}

static void ose_decatenateBundleFromStart(ose_bundle B,
                                          const int32_t offset,
                                          const int32_t n)
{
    ose_assert(n >= 0);
    int32_t s = ose_readInt32(B, offset);
    int32_t oo = offset + 4 + OSE_BUNDLE_HEADER_LEN;
    int32_t ss = ose_readInt32(B, oo);
    int i = 0;
    for(; i < n; i++)
    {
        if(oo >= offset + s + 4)
        {
            break;
        }
        oo += ss + 4;
        ss = ose_readInt32(B, oo);
    }
    if(i != n)
    {
        /* n is apparently greater than the number of elems. */
    }
    ose_incSize(B, OSE_BUNDLE_HEADER_LEN + 4);
    char *b = ose_getBundlePtr(B);
    int32_t newbundlesize = s - (oo - (offset + 4));
    memmove(b + oo + OSE_BUNDLE_HEADER_LEN + 4,
            b + oo,
            newbundlesize);
    ose_writeInt32(B,
                   offset,
                   ose_readInt32(B, offset) - newbundlesize);
    newbundlesize += OSE_BUNDLE_HEADER_LEN;
    ose_writeInt32(B, oo, newbundlesize);
    memcpy(b + oo + 4, OSE_BUNDLE_HEADER, OSE_BUNDLE_HEADER_LEN);
}

static void ose_decatenateMessageFromStart(ose_bundle B,
                                           int32_t offset,
                                           int32_t n)
{
    ose_assert(n >= 0);
    int32_t s = ose_readInt32(B, offset);
    int32_t to = offset + 4 + ose_getPaddedStringLen(B,
                                                     offset + 4);
    int32_t ntt = ose_getStringLen(B, to);
    int32_t po = to + ose_pnbytes(ntt);
    int32_t ton = to + 1, pon = po;
    int i = 0;
    char *b = ose_getBundlePtr(B);
    for(; i < n; i++)
    {
        if(ose_readByte(B, ton) == 0)
        {
            break;
        }
        /* pon += ose_getTypedDatumSize(b[ton], b + pon); */
        pon += ose_getPayloadItemSize(B,
                                      b[ton],
                                      offset,
                                      pon);
        ton++;
    }
    if(i != n)
    {
        /* n is apparently greater than the number of elems. */
    }

    int32_t msg1_ntt = i, msg2_ntt = (ntt - 1) - i;
    if(msg2_ntt < 0)
    {
        msg2_ntt = 0;
    }
    if(msg2_ntt == 0)
    {
        ose_incSize(B, 4 + OSE_ADDRESS_ANONVAL_SIZE
                    + OSE_EMPTY_TYPETAG_STRING_SIZE);
        ose_writeInt32(B, offset + s + 4,
                       OSE_ADDRESS_ANONVAL_SIZE
                       + OSE_EMPTY_TYPETAG_STRING_SIZE);
        memcpy(b + offset + s + 4 + 4,
               //OSE_ADDRESS_ANONVAL OSE_EMPTY_TYPETAG_STRING,
               OSE_ADDRESS_ANONVAL_EMPTY_TYPETAG_STRING,
               OSE_ADDRESS_ANONVAL_SIZE
               + OSE_EMPTY_TYPETAG_STRING_SIZE);
        return;
    }
    int32_t msg1_nttp = ose_pnbytes(msg1_ntt + 1);
    int32_t msg2_nttp = ose_pnbytes(msg2_ntt + 1);
    int32_t msg2_size = OSE_ADDRESS_ANONVAL_SIZE + msg2_nttp
        + (s - (pon - (offset + 4)));
    ose_incSize(B, msg2_size + 4);

    int32_t msg2_offset = offset + s + 4;
    int32_t msg2_ttoffset = msg2_offset + 4
        + OSE_ADDRESS_ANONVAL_SIZE;
    int32_t msg2_poffset = msg2_ttoffset + msg2_nttp;
    ose_writeInt32(B, msg2_offset, msg2_size);
    ose_writeByte(B, msg2_ttoffset, OSETT_ID);
    memcpy(b + msg2_ttoffset + 1, b + ton, msg2_ntt);
    memcpy(b + msg2_poffset, b + pon, s - (pon - (offset + 4)));

    for(int j = 0; j < msg1_nttp - msg1_ntt; j++)
    {
        ose_writeByte(B, ton + j, 0);
    }
    memmove(b + to + msg1_nttp,
            b + po,
            (msg2_offset + 4 + msg2_size) - po);

    int32_t diff = po - (to + msg1_nttp);
    memmove(b + pon - diff, b + msg2_offset - diff, msg2_size + 4);
    diff += (msg2_offset - pon);
    ose_decSize(B, diff);
    ose_addToInt32(B, offset, -diff);
}

static void ose_decatenateElemFromStart_impl(ose_bundle B,
                                             int32_t n,
                                             int32_t o)
{
    if(ose_getBundleElemType(B, o) == OSETT_BUNDLE)
    {
        ose_decatenateBundleFromStart(B, o, n);
    }
    else
    {
        ose_decatenateMessageFromStart(B, o, n);
    }
}

/**
 * @f$
 *	\fn{DECATENATEELEMFROMSTART}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K-1}{\type{\ttvar}}\items{
 *				\ita{1}{},
 *				\ldots,
 *				\itb{v}{},
 *				\ldots
 *			}
 *			\elb{K}{\type{\ttmsg(\type{\tti})}}\items{
 *				\itc{}{\type{\tti}}\values{\valv{}{}}
 *			}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\elat{K-1}{\type{\ttvar}}\items{
 *				\ita{1}{},
 *				\ldots,
 *				\itb{v}{}
 *			},
 *			\elc{K}{\type{\ttvar}}\items{\ldots}
 *		}
 *	}
 * @f$
 */
void ose_decatenateElemFromStart(ose_bundle B)
{
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    int32_t n = ose_popInt32(B);
    int32_t o = ose_getLastBundleElemOffset(B);
    ose_decatenateElemFromStart_impl(B, n, o);
}

/**
 * @f$
 *	\fn{DECATENATEELEMFROMEND}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K-1}{\type{\ttvar}}\items{
 *				\ldots,
 *				\ita{L-v}{},
 *				\ldots,
 *				\itb{L}{}
 *			},
 *			\elb{K}{\type{\ttmsg(\type{\tti})}}\items{
 *				\itc{}{\type{\tti}}\values{\valv{}{}}
 *			}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\elat{K-1}{\type{\ttvar}}\items{\ldots},
 *			\elc{K}{\type{\ttvar}}\items{
 *				\ita{1}{},
 *				\ldots,
 *				\itb{v}{}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_decatenateElemFromEnd(ose_bundle B)
{
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    int32_t n = ose_popInt32(B);
    int32_t o = ose_getLastBundleElemOffset(B);
    int32_t c = ose_getBundleElemElemCount(B, o);
    ose_decatenateElemFromStart_impl(B, c - n, o);
}

/**
 * @f$
 * 	\fnname{CONCATENATEELEMS}\left\{
 *		\begin{array}{lr}
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K-1}{\type{\ttvar}}\items{
 *						\ita{1}{},
 *						\ldots,
 *						\itb{L}{}
 *					},
 *					\elb{K}{\type{\ttvar}}\items{
 *						\itc{1}{},
 *						\ldots,
 *						\itd{M}{}
 *					}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\elat{K-1}{}\items{
 *						\ita{1}{},
 *						\ldots,
 *						\itb{L}{},
 *						\ldots,
 *						\itc{L+1}{},
 *						\ldots,
 *						\itd{L+M}{}
 *					}
 *				}
 *			}, \text{ for } \ttvar = \ttbndl \text{ and} \\
 *			\fnmapping{
 *				\BB
 *			}{
 *				\fnname{PUSH}\fninput{\BB}
 *			} \text{ otherwise.}
 *		\end{array}
 * 	\right.
 * @f$
 */
void ose_concatenateElems(ose_bundle B)
{
    ose_assert(ose_isBundle(B));
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    int32_t onm1, snm1, on, sn;
    be2(B, &onm1, &snm1, &on, &sn);
    char tnm1 = ose_getBundleElemType(B, onm1);
    char tn = ose_getBundleElemType(B, on);
    if(tnm1 == OSETT_BUNDLE && tn == OSETT_BUNDLE)
    {
        char *b = ose_getBundlePtr(B);
        memmove(b + on,
                b + on + 4 + OSE_BUNDLE_HEADER_LEN,
                sn - OSE_BUNDLE_HEADER_LEN);
        memset(b + on + sn + 4, 0, 4 + OSE_BUNDLE_HEADER_LEN);
        ose_addToInt32(B, onm1, sn - OSE_BUNDLE_HEADER_LEN);
        ose_decSize(B, OSE_BUNDLE_HEADER_LEN + 4);
    }
    else
    {
        ose_push(B);
    }
}

/**
 * @f$
 * 	\fnname{UNPACK}\left\{
 * 		\begin{array}{lr}
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{\type{\ttbndl}}\items{
 *						\ita{1}{},
 *						\ldots,
 *						\itb{L}{}
 *					}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\ela{K}{}\items{},
 *					\ita{K+1}{},
 *					\ldots,
 *					\itb{K+L}{}
 *				}
 *			}, \\
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{\type{\ttmsg}}\items{
 *						\ita{1}{},
 *						\ldots,
 *						\itb{L}{}
 *					}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\ela{K}{}\items{},
 *					\elb{K+1}{\type{\ttmsg}}\items{
 *						\ita{}{}
 *					},
 *					\ldots,
 *					\elc{K+L}{}\items{
 *						\itb{}{}
 *					}
 *				}
 *			}
 *		\end{array}
 *	\right.
 * @f$
 */
void ose_unpack(ose_bundle B)
{
    ose_assert(ose_isBundle(B));
    ose_assert(ose_bundleHasAtLeastNElems(B, 1));
    int32_t o = ose_getLastBundleElemOffset(B);
    if(ose_getBundleElemType(B, o) == OSETT_BUNDLE)
    {
        ose_writeInt32(B, o, OSE_BUNDLE_HEADER_LEN);
    }
    else
    {
        char *b = ose_getBundlePtr(B);
        int32_t s = ose_readInt32(B, o);
        int32_t to = o + 4;
        to += ose_pstrlen(b + to);
        int32_t po = to + ose_pstrlen(b + to);
        to++;
        ose_pushMessage(B, b + o + 4, strlen(b + o + 4), 0);
        char tt = ose_readByte(B, to);
        while(tt)
        {
            int32_t ps = ose_getPayloadItemSize(B, tt, o, po);
            switch(tt)
            {
            case OSETT_INT32:
            {
                ose_pushMessage(B,
                                OSE_ADDRESS_ANONVAL,
                                OSE_ADDRESS_ANONVAL_LEN,
                                1,
                                OSETT_INT32,
                                ose_readInt32(B, po));
                break;
            }
            case OSETT_FLOAT:
            {
                ose_pushMessage(B,
                                OSE_ADDRESS_ANONVAL,
                                OSE_ADDRESS_ANONVAL_LEN,
                                1,
                                OSETT_FLOAT,
                                ose_readFloat(B, po));
                break;
            }
            case OSETT_STRING:
            {
                ose_pushMessage(B,
                                OSE_ADDRESS_ANONVAL,
                                OSE_ADDRESS_ANONVAL_LEN,
                                1,
                                OSETT_STRING,
                                ose_readString(B, po));
                break;
            }
            case OSETT_BLOB:
            {
                ose_pushMessage(B,
                                OSE_ADDRESS_ANONVAL,
                                OSE_ADDRESS_ANONVAL_LEN,
                                1,
                                OSETT_BLOB,
                                ose_readBlobSize(B, po),
                                b + po + 4);
                break;
            }
#ifdef OSE_PROVIDE_TYPE_SYMBOL
            case OSETT_SYMBOL:
            {
                ose_pushMessage(B,
                                OSE_ADDRESS_ANONVAL,
                                OSE_ADDRESS_ANONVAL_LEN,
                                1,
                                OSETT_SYMBOL,
                                ose_readString(B, po));
                break;
            }
#endif
#ifdef OSE_PROVIDE_TYPE_DOUBLE
            case OSETT_DOUBLE:
            {
                ose_pushMessage(B,
                                OSE_ADDRESS_ANONVAL,
                                OSE_ADDRESS_ANONVAL_LEN,
                                1,
                                OSETT_DOUBLE,
                                ose_readInt32(B, po));
                break;
            }
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
            case OSETT_INT8:
            {
                ose_pushMessage(B,
                                OSE_ADDRESS_ANONVAL,
                                OSE_ADDRESS_ANONVAL_LEN,
                                1,
                                OSETT_INT8,
                                ose_readInt32(B, po));
                break;
            }
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
            case OSETT_UINT8: {
                ose_pushMessage(B,
                                OSE_ADDRESS_ANONVAL,
                                OSE_ADDRESS_ANONVAL_LEN,
                                1,
                                OSETT_UINT8,
                                ose_readInt32(B, po));
                break;
            }
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
            case OSETT_UINT32:
            {
                ose_pushMessage(B,
                                OSE_ADDRESS_ANONVAL,
                                OSE_ADDRESS_ANONVAL_LEN,
                                1,
                                OSETT_UINT32,
                                ose_readInt32(B, po));
                break;
            }
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
            case OSETT_INT64:
            {
                ose_pushMessage(B,
                                OSE_ADDRESS_ANONVAL,
                                OSE_ADDRESS_ANONVAL_LEN,
                                1,
                                OSETT_INT64,
                                ose_readInt32(B, po));
                break;
            }
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
            case OSETT_UINT64:
            {
                ose_pushMessage(B,
                                OSE_ADDRESS_ANONVAL,
                                OSE_ADDRESS_ANONVAL_LEN,
                                1,
                                OSETT_UINT64,
                                ose_readInt32(B, po));
                break;
            }
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
            case OSETT_TIMETAG:
            {
                ose_pushMessage(B,
                                OSE_ADDRESS_ANONVAL,
                                OSE_ADDRESS_ANONVAL_LEN,
                                1,
                                OSETT_TIMETAG,
                                ose_readInt32(B, po),
                                ose_readInt32(B, po + 4));
                break;
            }
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
            case OSETT_TRUE:
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
            case OSETT_FALSE:
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
            case OSETT_NULL:
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
            case OSETT_INFINITUM:
#endif
#if defined(OSE_PROVIDE_TYPE_TRUE) ||           \
    defined(OSE_PROVIDE_TYPE_TRUE) ||           \
    defined(OSE_PROVIDE_TYPE_TRUE) ||           \
    defined(OSE_PROVIDE_TYPE_TRUE) 
                ose_pushMessage(B,
                                OSE_ADDRESS_ANONVAL,
                                OSE_ADDRESS_ANONVAL_LEN,
                                1,
                                tt);
                break;
#endif
            default:
            {
                int32_t ss = ose_getPayloadItemSize(B,
                                                    tt,
                                                    o,
                                                    po);
                ose_pushMessage(B,
                                OSE_ADDRESS_ANONVAL,
                                OSE_ADDRESS_ANONVAL_LEN,
                                1, OSETT_BLOB, ss - 4, NULL);
                ose_writeByte(B,
                              ose_readSize(B) - (ss + 3),
                              tt);
                memcpy(b + (ose_readSize(B) - ss),
                       b + po,
                       ss);
                break;
            }
            }
            to++;
            tt = ose_readByte(B, to);
            po += ps;
        }
        int32_t bs = ose_readSize(B);
        memcpy(b + o, b + o + s + 4, bs - (o + s + 4));
        memset(b + (bs - (s + 4)), 0, s + 4);
        ose_decSize(B, (s + 4));
    }
}

/**
 * @f$
 * 	\fnname{UNPACKDROP}\left\{
 * 		\begin{array}{lr}
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{\type{\ttbndl}}\items{
 *						\ita{1}{},
 *						\ldots,
 *						\itb{L}{}
 *					}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\ita{K}{},
 *					\ldots,
 *					\itb{K+L-1}{}
 *				}
 *			}, \\
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{\type{\ttmsg}}\items{
 *						\ita{1}{},
 *						\ldots,
 *						\itb{L}{}
 *					}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\elb{K}{\type{\ttmsg}}\items{
 *						\ita{}{}
 *					},
 *					\ldots,
 *					\elc{K+L-1}{}\items{
 *						\itb{}{}
 *					}
 *				}
 *			}
 *		\end{array}
 *	\right.
 * @f$
 */
void ose_unpackDrop(ose_bundle B)
{
    ose_assert(ose_isBundle(B));
    char *b = ose_getBundlePtr(B);
    int32_t o = ose_getLastBundleElemOffset(B);
    int32_t s = ose_readInt32(B, o);
    if(!strcmp(b + o + 4, OSE_BUNDLE_ID))
    {
        memmove(b + o, b + o + 4 + OSE_BUNDLE_HEADER_LEN,
                (s - OSE_BUNDLE_HEADER_LEN));
        memset(b + o + 4 + (s - OSE_BUNDLE_HEADER_LEN), 0,
               4 + OSE_BUNDLE_HEADER_LEN);
        ose_decSize(B, 4 + OSE_BUNDLE_HEADER_LEN);
    }
    else
    {
        int32_t n = ose_getBundleElemElemCount(B, o);
        ose_unpack(B);
        ose_pushInt32(B, n);
        ose_roll(B);
        ose_drop(B);
    }
}

/**************************************************
 * Queries
 **************************************************/

/**
 * @f$
 *	\fn{COUNTELEMS}{
 *		\BB\elems{\ldots, \ela{K}{}}
 *	}{
 *		\BBtick\elems{
 *			\ldots, 
 *			\ela{K}{},
 *			\elb{K+1}{\type{\ttmsg(\type{\tti})}}\items{
 *				\ita{}{\type{\tti}}\values{K}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_countElems(ose_bundle B)
{
    int32_t s = ose_readSize(B);
    int32_t o = OSE_BUNDLE_HEADER_LEN;
    int32_t n = 0;
    while(o < s)
    {
        n++;
        o += ose_readInt32(B, o) + 4;
    }
    ose_pushInt32(B, n);
}

/**
 * @f$
 *	\fn{COUNTITEMS}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{}\items{
 *				\ldots,
 *				\ita{L}{}
 *			}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\ela{K}{}\items{
 *				\ldots,
 *				\ita{L}{}
 *			},
 *			\elb{K+1}{\type{\ttmsg(\type{\tti})}}\items{
 *				\itb{}{\type{\tti}}\values{L}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_countItems(ose_bundle B)
{
    int32_t o = ose_getLastBundleElemOffset(B);
    /* runtime check for bundle with 0 elems */
    int32_t n = 0;
    char t = ose_getBundleElemType(B, o);
    if(t == OSETT_BUNDLE)
    {
        int32_t oo = OSE_BUNDLE_HEADER_LEN + 4;
        int32_t ss = ose_readInt32(B, o);
        while(oo < ss)
        {
            n++;
            oo += ose_readInt32(B, o + oo) + 4;
        }
    }
    else if(t == OSETT_MESSAGE)
    {
        int32_t to = o + 4 + ose_getPaddedStringLen(B, o + 4);
        n = strlen(ose_getBundlePtr(B) + to) - 1;
    }
    else
    {
        ose_assert(0 &&
                   "found something that is neither a bundle nor a message");
    }
    ose_pushInt32(B, n);
}

/* void ose_lengthAddress(ose_bundle B) */
/* { */

/* } */

/* void ose_lengthTT(ose_bundle B) */
/* { */

/* } */

/**
 * @f$
 *	\fn{LENGTHITEM}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{}\items{
 *				\ldots,
 *				\ita{}L{}
 *			}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\ela{K}{}\items{
 *				\ldots,
 *				\ita{L}{}
 *			},
 *			\itb{K+1}{\type{\ttmsg(\type{\tti})}}\items{
 *				\itb{}{\type{\tti}}\values{\fnlength{\ita{}{}}}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_lengthItem(ose_bundle B)
{
    int32_t o = ose_getLastBundleElemOffset(B);
    int32_t to, ntt, lto, po, lpo;
    ose_getNthPayloadItem(B, 1, o, &to, &ntt, &lto, &po, &lpo);
    char tt = ose_readByte(B, lto);
    int32_t ps = ose_getPayloadItemLength(B, tt, o, lpo);
    ose_pushInt32(B, ps);
}

/**
 * @todo Implement.
 * 
 * @f$
 *	\fn{LENGTHSITEMS}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{}\items{
 *				\ita{1}{},
 *				\ldots,
 *				\itb{L}{}
 *			}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\ela{K}{}\items{
 *				\ita{1}{},
 *				\ldots,
 *				\itb{L}{}
 *			},
 *			\elb{K+1}{\type{\ttmsg(\allints{1}{L})}}\items{
 *				\itc{1}{\type{\tti}}\values{\fnlength{\ita{}{}}},
 *				\ldots,
 *				\itc{L}{\type{\tti}}\values{\fnlength{\itb{}{}}}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_lengthsItems(ose_bundle B)
{
}

/**
 * @f$
 *	\fn{SIZEELEM}{
 *		\BB\elems{\ldots, \ela{K}{}}
 *	}{
 *		\BBtick\elems{
 *			\ldots, 
 *			\ela{K}{},
 *			\elb{K+1}{\type{\ttmsg(\type{\tti})}}\items{
 *				\itb{}{\type{\tti}}\values{\fnsize{ela{}{}}}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_sizeElem(ose_bundle B)
{
    int32_t o = ose_getLastBundleElemOffset(B);
    /* int32_t n = ose_getBundleElemElemCount(B, o); */
    int32_t n = ose_readInt32(B, o);
    ose_pushInt32(B, n);
}

/**
 * @f$
 *	\fn{SIZEITEM}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{}\items{
 *				\ldots,
 *				\ita{L}{}
 *			}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\ela{K}{}\items{
 *				\ldots,
 *				\ita{L}{}
 *			},
 *			\elb{K+1}{\type{\ttmsg(\type{\tti})}}\items{
 *				\itb{}{\type{\tti}}\values{\fnsize{\ita{}{}}}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_sizeItem(ose_bundle B)
{
    int32_t o = ose_getLastBundleElemOffset(B);
    int32_t to, ntt, lto, po, lpo;
    ose_getNthPayloadItem(B, 1, o, &to, &ntt, &lto, &po, &lpo);
    int32_t s = ose_getPayloadItemSize(B,
                                       ose_readByte(B, lto),
                                       o,
                                       lpo);
    ose_pushInt32(B, s);
}

/**
 * @todo Implement.
 * 
 * @f$
 *	\fn{SIZESELEMS}{
 *		\BB\elems{
 *			\ela{1}{},
 *			\ldots,
 *			\elb{K}{}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ela{1}{},
 *			\ldots,
 *			\elb{K}{},
 *			\elc{K+1}{\type{\ttmsg(\allints{1}{K})}}\items{
 *				\ita{1}{\type{\tti}}\values{\fnsize{\ela{}{}}},
 *				\ldots,
 *				\itb{K}{\type{\tti}}\values{\fnsize{\elb{}{}}}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_sizesElems(ose_bundle B)
{
}

/**
 * @todo Implement.
 * 
 * @f$
 *	\fn{SIZESITEMS}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{}\items{
 *				\ita{1}{},
 *				\ldots,
 *				\itb{L}{}
 *			},
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\ela{K}{}\items{
 *				\ita{1}{},
 *				\ldots,
 *				\itb{L}{}
 *			},
 *			\elb{K+1}{\type{\ttmsg(\allints{1}{L})}}\items{
 *				\itc{1}{\type{\tti}}\values{\fnsize{\ita{}{}}},
 *				\ldots,
 *				\itd{L}{\type{\tti}}\values{\fnsize{\itb{}{}}},
 *			}
 *		}
 *	}
 * @f$
 */
void ose_sizesItems(ose_bundle B)
{
}

/**
 * @f$
 * 	\fnname{getaddresses}\left\{
 * 		\begin{array}{lr}
 * 			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{\type{\ttmsg}}
 *				}
 * 			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\ela{K}{},
 *				    \elb{K+1}{\type{\ttmsg}}\items{
 *						\ita{}{\tts}\values{\fnaddress{\ela{}{}}}
 *				    }
 *				}
 * 			}, \\
 *			\fnmapping{
 *				\BB\elems{
 *					\ldots,
 *					\ela{K}{\type{\ttbndl}}\items{
 *						\ita{1}{},
 *						\ldots,
 *						\itb{L}{}
 *					}
 *				}
 *			}{
 *				\BBtick\elems{
 *					\ldots,
 *					\ela{K}{\type{\ttbndl}}\items{
 *						\ita{1}{},
 *						\ldots,
 *						\itb{L}{}
 *					},
 *					\elb{K+1}{\type{\ttmsg}}\items{
 *						\itc{1}{\type{\tts}}\values{\fnaddress{\ita{}{}}},
 *						\ldots,
 *						\itd{L}{\type{\tts}}\values{\fnaddress{\itb{}{}}},
 *					}
 *				}
 *			}
 *		\end{array}
 *	\right.
 * @f$
 */
void ose_getAddresses(ose_bundle B)
{
    /* this should be a runtime check */
    ose_assert(ose_bundleHasAtLeastNElems(B, 1));
    int32_t on = ose_getLastBundleElemOffset(B);
    char *b = ose_getBundlePtr(B);
    if(ose_getBundleElemType(B, on) == OSETT_MESSAGE)
    {
        ose_pushString(B, b + on + 4);
    }
    else
    {
        int32_t sn = ose_readInt32(B, on);
        int32_t onp1 = on + sn + 4;
        int32_t p = onp1 + 4;
        memcpy(b + p, OSE_ADDRESS_ANONVAL, OSE_ADDRESS_ANONVAL_SIZE);
        p += OSE_ADDRESS_ANONVAL_SIZE;
        /* ose_writeByte_outOfBounds(B, p, OSETT_ID); */
        b[p] = OSETT_ID;
        ++p;
        on += 4 + OSE_BUNDLE_HEADER_LEN;
        while(on < onp1)
        {
            /* ose_writeByte_outOfBounds(B, p, OSETT_STRING); */
            b[p] = OSETT_STRING;
            ++p;
            on += ose_readInt32(B, on) + 4;
        }
        ++p;
        while(p % 4)
        {
            ++p;
        }
        on -= (sn + 4);
        on += 4 + OSE_BUNDLE_HEADER_LEN;
        while(on < onp1)
        {
            int32_t len = strlen(b + on + 4);
            int32_t plen = ose_pnbytes(len);
            memcpy(b + p, b + on + 4, plen);
            p += plen;
            on += ose_readInt32(B, on) + 4;
        }
        int32_t snp1 = (p - onp1);
        ose_writeInt32_outOfBounds(B, onp1, snp1 - 4);
        ose_addToSize(B, snp1);
    }
}

/**
 * @f$
 *	\fn{ELEMISBUNDLE}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{\type{\ttvar}}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\ela{K}{\type{\ttvar}},
 *			\elb{K+1}{\type{\tti}}\items{
 *				\ita{}{\type{\tti}}\values{\valv{}{}}
 *			}
 *		}
 *	}
 * @f$, where @f$v=1@f$ if @f$\ttvar=\type{\ttbndl}@f$, or @f$0@f$ otherwise.
 */
void ose_elemIsBundle(ose_bundle B)
{
    if(ose_peekType(B) == OSETT_BUNDLE)
    {
        ose_pushInt32(B, 1);
    }
    else
    {
        ose_pushInt32(B, 0);
    }
        
}

void ose_typeof0(ose_bundle B)
{
    if(ose_readSize(B) <= OSE_BUNDLE_HEADER_LEN)
    {
        ose_pushMessage(B,
                        OSE_ADDRESS_ANONVAL,
                        OSE_ADDRESS_ANONVAL_LEN,
                        1, OSETT_STRING, "/");
        return;
    }
    char *b = ose_getBundlePtr(B);
    int32_t o = ose_getLastBundleElemOffset(B);
    int32_t s = ose_readInt32(B, o);
    int32_t n = ose_printTypeof0(B, o, NULL, 0);
    ose_pushMessage(B,
                    OSE_ADDRESS_ANONVAL,
                    OSE_ADDRESS_ANONVAL_LEN,
                    1, OSETT_STRING, "");
    int32_t oo = o + s + 4;
    int32_t pn = ose_pnbytes(n);
    ose_incSize(B, pn - 4);
    memset(b + oo + 8 + OSE_ADDRESS_ANONVAL_SIZE, 0, pn);
    ose_writeInt32(B, oo,
                   ose_readInt32(B, oo) + (pn - 4));
    oo += 4 + OSE_ADDRESS_ANONVAL_SIZE + 4;
    ose_printTypeof0(B, o, b + oo, pn);
    ose_nip(B);
}

void ose_typeof1(ose_bundle B)
{
    if(ose_readSize(B) <= OSE_BUNDLE_HEADER_LEN)
    {
        ose_pushMessage(B,
                        OSE_ADDRESS_ANONVAL,
                        OSE_ADDRESS_ANONVAL_LEN,
                        1, OSETT_STRING, "/");
        return;
    }
    char *b = ose_getBundlePtr(B);
    int32_t o = ose_getLastBundleElemOffset(B);
    int32_t s = ose_readInt32(B, o);
    int32_t n = ose_printTypeof1(B, o, NULL, 0);
    ose_pushMessage(B,
                    OSE_ADDRESS_ANONVAL,
                    OSE_ADDRESS_ANONVAL_LEN,
                    1, OSETT_STRING, "");
    int32_t oo = o + s + 4;
    int32_t pn = ose_pnbytes(n);
    ose_incSize(B, pn - 4);
    memset(b + oo + 8 + OSE_ADDRESS_ANONVAL_SIZE, 0, pn);
    ose_writeInt32(B, oo,
                   ose_readInt32(B, oo) + (pn - 4));
    oo += 4 + OSE_ADDRESS_ANONVAL_SIZE + 4;
    ose_printTypeof1(B, o, b + oo, pn);
    ose_nip(B);
}

void ose_typeof2(ose_bundle B)
{
    if(ose_readSize(B) <= OSE_BUNDLE_HEADER_LEN)
    {
        ose_pushMessage(B,
                        OSE_ADDRESS_ANONVAL,
                        OSE_ADDRESS_ANONVAL_LEN,
                        1, OSETT_STRING, "/");
        return;
    }
    char *b = ose_getBundlePtr(B);
    int32_t o = ose_getLastBundleElemOffset(B);
    int32_t s = ose_readInt32(B, o);
    int32_t n = ose_printTypeof2(B, o, NULL, 0);
    ose_pushMessage(B,
                    OSE_ADDRESS_ANONVAL,
                    OSE_ADDRESS_ANONVAL_LEN,
                    1, OSETT_STRING, "");
    int32_t oo = o + s + 4;
    int32_t pn = ose_pnbytes(n);
    ose_incSize(B, pn - 4);
    memset(b + oo + 8 + OSE_ADDRESS_ANONVAL_SIZE, 0, pn);
    ose_writeInt32(B, oo,
                   ose_readInt32(B, oo) + (pn - 4));
    oo += 4 + OSE_ADDRESS_ANONVAL_SIZE + 4;
    ose_printTypeof2(B, o, b + oo, pn);
    ose_nip(B);
}

/**************************************************
 * Operations on Bundle Elements and Items
 **************************************************/

/**
 * @f$
 * 	\fn{SETTYPETAG\_IMPL}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{\type{\ttmsg}}\items{
 *				\ldots,
 *				\ita{L}{\ttvar}
 *			}
 *		}, \upsilon
 *	}{
 * 		\BBtick\elems{
 * 			\ldots,
 * 			\elat{K}{\type{\ttmsg}}\items{
 *				\ldots,
 *				\ita{L}{\upsilon}
 * 			}
 *		}
 *	}
 * @f$
 */
void ose_setTypetag_impl(ose_bundle B, char typetag)
{
    int32_t o = ose_getLastBundleElemOffset(B);
    int32_t to, ntt, lto, po, lpo;
    ose_getNthPayloadItem(B, 1, o, &to, &ntt, &lto, &po, &lpo);
    ose_writeByte(B, lto, typetag);
}

/**
 * @f$
 * 	\fn{SETTYPETAG}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K-1}{\type{\ttmsg}}\items{
 *				\ldots,
 *				\ita{L}{\ttvar}
 *			},
 *			\elb{K}{\type{\ttmsg(\type{\tti})}}\items{
 *				\itb{}{\type{\tti}}\values{\upsilon}
 *			}
 *		}
 *	}{
 * 		\BBtick\elems{
 * 			\ldots,
 * 			\elat{K-1}{\type{\ttmsg}}\items{
 *				\ldots,
 *				\ita{L}{\upsilon}
 * 			}
 *		}
 *	}
 * @f$
 */
void ose_setTypetag(ose_bundle B)
{
    ose_setTypetag_impl(B, ose_popInt32(B));
}

/**
 * @f$
 * 	\fn{BLOBTOELEM}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{\type{\ttmsg(\type{\ttb})}}\items{
 *				\ita{}{\type{\ttb}}
 *			}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\itb{K}{\type{\ttvar}}
 *		}
 *	}
 * @f$, where @f$\ttvar@f$ is either @f$\ttmsg@f$ or @f$\ttbndl@f$, 
 * depending on the contents of the blob @f$\ita{}{\type{\ttb}}@f$.
 */
void ose_blobToElem(ose_bundle B)
{
    int32_t o = ose_getLastBundleElemOffset(B);
    int32_t to, ntt, lto, po, lpo;
    ose_getNthPayloadItem(B, 1, o, &to, &ntt, &lto, &po, &lpo);
    ose_assert(ose_readByte(B, lto) == OSETT_BLOB);
    ose_writeByte(B, lto, 0);
    int32_t ps = ose_readInt32(B, lpo);
    while(ps % 4)
    {
        ps++;
    }
    ose_addToInt32(B, o, -(ps + 4));
    ose_writeInt32(B, lpo, ps);
    ose_nip(B);
}

/**
 * @f$
 * 	\fn{BLOBTOTYPE\_IMPL}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{\type{\ttmsg}}\items{
 *				\ldots,
 *				\ita{L}{\ttb}
 *			}
 *		}, \ttvar
 *	}{
 * 		\BBtick\elems{
 * 			\ldots,
 * 			\elat{K}{\type{\ttmsg}}\items{
 *				\ldots,
 *				\ita{L}{\ttvar}
 * 			}
 *		}
 *	}
 * @f$
 */
void ose_blobToType_impl(ose_bundle B, char typetag)
{
    int32_t o = ose_getLastBundleElemOffset(B);
    int32_t to, ntt, lto, po, lpo;
    ose_getNthPayloadItem(B, 1, o, &to, &ntt, &lto, &po, &lpo);
    ose_assert(ose_readByte(B, lto) == OSETT_BLOB);
    ose_writeByte(B, lto, typetag);
    int32_t pbs = ose_getPaddedBlobSize(B, lpo);
    char *b = ose_getBundlePtr(B);
    memmove(b + lpo, b + lpo + 4, pbs);
    memset(b + o + ose_readInt32(B, o), 0, 4);
    ose_addToInt32(B, o, -4);
    ose_addToSize(B, -4);
}

/**
 * @f$
 * 	\fn{BLOBTOTYPE}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K-1}{\type{\ttmsg}}\items{
 *				\ldots,
 *				\ita{L}{\ttb}
 *			},
 *			\elb{K}{\type{\ttmsg(\type{\tti})}}\items{
 *				\itb{}{\type{\tti}}\values{\ttvar}
 *			}
 *		}
 *	}{
 * 		\BBtick\elems{
 * 			\ldots,
 * 			\elat{K-1}{\type{\ttmsg}}\items{
 *				\ldots,
 *				\ita{L}{\ttvar}
 * 			}
 *		}
 *	}
 * @f$
 */
void ose_blobToType(ose_bundle B)
{
    ose_blobToType_impl(B, ose_popInt32(B));
}

/**
 * @todo Implement.
 */
void ose_toType(ose_bundle B)
{
}

/**
 * @f$\fntotype{TOINT32}{\tti}@f$
 *
 * @todo Fully implement blob case.
 * @todo Implement default case.
 * @todo Implement extended types.
 */
void ose_toInt32(ose_bundle B)
{
    {
        const char t = ose_peekMessageArgType(B);
        switch(t)
        {
        case OSETT_INT32:
        {
            ;
        }
        break;
        case OSETT_FLOAT:
        {
            const float f = ose_popFloat(B);
            ose_pushInt32(B, (int32_t)f);
        }
        break;
        case OSETT_STRING:
        {
            const char * const s = ose_peekString(B);
            int32_t l;
            if(*s == '/')
            {
                l = strtol(s + 1, NULL, 10);
            }
            else
            {
                l = strtol(s, NULL, 10);
            }
            ose_drop(B);
            ose_pushInt32(B, l);
        }
        break;
        case OSETT_BLOB:
        {
            const char * const b = ose_peekBlob(B);
            if(ose_ntohl(*((int32_t *)b)) == 4)
            {
                int32_t i = ose_ntohl(*((int32_t *)(b + 4)));
                ose_drop(B);
                ose_pushInt32(B, i);
            }
            else
            {
                /* popControlToStack(vm_c, bundle); */
            }
        }
        break;
#ifdef OSE_PROVIDE_TYPE_SYMBOL
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_DOUBLE
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INT16
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT16
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_FALSE
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_NULL
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
#warning NOT IMPLEMENTED
#endif
        default: ;
            /* popControlToStack(vm_c, vm_s); */
        }
    }
}

/**
 * @f$\fntotype{TOFLOAT}{\ttf}@f$
 *
 * @todo Fully implement blob case.
 * @todo Implement default case.
 * @todo Implement extended types.
 */
void ose_toFloat(ose_bundle B)
{
    {
        const char t = ose_peekMessageArgType(B);
        switch(t)
        {
        case OSETT_INT32:
        {
            const int32_t i = ose_popInt32(B);
            ose_pushFloat(B, (float)i);
        }
        break;
        case OSETT_FLOAT:
        {
            ;
        }
        break;
        case OSETT_STRING:
        {
            const char * const s = ose_peekString(B);
            float f;
            if(*s == '/')
            {
                f = strtof(s + 1, NULL);
            }
            else
            {
                f = strtof(s, NULL);
            }
            ose_drop(B);
            ose_pushFloat(B, f);
        }
        break;
        case OSETT_BLOB:
        {
            const char * const b = ose_peekBlob(B);
            if(ose_ntohl(*((int32_t *)b)) == 4)
            {
                int32_t i = ose_ntohl(*((int32_t *)(b + 4)));
                float f = *((float *)&i);
                ose_drop(B);
                ose_pushFloat(B, f);
            }
            else
            {
                /* popControlToStack(vm_c, bundle); */
            }
        }
        break;
#ifdef OSE_PROVIDE_TYPE_SYMBOL
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_DOUBLE
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INT16
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT16
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
        case OSETT_TIMETAG:
        {
            const struct ose_timetag n = ose_popTimetag(B);
            ose_pushFloat(B,
                          ((double)(n.sec))
                          + ((double)((uint64_t)(n.fsec)))
                          / 4294967295.0);
        }
        break;
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_FALSE
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_NULL
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
#warning NOT IMPLEMENTED
#endif        
        default: ;
            /* popControlToStack(vm_c, vm_s); */
        }
    }
}

/**
 * @f$\fntotype{TOSTRING}{\tts}@f$
 *
 * @todo Implement default case.
 * @todo Implement extended types.
 */
void ose_toString(ose_bundle B)
{
    {
        const char t = ose_peekMessageArgType(B);
        switch(t){
        case OSETT_INT32:
        {
            const int32_t i = ose_popInt32(B);
            const int32_t n = snprintf(NULL, 0, "%d", i);
            ose_pushBlob(B, n - 3 >= 0 ? n - 3 : 0, NULL);
            char *p = (char *)ose_peekBlob(B);
            snprintf(p, n + 1, "%d", i);
            p--;
            while(*p != OSETT_BLOB)
            {
                p--;
            }
            *p = OSETT_STRING;
        }
        break;
        case OSETT_FLOAT:
        {
            const float f = ose_popFloat(B);
            const int32_t n = snprintf(NULL, 0, "%f", f);
            ose_pushBlob(B, n - 3 >= 0 ? n - 3 : 0, NULL);
            char *p = (char *)ose_peekBlob(B);
            snprintf(p, n + 1, "%f", f);
            p--;
            while(*p != OSETT_BLOB)
            {
                p--;
            }
            *p = OSETT_STRING;
        }
        break;
        case OSETT_STRING:
        {
            ;
        }
        break;
        case OSETT_BLOB:
        {
            /* ensure that the string has null padding */
            if(ose_readByte(B, ose_readSize(B) - 1) != 0)
            {
                char c = 0;
                ose_pushBlob(B, 1, &c);
                ose_push(B);
                ose_concatenateBlobs(B);
            }
            ose_blobToType_impl(B, OSETT_STRING);
        }
        break;
#ifdef OSE_PROVIDE_TYPE_SYMBOL
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_DOUBLE
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INT16
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT16
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_FALSE
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_NULL
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
#warning NOT IMPLEMENTED
#endif
        default: ;
            /* popControlToStack(vm_c, bundle); */
        }
    }
}

/**
 * @f$\fntotype{TOBLOB}{\ttb}@f$
 */
void ose_toBlob(ose_bundle B)
{
    ose_itemToBlob(B);
}

void ose_appendByte(ose_bundle B)
{
#define SLIP_END 0300
#define SLIP_ESC 0333
#define SLIP_ESC_END 0334
#define SLIP_ESC_ESC 0335

    const char * const str = ose_peekString(B);
    unsigned char c = 0;
    c = (unsigned char)strtol(str + 1, NULL, 10);
    const int32_t n = ose_getBundleElemCount(B);
    if(n == 0)
    {
        ose_pushMessage(B,
                        OSE_ADDRESS_ANONVAL,
                        OSE_ADDRESS_ANONVAL_LEN,
                        2,
                        OSETT_BLOB, 0, NULL,
                        OSETT_INT32, 1);
    }
    else
    {
        const char elemtype = ose_peekType(B);
        if(elemtype == OSETT_BUNDLE)
        {
            ose_pushMessage(B,
                            OSE_ADDRESS_ANONVAL,
                            OSE_ADDRESS_ANONVAL_LEN,
                            2,
                            OSETT_BLOB, 0, NULL,
                            OSETT_INT32, 1);
        }
        else if(elemtype == OSETT_MESSAGE)
        {
            if(ose_peekMessageArgType(B) == OSETT_INT32)
            {
                ose_pop(B);
                int32_t state = ose_popInt32(B);
                if(ose_peekMessageArgType(B)
                   == OSETT_BLOB)
                {
                    switch(state)
                    {
                    case 0:
                        ose_pushInt32(B, 1);
                        ose_push(B);
                        break;
                    case 1:
                        switch(c)
                        {
                        case SLIP_END:
                            /* done */
                            break;
                        case SLIP_ESC:
                            ose_pushInt32(B, 2);
                            ose_push(B);
                            break;
                        default:
                            ose_pushBlob(B,
                                         1,
                                         (char *)&c);
                            ose_push(B);
                            ose_concatenateBlobs(B);
                            ose_pushInt32(B, 1);
                            ose_push(B);
                            break;
                        }
                        break;
                    case 2:
                        switch(c)
                        {
                        case SLIP_ESC_END:
                        {
                            const char cc = SLIP_END;	
                            ose_pushBlob(B,
                                         1,
                                         &cc);
                            ose_push(B);
                            ose_concatenateBlobs(B);
                            ose_pushInt32(B, 1);
                            ose_push(B);
                        }
                        break;
                        case SLIP_ESC_ESC:
                        {
                            const char cc = SLIP_ESC;	
                            ose_pushBlob(B,
                                         1,
                                         &cc);
                            ose_push(B);
                            ose_concatenateBlobs(B);
                            ose_pushInt32(B, 1);
                            ose_push(B);
                        }
                        break;
                        default:
                            ose_assert(0
                                       && "SLIP ESC not followed by ESC_END or ESC_ESC.");
                        }
                        break;
                    default:
                        ose_pushInt32(B, state);
                        ose_push(B);
                        ose_pushMessage(B,
                                        OSE_ADDRESS_ANONVAL,
                                        OSE_ADDRESS_ANONVAL_LEN,
                                        2,
                                        OSETT_BLOB, 0, NULL,
                                        OSETT_INT32, 1);
                        break;
                    }
                }
                else
                {
                    ose_pushInt32(B, state);
                    ose_push(B);
                    ose_pushMessage(B,
                                    OSE_ADDRESS_ANONVAL,
                                    OSE_ADDRESS_ANONVAL_LEN,
                                    2,
                                    OSETT_BLOB, 0, NULL,
                                    OSETT_INT32, 1);
                }
            }
            else
            {
                ose_pushMessage(B,
                                OSE_ADDRESS_ANONVAL,
                                OSE_ADDRESS_ANONVAL_LEN,
                                2,
                                OSETT_BLOB, 0, NULL,
                                OSETT_INT32, 1);
            }
        }
        else
        {
            ose_assert(0 && "found something other than "
                       "a bundle or message");
        }
    }
}

#ifdef OSE_PROVIDE_TYPE_SYMBOL
void ose_toSymbol(ose_bundle B)
{
#warning NOT IMPLEMENTED
}
#endif

#ifdef OSE_PROVIDE_TYPE_DOUBLE
void ose_toDouble(ose_bundle B)
{
    {
        const char t = ose_peekMessageArgType(B);
        switch(t)
        {
        case OSETT_INT32:
        {
            const int32_t i = ose_popInt32(B);
            ose_pushDouble(B, (float)i);
        }
        break;
        case OSETT_FLOAT:
        {
            const float f = ose_popFloat(B);
            ose_pushDouble(B, (double)f);
        }
        break;
        case OSETT_STRING:
        {
            const char * const s = ose_peekString(B);
            double d;
            if(*s == '/')
            {
                d = strtod(s + 1, NULL);
            }
            else
            {
                d = strtod(s, NULL);
            }
            ose_drop(B);
            ose_pushDouble(B, d);
        }
        break;
        case OSETT_BLOB:
        {
            const char * const b = ose_peekBlob(B);
            if(ose_ntohl(*((int32_t *)b)) == 8)
            {
                int64_t i = ose_ntohl(*((int64_t *)(b + 4)));
                double d = *((double *)&i);
                ose_drop(B);
                ose_pushDouble(B, d);
            }
            else
            {
                /* popControlToStack(vm_c, bundle); */
            }
        }
        break;
#ifdef OSE_PROVIDE_TYPE_SYMBOL
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_DOUBLE
        case OSETT_DOUBLE:
            break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INT16
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT16
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
        case OSETT_TIMETAG:
        {
            const struct ose_timetag n = ose_popTimetag(B);
            ose_pushDouble(B,
                           ((double)(n.sec))
                           + ((double)((uint64_t)(n.fsec)))
                           / 4294967295.0);
        }
        break;
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_FALSE
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_NULL
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
#warning NOT IMPLEMENTED
#endif
        default: ;
            /* popControlToStack(vm_c, bundle); */
        }
    }
}
#endif

#ifdef OSE_PROVIDE_TYPE_INT8
void ose_toInt8(ose_bundle B)
{
#warning NOT IMPLEMENTED
}
#endif

#ifdef OSE_PROVIDE_TYPE_UINT8
void ose_toUInt8(ose_bundle B)
{
#warning NOT IMPLEMENTED
}
#endif

#ifdef OSE_PROVIDE_TYPE_INT16
void ose_toInt16(ose_bundle B)
{
#warning NOT IMPLEMENTED
}
#endif

#ifdef OSE_PROVIDE_TYPE_UINT16
void ose_toUInt16(ose_bundle B)
{
#warning NOT IMPLEMENTED
}
#endif

#ifdef OSE_PROVIDE_TYPE_UINT32
void ose_toUInt32(ose_bundle B)
{
#warning NOT IMPLEMENTED
}
#endif

#ifdef OSE_PROVIDE_TYPE_INT64
void ose_toInt64(ose_bundle B)
{
#warning NOT IMPLEMENTED
}
#endif

#ifdef OSE_PROVIDE_TYPE_UINT64
void ose_toUInt64(ose_bundle B)
{
#warning NOT IMPLEMENTED
}
#endif

#ifdef OSE_PROVIDE_TYPE_TIMETAG
void ose_toTimetag(ose_bundle B)
{
#warning NOT IMPLEMENTED
}
#endif

#ifdef OSE_PROVIDE_TYPE_TRUE
void ose_toTrue(ose_bundle B)
{
#warning NOT IMPLEMENTED
}
#endif

#ifdef OSE_PROVIDE_TYPE_FALSE
void ose_toFalse(ose_bundle B)
{
#warning NOT IMPLEMENTED
}
#endif

#ifdef OSE_PROVIDE_TYPE_NULL
void ose_toNull(ose_bundle B)
{
#warning NOT IMPLEMENTED
}
#endif

#ifdef OSE_PROVIDE_TYPE_INFINITUM
void ose_toInfinitum(ose_bundle B)
{
#warning NOT IMPLEMENTED
}
#endif

/**
 * @f$
 *	\fn{CONCATENATEBLOBS}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{\type{\ttmsg(\ldots, \type{\ttb}_{L-1}, \type{\ttb}_{L})}}\items{
 *				\ldots,
 *				\ita{L-1}{\type{\ttb}},
 *				\itb{L}{\type{\ttb}}
 *			}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\itat{K}{\type{\ttmsg}}\items{
 *				\ldots,
 *				\ita{}{}\itb{L-1}{\type{\ttb}}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_concatenateBlobs(ose_bundle B)
{
    int32_t o = ose_getLastBundleElemOffset(B);
    int32_t s = ose_readInt32(B, o);
    int32_t to, ntt, lto, po, lpo;
    ose_getNthPayloadItem(B, 2, o, &to, &ntt, &lto, &po, &lpo);
    ose_assert(ose_readByte(B, lto) == OSETT_BLOB);
    ose_assert(ose_readByte(B, lto + 1) == OSETT_BLOB);
    
    int32_t blob2_offset = lpo;
    int32_t blob2_size = ose_readInt32(B, blob2_offset);
    int32_t blob2_psize = blob2_size
        + ose_getBlobPaddingForNBytes(blob2_size);
    
    int32_t blob1_offset = blob2_offset + 4 + blob2_psize;
    int32_t blob1_size = ose_readInt32(B, blob1_offset);
    int32_t blob1_psize = blob1_size
        + ose_getBlobPaddingForNBytes(blob1_size);

    char *b = ose_getBundlePtr(B);
    char *b2 = b + blob2_offset;
    char *b2_end = b2 + blob2_size + 4;
    char *b1 = b + blob1_offset;
    char *b1_end = b1 + blob1_size + 4;

    int32_t new_blob2_size = blob2_size + blob1_size;
    int32_t new_blob2_psize =
        new_blob2_size + ose_getBlobPaddingForNBytes(new_blob2_size);
    int32_t new_message_size =
        s - (blob2_psize + blob1_psize + 8) + (new_blob2_psize + 4);
    b[to + ntt - 1] = 0;
    if(ntt % 4 == 0)
    {
        /* need to remove a type tag */
        memmove(b2 - 4, b2, blob2_psize + blob1_psize + 8);
        ose_writeInt32_outOfBounds(B,
                                   blob1_offset + 4 + blob1_psize, 0);
        b1 -= 4;
        b1_end -= 4;
        b2 -= 4;
        b2_end -= 4;
        new_message_size -= 4;
    }
    else
    {
        ;        
    }
    memmove(b2_end, b1 + 4, blob1_psize);
    int32_t n = (b1 + 4) - b2_end;
    memset(b1 + 4 + blob1_psize - n, 0, n);
    ose_writeInt32(B, blob2_offset, new_blob2_size);
    ose_writeInt32(B, o, new_message_size);
    ose_addToSize(B, new_message_size - s);
}

/**
 * @f$
 *	\fn{CONCATENATESTRINGS}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{\type{\ttmsg(\ldots, \type{\tts}_{L-1}, \type{\tts}_{L})}}\items{
 *				\ldots,
 *				\ita{L-1}{\type{\tts}},
 *				\itb{L}{\type{\tts}}
 *			}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\itat{K}{\type{\ttmsg}}\items{
 *				\ldots,
 *				\ita{}{}\itb{L-1}{\type{\tts}}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_concatenateStrings(ose_bundle B)
{
    int32_t o = ose_getLastBundleElemOffset(B);
    int32_t to, ntt, to2, po, po2;
    ose_getNthPayloadItem(B, 2, o, &to, &ntt, &to2, &po, &po2);
    int32_t po1 = po2 + ose_getPayloadItemSize(B,
                                               ose_readByte(B, to2),
                                               o,
                                               po2);
    int32_t to1 = to2 + 1;
    ose_assert(ose_isStringType(ose_readByte(B, to2)) &&
               ose_isStringType(ose_readByte(B, to1)));
    char *b = ose_getBundlePtr(B);
    int32_t s2len = strlen(b + po2);
    int32_t s1len = strlen(b + po1);
    memmove(b + po2 + s2len, b + po1, s1len);
    int32_t news2len = s2len + s1len;
    memset(b + po2 + news2len, 0, po1 - (po2 + s2len));
    int32_t oldsize = ose_readInt32(B, o);
    int32_t newsize = ((oldsize -
                        (ose_pnbytes(s2len) + ose_pnbytes(s1len))) +
                       (ose_pnbytes(news2len)));
    ose_writeByte(B, to1, 0);  
    if(ose_pnbytes(ntt) != ose_pnbytes(ntt - 1))
    {
        memmove(b + to1 + 1, b + to1 + 5, newsize - (po - (o + 4)));
        memset(b + o + newsize + 4, 0, 4);
        newsize -= 4;
    }
    ose_writeInt32(B, o, newsize);
    ose_incSize(B, newsize - oldsize);
}

/*
  take a string at the top of the stack (top arg of the top message) and
  make it the address of the message:

  #bundle
  ...
  /foo ... "/bar"
  toAddress

  |
  V

  #bundle
  ...
  /bar ...
*/
static void swapStringToAddress(ose_bundle B)
{
    ose_assert(ose_bundleHasAtLeastNElems(B, 1));
    int32_t so = ose_getLastBundleElemOffset(B);
    int32_t s = ose_readInt32(B, so);
    int32_t len1 = ose_getPaddedStringLen(B, so + 4);
    int32_t to, ntt, lto, po, lpo;
    ose_getNthPayloadItem(B, 1, so, &to, &ntt, &lto, &po, &lpo);
    ose_assert(ose_isStringType(ose_readByte(B, lto)));
    int32_t len2 = ose_getPaddedStringLen(B, lpo);
    char *b = ose_getBundlePtr(B);
    int32_t o = so + 4;

    o /= 4;
    s /= 4;
    len1 /= 4;
    len2 /= 4;
    int32_t *bb = (int32_t *)b;
    int i = 0;
    for(i = 0; i < s / 2; i++)
    {
        int32_t c = __builtin_bswap32(bb[o + i]);
        bb[o + i] = __builtin_bswap32(bb[(o + s - 1) - i]);
        bb[(o + s - 1) - i] = c;
    }
    if(s % 2)
    {
        bb[o + s / 2] = __builtin_bswap32(bb[o + s / 2]);
    }
    for(i = 0; i < len2 / 2; i++)
    {
        int32_t c = __builtin_bswap32(bb[o + i]);
        bb[o + i] = __builtin_bswap32(bb[(o + len2 - 1) - i]);
        bb[(o + len2 - 1) - i] = c;
    }
    if(len2 % 2)
    {
        bb[o + len2 / 2] = __builtin_bswap32(bb[o + len2 / 2]);
    }
    int32_t len3 = s - (len1 + len2);
    for(i = 0; i < len3 / 2; i++)
    {
        int32_t c = __builtin_bswap32(bb[o + len2 + i]);
        bb[o + len2 + i] = __builtin_bswap32(bb[(o + len2 + len3 - 1) - i]);
        bb[(o + len2 + len3 - 1) - i] = c;
    }
    if(len3 % 2)
    {
        bb[o + len2 + len3 / 2] = __builtin_bswap32(bb[o + len2 + len3 / 2]);
    }
    for(i = 0; i < len1 / 2; i++)
    {
        int32_t c = __builtin_bswap32(bb[o + len2 + len3 + i]);
        bb[o + len2 + len3 + i] = __builtin_bswap32(bb[(o + len2 + len3 + len1 - 1) - i]);
        bb[(o + len2 + len3 + len1 - 1) - i] = c;
    }
    if(len1 % 2)
    {
        bb[o + len2 + len3 + len1 / 2] = __builtin_bswap32(bb[o + len2 + len3 + len1 / 2]);
    }

    
    /* int32_t old_alen = to - ao; */
    /* /\* char *b = ose_getBundlePtr(B); *\/ */
    /* to = lto; */
    /* po = lpo; */
    /* int32_t new_alen = ose_getPaddedStringLen(B, po); */
    /* int32_t omn = old_alen - new_alen; */
    /* int32_t nmo = new_alen - old_alen; */
    /* if(new_alen == old_alen){ */
    /*  memcpy(b + ao, b + po, new_alen); */
    /* }else if(new_alen < old_alen){ */
    /*  memcpy(b + ao, b + po, new_alen); */
    /*  memmove(b + ao + new_alen, b + ao + old_alen, s - old_alen); */
    /*  memset(b + s + + 4 - (omn), 0, omn); */
    /*  ose_addToInt32(B, so, nmo); */
    /*  ose_addToSize(B, nmo); */
    /* }else{ */
    /*  memcpy(b + ao + new_alen, b + ao + old_alen, s - old_alen); */
    /*  memcpy(b + ao, b + po + (nmo), new_alen); */
    /*  ose_addToInt32(B, so, nmo); */
    /*  ose_addToSize(B, nmo); */
    /* } */
}

/**
 * @f$
 *	\fn{SWAPSTRINGTOADDRESS}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{\ttmsg(\ldots, \type{\tts}_L)}\items{
 *				\alpha=a\mid
 *				\ldots,
 *				\itb{L}{\type{\tts}}
 *			}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\ela{K}{\ttmsg(\ldots, \type{\tts}_L)}\items{
 *				\alpha=b\mid
 *				\ldots,
 *				\ita{L}{\type{\tts}}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_swapStringToAddress(ose_bundle B)
{
    swapStringToAddress(B);
}

/**
 * @f$
 *	\fn{MOVESTRINGTOADDRESS}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{\ttmsg(\ldots, \type{\tts}_L)}\items{
 *				\alpha=a\mid
 *				\ldots,
 *				\itb{L}{\type{\tts}}
 *			}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\ela{K}{\ttmsg(\ldots, \type{\tts}_L)}\items{
 *				\alpha=b\mid
 *				\ldots
 *			}
 *		}
 *	}
 * @f$
 */
void ose_moveStringToAddress(ose_bundle B)
{
    /* swapStringToAddress(B); */
    /* dropArg(B); */
    ose_assert(ose_isBundle(B));
    ose_assert(ose_bundleHasAtLeastNElems(B, 1));
    int32_t on = 0, sn = 0;
    be1(B, &on, &sn);
    int32_t to = 0, ntt = 0, lto = 0, po = 0, lpo = 0;
    ose_getNthPayloadItem(B, 1, on,
                          &to, &ntt, &lto, &po, &lpo);
    char *b = ose_getBundlePtr(B);
    const int32_t addrlen = strlen(b + on + 4);
    const int32_t paddrlen = ose_pnbytes(addrlen);
    const int32_t newaddrlen = strlen(b + lpo);
    const int32_t pnewaddrlen = ose_pnbytes(newaddrlen);
    int32_t diff = 0;
    if(paddrlen == pnewaddrlen)
    {
        memcpy(b + on + 4, b + lpo, pnewaddrlen);
    }
    else
    {
        *((int32_t *)(b + on + sn + 4)) = 0;
        diff = pnewaddrlen - paddrlen;
        memmove(b + on + 4 + pnewaddrlen,
                b + on + 4 + paddrlen,
                sn - paddrlen);
        to += diff;
        lto += diff;
        po += diff;
        lpo += diff;
        memcpy(b + on + 4, b + lpo, pnewaddrlen);
    }
    int32_t pntt = ose_pnbytes(ntt);
    int32_t pnttm1 = ose_pnbytes(ntt - 1);
    b[lto] = 0;
    int32_t amt = paddrlen;
    if(pntt == pnttm1)
    {
        memset(b + lpo, 0, pnewaddrlen);
    }
    else
    {
        memmove(b + lto + 1, b + po, sn - (po - (on + 4)));
        memset(b + lpo - 4, 0, pnewaddrlen);
        amt += 4;
    }
    *((int32_t *)(b + on)) = ose_htonl(sn - amt);
    ose_decSize(B, amt);
}

void ose_splitStringFromEnd(ose_bundle B)
{
    int32_t onm1, snm1, on, sn;
    be2(B, &onm1, &snm1, &on, &sn);
    int32_t nm1_to, nm1_ntt, nm1_lto, nm1_po, nm1_lpo;
    ose_getNthPayloadItem(B, 1, onm1,
                          &nm1_to,
                          &nm1_ntt,
                          &nm1_lto,
                          &nm1_po,
                          &nm1_lpo);
    int32_t n_to, n_ntt, n_lto, n_po, n_lpo;
    ose_getNthPayloadItem(B, 1, on,
                          &n_to,
                          &n_ntt,
                          &n_lto,
                          &n_po,
                          &n_lpo);
    onm1 = nm1_lpo;
    on = n_lpo;
    ose_over(B);
    char *b = ose_getBundlePtr(B);
    char *str = b + onm1;
    char *sep = b + on;
    const char * const s = ose_peekString(B);
    int32_t slen = strlen(s);
    char *ltok = str;
    char *tok = NULL;
    while(ltok - str < slen && (ltok = strstr(ltok, sep)))
    {
        tok = ltok;
        ltok++;
    }
    if(!tok)
    {
        ose_drop(B);
        return;
    }
    int32_t n = tok - str;
    if(n == 0)
    {
        n = 1;
    }
    ose_pushInt32(B, slen - n);
    ose_decatenateStringFromEnd(B);
    ose_rot(B);
    ose_drop(B);
    ose_pop(B);
    ose_swap(B);
    ose_rot(B);
}

/**
 * @todo Implement.
 */
void ose_getTypetags(ose_bundle B)
{
}

void ose_decatenateBlobFromEnd_impl(ose_bundle B, int32_t n)
{
    ose_assert(n >= 0);
    int32_t o = ose_getLastBundleElemOffset(B);
    int32_t to, ntt, lto, po, lpo;
    ose_getNthPayloadItem(B, 1, o, &to, &ntt, &lto, &po, &lpo);
    ose_assert(ose_readByte(B, lto) == OSETT_BLOB);

    int32_t old_blob1_size = ose_readInt32(B, lpo);
    int32_t new_blob1_size = old_blob1_size - n;

    int32_t blob2_size = n;

    ose_pushBlob(B, new_blob1_size, NULL);
    int32_t blob1_offset = ose_getLastBundleElemOffset(B)
        + OSE_ADDRESS_ANONVAL_SIZE + 4 + 4;
    ose_pushBlob(B, blob2_size, NULL);
    int32_t blob2_offset = ose_getLastBundleElemOffset(B)
        + OSE_ADDRESS_ANONVAL_SIZE + 4 + 4;

    char *b = ose_getBundlePtr(B);
    memcpy(b + blob1_offset + 4,
           b + lpo + 4,
           new_blob1_size);
    memcpy(b + blob2_offset + 4,
           b + lpo + 4 + new_blob1_size,
           blob2_size);
    ose_push(B);
    ose_nip(B);
}

void ose_decatenateBlobFromEnd(ose_bundle B)
{
    ose_assert(ose_peekType(B) == OSETT_MESSAGE);
    ose_assert(ose_peekMessageArgType(B) == OSETT_INT32);
    int32_t n = ose_popInt32(B);
    ose_assert(ose_peekMessageArgType(B) == OSETT_BLOB);
    ose_decatenateBlobFromEnd_impl(B, n);
}

void ose_decatenateBlobFromStart_impl(ose_bundle B, int32_t n)
{
    int32_t bloblen = ose_ntohl(*((int32_t *)ose_peekBlob(B)));
    n = bloblen - n;
    ose_decatenateBlobFromEnd_impl(B, n);
}

void ose_decatenateBlobFromStart(ose_bundle B)
{
    ose_assert(ose_peekType(B) == OSETT_MESSAGE);
    ose_assert(ose_peekMessageArgType(B) == OSETT_INT32);
    int32_t n = ose_popInt32(B);
    ose_assert(ose_peekMessageArgType(B) == OSETT_BLOB);
    ose_decatenateBlobFromStart_impl(B, n);
}

void ose_decatenateStringFromEnd_impl(ose_bundle B, int32_t n)
{
    ose_assert(n >= 0);
    ose_pushString(B, "");
    ose_push(B);
    int32_t o = ose_getLastBundleElemOffset(B);
    int32_t to, ntt, lto, po, lpo;
    ose_getNthPayloadItem(B, 2, o, &to, &ntt, &lto, &po, &lpo);
    to = lto;
    po = lpo;
    int32_t len = ose_getStringLen(B, po);
    int32_t plen = ose_pnbytes(len);
    char *b = ose_getBundlePtr(B);
    int32_t src = po + (len - n);
    int32_t dest = ose_pnbytes(po + (len - n));
    memmove(b + dest, b + src, n);
    memset(b + src, 0, dest - src);
    int32_t d = (ose_pnbytes(len - n) + ose_pnbytes(n)) - (plen + 4);
    ose_addToInt32(B, o, d);
    ose_incSize(B, d);
}

void ose_decatenateStringFromEnd(ose_bundle B)
{
    ose_assert(ose_peekType(B) == OSETT_MESSAGE);
    ose_assert(ose_peekMessageArgType(B) == OSETT_INT32);
    int32_t n = ose_popInt32(B);
    ose_assert(ose_isStringType(ose_peekMessageArgType(B)));
    ose_decatenateStringFromEnd_impl(B, n);
}

void ose_decatenateStringFromStart_impl(ose_bundle B, int32_t n)
{
    int32_t stringlen = strlen(ose_peekString(B));
    n = stringlen - n;
    ose_decatenateStringFromEnd_impl(B, n);
}

void ose_decatenateStringFromStart(ose_bundle B)
{
    ose_assert(ose_peekType(B) == OSETT_MESSAGE);
    ose_assert(ose_peekMessageArgType(B) == OSETT_INT32);
    int32_t n = ose_popInt32(B);
    ose_assert(ose_isStringType(ose_peekMessageArgType(B)));
    ose_decatenateStringFromStart_impl(B, n);
}

/**
 * @f$
 *	\fn{ELEMTOBLOB}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\elb{K}{\type{\ttmsg}}\items{
 *				\ita{}{\type{\ttb}}\values{\ela{}{}}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_elemToBlob(ose_bundle B)
{
    /* ose_pushString(B, OSE_ADDRESS_ANONVAL); */
    /* ose_moveStringToAddress(B); */
    /* ose_swap(B); */
    /* int32_t o = ose_getLastBundleElemOffset(B); */
    /* int32_t s = ose_readInt32(B, o); */
    /* ose_writeByte(B, o - 3, OSETT_BLOB); */
    /* ose_addToInt32(B, o - (8 + OSE_ADDRESS_ANONVAL_SIZE), s + 4); */
    if(ose_bundleIsEmpty(B))
    {
        return;
    }
    char *b = ose_getBundlePtr(B);
    int32_t o = ose_getLastBundleElemOffset(B);
    int32_t s = ose_readInt32(B, o);
    int32_t amt = 4 + OSE_ADDRESS_ANONVAL_SIZE + 4;
    ose_incSize(B, amt);
    memmove(b + o + amt, b + o, s + 4);
    ose_writeInt32(B, o, s + amt);
    memcpy(b + o + 4,
           OSE_ADDRESS_ANONVAL,
           OSE_ADDRESS_ANONVAL_SIZE);
    int32_t idx = o + 4 + OSE_ADDRESS_ANONVAL_SIZE;
    b[idx] = OSETT_ID;
    b[idx + 1] = OSETT_BLOB;
    b[idx + 2] = 0;
    b[idx + 3] = 0;
}

/**
 * @f$
 *	\fn{ELEMTOBLOB}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{}\items{
 *				\ldots,
 *				\ita{L}{}
 *			}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\elat{K}{}\items{
 *				\ldots,
 *				\itat{L}{\type{\ttb}}\values{ita{}{}}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_itemToBlob(ose_bundle B)
{
    int32_t o = ose_getLastBundleElemOffset(B);
    int32_t s = ose_readInt32(B, o);
    int32_t to, ntt, lto, po, lpo;
    ose_getNthPayloadItem(B, 1, o, &to, &ntt, &lto, &po, &lpo);
    ose_incSize(B, 4);
    ose_writeByte(B, lto, OSETT_BLOB);
    int32_t datasize = s - (lpo - (o + 4));
    char *b = ose_getBundlePtr(B);
    memmove(b + lpo + 4,
            b + lpo,
            datasize);
    ose_writeInt32(B, lpo, datasize);
    ose_addToInt32(B, o, 4);
}

/**
 * @f$
 *	\fn{JOINSTRINGS}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K-2}{\type{\ttmsg(\tts)}}\items{
 *				\ita{}{\type{\tts}}\values{\valv{}{}}
 *			},
 *			\elb{K-1}{\type{\ttmsg(\tts)}}\items{
 *				\itb{}{\type{\tts}}\values{\valw{}{}}
 *			},
 *			\elc{K}{\type{\ttmsg(\tts)}}\items{
 *				\itc{}{\type{\tts}}\values{\valx{}{}}
 *			},
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\elat{K-2}{\type{\ttmsg(\tts)}}\items{
 *				\itat{a}{\type{\tts}}\values{
 *					\valv{}{}\valx{}{}\valw{}{}
 *				}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_joinStrings(ose_bundle B)
{
    ose_assert(ose_bundleHasAtLeastNElems(B, 3));
    int32_t onm2, snm2, onm1, snm1, on, sn;
    be3(B, &onm2, &snm2, &onm1, &snm1, &on, &sn);
    int32_t tonm2, nttnm2, ltonm2, ponm2, lponm2;
    int32_t tonm1, nttnm1, ltonm1, ponm1, lponm1;
    int32_t ton, nttn, lton, pon, lpon;
    ose_getNthPayloadItem(B, 1, onm2,
                          &tonm2, &nttnm2, &ltonm2, &ponm2, &lponm2);
    ose_getNthPayloadItem(B, 1, onm1,
                          &tonm1, &nttnm1, &ltonm1, &ponm1, &lponm1);
    ose_getNthPayloadItem(B, 1, on,
                          &ton, &nttn, &lton, &pon, &lpon);
    ose_assert(ose_isStringType(ose_readByte(B, ltonm2)));
    ose_assert(ose_isStringType(ose_readByte(B, ltonm1)));
    ose_assert(ose_isStringType(ose_readByte(B, lton)));
    ose_assert(nttnm1 == 2);
    ose_assert(nttn == 2);
    ose_swap(B);
    ose_push(B);
    ose_push(B);
    ose_concatenateStrings(B);
    ose_concatenateStrings(B);
}

void ose_splitStringFromStart(ose_bundle B)
{
    int32_t onm1, snm1, on, sn;
    be2(B, &onm1, &snm1, &on, &sn);
    int32_t nm1_to, nm1_ntt, nm1_lto, nm1_po, nm1_lpo;
    ose_getNthPayloadItem(B, 1, onm1,
                          &nm1_to,
                          &nm1_ntt,
                          &nm1_lto,
                          &nm1_po,
                          &nm1_lpo);
    int32_t n_to, n_ntt, n_lto, n_po, n_lpo;
    ose_getNthPayloadItem(B, 1, on,
                          &n_to,
                          &n_ntt,
                          &n_lto,
                          &n_po,
                          &n_lpo);
    onm1 = nm1_lpo;
    on = n_lpo;
    ose_over(B);
    char *b = ose_getBundlePtr(B);
    char *str = b + onm1;
    char *sep = b + on;
    const char * const s = ose_peekString(B);
    int32_t slen = strlen(s);
    char *ltok = str;
    char *tok = strstr(str, sep);
    if(!tok)
    {
        ose_drop(B);
        return;
    }
    int32_t n = tok - ltok;
    if(n == 0)
    {
        ltok = tok;
        tok = strstr(tok + 1, sep);
        if(!tok)
        {
            n = 1;
        }
        else
        {
            n = tok - ltok;
        }
    }
    ose_pushInt32(B, slen - n);
    ose_decatenateStringFromEnd(B);
    ose_rot(B);
    ose_drop(B);
    ose_pop(B);
    ose_rot(B);
}

static void swap4Bytes(ose_bundle B, int32_t o)
{
    char *b = ose_getBundlePtr(B);
    char c = b[o - 1];
    b[o - 1] = b[o - 4];
    b[o - 4] = c;
    c = b[o - 2];
    b[o - 2] = b[o - 3];
    b[o - 3] = c;
}

void ose_swap4Bytes(ose_bundle B)
{
    swap4Bytes(B, ose_readSize(B));
}

static void swap8Bytes(ose_bundle B, int32_t o)
{
    char *b = ose_getBundlePtr(B);
    char c = b[o - 1];
    b[o - 1] = b[o - 8];
    b[o - 8] = c;
    c = b[o - 2];
    b[o - 2] = b[o - 7];
    b[o - 7] = c;
    c = b[o - 3];
    b[o - 3] = b[o - 6];
    b[o - 6] = c;
    c = b[o - 4];
    b[o - 4] = b[o - 5];
    b[o - 5] = c;
}

void ose_swap8Bytes(ose_bundle B)
{
    swap8Bytes(B, ose_readSize(B));
}

static void swapNBytes(ose_bundle B, int32_t o, int32_t n)
{
    ose_assert(n >= 0);
    char *b = ose_getBundlePtr(B);
    for(int i = 1; i <= n; i++)
    {
        char c = b[o - i];
        b[o - i] = b[o - (n - i - 1)];
        b[o - (n - i - 1)] = c;
    }
}

void ose_swapNBytes(ose_bundle B)
{
    swapNBytes(B, ose_readSize(B), ose_popInt32(B));
}

void ose_trimStringEnd(ose_bundle B)
{
    int32_t o = ose_getLastBundleElemOffset(B);
    int32_t to, ntt, lto, po, lpo;
    ose_getNthPayloadItem(B, 1, o, &to, &ntt, &lto, &po, &lpo);
    ose_assert(ose_isStringType(ose_readByte(B, lto)));
    int32_t s = ose_getStringLen(B, lpo);
    char *p = (char *)ose_readString(B, lpo);
    int32_t i = s - 1;
    while(i >= 0)
    {
        if(p[i] <= 32 || p[i] >= 127)
        {
            p[i] = 0;
        }
        else
        {
            break;
        }
        i--;
    }
    int32_t d = (ose_pnbytes(s) - ose_pnbytes(i));
    ose_addToInt32(B, o, -d);
    ose_decSize(B, d);
}

void ose_trimStringStart(ose_bundle B)
{
    int32_t o = ose_getLastBundleElemOffset(B);
    int32_t to, ntt, lto, po, lpo;
    ose_getNthPayloadItem(B, 1, o, &to, &ntt, &lto, &po, &lpo);
    ose_assert(ose_isStringType(ose_readByte(B, lto)));
    int32_t s = ose_getStringLen(B, lpo);
    char *p = (char *)ose_readString(B, lpo);
    int32_t i = 0;
    while(i < s)
    {
        if(p[i] <= 32 || p[i] >= 127)
        {
            ;
        }
        else
        {
            break;
        }
        i++;
    }
    int32_t d = (ose_pnbytes(i));
    memmove(p, p + i, s - i);
    memset(p + (s - i), 0, i);
    ose_addToInt32(B, o, -d);
    ose_decSize(B, d);
}

/**
 * @f$
 *	\fn{MATCH}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K-1}{\type{\ttmsg(\type{\tts})}}\items{
 *				\ita{}{\type{\tts}}\values{\valv{}{}}
 *			},
 *			\elb{K}{\type{\ttmsg(\type{\tts})}}\items{
 *				\itb{}{\type{\tts}}\values{\valw{}{}}
 *			}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\ela{K-1}{\type{\ttmsg(\type{\tts})}}\items{
 *				\ita{}{\type{\tts}}\values{\valv{}{}}
 *			},
 *			\elb{K}{\type{\ttmsg(\type{\tts})}}\items{
 *				\itb{}{\type{\tts}}\values{\valw{}{}}
 *			},
 *			\elc{K+1}{\type{\ttmsg}}\items{
 *				\itc{}{\type{\tti}}\values{\valv{}{} \match \valw{}{}}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_match(ose_bundle B)
{
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    int32_t onm1, snm1, on, sn;
    int32_t tonm1, nttnm1, ltonm1, ponm1, lponm1;
    int32_t ton, nttn, lton, pon, lpon;
    be2(B, &onm1, &snm1, &on, &sn);
    ose_getNthPayloadItem(B, 1,
                          onm1,
                          &tonm1,
                          &nttnm1,
                          &ltonm1,
                          &ponm1,
                          &lponm1);
    ose_getNthPayloadItem(B, 1,
                          on,
                          &ton,
                          &nttn,
                          &lton,
                          &pon,
                          &lpon);
    ose_assert(ose_isStringType(ose_readByte(B, ltonm1))
               && ose_isStringType(ose_readByte(B, lton)));
    char *b = ose_getBundlePtr(B);
    if(strcmp(b + lponm1, b + lpon))
    {
        ose_pushInt32(B, 0);
    }
    else
    {
        ose_pushInt32(B, 1);
    }
}

/**
 * @f$
 *	\fn{PMATCH}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K-1}{\type{\ttmsg(\type{\tts})}}\items{
 *				\ita{}{\type{\tts}}\values{\valv{}{}}
 *			},
 *			\elb{K}{\type{\ttmsg(\type{\tts})}}\items{
 *				\itb{}{\type{\tts}}\values{\valw{}{}}
 *			}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\elat{K-1}{\type{\ttmsg(\type{\tts})}}\items{
 *				\itat{}{\type{\tts}}\values{\valvt{}{}}
 *			},
 *			\elb{K}{\type{\ttmsg(\type{\tts})}}\items{
 *				\itb{}{\type{\tts}}\values{\valw{}{}}
 *			},
 *			\elc{K+1}{\type{\ttmsg}}\items{
 *				\itc{}{\type{\tti}}
 *			},
 *			\eld{K+2}{\type{\ttmsg}}\items{
 *				\itd{}{\type{\tti}}
 *			}
 *		}
 *	}
 * @f$, where @f$\valvt{}{}@f$ may have been modified with any
 * matching portion stripped, @f$\itc{}{}@f$ is non-zero if
 * @f$\valvt{}{}@f$ was fully matched and zero otherwise, and
 * @f$\itd{}{}@f$ is non-zero if @f$\valw{}{}@f$ was fully matched
 * and zero otherwise.
 */
void ose_pmatch(ose_bundle B)
{
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    int32_t onm1, snm1, on, sn;
    int32_t tonm1, nttnm1, ltonm1, ponm1, lponm1;
    int32_t ton, nttn, lton, pon, lpon;
    be2(B, &onm1, &snm1, &on, &sn);
    ose_getNthPayloadItem(B, 1,
                          onm1,
                          &tonm1,
                          &nttnm1,
                          &ltonm1,
                          &ponm1,
                          &lponm1);
    ose_getNthPayloadItem(B, 1,
                          on,
                          &ton,
                          &nttn,
                          &lton,
                          &pon,
                          &lpon);
    ose_assert(ose_isStringType(ose_readByte(B, ltonm1))
               && ose_isStringType(ose_readByte(B, lton)));
    char *b = ose_getBundlePtr(B);
    int po = 0, ao = 0;
    int r = ose_match_pattern(b + lponm1, b + lpon, &po, &ao);
    ose_drop(B);
    ose_pushInt32(B, strlen(ose_peekString(B)) - po);
    ose_decatenateStringFromEnd(B);
    ose_pop(B);
    ose_swap(B);
    ose_pushInt32(B, (r & OSE_MATCH_PATTERN_COMPLETE) != 0);
    ose_pushInt32(B, (r & OSE_MATCH_ADDRESS_COMPLETE) != 0);
}

/**
 * @f$
 * 	\fn{ROUTE1}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K-1}{\type{\ttbndl}}\items{
 *				\ita{i}{\type{\ttmsg}}
 *			},
 *			\elb{K}{\type{\ttmsg(\type{\tts}_i)}}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\ela{K-1}{\type{\ttbndl}},
 *			\elc{K}{\type{\ttbndl}}\items{
 *				\itat{i}{} \pmatchin \ela{}{}
 *			}
 *		}
 *	}
 * @f$, where the patterns of @f$\itat{i}{}@f$ have been
 * stripped of their matching part.
 */
void ose_route1(ose_bundle B)
{
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    int32_t onm1, snm1, on, sn;
    int32_t ton, nttn, lton, pon, lpon;
    be2(B, &onm1, &snm1, &on, &sn);
    ose_pushBundle(B);
    ose_assert(ose_getBundleElemType(B, onm1) == OSETT_BUNDLE);
    ose_assert(ose_getBundleElemType(B, on) == OSETT_MESSAGE);
    if(snm1 <= OSE_BUNDLE_HEADER_LEN)
    {
        ose_drop(B);
        return;
    }
    ose_getNthPayloadItem(B, 1,
                          on,
                          &ton,
                          &nttn,
                          &lton,
                          &pon,
                          &lpon);
    int a = 0;
    if(ose_isStringType(ose_readByte(B, lton)))
    {
    }
    else
    {
        a = 1;
    }
    const char * const addr = a ? ose_readString(B, on + 4)
        : ose_readString(B, lpon);
    const int32_t addrlen = strlen(addr);
    onm1 += 4 + OSE_BUNDLE_HEADER_LEN;
    int po, ao, r;
    int32_t new_bundle_size = 0;
    while(onm1 < on)
    {
        r = ose_match_pattern(ose_readString(B, onm1 + 4), addr,
                              &po, &ao);
        if(r & OSE_MATCH_ADDRESS_COMPLETE)
        {
            new_bundle_size += ose_routeElemAtOffset(onm1,
                                                     B,
                                                     addrlen,
                                                     B) + 4;
        }
        onm1 += ose_readInt32(B, onm1) + 4;
    }
    ose_writeInt32(B,
                   on + sn + 4,
                   new_bundle_size + OSE_BUNDLE_HEADER_LEN);
    ose_nip(B);
}

/**
 * @f$
 * 	\fn{SELECT1}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K-1}{\type{\ttbndl}}\items{
 *				\ita{i}{\type{\ttmsg}}
 *			},
 *			\elb{K}{\type{\ttmsg(\type{\tts}_i)}}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\ela{K-1}{\type{\ttbndl}},
 *			\elc{K}{\type{\ttbndl}}\items{
 *				\ita{i}{} \pmatchin \ela{}{}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_select1(ose_bundle B)
{
	ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    int32_t onm1, snm1, on, sn;
    int32_t ton, nttn, lton, pon, lpon;
    be2(B, &onm1, &snm1, &on, &sn);
    ose_pushBundle(B);
    ose_assert(ose_getBundleElemType(B, onm1) == OSETT_BUNDLE);
    ose_assert(ose_getBundleElemType(B, on) == OSETT_MESSAGE);
    if(snm1 <= OSE_BUNDLE_HEADER_LEN)
    {
        ose_drop(B);
        return;
    }
    ose_getNthPayloadItem(B, 1,
                          on,
                          &ton,
                          &nttn,
                          &lton,
                          &pon,
                          &lpon);
    int a = 0;
    if(ose_isStringType(ose_readByte(B, lton)))
    {
    }
    else
    {
        a = 1;
    }
    const char * const addr = a ? ose_readString(B, on + 4)
        : ose_readString(B, lpon);
    onm1 += 4 + OSE_BUNDLE_HEADER_LEN;
    int po, ao, r;
    int32_t new_bundle_size = 0;
    while(onm1 < on)
    {
        r = ose_match_pattern(ose_readString(B, onm1 + 4), addr,
                              &po, &ao);
        if(r & OSE_MATCH_ADDRESS_COMPLETE)
        {
            char *b = ose_getBundlePtr(B);
            const int32_t old_bundle_size = ose_readSize(B);
            const int32_t elem_size = ose_readInt32(B, onm1);
            ose_addToSize(B, elem_size + 4);
            memcpy(b + old_bundle_size, b + onm1, elem_size + 4);
            new_bundle_size += elem_size + 4;
        }
        onm1 += ose_readInt32(B, onm1) + 4;
    }
    ose_writeInt32(B,
                   on + sn + 4,
                   new_bundle_size + OSE_BUNDLE_HEADER_LEN);
    ose_nip(B);
}

/**
 * @f$
 *	\fn{ROUTEWITHDELEGATION}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{\type{\ttbndl}}\items{
 *				\ita{i}{\type{\ttmsg}}
 *			},
 *			\elb{K+1}{\type{\ttmsg(\allstrings{1}{L})}}\items{
 *				\itb{1}{\type{\tts}},
 *				\ldots,
 *				\itb{L}{\type{\tts}}
 *			}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\elc{K}{\type{\ttbndl}}\items{
 *				\itat{i}{} \pmatchin \itb{L}{}
 *			},
 *			\ldots,
 *			\eld{K+L}{\type{\ttbndl}}\items{
 *				\itat{i}{} \pmatchin \itb{1}{}
 *			},
 *			\ele{K+L+1}{\type{\ttbndl}}\items{
 *				\itat{i}{} \pmatchnotin \elb{}{}
 *			}
 *		}
 *	}
 * @f$, where the patterns of @f$\itat{i}{}@f$ have been
 * stripped of their matching part.
 */
void ose_routeWithDelegation(ose_bundle B)
{
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    int32_t onm1, snm1, on, sn;
    be2(B, &onm1, &snm1, &on, &sn);
    ose_assert(ose_getBundleElemType(B, onm1) == OSETT_BUNDLE);
    ose_assert(ose_getBundleElemType(B, on) == OSETT_MESSAGE);
    char *b = ose_getBundlePtr(B);
    int32_t tto = on + 4 + ose_getPaddedStringLen(B, on + 4);
    int32_t plo = tto + ose_getPaddedStringLen(B, tto);
    tto++;
    char tt;
    int32_t n = 0;
    int32_t _plo = plo;
    while((tt = ose_readByte(B, tto + n)) != 0)
    {
        if(ose_isStringType(tt))
        {
            b[tto + n] = _plo - plo;
            _plo += ose_getPayloadItemSize(B, tt, on, _plo);
            ++n;
        }
        else
        {
            ose_assert(0 && "found a non-string type");
        }
    }
    ose_pushBundle(B);
    int32_t route_bundle_offset = on + sn + 4 + 4 + OSE_BUNDLE_HEADER_LEN;
    int32_t i;
    for(i = n - 1; i >= 0; --i)
    {
        ose_pushBundle(B);
        int32_t ns = 0;
        int32_t o = onm1 + 4 + OSE_BUNDLE_HEADER_LEN;
        int32_t s;
        while(o < on)
        {
            s = ose_readInt32(B, o);
            int32_t matched = s & 0x80000000;
            s &= 0x7FFFFFFF;
            const char * const pattern = b + o + 4;
            const char * const address = b + plo + b[tto + i];
            int32_t po, ao, r;
            r = ose_match_pattern(pattern, address,
                                  &po, &ao);
            if(r & OSE_MATCH_ADDRESS_COMPLETE)
            {
                ose_writeInt32(B, o, s);
                ns += ose_routeElemAtOffset(o, B,
                                            po, B);
                ns += 4;
                matched = 0x80000000;
            }
            ose_writeInt32(B, o, s | matched);
            o += s + 4;
        }
        ns += OSE_BUNDLE_HEADER_LEN;
        ose_writeInt32(B,
                       route_bundle_offset,
                       ns);
        route_bundle_offset += ns + 4;

    }
    /* delegation */
    {
        ose_pushBundle(B);
        int32_t ns = 0;
        int32_t o = onm1 + 4 + OSE_BUNDLE_HEADER_LEN;
        int32_t s;
        while(o < on)
        {
            s = ose_readInt32(B, o);
            int32_t matched = s & 0x80000000;
            s &= 0x7FFFFFFF;
            ose_writeInt32(B, o, s);
            if(!matched)
            {
                ose_copyElemAtOffset(o, B, B);
                ns += s + 4;
            }
            o += s + 4;
        }
        ose_writeInt32(B,
                       route_bundle_offset,
                       ns + OSE_BUNDLE_HEADER_LEN);
        route_bundle_offset += ns + 4 + OSE_BUNDLE_HEADER_LEN;
    }
    int32_t ss = route_bundle_offset - (on + sn + 4 + 4);
    ose_writeInt32(B, on + sn + 4, ss);
    /* delete args */
    {
        memmove(b + onm1, b + on + sn + 4, ss + 4);
        int32_t diff = (sn + snm1) - ss;
        if(diff > 0)
        {
            memset(b + onm1 + ss + 4, 0, diff + 4);
        }
        ose_addToSize(B, -(sn + snm1 + 8));
    }
}

/**
 * @f$
 *	\fn{SELECTWITHDELEGATION}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{\type{\ttbndl}}\items{
 *				\ita{i}{\type{\ttmsg}}
 *			},
 *			\elb{K+1}{\type{\ttmsg(\allstrings{1}{L})}}\items{
 *				\itb{1}{\type{\tts}},
 *				\ldots,
 *				\itb{L}{\type{\tts}}
 *			}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\elc{K}{\type{\ttbndl}}\items{
 *				\ita{i}{} \pmatchin \itb{L}{}
 *			},
 *			\ldots,
 *			\eld{K+L}{\type{\ttbndl}}\items{
 *				\ita{i}{} \pmatchin \itb{1}{}
 *			},
 *			\ele{K+L+1}{\type{\ttbndl}}\items{
 *				\ita{i}{} \pmatchnotin \elb{}{}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_selectWithDelegation(ose_bundle B)
{
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    int32_t onm1, snm1, on, sn;
    be2(B, &onm1, &snm1, &on, &sn);
    ose_assert(ose_getBundleElemType(B, onm1) == OSETT_BUNDLE);
    ose_assert(ose_getBundleElemType(B, on) == OSETT_MESSAGE);
    char *b = ose_getBundlePtr(B);
    int32_t tto = on + 4 + ose_getPaddedStringLen(B, on + 4);
    int32_t plo = tto + ose_getPaddedStringLen(B, tto);
    tto++;
    char tt;
    int32_t n = 0;
    int32_t _plo = plo;
    while((tt = ose_readByte(B, tto + n)) != 0)
    {
        if(ose_isStringType(tt))
        {
            b[tto + n] = _plo - plo;
            _plo += ose_getPayloadItemSize(B, tt, on, _plo);
            ++n;
        }
        else
        {
            ose_assert(0 && "found a non-string type");
        }
    }
    ose_pushBundle(B);
    int32_t route_bundle_offset = on + sn + 4 + 4 + OSE_BUNDLE_HEADER_LEN;
    int32_t i;
    for(i = n - 1; i >= 0; --i)
    {
        ose_pushBundle(B);
        int32_t ns = 0;
        int32_t o = onm1 + 4 + OSE_BUNDLE_HEADER_LEN;
        int32_t s;
        while(o < on)
        {
            s = ose_readInt32(B, o);
            int32_t matched = s & 0x80000000;
            s &= 0x7FFFFFFF;
            const char * const pattern = b + o + 4;
            const char * const address = b + plo + b[tto + i];
            int32_t po, ao, r;
            r = ose_match_pattern(pattern, address,
                                  &po, &ao);
            if(r & OSE_MATCH_ADDRESS_COMPLETE)
            {
                ose_writeInt32(B, o, s);
                char *b = ose_getBundlePtr(B);
                const int32_t old_bundle_size = ose_readSize(B);
                const int32_t elem_size = ose_readInt32(B, o);
                ose_addToSize(B, elem_size + 4);
                memcpy(b + old_bundle_size, b + o, elem_size + 4);
                ns += elem_size + 4;
                matched = 0x80000000;
            }
            ose_writeInt32(B, o, s | matched);
            o += s + 4;
        }
        ns += OSE_BUNDLE_HEADER_LEN;
        ose_writeInt32(B,
                       route_bundle_offset,
                       ns);
        route_bundle_offset += ns + 4;
    }
    /* delegation */
    {
        ose_pushBundle(B);
        int32_t ns = 0;
        int32_t o = onm1 + 4 + OSE_BUNDLE_HEADER_LEN;
        int32_t s;
        while(o < on)
        {
            s = ose_readInt32(B, o);
            int32_t matched = s & 0x80000000;
            s &= 0x7FFFFFFF;
            ose_writeInt32(B, o, s);
            if(!matched)
            {
                ose_copyElemAtOffset(o, B, B);
                ns += s + 4;
            }
            o += s + 4;
        }
        ose_writeInt32(B,
                       route_bundle_offset,
                       ns + OSE_BUNDLE_HEADER_LEN);
        route_bundle_offset += ns + 4 + OSE_BUNDLE_HEADER_LEN;
    }
    int32_t ss = route_bundle_offset - (on + sn + 4 + 4);
    ose_writeInt32(B, on + sn + 4, ss);
    /* delete args */
    {
        memmove(b + onm1, b + on + sn + 4, ss + 4);
        int32_t diff = (sn + snm1) - ss;
        if(diff > 0)
        {
            memset(b + onm1 + ss + 4, 0, diff + 4);
        }
        ose_addToSize(B, -(sn + snm1 + 8));
    }
}

/**
 * @f$
 *	\fn{GATHER}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K-1}{\type{\ttbndl}}\items{
 *				\ita{i}{\type{\ttmsg}}
 *			},
 *			\elb{K}{\type{\ttmsg(\type{\tts}_i)}}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\elc{K-1}{\type{\ttbndl}}\items{
 *				\ita{i} \pmatchin \elb{}{}
 *			},
 *			\eld{K}{\type{\ttbndl}}\items{
 *				\ita{i} \pmatchnotin \elb{}{}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_gather(ose_bundle B)
{
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    int32_t onm1, snm1, on, sn;
    be2(B, &onm1, &snm1, &on, &sn);
    ose_assert(ose_getBundleElemType(B, onm1) == OSETT_BUNDLE);
    ose_assert(ose_getBundleElemType(B, on) == OSETT_MESSAGE);
    char *b = ose_getBundlePtr(B);
    int32_t tto = on + 4 + ose_getPaddedStringLen(B, on + 4);
    int32_t plo = tto + ose_getPaddedStringLen(B, tto);
    tto++;
    char tt;
    int32_t n = 0;
    int32_t _plo = plo;
    while((tt = ose_readByte(B, tto + n)) != 0)
    {
        if(ose_isStringType(tt))
        {
            b[tto + n] = _plo - plo;
            _plo += ose_getPayloadItemSize(B, tt, on, _plo);
            ++n;
        }
        else
        {
            ose_assert(0 && "found a non-string type");
        }
    }
    ose_pushBundle(B);
    int32_t current_offset = on + sn + 4;
    int32_t bundlesize = OSE_BUNDLE_HEADER_LEN;
    int32_t i;
    for(i = n - 1; i >= 0; --i)
    {
        
        int32_t o = onm1 + 4 + OSE_BUNDLE_HEADER_LEN;
        int32_t s;
        while(o < on)
        {
            s = ose_readInt32(B, o);
            int32_t matched = s & 0x80000000;
            s &= 0x7FFFFFFF;
            const char * const pattern = b + o + 4;
            const char * const address = b + plo + b[tto + i];
            int32_t po, ao, r;
            r = ose_match_pattern(pattern, address,
                                  &po, &ao);
            if(r & OSE_MATCH_ADDRESS_COMPLETE)
            {
                ose_writeInt32(B, o, s);
                ose_copyElemAtOffset(o, B, B);
                bundlesize += s + 4;
                matched = 0x80000000;
            }
            ose_writeInt32(B, o, s | matched);
            o += s + 4;
        }
        /* bundlesize += OSE_BUNDLE_HEADER_LEN; */
        /* ose_writeInt32(B, */
        /*                current_offset, */
        /*                bundlesize); */
        /* current_offset += bundlesize; */

        /* plo += ose_getPayloadItemSize(B, tt, plo); */
        /* tto++; */
    }
    ose_writeInt32(B, on + sn + 4, bundlesize);
    current_offset += bundlesize + 4;
    /* delegation */
    {
        ose_pushBundle(B);
        int32_t ns = 0;
        int32_t o = onm1 + 4 + OSE_BUNDLE_HEADER_LEN;
        int32_t s;
        while(o < on)
        {
            s = ose_readInt32(B, o);
            int32_t matched = s & 0x80000000;
            s &= 0x7FFFFFFF;
            ose_writeInt32(B, o, s);
            if(!matched)
            {
                ose_copyElemAtOffset(o, B, B);
                ns += s + 4;
            }
            o += s + 4;
        }
        ose_writeInt32(B,
                       current_offset,
                       ns + OSE_BUNDLE_HEADER_LEN);
        current_offset += ns + 4 + OSE_BUNDLE_HEADER_LEN;
    }
    int32_t ss = current_offset - (on + sn + 4 + 4);
    /* ose_writeInt32(B, on + sn + 4, ss); */
    /* delete args */
    {
        memmove(b + onm1, b + on + sn + 4, ss + 4);
        int32_t diff = (sn + snm1) - ss;
        if(diff > 0)
        {
            memset(b + onm1 + ss + 4, 0, diff + 4);
        }
        ose_addToSize(B, -(sn + snm1 + 8));
    }
}

/**
 * @f$
 *	\fn{NTH}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K-1}{\ttvar}\items{
 *				\ldots,
 *				\ita{\valv{}{}}{},
 *				\ldots,
 *				\itb{\valw{}{}}{},
 *				\ldots
 *			},
 *			\elb{K}{\type{\ttmsg(\allints{1}{M})}}\items{
 *				\itc{1}{\type{\tti}}\values{\valv{}{}},
 *				\ldots,
 *				\itd{M}{\type{\tti}}\values{\valw{}{}},
 *			}
 *		}
 *	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\elc{K-1}{\ttvar}\items{
 *				\ita{1}{},
 *				\ldots,
 *				\itb{M}{}
 *			}
 *		}
 *	}
 * @f$
 */
void ose_nth(ose_bundle B)
#if 1
{
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    int32_t onm1, snm1, on, sn;
    char *b;
    int32_t tton, nttn, plon;

    be2(B, &onm1, &snm1, &on, &sn);
    ose_assert(ose_getBundleElemType(B, on) == OSETT_MESSAGE);
    b = ose_getBundlePtr(B);
    tton = on + 4 + ose_getPaddedStringLen(B, on + 4);
    nttn = strlen(b + tton) - 1;
    plon = tton + ose_pnbytes(nttn + 1);
    ++tton;
    
    if(ose_getBundleElemType(B, onm1) == OSETT_MESSAGE)
    {
        int32_t ttonm1 = onm1 + 4 + ose_getPaddedStringLen(B,
                                                           onm1 + 4) + 1;
        int32_t nttnm1 = strlen(b + ttonm1);
        int32_t plonm1 = ttonm1 - 1 + ose_pnbytes(nttnm1 + 1);
        int32_t ttonm1p = ttonm1;
        int32_t plonm1p = plonm1;
        int32_t ttonp = tton;
        int32_t plonp = plon;
        int32_t i;
        int32_t new_msg_payload_size = 0;
        int32_t new_msg_size;
        int32_t new_msg_offset;
        int32_t nmtto, nmplo;
        int32_t *offsets, *offsetp;

        if(nttn == 0 || nttnm1 == 0)
        {
            /* empty message? */
            ose_2drop(B);
            return;
        }
        
        ose_pushMessage(B,
                        OSE_ADDRESS_ANONVAL,
                        OSE_ADDRESS_ANONVAL_LEN,
                        1,
                        OSETT_BLOB, (nttnm1 + 1) * 4, NULL);
        offsets = (int32_t *)(b + ose_readSize(B) - ((nttnm1 + 1) * 4));
        offsetp = offsets;
        
        for(i = 0; i < nttnm1; ++i)
        {
            *offsetp = plonm1p;
            char tt = ose_readByte(B, ttonm1p);
            plonm1p += ose_getPayloadItemSize(B, tt, onm1, plonm1p);
            ++ttonm1p;
            ++offsetp;
        }
        *offsetp = plonm1p;
        ++offsetp;
        for(i = 0; i < nttn; ++i)
        {
            ose_assert(ose_readByte(B, ttonp) == OSETT_INT32);
            int32_t idx = ose_readInt32(B, plonp);
            new_msg_payload_size += offsets[idx + 1] - offsets[idx];
            ++ttonp;
            plonp += 4;
        }
        new_msg_offset = ose_readSize(B);
        new_msg_size = OSE_ADDRESS_ANONVAL_SIZE
            + ose_pnbytes(nttn + 1)
            + new_msg_payload_size;
        ose_addToSize(B,
                      4 + new_msg_size);
        ose_writeInt32(B, new_msg_offset, new_msg_size);
        memcpy(b + new_msg_offset + 4,
               OSE_ADDRESS_ANONVAL,
               OSE_ADDRESS_ANONVAL_SIZE);
        nmtto = new_msg_offset + 4 + OSE_ADDRESS_ANONVAL_SIZE;
        nmplo = nmtto + ose_pnbytes(nttn + 1);
        plonp = plon;
        ose_writeByte(B, nmtto++, OSETT_ID);
        for(i = 0; i < nttn; ++i)
        {
            int32_t idx = ose_readInt32(B, plonp);
            int32_t sz = offsets[idx + 1] - offsets[idx];
            ose_writeByte(B, nmtto++, ose_readByte(B, ttonm1 + idx));
            memcpy(b + nmplo,
                   b + offsets[idx],
                   sz);
            nmplo += sz;
            plonp += 4;
        }
        memmove(b + onm1,
                b + new_msg_offset,
                new_msg_size + 4);
        memset(b + onm1 + new_msg_size + 4,
               0,
               ose_readSize(B) - (onm1 + new_msg_size + 4));
        ose_decSize(B, ose_readSize(B) - (onm1 + new_msg_size + 4));
    }
    else
    {
        int32_t o, i;
        int32_t ttonp = tton;
        int32_t plonp = plon;
        /* int32_t ttonm1 = onm1 + 4 + ose_getPaddedStringLen(B, */
        /*                                                    onm1 + 4) + 1; */
        /* int32_t nttnm1 = strlen(b + ttonm1); */
        int32_t nmnm1 = 0;
        int32_t new_bundle_size = OSE_BUNDLE_HEADER_LEN;
        int32_t new_bundle_offset;
        int32_t *offsets, *offsetp;
        if(nttn == 0 || snm1 == OSE_BUNDLE_HEADER_LEN)
        {
            /* empty bundle? */
            ose_2drop(B);
            return;
        }
        o = onm1 + 4 + OSE_BUNDLE_HEADER_LEN;
        while(o < on)
        {
            int32_t s = ose_readInt32(B, o);
            ++nmnm1;
            o += 4 + s;
        }
        ose_pushMessage(B,
                        OSE_ADDRESS_ANONVAL,
                        OSE_ADDRESS_ANONVAL_LEN,
                        1,
                        OSETT_BLOB, nmnm1 * 4, NULL);
        offsets = (int32_t *)(b + ose_readSize(B) - (nmnm1 * 4));
        offsetp = offsets;
        o = onm1 + 4 + OSE_BUNDLE_HEADER_LEN;
        while(o < on)
        {
            int32_t s = ose_readInt32(B, o);
            *offsetp = o;
            ++offsetp;
            o += 4 + s;
        }
        for(i = 0; i < nttn; ++i)
        {
            ose_assert(ose_readByte(B, ttonp) == OSETT_INT32);
            int32_t idx = ose_readInt32(B, plonp);
            new_bundle_size += ose_readInt32(B, offsets[idx]) + 4;
            ++ttonp;
            plonp += 4;
        }
        new_bundle_offset = ose_readSize(B);
        ose_incSize(B, new_bundle_size + 4);
        ose_writeInt32(B, new_bundle_offset, new_bundle_size);
        memcpy(b + new_bundle_offset + 4,
               OSE_BUNDLE_HEADER, OSE_BUNDLE_HEADER_LEN);
        o = new_bundle_offset + 4 + OSE_BUNDLE_HEADER_LEN;
        ttonp = tton;
        plonp = plon;
        for(i = 0; i < nttn; ++i)
        {
            int32_t idx = ose_readInt32(B, plonp);
            int32_t offset = offsets[idx];
            int32_t size = ose_readInt32(B, offset);
            memcpy(b + o, b + offset, size + 4);
            ++ttonp;
            plonp += 4;
            o += size + 4;
        }
        memcpy(b + onm1,
               b + new_bundle_offset,
               new_bundle_size + 4);
        memset(b + onm1 + new_bundle_size + 4,
               0,
               ose_readSize(B) - (onm1 + new_bundle_size + 4));
        ose_decSize(B, ose_readSize(B) - (onm1 + new_bundle_size + 4));
    }
}
#else
{
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    int32_t onm1, snm1, on, sn;
    be2(B, &onm1, &snm1, &on, &sn);
    ose_assert(ose_getBundleElemType(B, on) == OSETT_MESSAGE);
    char *b = ose_getBundlePtr(B);
    int32_t tton = on + 4 + ose_getPaddedStringLen(B, on + 4);
    int32_t nttn = strlen(b + tton) - 1;
    int32_t plon = tton + ose_pnbytes(nttn + 1);
    ++tton;
    if(ose_getBundleElemType(B, onm1) == OSETT_MESSAGE)
    {
        int32_t ttonm1 = onm1 + 4 + ose_getPaddedStringLen(B,
                                                           onm1 + 4);
        int32_t nttnm1 = strlen(b + ttonm1) - 1;
        if(nttnm1 == 0)
        {
            ose_drop(B);
            return;
        }
        int32_t plonm1 = ttonm1 + ose_pnbytes(nttnm1 + 1);
        ++ttonm1;
        int32_t *offsets = (int32_t *)(b + on + sn + 4);
        int32_t *offsetp = offsets;
        int32_t _ttonm1 = ttonm1, _plonm1 = plonm1;
        int32_t i;
        for(i = 0; i < nttnm1; i++)
        {
            *offsetp = _plonm1;
            char tt = ose_readByte(B, _ttonm1);
            _plonm1 += ose_getPayloadItemSize(B, tt, onm1, _plonm1);
            ++_ttonm1;
            ++offsetp;
        }
        *offsetp = _plonm1;
        ++offsetp;
        int32_t so = (char *)offsetp - b;
        int32_t ao = so + 4;
        int32_t tto = ao + 4;
        int32_t plo = tto + ose_pnbytes(nttn + 1);
        /* ose_writeByte(B, tto, OSETT_ID); */
        b[tto] = OSETT_ID;
        ++tto;
        for(i = 0; i < nttn; i++)
        {
            int32_t idx = ose_readInt32(B, plon + (i * 4));
            char tt = ose_readByte(B, ttonm1 + idx);
            int32_t sz = offsets[idx + 1] - offsets[idx];
            /* ose_writeByte(B, tto, tt); */
            b[tto] = tt;
            memcpy(b + plo, b + offsets[idx], sz);
            plo += sz;
            ++tto;
        }
        int32_t newsize = (plo - so) - 4;
        ose_writeInt32_outOfBounds(B, so, newsize);
        memmove(b + onm1, b + so, plo - so);
        int32_t diff = plo - (onm1 + newsize + 4);
        if(diff > 0)
        {
            memset(b + onm1 + newsize + 4, 0, diff);
        }
        ose_addToSize(B, newsize - (snm1 + sn + 4));
    }
    else
    {
        if(snm1 == OSE_BUNDLE_HEADER_LEN)
        {
            ose_drop(B);
            return;
        }
        int32_t o = onm1 + 4 + OSE_BUNDLE_HEADER_LEN;
        int32_t *offsets = (int32_t *)(b + on + sn + 4);
        int32_t *offsetp = offsets;
        while(o < on)
        {
            *offsetp = o;
            ++offsetp;
            o += ose_readInt32(B, o) + 4;
        }
        *offsetp = o;
        ++offsetp;
        int32_t so = o = (char *)offsetp - b;
        o += 4;
        memcpy(b + o, OSE_BUNDLE_HEADER, OSE_BUNDLE_HEADER_LEN);
        o += OSE_BUNDLE_HEADER_LEN;
        int32_t i;
        for(i = 0; i < nttn; i++)
        {
            int32_t idx = ose_readInt32(B, plon + (i * 4));
            int32_t oo = offsets[idx];
            int32_t ss = ose_readInt32(B, oo);
            memcpy(b + o, b + oo, ss + 4);
            o += ss + 4;
        }
        int32_t bs = (o - so) - 4;
        ose_writeInt32_outOfBounds(B, so, bs);
        memmove(b + onm1, b + so, bs + 4);
        memset(b + onm1 + bs + 4, 0, (so + bs + 4) - (onm1 + bs + 4));
        ose_addToSize(B, bs - (snm1 + sn + 4));
    }
}
#endif

static void ose_replace_impl(ose_bundle B,
                             int32_t dest_offset,
                             int32_t src_offset,
                             int32_t src_size)
{
    char *b = ose_getBundlePtr(B);
    int32_t o = dest_offset + 4 + OSE_BUNDLE_HEADER_LEN;
    int32_t end = src_offset;
    while(o < end)
    {
        int32_t s = ose_readInt32(B, o);
        if(!strcmp(b + o + 4, b + end + 4))
        {
            if(s < src_size)
            {
                int32_t diff = src_size - s;
                memmove(b + o + s + 4 + diff,
                        b + o + s + 4,
                        (src_offset + src_size + 4) - (o + s + 4));
                memcpy(b + o,
                       b + src_offset + diff,
                       src_size + 4);
                memset(b + src_offset + diff,
                       0,
                       src_size + 4);
                ose_writeInt32(B,
                               dest_offset,
                               ose_readInt32(B, dest_offset) + diff);
                ose_addToSize(B, -((src_size + 4) - diff));
            }
            else if(s > src_size)
            {
                int32_t diff = s - src_size;
                memcpy(b + o, b + src_offset, src_size + 4);
                memmove(b + o + src_size + 4,
                        b + o + s + 4,
                        (src_offset + src_size + 4) - (o + s + 4));
                memset(b + ((src_offset + src_size + 4) - diff),
                       0,
                       diff + 4); /* old context bndl size */
                ose_writeInt32(B,
                               dest_offset,
                               ose_readInt32(B, dest_offset) - diff);
                ose_addToSize(B, -(diff + src_size + 4));
            }
            else
            {
                memcpy(b + o, b + src_offset, s + 4);
                memset(b + src_offset, 0, s + 4);
                ose_addToSize(B, -(s + 4));
            }
            return;
        }
        else
        {
            o += s + 4;
        }
    }
    ose_push(B);
}

void ose_replace(ose_bundle B)
{
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    int32_t on, sn, onm1, snm1;
    be2(B, &onm1, &snm1, &on, &sn);
    ose_assert(ose_getBundleElemType(B, onm1) == OSETT_BUNDLE);
    ose_assert(ose_getBundleElemType(B, on) == OSETT_MESSAGE);
    ose_replace_impl(B, onm1, on, sn);
}

void ose_assign(ose_bundle B)
{
    ose_assert(ose_bundleHasAtLeastNElems(B, 3));
    int32_t on, sn, onm1, snm1, onm2, snm2;
    be3(B, &onm2, &snm2, &onm1, &snm1, &on, &sn);
    ose_assert(ose_getBundleElemType(B, onm2) == OSETT_BUNDLE);
    ose_assert(ose_getBundleElemType(B, on) == OSETT_MESSAGE);

    if(ose_getBundleElemType(B, onm1) == OSETT_BUNDLE)
    {
        /* replace this with faster code that uses the offsets */
        ose_swap(B);
        ose_elemToBlob(B);
        ose_swap(B);
        be3(B, &onm2, &snm2, &onm1, &snm1, &on, &sn);
    }

    int32_t to, ntt, lto, po, lpo;
    ose_getNthPayloadItem(B, 1, on, &to, &ntt, &lto, &po, &lpo);
    ose_assert(ose_isStringType(ose_readByte(B, lto)));

    char *b = ose_getBundlePtr(B);
    const char addylen = strlen(b + lpo);
    const char paddylen = ose_pnbytes(addylen);
    memmove(b + on + 4, b + lpo, paddylen);

    ose_incSize(B, snm1);
    int32_t data_offset = onm1 + 4;
    data_offset += ose_pstrlen(b + data_offset);
    int32_t data_len = on - data_offset;
    memcpy(b + on + 4 + paddylen, b + data_offset, data_len);
    memcpy(b + onm1 + 4, b + on + 4, paddylen + data_len);
    int32_t extra = ose_readSize(B)
        - (onm1 + 4 + paddylen + data_len);
        
    memset(b + onm1 + 4 + paddylen + data_len, 0, extra);
    ose_decSize(B, extra);
    ose_writeInt32(B, onm1, paddylen + data_len);

    ose_replace_impl(B, onm2, onm1, paddylen + data_len);
}

void ose_lookup(ose_bundle B)
{
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    int32_t on, sn, onm1, snm1;
    be2(B, &onm1, &snm1, &on, &sn);
    ose_assert(ose_getBundleElemType(B, onm1) == OSETT_BUNDLE);

    int32_t to, ntt, lto, po, lpo;
    ose_getNthPayloadItem(B, 1, on, &to, &ntt, &lto, &po, &lpo);
    ose_assert(ose_isStringType(ose_readByte(B, lto)));

    char *b = ose_getBundlePtr(B);

    int32_t o = onm1 + 4 + OSE_BUNDLE_HEADER_LEN;
    while(o < on)
    {
        int32_t ss = ose_readInt32(B, o);
        if(!strcmp(b + o + 4, b + lpo))
        {
            memset(b + on, 0, sn + 4);
            int32_t len = (ss + 4) - (sn + 4);
            ose_incSize(B, len);
            memcpy(b + on, b + o, ss + 4);
            return;
        }
        o += ss + 4;
    }
    ose_drop(B);
    ose_pushMessage(B, OSE_ADDRESS_ANONVAL, OSE_ADDRESS_ANONVAL_LEN, 0);
}

/**
 * @todo Implement.
 */
void ose_plookup(ose_bundle B)
{
}

/**************************************************
 * Creatio Ex Nihilo
 **************************************************/

/**
 * @f$
 * 	\fn{MAKEBLOB}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{}
 *		}
 * 	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\ela{K}{},
 *			\elb{K+1}{\type{\ttmsg}}\items{
 *				\ita{}{\type{\ttb}}
 *			}
 *		}
 * 	}
 * @f$
 */
void ose_makeBlob(ose_bundle B)
{
    ose_assert(ose_peekMessageArgType(B) == OSETT_INT32);
    int32_t s = ose_popInt32(B);
    int32_t sp = s;
    if(sp <= 0)
    {
        sp = 1;
    }
    while(sp % 4)
    {
        sp++;
    }
    ose_pushBlob(B, s, NULL);
}

/**
 * @f$
 * 	\fn{PUSHBUNDLE}{
 *		\BB\elems{\ldots, \ela{K}{}}
 * 	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\ela{K}{},
 *			\elb{K+1}{\type{\ttbndl}}\items{}
 *		}
 * 	}
 * @f$
 */
void ose_pushBundle(ose_bundle B)
{
    int32_t wp = ose_readSize(B);
    ose_incSize(B, 4 + OSE_BUNDLE_HEADER_LEN);
    ose_writeInt32(B, wp, OSE_BUNDLE_HEADER_LEN);
    char *b = ose_getBundlePtr(B);
    memcpy(b + wp + 4, OSE_BUNDLE_HEADER, OSE_BUNDLE_HEADER_LEN);
}

/**************************************************
 * arithmetic
 **************************************************/

/**
 * @todo Implement extended types.
 * 
 * @f$\fnbinop{ADD}{+}@f$
 */
void ose_add(ose_bundle B)
{
    int32_t onm1, snm1, on, sn;
    be2(B, &onm1, &snm1, &on, &sn);
    int32_t nm1to, nm1ntt, nm1lto, nm1po, nm1lpo;
    int32_t nto, nntt, nlto, npo, nlpo;
    ose_getNthPayloadItem(B, 1, onm1,
                          &nm1to, &nm1ntt, &nm1lto, &nm1po, &nm1lpo);
    ose_getNthPayloadItem(B, 1, on,
                          &nto, &nntt, &nlto, &npo, &nlpo);
    char t2 = ose_readByte(B, nm1lto);
    char t1 = ose_readByte(B, nlto);
    if(!ose_isNumericType(t1)
       || !ose_isNumericType(t2)
       || t1 != t2)
    {
        ose_errno_set(B, OSE_ERR_ITEM_TYPE);
        return;
    }
    char *b = ose_getBundlePtr(B);
    switch(t1)
    {
    case OSETT_INT32:
    {
        int32_t v2 = ose_readInt32(B, nm1lpo);
        int32_t v1 = ose_readInt32(B, nlpo);
        memset(b + onm1, 0, snm1 + sn + 8);
        ose_decSize(B, snm1 + sn + 8);
        ose_pushInt32(B, v1 + v2);
    }
    break;
    case OSETT_FLOAT:
    {
        float v2 = ose_readFloat(B, nm1lpo);
        float v1 = ose_readFloat(B, nlpo);
        memset(b + onm1, 0, snm1 + sn + 8);
        ose_decSize(B, snm1 + sn + 8);
        ose_pushFloat(B, v1 + v2);
    }
    break;
#ifdef OSE_PROVIDE_TYPE_DOUBLE
    case OSETT_DOUBLE:
    {
        double v2 = ose_readDouble(B, nm1lpo);
        double v1 = ose_readDouble(B, nlpo);
        memset(b + onm1, 0, snm1 + sn + 8);
        ose_decSize(B, snm1 + sn + 8);
        ose_pushDouble(B, v1 + v2);
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
    case OSETT_INT8:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
    case OSETT_UINT8:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
    case OSETT_UINT32:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
    case OSETT_INT64:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
    case OSETT_UINT64:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
    case OSETT_TIMETAG:
    {
        struct ose_timetag v2 = ose_readTimetag(B, nm1lpo);
        struct ose_timetag v1 = ose_readTimetag(B, nlpo);
        struct ose_timetag r;
        memset(b + onm1, 0, snm1 + sn + 8);
        ose_decSize(B, snm1 + sn + 8);
        r.sec = v1.sec + v2.sec;
        r.fsec = v1.fsec + v2.fsec;
        if(r.fsec < v1.fsec) { // rollover occurred
            r.sec += 1;
        }
        ose_pushTimetag(B, r.sec, r.fsec);
    }
    break;
#endif
    }
}

/**
 * @todo Implement extended types.
 * 
 * @f$\fnbinop{SUB}{-}@f$
 */
void ose_sub(ose_bundle B)
{
    int32_t onm1, snm1, on, sn;
    be2(B, &onm1, &snm1, &on, &sn);
    int32_t nm1to, nm1ntt, nm1lto, nm1po, nm1lpo;
    int32_t nto, nntt, nlto, npo, nlpo;
    ose_getNthPayloadItem(B, 1, onm1,
                          &nm1to, &nm1ntt, &nm1lto, &nm1po, &nm1lpo);
    ose_getNthPayloadItem(B, 1, on,
                          &nto, &nntt, &nlto, &npo, &nlpo);
    char t2 = ose_readByte(B, nm1lto);
    char t1 = ose_readByte(B, nlto);
    if(!ose_isNumericType(t1)
       || !ose_isNumericType(t2)
       || t1 != t2)
    {
        ose_errno_set(B, OSE_ERR_ITEM_TYPE);
        return;
    }
    char *b = ose_getBundlePtr(B);
    switch(t1)
    {
    case OSETT_INT32:
    {
        int32_t v2 = ose_readInt32(B, nm1lpo);
        int32_t v1 = ose_readInt32(B, nlpo);
        memset(b + onm1, 0, snm1 + sn + 8);
        ose_decSize(B, snm1 + sn + 8);
        ose_pushInt32(B, v1 - v2);
    }
    break;
    case OSETT_FLOAT:
    {
        float v2 = ose_readFloat(B, nm1lpo);
        float v1 = ose_readFloat(B, nlpo);
        memset(b + onm1, 0, snm1 + sn + 8);
        ose_decSize(B, snm1 + sn + 8);
        ose_pushFloat(B, v1 - v2);
    }
    break;
#ifdef OSE_PROVIDE_TYPE_DOUBLE
    case OSETT_DOUBLE:
    {
        double v2 = ose_readDouble(B, nm1lpo);
        double v1 = ose_readDouble(B, nlpo);
        memset(b + onm1, 0, snm1 + sn + 8);
        ose_decSize(B, snm1 + sn + 8);
        ose_pushDouble(B, v1 + v2);
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
    case OSETT_INT8:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
    case OSETT_UINT8:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
    case OSETT_UINT32:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
    case OSETT_INT64:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
    case OSETT_UINT64:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
    case OSETT_TIMETAG:
    {
        struct ose_timetag v2 = ose_readTimetag(B, nm1lpo);
        struct ose_timetag v1 = ose_readTimetag(B, nlpo);
        struct ose_timetag r;
        memset(b + onm1, 0, snm1 + sn + 8);
        ose_decSize(B, snm1 + sn + 8);
        if(v1.sec > v2.sec || (v1.sec == v2.sec && v1.fsec >= v2.fsec)){
            r.sec = v1.sec - v2.sec;
            if(v1.fsec >= v2.fsec){
                r.fsec = v1.fsec - v2.fsec;
            }else{
                if(r.sec == 0){
                    r.fsec = v2.fsec - v1.fsec;
                }else{
                    r.sec--;
                    r.fsec = v1.fsec - v2.fsec;
                }
            }
        }else{
            r.sec = v2.sec - v1.sec;
            if(v1.fsec >= v2.fsec){
                r.fsec = v1.fsec - v2.fsec;
            }else{
                r.fsec = v2.fsec - v1.fsec;
            }
        }
        ose_pushTimetag(B, r.sec, r.fsec);
    }
    break;
#endif
    }
}

/**
 * @todo Implement extended types.
 * 
 * @f$\fnbinop{MUL}{}@f$
 */
void ose_mul(ose_bundle B)
{
    char t1 = ose_peekMessageArgType(B);
    ose_assert(ose_isNumericType(t1));
    ose_swap(B);
    char t2 = ose_peekMessageArgType(B);(void)t2;
    ose_assert(ose_isNumericType(t2));
    ose_assert(t1 == t2);
    switch(t1)
    {
    case OSETT_INT32:
    {
        int32_t v2 = ose_popInt32(B);
        int32_t v1 = ose_popInt32(B);
        ose_pushInt32(B, v1 * v2);
    }
    break;
    case OSETT_FLOAT:
    {
        float v2 = ose_popFloat(B);
        float v1 = ose_popFloat(B);
        ose_pushFloat(B, v1 * v2);
    }
    break;
#ifdef OSE_PROVIDE_TYPE_DOUBLE
    case OSETT_DOUBLE:
    {
        double v2 = ose_popDouble(B);
        double v1 = ose_popDouble(B);
        ose_pushDouble(B, v1 * v2);
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
    case OSETT_INT8:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
    case OSETT_UINT8:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
    case OSETT_UINT32:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
    case OSETT_INT64:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
    case OSETT_UINT64:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
    case OSETT_TIMETAG:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
    }
}

/**
 * @todo Implement extended types.
 * 
 * @f$\fnbinop{DIV}{/}@f$
 */
void ose_div(ose_bundle B)
{
    char t1 = ose_peekMessageArgType(B);
    ose_assert(ose_isNumericType(t1));
    ose_swap(B);
    char t2 = ose_peekMessageArgType(B);(void)t2;
    ose_assert(ose_isNumericType(t2));
    ose_assert(t1 == t2);
    switch(t1){
    case OSETT_INT32:
    {
        int32_t v2 = ose_popInt32(B);
        int32_t v1 = ose_popInt32(B);
        ose_pushInt32(B, v1 / v2);
    }
    break;
    case OSETT_FLOAT:
    {
        float v2 = ose_popFloat(B);
        float v1 = ose_popFloat(B);
        ose_pushFloat(B, v1 / v2);
    }
    break;
#ifdef OSE_PROVIDE_TYPE_DOUBLE
    case OSETT_DOUBLE:
    {
        double v2 = ose_popDouble(B);
        double v1 = ose_popDouble(B);
        ose_pushDouble(B, v1 / v2);
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
    case OSETT_INT8:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
    case OSETT_UINT8:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
    case OSETT_UINT32:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
    case OSETT_INT64:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
    case OSETT_UINT64:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
    case OSETT_TIMETAG:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
    }
}

/**
 * @todo Implement extended types.
 * 
 * @f$\fnbinop{MOD}{\bmod}@f$
 */
void ose_mod(ose_bundle B)
{
    int32_t onm1, snm1, on, sn;
    be2(B, &onm1, &snm1, &on, &sn);
    int32_t nm1to, nm1ntt, nm1lto, nm1po, nm1lpo;
    int32_t nto, nntt, nlto, npo, nlpo;
    ose_getNthPayloadItem(B, 1, onm1,
                          &nm1to, &nm1ntt, &nm1lto, &nm1po, &nm1lpo);
    ose_getNthPayloadItem(B, 1, on,
                          &nto, &nntt, &nlto, &npo, &nlpo);
    char t2 = ose_readByte(B, nm1lto);(void)t2;
    ose_assert(ose_isNumericType(t2));
    char t1 = ose_readByte(B, nlto);
    ose_assert(ose_isNumericType(t1));
    ose_assert(t1 == t2);
    char *b = ose_getBundlePtr(B);
    switch(t1)
    {
    case OSETT_INT32:
    {
        int32_t v2 = ose_readInt32(B, nm1lpo);
        int32_t v1 = ose_readInt32(B, nlpo);
        memset(b + onm1, 0, snm1 + sn + 8);
        ose_decSize(B, snm1 + sn + 8);
        ose_pushInt32(B, v1 % v2);
    }
    break;
    case OSETT_FLOAT:
    {
        float v2 = ose_readFloat(B, nm1lpo);
        float v1 = ose_readFloat(B, nlpo);
        memset(b + onm1, 0, snm1 + sn + 8);
        ose_decSize(B, snm1 + sn + 8);
        ose_pushFloat(B, fmodf(v1, v2));
    }
    break;
#ifdef OSE_PROVIDE_TYPE_DOUBLE
    case OSETT_DOUBLE:
    {
        double v2 = ose_readDouble(B, nm1lpo);
        double v1 = ose_readDouble(B, nlpo);
        memset(b + onm1, 0, snm1 + sn + 8);
        ose_decSize(B, snm1 + sn + 8);
        ose_pushDouble(B, fmod(v1, v2));
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
    case OSETT_INT8:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
    case OSETT_UINT8:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
    case OSETT_UINT32:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
    case OSETT_INT64:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
    case OSETT_UINT64:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
    case OSETT_TIMETAG:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
    }
}

/**
 * @todo Implement extended types.
 * 
 * @f$\fnbinop{POW}{^}@f$
 */
void ose_pow(ose_bundle B)
{
    char t1 = ose_peekMessageArgType(B);
    ose_assert(ose_isNumericType(t1));
    ose_swap(B);
    char t2 = ose_peekMessageArgType(B);(void)t2;
    ose_assert(ose_isNumericType(t2));
    ose_assert(t1 == t2);
    switch(t1)
    {
    case OSETT_INT32:
    {
        int32_t v2 = ose_popInt32(B);
        int32_t v1 = ose_popInt32(B);
        ose_pushInt32(B, (int32_t)pow(v1, v2));
    }
    break;
    case OSETT_FLOAT:
    {
        float v2 = ose_popFloat(B);
        float v1 = ose_popFloat(B);
        ose_pushFloat(B, powf(v1, v2));
    }
    break;
#ifdef OSE_PROVIDE_TYPE_DOUBLE
    case OSETT_DOUBLE:
    {
        double v2 = ose_popDouble(B);
        double v1 = ose_popDouble(B);
        ose_pushDouble(B, pow(v1, v2));
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
    case OSETT_INT8:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
    case OSETT_UINT8:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
    case OSETT_UINT32:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
    case OSETT_INT64:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
    case OSETT_UINT64:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
    case OSETT_TIMETAG:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
    }
}

/**
 * @todo Implement extended types.
 * 
 * @f$
 * 	\fn{NEG}{
 *		\BB\elems{
 *			\ldots,
 *			\ela{K}{\type{\ttmsg(\type{\ttvar})}}\items{
 *				\ita{}{\type{\ttvar}}\values{\valv{}{}}
 *			}
 *		}
 * 	}{
 *		\BBtick\elems{
 *			\ldots,
 *			\elb{K}{\type{\ttmsg(\type{\ttvar})}}\items{
 *				\itb{}{\type{\ttvar}}\values{-\valv{}{}}
 *			}
 *		}
 * 	}, \ttvar=\type{\tti\ttf}
 * @f$
 */
void ose_neg(ose_bundle B)
{
    char t1 = ose_peekMessageArgType(B);
    ose_assert(ose_isNumericType(t1));
    switch(t1)
    {
    case OSETT_INT32:
    {
        int32_t v1 = ose_popInt32(B);
        ose_pushInt32(B, -v1);
    }
    break;
    case OSETT_FLOAT:
    {
        float v1 = ose_popFloat(B);
        ose_pushFloat(B, -v1);
    }
    break;
#ifdef OSE_PROVIDE_TYPE_DOUBLE
    case OSETT_DOUBLE:
    {
        double v1 = ose_popDouble(B);
        ose_pushDouble(B, -v1);
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
    case OSETT_INT8:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
    case OSETT_UINT8:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
    case OSETT_UINT32:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
    case OSETT_INT64:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
    case OSETT_UINT64:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
    }
}

/**
 * @f$\fnbinop{EQL}{=}@f$
 */
void ose_eql(ose_bundle B)
{
    int32_t onm1, on, snm1, sn;
    be2(B, &onm1, &snm1, &on, &sn);
    int32_t tonm1 = onm1 + 4 + ose_getPaddedStringLen(B, onm1 + 4);
    int32_t ton = on + 4 + ose_getPaddedStringLen(B, on + 4);
    char *b = ose_getBundlePtr(B);
    int32_t lnm1 = snm1 - (tonm1 - (onm1 + 4));
    int32_t ln = sn - (ton - (on + 4));
    if(lnm1 != ln)
    {
        ose_2drop(B);
        ose_pushInt32(B, 0);
        return;
    }
    if(!memcmp(b + tonm1, b + ton, ln))
    {
        ose_pushInt32(B, 1);
    }
    else
    {
        ose_pushInt32(B, 0);
    }
    ose_swap(B);
    ose_drop(B);
    ose_swap(B);
    ose_drop(B);
}

/**
 * @f$\fnbinop{NEQ}{\neq}@f$
 */
void ose_neq(ose_bundle B)
{
    int32_t onm1, on, snm1, sn;
    be2(B, &onm1, &snm1, &on, &sn);
    int32_t tonm1 = onm1 + 4 + ose_getPaddedStringLen(B, onm1 + 4);
    int32_t ton = on + 4 + ose_getPaddedStringLen(B, on + 4);
    char *b = ose_getBundlePtr(B);
    int32_t lnm1 = snm1 - (tonm1 - (onm1 + 4));
    int32_t ln = sn - (ton - (on + 4));
    if(lnm1 != ln)
    {
        ose_2drop(B);
        ose_pushInt32(B, 0);
        return;
    }
    if(!memcmp(b + tonm1, b + ton, ln))
    {
        ose_pushInt32(B, 0);
    }
    else
    {
        ose_pushInt32(B, 1);
    }
    ose_swap(B);
    ose_drop(B);
    ose_swap(B);
    ose_drop(B);
}

/**
 * @todo Implement extended types.
 * 
 * @f$\fnbinop{LTE}{\le}@f$
 */
void ose_lte(ose_bundle B)
{
    int32_t onm1, snm1, on, sn;
    be2(B, &onm1, &snm1, &on, &sn);
    int32_t nm1to, nm1ntt, nm1lto, nm1po, nm1lpo;
    int32_t nto, nntt, nlto, npo, nlpo;
    ose_getNthPayloadItem(B, 1, onm1,
                          &nm1to, &nm1ntt, &nm1lto, &nm1po, &nm1lpo);
    ose_getNthPayloadItem(B, 1, on,
                          &nto, &nntt, &nlto, &npo, &nlpo);
    char t2 = ose_readByte(B, nm1lto); (void)t2;
    ose_assert(ose_isNumericType(t2));
    char t1 = ose_readByte(B, nlto);
    ose_assert(ose_isNumericType(t1));
    ose_assert(t1 == t2);
    char *b = ose_getBundlePtr(B);
    switch(t1)
    {
    case OSETT_INT32:
    {
        int32_t v2 = ose_readInt32(B, nm1lpo);
        int32_t v1 = ose_readInt32(B, nlpo);
        memset(b + onm1, 0, snm1 + sn + 8);
        ose_decSize(B, snm1 + sn + 8);
        ose_pushInt32(B, v1 <= v2);
    }
    break;
    case OSETT_FLOAT:
    {
        float v2 = ose_readFloat(B, nm1lpo);
        float v1 = ose_readFloat(B, nlpo);
        memset(b + onm1, 0, snm1 + sn + 8);
        ose_decSize(B, snm1 + sn + 8);
        ose_pushInt32(B, v1 <= v2);
    }
    break;
#ifdef OSE_PROVIDE_TYPE_DOUBLE
    case OSETT_DOUBLE:
    {
        double v2 = ose_readDouble(B, nm1lpo);
        double v1 = ose_readDouble(B, nlpo);
        memset(b + onm1, 0, snm1 + sn + 8);
        ose_decSize(B, snm1 + sn + 8);
        ose_pushInt32(B, v1 <= v2);
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
    case OSETT_INT8:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
    case OSETT_UINT8:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
    case OSETT_UINT32:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
    case OSETT_INT64:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
    case OSETT_UINT64:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
    case OSETT_TIMETAG:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
    }
}

/**
 * @todo Implement extended types.
 * 
 * @f$\fnbinop{LT}{<}@f$
 */
void ose_lt(ose_bundle B)
{
    int32_t onm1, snm1, on, sn;
    be2(B, &onm1, &snm1, &on, &sn);
    int32_t nm1to, nm1ntt, nm1lto, nm1po, nm1lpo;
    int32_t nto, nntt, nlto, npo, nlpo;
    ose_getNthPayloadItem(B, 1, onm1,
                          &nm1to, &nm1ntt, &nm1lto, &nm1po, &nm1lpo);
    ose_getNthPayloadItem(B, 1, on,
                          &nto, &nntt, &nlto, &npo, &nlpo);
    char t2 = ose_readByte(B, nm1lto); (void)t2;
    ose_assert(ose_isNumericType(t2));
    char t1 = ose_readByte(B, nlto);
    ose_assert(ose_isNumericType(t1));
    ose_assert(t1 == t2);
    char *b = ose_getBundlePtr(B);
    switch(t1)
    {
    case OSETT_INT32:
    {
        int32_t v2 = ose_readInt32(B, nm1lpo);
        int32_t v1 = ose_readInt32(B, nlpo);
        memset(b + onm1, 0, snm1 + sn + 8);
        ose_decSize(B, snm1 + sn + 8);
        ose_pushInt32(B, v1 < v2);
    }
    break;
    case OSETT_FLOAT:
    {
        float v2 = ose_readFloat(B, nm1lpo);
        float v1 = ose_readFloat(B, nlpo);
        memset(b + onm1, 0, snm1 + sn + 8);
        ose_decSize(B, snm1 + sn + 8);
        ose_pushInt32(B, v1 < v2);
    }
    break;
#ifdef OSE_PROVIDE_TYPE_DOUBLE
    case OSETT_DOUBLE:
    {
        double v2 = ose_readDouble(B, nm1lpo);
        double v1 = ose_readDouble(B, nlpo);
        memset(b + onm1, 0, snm1 + sn + 8);
        ose_decSize(B, snm1 + sn + 8);
        ose_pushInt32(B, v1 < v2);
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
    case OSETT_INT8:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
    case OSETT_UINT8:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
    case OSETT_UINT32:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
    case OSETT_INT64:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
    case OSETT_UINT64:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
    case OSETT_TIMETAG:
    {
#warning NOT IMPLEMENTED
    }
    break;
#endif
    }
}

/**
 * @f$\fnbinop{AND}{\land}@f$
 */
void ose_and(ose_bundle B)
{
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    int32_t i1 = ose_popInt32(B);
    int32_t i2 = ose_popInt32(B);
    ose_pushInt32(B, i1 && i2);
}

/**
 * @f$\fnbinop{OR}{\lor}@f$
 */
void ose_or(ose_bundle B)
{
    ose_assert(ose_bundleHasAtLeastNElems(B, 2));
    int32_t i1 = ose_popInt32(B);
    int32_t i2 = ose_popInt32(B);
    ose_pushInt32(B, i1 || i2);
}

/**************************************************
 * helper functions
 **************************************************/
void be1(ose_bundle B, int32_t *on, int32_t *sn)
{
    int32_t s = ose_readSize(B);
    ose_assert(s > OSE_BUNDLE_HEADER_LEN);
    int32_t o1 = OSE_BUNDLE_HEADER_LEN;
    int32_t s1 = ose_readInt32(B, o1);
    while(o1 + s1 + 4 < s)
    {
        o1 += s1 + 4;
        s1 = ose_readInt32(B, o1);
    }
    *on = o1;
    *sn = s1;
}

void be2(ose_bundle B,
         int32_t *onm1,
         int32_t *snm1,
         int32_t *on,
         int32_t *sn)
{
    int32_t s = ose_readSize(B);
    ose_assert(s > OSE_BUNDLE_HEADER_LEN);
    int32_t o1 = OSE_BUNDLE_HEADER_LEN;
    int32_t s1 = ose_readInt32(B, o1);
    ose_assert(s > o1 + 4 + s1);
    int32_t o2 = o1 + 4 + s1;
    int32_t s2 = ose_readInt32(B, o2);
    while(o2 + s2 + 4 < s)
    {
        o1 = o2;
        s1 = s2;
        o2 += s2 + 4;
        s2 = ose_readInt32(B, o2);
    }
    *onm1 = o1;
    *snm1 = s1;
    *on = o2;
    *sn = s2;
}

void be3(ose_bundle B,
         int32_t *onm2,
         int32_t *snm2,
         int32_t *onm1,
         int32_t *snm1,
         int32_t *on,
         int32_t *sn)
{
    int32_t s = ose_readSize(B);
    ose_assert(s > OSE_BUNDLE_HEADER_LEN);
    int32_t o1 = OSE_BUNDLE_HEADER_LEN;
    int32_t s1 = ose_readInt32(B, o1);
    ose_assert(s > o1 + 4 + s1);
    int32_t o2 = o1 + s1 + 4;
    int32_t s2 = ose_readInt32(B, o2);
    ose_assert(s > o2 + 4 + s2);
    int32_t o3 = o2 + s2 + 4;
    int32_t s3 = ose_readInt32(B, o3);
    while(o3 + s3 + 4 < s)
    {
        o1 = o2;
        s1 = ose_readInt32(B, o1);
        o2 = o3;
        s2 = ose_readInt32(B, o2);
        o3 += s3 + 4;
        s3 = ose_readInt32(B, o3);
    }
    *onm2 = o1;
    *snm2 = s1;
    *onm1 = o2;
    *snm1 = s2;
    *on = o3;
    *sn = s3;
}

void be4(ose_bundle B,
         int32_t *onm3,
         int32_t *snm3,
         int32_t *onm2,
         int32_t *snm2,
         int32_t *onm1,
         int32_t *snm1,
         int32_t *on,
         int32_t *sn)
{
    int32_t s = ose_readSize(B);
    ose_assert(s > OSE_BUNDLE_HEADER_LEN);
    int32_t o1 = OSE_BUNDLE_HEADER_LEN;
    int32_t s1 = ose_readInt32(B, o1);
    ose_assert(s > o1 + 4 + s1);
    int32_t o2 = o1 + s1 + 4;
    int32_t s2 = ose_readInt32(B, o2);
    ose_assert(s > o2 + 4 + s2);
    int32_t o3 = o2 + s2 + 4;
    int32_t s3 = ose_readInt32(B, o3);
    ose_assert(s > o3 + 4 + s3);
    int32_t o4 = o3 + s3 + 4;
    int32_t s4 = ose_readInt32(B, o4);
    while(o4 + s4 + 4 < s)
    {
        o1 = o2;
        s1 = ose_readInt32(B, o1);
        o2 = o3;
        s2 = ose_readInt32(B, o2);
        o3 += s3 + 4;
        s3 = ose_readInt32(B, o3);
        o4 += s4 + 4;
        s4 = ose_readInt32(B, o4);
    }
    *onm3 = o1;
    *snm3 = s1;
    *onm2 = o2;
    *snm2 = s2;
    *onm1 = o3;
    *snm1 = s3;
    *on = o4;
    *sn = s4;
}
