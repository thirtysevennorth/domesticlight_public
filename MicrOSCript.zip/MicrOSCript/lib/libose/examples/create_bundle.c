#include <string.h>

#include "ose.h"
#include "ose_context.h"
#include "ose_stackops.h"

#define NUM_BYTES 65536

int main(int ac, char **av)
{
    char bytes[NUM_BYTES];
    ose_bundle bundle = ose_newBundleFromCBytes(NUM_BYTES, bytes);
    ose_pushMessage(bundle,     /* the bundle to add the message to */
                    "/hello",   /* the address of the message */
                    strlen("/hello"), /* the length of the address */
                    1,                /* the number of arguments */
                    OSETT_STRING,     /* the type of the first arg */
                    "world!");        /* the first arg */
    ose_pushMessage(bundle,           /* the bundle to add the message to */
                    "/list",          /* the address of the message */
                    strlen("/list"),  /* the length of the address */
                    3,                /* the number of arguments */
                    OSETT_INT32,      /* the type of the first arg */
                    1,                /* the first arg */
                    OSETT_INT32,      /* the type of the second arg */
                    2,                /* the second arg */
                    OSETT_INT32,      /* the type of the third arg */
                    3);               /* the third arg */
    return 0;
}
