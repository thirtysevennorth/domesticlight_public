#include <stdio.h>
#include <string.h>

#include "ose.h"
#include "ose_context.h"
#include "ose_stackops.h"
#include "ose_vm.h"

/* The size of the bundle / VM to create. */
#define NUM_BYTES 65536

/*
 * The function we want to create an OSC message for. 
 */
static void hello_world(ose_bundle vm)
{
    printf("Hello, World!\n");
}

int main(int ac, char **av)
{
    /* Allocate memory for the VM. */
    char bytes[NUM_BYTES];
    
    /* First, we turn the bytes into a bundle. */
    ose_bundle bundle = ose_newBundleFromCBytes(NUM_BYTES, bytes);

    /* Now initialize the bundle as a VM. */
    ose_bundle vm = osevm_init(bundle,
                                  1024, 1024, 1024, 1024, 1024);

    /* Get references to the input and environment bundles. */
    ose_bundle vm_input = OSEVM_INPUT(vm);
    ose_bundle vm_env = OSEVM_ENV(vm);

    /*
     * This function creates a message in the environment bundle
     * with the address `/greet` and a single item, a pointer to the
     * function that we want to be executed when the message
     * `/!/greet` is processed by the VM.
     */
    ose_pushMessage(vm_env, "/greet", strlen("/greet"), 1,
                    OSETT_ALIGNEDPTR, hello_world);

	/*
     * Now "send" a message to the VM. We put a single message into
     * the input bundle with the address `/!/greet` and no
     * arguments.
     */
    ose_pushMessage(vm_input, "/!/greet", strlen("/!/greet"), 0);

    /* Run the VM. */
    osevm_run(vm);

    return 0;
}
