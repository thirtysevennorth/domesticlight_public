#include <stdio.h>
#include <string.h>

#include "ose.h"
#include "ose_context.h"
#include "ose_stackops.h"
#include "ose_vm.h"

/*
 */

/* The size of the bundle / VM to create. */
#define NUM_BYTES 65536

/*
 * This function will be bound to the address /printstack in the
 * VM's environment and, when executed, will print the value of an
 * int found in a message.
 */
static void printstack(ose_bundle vm)
{
    /* Get a reference to the VM's stack. */
    ose_bundle vm_stack = OSEVM_STACK(vm);
    while(!ose_bundleIsEmpty(vm_stack))
    {
        /* Check the type of the element on top of the stack. */
        if(ose_peekType(vm_stack) == OSETT_MESSAGE)
        {
            /* If this it is a message, check the type of its data. */
            if(ose_peekMessageArgType(vm_stack) == OSETT_INT32)
            {
                /* If it has an int, get the value and print it. */
                /* ose_popInt32 will also drop the message. */
                int32_t i = ose_popInt32(vm_stack);
                printf("found an int: %d\n", i);
            }
            else
            {
                /* If it's not an int, drop it. */
                ose_drop(vm_stack);
            }
        }
        else
        {
            /* If it's not a message, drop it. */
            ose_drop(vm_stack);
        }
    }
}

int main(int ac, char **av)
{
    /* Allocate memory for the VM. */
    char bytes[NUM_BYTES];
    
    /* First, we turn the bytes into a bundle. */
    ose_bundle bundle = ose_newBundleFromCBytes(NUM_BYTES, bytes);

    /* Now initialize the bundle as a VM. */
    ose_bundle vm = osevm_init(bundle,
                                  1024, 1024, 1024, 1024, 1024);

    /* Get references to the input and environment bundles. */
    ose_bundle vm_input = OSEVM_INPUT(vm);
    ose_bundle vm_env = OSEVM_ENV(vm);

    /*
     * This function creates a message in the environment bundle
     * with the address `/printstack` and a single item, a pointer
     * to our printstack function that will be executed when the
     * message `/!/printstack` is processed by the VM.
     */
    ose_pushMessage(vm_env, "/printstack", strlen("/printstack"), 1,
                    OSETT_ALIGNEDPTR, printstack);

	/*
     * Now we send three messages to the VM. Here we run the VM for
     * each message we want to send, but we could also input all
     * three messages at once and run the VM a single time. Note
     * that if we do that, we have to reverse the order of the
     * messages, since the VM processes them starting at the end!
     */

    /*
     * Put a message with address /@/x and a single int with value
     * 123 into the input. The /@ prefix in front of an address
     * means "assign everything on the stack to that address
     * (/x)."
     */
    ose_pushMessage(vm_input, "/@/x", strlen("/@/x"), 1,
                    OSETT_INT32, 123);
    
    /*
     * Run the VM. Upon completion, the stack will be empty, and the
     * environment will have a message with address /x and value
     * 123.
     */
    osevm_run(vm);

    /*
     * Now add a message with address /$/x and no data to the
     * input. The /$ prefix in front of an address means "lookup the
     * value of an address (/x)." If found, the entire message that
     * corresponds to that address will be copied to the stack, and
     * if not, the string "/x" will be left on the stack in a
     * message with no address.
     */
    ose_pushMessage(vm_input, "/$/x", strlen("/$/x"), 0);
    
    /*
     * Run the VM. The message with address /x and value 123 will be
     * found and left on the stack.
     */
    osevm_run(vm);

    /*
     * Finally, add a message with address /!/printstack to the
     * input and run the VM. The /! prefix in front of an address
     * means "lookup an address (/printstack) and if found and it
     * contains a function, execute that function. Similar to the /$
     * prefix, if it is not found, the name of the missing address
     * will be left on the stack as a string.
     */
    ose_pushMessage(vm_input,
                    "/!/printstack",
                    strlen("/!/printstack"),
                    0);
    /*
     * Run the VM. Our printstack function will be executed, and
     * will print the contents of the stack.
     */
    osevm_run(vm);

    return 0;
}
