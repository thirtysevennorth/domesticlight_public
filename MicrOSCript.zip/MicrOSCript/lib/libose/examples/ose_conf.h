/*
 * Define the sizes of the different VM bundles. Note that all must
 * be defined, or none.
 *
 * If these are defined, #osevm_init will take a single bundle as an
 * argument, and if not, it will take a bundle and 5 values for
 * specifying these sizes at runtime.
 */
#define OSE_CONF_VM_INPUT_SIZE 8192
#define OSE_CONF_VM_STACK_SIZE 8192
#define OSE_CONF_VM_ENV_SIZE 8192
#define OSE_CONF_VM_CONTROL_SIZE 8192
#define OSE_CONF_VM_DUMP_SIZE 8192

/*
 * Define custom hooks for different aspects of the VM. See the
 * documentation page about the VM hooks for more detailed
 * information about when and how each of these is invoked, and how
 * to implement them.
 */
#define OSEVM_ASSIGN my_assign
#define OSEVM_LOOKUP my_lookup
#define OSEVM_FUNCALL my_funcall
#define OSEVM_QUOTE my_quote
#define OSEVM_COPYREGISTERTOELEM my_copyRegisterToElem
#define OSEVM_APPENDELEMTOREGISTER my_appendRegisterToElem
#define OSEVM_REPLACEREGISTERWITHELEM my_replaceRegisterWithElem
#define OSEVM_MOVEELEMTOREGISTER my_moveElemToRegister
#define OSEVM_EXEC my_exec
#define OSEVM_EXECINCURRENTCONTEXT my_execInCurrentContext
#define OSEVM_APPLY my_apply
#define OSEVM_RETURN my_return
#define OSEVM_TOINT32 my_toInt32
#define OSEVM_TOFLOAT my_toFloat
#define OSEVM_TOSTRING my_toString
#define OSEVM_TOBLOB my_toBlob
#define OSEVM_APPENDBYTE my_appendByte
#define OSEVM_RESPONDTOSTRING my_respondToString
#define OSEVM_PREINPUT my_preInput
#define OSEVM_POSTINPUT my_postInput
#define OSEVM_POPINPUTTOCONTROL my_popInputToControl
#define OSEVM_POSTCONTROL my_postControl

/*
 * Support for extended OSC types. 
 */
#define OSE_CONF_PROVIDE_TYPE_SYMBOL
#define OSE_CONF_PROVIDE_TYPE_DOUBLE
#define OSE_CONF_PROVIDE_TYPE_INT8
#define OSE_CONF_PROVIDE_TYPE_UINT8
#define OSE_CONF_PROVIDE_TYPE_UINT32
#define OSE_CONF_PROVIDE_TYPE_INT64
#define OSE_CONF_PROVIDE_TYPE_UINT64
#define OSE_CONF_PROVIDE_TYPE_TYPETAG
#define OSE_CONF_PROVIDE_TYPE_TRUE
#define OSE_CONF_PROVIDE_TYPE_FALSE
#define OSE_CONF_PROVIDE_TYPE_NULL
#define OSE_CONF_PROVIDE_TYPE_INFINITUM

/*
 * Enable debug mode. Debug mode is significantly slower.
 */
#define OSE_CONF_DEBUG
