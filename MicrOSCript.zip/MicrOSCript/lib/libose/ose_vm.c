/*
  Copyright (c) 2019-23 John MacCallum Permission is hereby granted,
  free of charge, to any person obtaining a copy of this software
  and associated documentation files (the "Software"), to deal in
  the Software without restriction, including without limitation the
  rights to use, copy, modify, merge, publish, distribute,
  sublicense, and/or sell copies of the Software, and to permit
  persons to whom the Software is furnished to do so, subject to the
  following conditions:

  The above copyright notice and this permission notice shall be
  included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
  DEALINGS IN THE SOFTWARE.
*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>

#include "ose.h"
#include "ose_context.h"
#include "ose_util.h"
#include "ose_stackops.h"
#include "ose_assert.h"
#include "ose_vm.h"
#include "osevm_lib.h"
#include "ose_errno.h"

#if defined(OSE_ENDIAN)

#if OSE_ENDIAN == OSE_LITTLE_ENDIAN

#define OSEVM_INTCMP_MASK_1     0x000000ff
#define OSEVM_INTCMP_MASK_2     0x0000ffff
#define OSEVM_INTCMP_MASK_3     0x00ffffff

#define OSEVM_TOK_AT            0x002f402f
#define OSEVM_TOK_QUOTE         0x002f272f
#define OSEVM_TOK_BANG          0x002f212f
#define OSEVM_TOK_DOLLAR        0x002f242f
#define OSEVM_TOK_GT            0x002f3e2f
#define OSEVM_TOK_LTLT          0x2f3c3c2f
#define OSEVM_TOK_LT            0x002f3c2f
#define OSEVM_TOK_DASH          0x002f2d2f
#define OSEVM_TOK_DOT           0x002f2e2f
#define OSEVM_TOK_COLON         0x002f3a2f
#define OSEVM_TOK_SCOLON        0x002f3b2f
#define OSEVM_TOK_PIPE          0x002f7c2f
#define OSEVM_TOK_OPAR          0x002f282f
#define OSEVM_TOK_CPAR          0x002f292f
#define OSEVM_TOK_COMMA	        0x002f2c2f
#define OSEVM_TOK_COMMA_i       0x692f2c2f
#define OSEVM_TOK_COMMA_f       0x662f2c2f
#define OSEVM_TOK_COMMA_s       0x732f2c2f
#define OSEVM_TOK_COMMA_b       0x622f2c2f
#ifdef OSE_PROVIDE_TYPE_SYMBOL
#define OSEVM_TOK_COMMA_S				0x532f2c2f
#endif
#ifdef OSE_PROVIDE_TYPE_DOUBLE  
#define OSEVM_TOK_COMMA_d				0x642f2c2f
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
#define OSEVM_TOK_COMMA_c				0x632f2c2f
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
#define OSEVM_TOK_COMMA_C				0x432f2c2f
#endif
#ifdef OSE_PROVIDE_TYPE_INT16
#define OSEVM_TOK_COMMA_u				0x752f2c2f
#endif
#ifdef OSE_PROVIDE_TYPE_UINT16  
#define OSEVM_TOK_COMMA_U				0x552f2c2f
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32  
#define OSEVM_TOK_COMMA_k				0x002f6b2f
#endif
#ifdef OSE_PROVIDE_TYPE_INT64  
#define OSEVM_TOK_COMMA_h				0x682f2c2f
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
#define OSEVM_TOK_COMMA_H				0x482f2c2f
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
#define OSEVM_TOK_COMMA_t				0x742f2c2f
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
#define OSEVM_TOK_COMMA_T				0x542f2c2f
#endif
#ifdef OSE_PROVIDE_TYPE_FALSE
#define OSEVM_TOK_COMMA_F				0x462f2c2f
#endif
#ifdef OSE_PROVIDE_TYPE_NULL
#define OSEVM_TOK_COMMA_N				0x002f4e2f
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
#define OSEVM_TOK_COMMA_I				0x492f2c2f
#endif
#define OSEVM_TOK_AMP           0x002f262f
#define OSEVM_TOK_HASH          0x002f232f

#define route_init(address, varname)            \
    struct { int32_t i2, i3, i4; } varname;     \
    do                                          \
    {                                           \
        varname.i4 = *((int32_t *)(address));   \
        varname.i3 = varname.i4 & 0x00ffffff;   \
        varname.i2 = varname.i3 & 0x0000ffff;   \
    } while(0);

#elif OSE_ENDIAN == OSE_BIG_ENDIAN

#define OSEVM_INTCMP_MASK_1     0xff000000
#define OSEVM_INTCMP_MASK_2     0xffff0000
#define OSEVM_INTCMP_MASK_3     0xffffff00

#define OSEVM_TOK_AT            0x2f402f00
#define OSEVM_TOK_QUOTE         0x2f272f00
#define OSEVM_TOK_BANG          0x2f212f00
#define OSEVM_TOK_DOLLAR        0x2f242f00
#define OSEVM_TOK_GT            0x2f3e2f00
#define OSEVM_TOK_LTLT          0x2f3c3c2f
#define OSEVM_TOK_LT            0x2f3c2f00
#define OSEVM_TOK_DASH          0x2f2d2f00
#define OSEVM_TOK_DOT           0x2f2e2f00
#define OSEVM_TOK_COLON         0x2f3a2f00
#define OSEVM_TOK_SCOLON        0x2f3b2f00
#define OSEVM_TOK_PIPE          0x2f7c2f00
#define OSEVM_TOK_OPAR          0x2f282f00
#define OSEVM_TOK_CPAR          0x2f292f00
#define OSEVM_TOK_COMMA 		0x2f2c2f00
#define OSEVM_TOK_COMMA_i 		0x2f2c2f69
#define OSEVM_TOK_COMMA_f 		0x2f2c2f66
#define OSEVM_TOK_COMMA_s 		0x2f2c2f73
#define OSEVM_TOK_COMMA_b 		0x2f2c2f62
#ifdef OSE_PROVIDE_TYPE_SYMBOL
#define OSEVM_TOK_COMMA_S				0x2f2c2f53
#endif
#ifdef OSE_PROVIDE_TYPE_DOUBLE
#define OSEVM_TOK_COMMA_d				0x2f2c2f64
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
#define OSEVM_TOK_COMMA_c				0x2f2c2f63
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
#define OSEVM_TOK_COMMA_C				0x2f2c2f43
#endif
#ifdef OSE_PROVIDE_TYPE_INT16
#define OSEVM_TOK_COMMA_u				0x2f2c2f75
#endif
#ifdef OSE_PROVIDE_TYPE_UINT16
#define OSEVM_TOK_COMMA_U				0x2f2c2f55
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
#define OSEVM_TOK_COMMA_k				0x2f6b2f00
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
#define OSEVM_TOK_COMMA_h				0x2f2c2f68
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
#define OSEVM_TOK_COMMA_H				0x2f2c2f48
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
#define OSEVM_TOK_COMMA_t				0x2f2c2f74
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
#define OSEVM_TOK_COMMA_T				0x2f2c2f54
#endif
#ifdef OSE_PROVIDE_TYPE_FALSE
#define OSEVM_TOK_COMMA_F				0x2f2c2f46
#endif
#ifdef OSE_PROVIDE_TYPE_NULL
#define OSEVM_TOK_COMMA_N				0x2f4e2f00
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
#define OSEVM_TOK_COMMA_I				0x2f2c2f49
#endif
#define OSEVM_TOK_AMP           0x2f262f00
#define OSEVM_TOK_HASH          0x2f232f00

#define route_init(address, varname)            \
    struct { int32_t i2, i3, i4; } varname;     \
    do                                          \
    {                                           \
        varname.i4 = *((int32_t *)(address));   \
        varname.i3 = varname.i4 & 0xffffff00;   \
        varname.i2 = varname.i3 & 0xffff0000;   \
    } while(0);
#endif

#define route_pfx_2(var, sym)                   \
    ((sym) == (var.i4))
#define route_pfx_1(var, sym)                   \
    ((sym & OSEVM_INTCMP_MASK_3) == (var.i3))
#define route_pfx(var, sym, n)                  \
    (route_pfx_##n((var), (sym)))

#define route_mthd_3(var, sym)                  \
    ((sym) == (var.i4))
#define route_mthd_2(var, sym)                  \
    ((sym & OSEVM_INTCMP_MASK_3) == (var.i4))
#define route_mthd_1(var, sym)                  \
    ((sym & OSEVM_INTCMP_MASK_2) == (var.i4))
#define route_mthd(var, sym, n)                 \
    (route_mthd_##n((var), (sym)))

#else

#define route_init(address, varname)            \
    const char * const varname = address

#define route_pfx(var, sym, n)                  \
    (strncmp(var, sym, n + 2) == 0)
#define route_mthd(var, sym, n)                 \
    (strncmp(var, sym, n + 1) == 0)

#define OSEVM_TOK_AT        "/@/\0"
#define OSEVM_TOK_QUOTE     "/'/\0"
#define OSEVM_TOK_BANG      "/!/\0"
#define OSEVM_TOK_DOLLAR    "/$/\0"
#define OSEVM_TOK_GT        "/>/\0"
#define OSEVM_TOK_LTLT      "/<</"
#define OSEVM_TOK_LT        "/</\0"
#define OSEVM_TOK_DASH      "/-/\0"
#define OSEVM_TOK_DOT       "/./\0"
#define OSEVM_TOK_COLON     "/:/\0"
#define OSEVM_TOK_SCOLON    "/;/\0"
#define OSEVM_TOK_PIPE      "/|/\0"
#define OSEVM_TOK_OPAR      "/(/\0"
#define OSEVM_TOK_CPAR      "/)/\0"
#define OSEVM_TOK_COMMA		"/,/\0"
#define OSEVM_TOK_COMMA_i	"/,/i"
#define OSEVM_TOK_COMMA_f	"/,/f"
#define OSEVM_TOK_COMMA_s	"/,/s"
#define OSEVM_TOK_COMMA_b	"/,/b"
#ifdef OSE_PROVIDE_TYPE_SYMBOL
#define OSEVM_TOK_COMMA_S			"/,/S"
#endif
#ifdef OSE_PROVIDE_TYPE_DOUBLE
#define OSEVM_TOK_COMMA_d			"/,/d"
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
#define OSEVM_TOK_COMMA_c			"/,/c"
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
#define OSEVM_TOK_COMMA_C			"/,/C"
#endif
#ifdef OSE_PROVIDE_TYPE_INT16
#define OSEVM_TOK_COMMA_u			"/,/u"
#endif
#ifdef OSE_PROVIDE_TYPE_UINT16
#define OSEVM_TOK_COMMA_U			"/,/U"
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
#define OSEVM_TOK_COMMA_k			"/,/k"
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
#define OSEVM_TOK_COMMA_h			"/,/h"
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
#define OSEVM_TOK_COMMA_H			"/,/H"
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
#define OSEVM_TOK_COMMA_t			"/,/t"
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
#define OSEVM_TOK_COMMA_T			"/,/T"
#endif
#ifdef OSE_PROVIDE_TYPE_FALSE
#define OSEVM_TOK_COMMA_F			"/,/F"
#endif
#ifdef OSE_PROVIDE_TYPE_NULL
#define OSEVM_TOK_COMMA_N			"/,/N"
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
#define OSEVM_TOK_COMMA_I			"/,/I"
#endif
#define OSEVM_TOK_AMP       "/&/\0"
#define OSEVM_TOK_HASH      "/#/\0"

#endif

#define route(var, sym, n)                              \
    (route_mthd(var, sym, n) || route_pfx(var, sym, n))

void osevm_popInputToControl(ose_bundle osevm)
{
    ose_bundle vm_i = OSEVM_INPUT(osevm);
    ose_bundle vm_c = OSEVM_CONTROL(osevm);
    ose_moveElem(vm_i, vm_c);
}

void osevm_respondToString(ose_bundle osevm)
{
}

#ifdef OSEVM_HAVE_SIZES
ose_bundle osevm_init(ose_bundle bundle)
#else
ose_bundle osevm_init(ose_bundle bundle,
                      int32_t input_size,
                      int32_t stack_size,
                      int32_t env_size,
                      int32_t control_size,
                      int32_t dump_size)
#endif
{
#ifdef OSEVM_HAVE_SIZES
    const int32_t input_size = OSEVM_INPUT_SIZE
        + OSE_CONTEXT_MESSAGE_OVERHEAD;
    const int32_t stack_size = OSEVM_STACK_SIZE
        + OSE_CONTEXT_MESSAGE_OVERHEAD;
    const int32_t env_size = OSEVM_ENV_SIZE
        + OSE_CONTEXT_MESSAGE_OVERHEAD;
    const int32_t control_size = OSEVM_CONTROL_SIZE
        + OSE_CONTEXT_MESSAGE_OVERHEAD;
    const int32_t dump_size = OSEVM_DUMP_SIZE
        + OSE_CONTEXT_MESSAGE_OVERHEAD;
#endif
    /* cache */
    ose_pushContextMessage(bundle,
                           OSEVM_CACHE_MSG_SIZE,
                           OSEVM_ADDR_CACHE);

    /* input from the world */
    ose_pushContextMessage(bundle,
                           input_size,
                           OSEVM_ADDR_INPUT);
    /* stack */
    ose_pushContextMessage(bundle,
                           stack_size,
                           OSEVM_ADDR_STACK);
    /* environment */
    ose_pushContextMessage(bundle,
                           env_size,
                           OSEVM_ADDR_ENV);
    /* control */
    ose_pushContextMessage(bundle,
                           control_size,
                           OSEVM_ADDR_CONTROL);
    /* dump */
    ose_pushContextMessage(bundle,
                           dump_size,
                           OSEVM_ADDR_DUMP);

    ose_bundle vm_cache = ose_enter(bundle, OSEVM_ADDR_CACHE);
    ose_bundle vm_i = ose_enter(bundle, OSEVM_ADDR_INPUT);
    ose_bundle vm_s = ose_enter(bundle, OSEVM_ADDR_STACK);
    ose_bundle vm_e = ose_enter(bundle, OSEVM_ADDR_ENV);
    ose_bundle vm_c = ose_enter(bundle, OSEVM_ADDR_CONTROL);
    ose_bundle vm_d = ose_enter(bundle, OSEVM_ADDR_DUMP);
    ose_pushMessage(vm_cache,
                    OSE_ADDRESS_ANONVAL,
                    OSE_ADDRESS_ANONVAL_LEN,
                    30,
                    OSETT_INT32,
                    7,
                    OSETT_INT32,
                    0,
                    OSETT_INT32,
                    ose_getBundlePtr(vm_i) - ose_getBundlePtr(bundle),
                    OSETT_INT32,
                    ose_getBundlePtr(vm_s) - ose_getBundlePtr(bundle),
                    OSETT_INT32,
                    ose_getBundlePtr(vm_e) - ose_getBundlePtr(bundle),
                    OSETT_INT32,
                    ose_getBundlePtr(vm_c) - ose_getBundlePtr(bundle),
                    OSETT_INT32,
                    ose_getBundlePtr(vm_d) - ose_getBundlePtr(bundle),
                    OSETT_INT32, 0, OSETT_INT32, 0, OSETT_INT32, 0,
                    OSETT_INT32, 0, OSETT_INT32, 0, OSETT_INT32, 0,
                    OSETT_INT32, 0, OSETT_INT32, 0, OSETT_INT32, 0,
                    OSETT_INT32, 0, OSETT_INT32, 0, OSETT_INT32, 0,
                    OSETT_INT32, 0, OSETT_INT32, 0, OSETT_INT32, 0,
                    OSETT_INT32, 0, OSETT_INT32, 0, OSETT_INT32, 0,
                    OSETT_INT32, 0, OSETT_INT32, 0, OSETT_INT32, 0,
                    OSETT_INT32, 0, OSETT_INT32, 0);
    extern struct osevm_hooks osevm_hooks;
        osevm_hooks = (struct osevm_hooks)
        {
            OSEVM_ASSIGN,
            OSEVM_LOOKUP,
            OSEVM_FUNCALL,
            OSEVM_QUOTE,
            OSEVM_COPYREGISTERTOELEM,
            OSEVM_APPENDELEMTOREGISTER,
            OSEVM_REPLACEREGISTERWITHELEM,
            OSEVM_MOVEELEMTOREGISTER,
            OSEVM_TOTYPE,
            OSEVM_TOINT32,
            OSEVM_TOFLOAT,
            OSEVM_TOSTRING,
            OSEVM_TOBLOB,
#ifdef OSE_PROVIDE_TYPE_SYMBOL
            OSEVM_TOSYMBOL,
#endif
#ifdef OSE_PROVIDE_TYPE_DOUBLE
            OSEVM_TODOUBLE,
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
            OSEVM_TOINT8,
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
            OSEVM_TOUINT8,
#endif
#ifdef OSE_PROVIDE_TYPE_INT16
            OSEVM_TOINT16,
#endif
#ifdef OSE_PROVIDE_TYPE_UINT16
            OSEVM_TOUINT16,
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
            OSEVM_TOUINT32,
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
            OSEVM_TOINT64,
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
            OSEVM_TOUINT64,
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
            OSEVM_TOTIMETAG,
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
            OSEVM_TOTRUE,
#endif
#ifdef OSE_PROVIDE_TYPE_FALSE
            OSEVM_TOFALSE,
#endif
#ifdef OSE_PROVIDE_TYPE_NULL
            OSEVM_TONULL,
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
            OSEVM_TOINFINITUM,
#endif
            OSEVM_APPENDBYTE,
            OSEVM_RESPONDTOSTRING,
            OSEVM_PREINPUT,
            OSEVM_POSTINPUT,
            OSEVM_POPINPUTTOCONTROL,
            OSEVM_POSTCONTROL,
            OSEVM_EVALTYPE
        };
    return bundle;
}

void osevm_evalType(ose_bundle osevm)
{
}

static void applyControl(ose_bundle osevm, char *address)
{
    ose_bundle vm_s = OSEVM_STACK(osevm);
    ose_bundle vm_c = OSEVM_CONTROL(osevm);

    if(ose_peekType(vm_c) == OSETT_MESSAGE)
    {
        char t = ose_peekMessageArgType(vm_c);
        if(!ose_isStringType(t))
        {
            ose_copyElem(vm_c, vm_s);
            OSEVM_EVALTYPE(osevm);
            return;
        }
    }
    else
    {
        ose_copyElem(vm_c, vm_s);
        OSEVM_EVALTYPE(osevm);
        return;
    }

    const char * const str = ose_peekString(vm_c);
    route_init(str, a);

    if(route_pfx(a, OSEVM_TOK_AT, 1))
    {
        if(str[3])
        {
            ose_pushString(vm_s, str + 2);
        }
        else
        {
            ose_pushString(vm_s, OSE_ADDRESS_ANONVAL);
        }
        OSEVM_ASSIGN(osevm);
    }
    else if(route_pfx(a, OSEVM_TOK_QUOTE, 1))
    {
        ose_pushString(vm_s, str + 2);
        OSEVM_QUOTE(osevm);
    }
    /* else if(route_pfx(a, OSEVM_TOK_BANG, 1)) */
    /* { */
        /* ose_pushString(vm_s, str + 2); */
        /* OSEVM_FUNCALL(osevm); */        
    /* } */
    else if(route_pfx(a, OSEVM_TOK_DOLLAR, 1)
            || route_pfx(a, OSEVM_TOK_BANG, 1))
    {
        route_init(str + 2, b);
        int isstring = 0;
        if(route_mthd(b, OSEVM_TOK_AT, 1))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_ASSIGN);
        }
        else if(route_mthd(b, OSEVM_TOK_QUOTE, 1))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_QUOTE);
        }
        else if(route_mthd(b, OSEVM_TOK_BANG, 1))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_FUNCALL);
        }
        else if(route_mthd(b, OSEVM_TOK_DOLLAR, 1))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_LOOKUP);
        }
        else if(route_mthd(b, OSEVM_TOK_GT, 1))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_COPYREGISTERTOELEM);
        }
        else if(route_mthd(b, OSEVM_TOK_LTLT, 2))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_APPENDELEMTOREGISTER);
        }
        else if(route_mthd(b, OSEVM_TOK_LT, 1))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_REPLACEREGISTERWITHELEM);
        }
        else if(route_mthd(b, OSEVM_TOK_DASH, 1))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_MOVEELEMTOREGISTER);
        }
        else if(route_mthd(b, OSEVM_TOK_COMMA, 1))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_TOTYPE);
        }
        else if(route_mthd(b, OSEVM_TOK_COMMA_i, 3))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_TOINT32);
        }
        else if(route_mthd(b, OSEVM_TOK_COMMA_f, 3))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_TOFLOAT);
        }
        else if(route_mthd(b, OSEVM_TOK_COMMA_s, 3))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_TOSTRING);
        }
        else if(route_mthd(b, OSEVM_TOK_COMMA_b, 3))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_TOBLOB);
        }
#ifdef OSE_PROVIDE_TYPE_SYMBOL
        else if(route_mthd(b, OSEVM_TOK_COMMA_S, 3))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_TOSYMBOL);
        }
#endif
#ifdef OSE_PROVIDE_TYPE_DOUBLE
        else if(route_mthd(b, OSEVM_TOK_COMMA_d, 3))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_TODOUBLE);
        }
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
        else if(route_mthd(b, OSEVM_TOK_COMMA_c, 3))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_TOINT8);
        }
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
        else if(route_mthd(b, OSEVM_TOK_COMMA_C, 3))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_TOUINT8);
        }
#endif
#ifdef OSE_PROVIDE_TYPE_INT16
        else if(route_mthd(b, OSEVM_TOK_COMMA_u, 3))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_TOINT16);
        }
#endif
#ifdef OSE_PROVIDE_TYPE_UINT16
        else if(route_mthd(b, OSEVM_TOK_COMMA_U, 3))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_TOUINT16);
        }
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
        else if(route_mthd(b, OSEVM_TOK_COMMA_k, 3))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_TOUINT32);
        }
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
        else if(route_mthd(b, OSEVM_TOK_COMMA_h, 3))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_TOINT64);
        }
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
        else if(route_mthd(b, OSEVM_TOK_COMMA_H, 3))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_TOUINT64);
        }
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
        else if(route_mthd(b, OSEVM_TOK_COMMA_t, 3))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_TOTIMETAG);
        }
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
        else if(route_mthd(b, OSEVM_TOK_COMMA_T, 3))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_TOTRUE);
        }
#endif
#ifdef OSE_PROVIDE_TYPE_FALSE
        else if(route_mthd(b, OSEVM_TOK_COMMA_F, 3))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_TOFALSE);
        }
#endif
#ifdef OSE_PROVIDE_TYPE_NULL
        else if(route_mthd(b, OSEVM_TOK_COMMA_N, 3))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_TONULL);
        }
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
        else if(route_mthd(b, OSEVM_TOK_COMMA_I, 3))
        {
            ose_pushAlignedPtr(vm_s, OSEVM_TOINFINITUM);
        }
#endif
        else
        {
            isstring = 1;
            ose_pushString(vm_s, str + 2);
            if(route_pfx(a, OSEVM_TOK_DOLLAR, 1))
            {
            	OSEVM_LOOKUP(osevm);
            }
        }
        if(route_pfx(a, OSEVM_TOK_BANG, 1))
        {
            if(isstring)
            {
            	OSEVM_FUNCALL(osevm);
            }
            else
            {
                osevm_apply(osevm);
            }
        }
    }
    else if(route_pfx(a, OSEVM_TOK_GT, 1))
    {
        ose_pushString(vm_s, str + 2);
        OSEVM_COPYREGISTERTOELEM(osevm);
    }
    else if(route_pfx(a, OSEVM_TOK_LTLT, 2))
    {
        ose_pushString(vm_s, str + 3);
        OSEVM_APPENDELEMTOREGISTER(osevm);
    }
    else if(route_pfx(a, OSEVM_TOK_LT, 1))
    {
        ose_pushString(vm_s, str + 2);
        OSEVM_REPLACEREGISTERWITHELEM(osevm);
    }
    else if(route_pfx(a, OSEVM_TOK_DASH, 1))
    {
        ose_pushString(vm_s, str + 2);
        OSEVM_MOVEELEMTOREGISTER(osevm);
    }
    else if(route_pfx(a, OSEVM_TOK_COMMA_i, 2))
    {
        if(str[4] == '/')
        {
            ose_pushString(vm_s, str + 4);
            OSEVM_TOINT32(osevm);
        }
        else
        {
            ose_pushString(vm_s, str);
        }
    }
    else if(route_pfx(a, OSEVM_TOK_COMMA_f, 2))
    {
        if(str[4] == '/')
        {
            ose_pushString(vm_s, str + 4);
            OSEVM_TOFLOAT(osevm);
        }
        else
        {
            ose_pushString(vm_s, str);
        }
    }
    else if(route_pfx(a, OSEVM_TOK_COMMA_s, 2))
    {
        if(str[4] == '/')
        {
            ose_pushString(vm_s, str + 5);
            OSEVM_TOSTRING(osevm);
        }
        else
        {
            ose_pushString(vm_s, str);
        }
    }
    else if(route_pfx(a, OSEVM_TOK_COMMA_b, 2))
    {
        if(str[4] == '/')
        {
            ose_pushString(vm_s, str + 5);
            OSEVM_TOBLOB(osevm);
        }
        else
        {
            ose_pushString(vm_s, str);
        }
    }
#ifdef OSE_PROVIDE_TYPE_SYMBOL
    else if(route_pfx(a, OSEVM_TOK_COMMA_S, 2))
    {
        if(str[4] == '/')
        {
            ose_pushString(vm_s, str + 5);
            OSEVM_TOSYMBOL(osevm);
        }
        else
        {
            ose_pushString(vm_s, str);
        }
    }
#endif
#ifdef OSE_PROVIDE_TYPE_DOUBLE
    else if(route_pfx(a, OSEVM_TOK_COMMA_d, 2))
    {
        if(str[4] == '/')
        {
            ose_pushString(vm_s, str + 4);
            OSEVM_TODOUBLE(osevm);
        }
        else
        {
            ose_pushString(vm_s, str);
        }
    }
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
    else if(route_pfx(a, OSEVM_TOK_COMMA_c, 2))
    {
        if(str[4] == '/')
        {
            ose_pushString(vm_s, str + 4);
            OSEVM_TOINT8(osevm);
        }
        else
        {
            ose_pushString(vm_s, str);
        }
    }
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
    else if(route_pfx(a, OSEVM_TOK_COMMA_C, 2))
    {
        if(str[4] == '/')
        {
            ose_pushString(vm_s, str + 4);
            OSEVM_TOUINT8(osevm);
        }
        else
        {
            ose_pushString(vm_s, str);
        }
    }
#endif
#ifdef OSE_PROVIDE_TYPE_INT16
    else if(route_pfx(a, OSEVM_TOK_COMMA_u, 2))
    {
        if(str[4] == '/')
        {
            ose_pushString(vm_s, str + 4);
            OSEVM_TOINT16(osevm);
        }
        else
        {
            ose_pushString(vm_s, str);
        }
    }
#endif
#ifdef OSE_PROVIDE_TYPE_UINT16
    else if(route_pfx(a, OSEVM_TOK_COMMA_U, 2))
    {
        if(str[4] == '/')
        {
            ose_pushString(vm_s, str + 4);
            OSEVM_TOUINT16(osevm);
        }
        else
        {
            ose_pushString(vm_s, str);
        }
    }
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
    else if(route_pfx(a, OSEVM_TOK_COMMA_k, 2))
    {
        if(str[4] == '/')
        {
            ose_pushString(vm_s, str + 4);
            OSEVM_TOUINT32(osevm);
        }
        else
        {
            ose_pushString(vm_s, str);
        }
    }
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
    else if(route_pfx(a, OSEVM_TOK_COMMA_h, 2))
    {
        if(str[4] == '/')
        {
            ose_pushString(vm_s, str + 4);
            OSEVM_TOINT64(osevm);
        }
        else
        {
            ose_pushString(vm_s, str);
        }
    }
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
    else if(route_pfx(a, OSEVM_TOK_COMMA_H, 2))
    {
        if(str[4] == '/')
        {
            ose_pushString(vm_s, str + 4);
            OSEVM_TOUINT64(osevm);
        }
        else
        {
            ose_pushString(vm_s, str);
        }
    }
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
    else if(route_pfx(a, OSEVM_TOK_COMMA_t, 2))
    {
        if(str[4] == '/')
        {
            ose_pushString(vm_s, str + 4);
            OSEVM_TOTIMETAG(osevm);
        }
        else
        {
            ose_pushString(vm_s, str);
        }
    }
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
    else if(route_pfx(a, OSEVM_TOK_COMMA_T, 2))
    {
        OSEVM_TOTRUE(osevm);
    }
#endif
#ifdef OSE_PROVIDE_TYPE_FALSE
    else if(route_pfx(a, OSEVM_TOK_COMMA_F, 2))
    {
        OSEVM_TOFALSE(osevm);
    }
#endif
#ifdef OSE_PROVIDE_TYPE_NULL
    else if(route_pfx(a, OSEVM_TOK_COMMA_N, 2))
    {
        OSEVM_TONULL(osevm);
    }
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
    else if(route_pfx(a, OSEVM_TOK_COMMA_I, 2))
    {
        OSEVM_TOINFINITUM(osevm);
    }
#endif
    else if(route_pfx(a, OSEVM_TOK_COMMA, 1))
    {
        ose_pushString(vm_s, str + 5);
        ose_pushInt32(vm_s, str[3]);
        OSEVM_TOTYPE(osevm);
    }
    else if(route_pfx(a, OSEVM_TOK_HASH, 1))
    {
        ;
    }
    else
    {
        ose_pushString(vm_s, str);
        OSEVM_RESPONDTOSTRING(osevm);
    }
}

static void popAllControl(ose_bundle osevm)
{
    ose_bundle vm_c = OSEVM_CONTROL(osevm);
    const char * const address = ose_peekAddress(vm_c);
    if(!strncmp(address, OSE_BUNDLE_ID, OSE_BUNDLE_ID_LEN))
    {
        return;
    }
    else if(strncmp(address,
                    OSE_ADDRESS_ANONVAL,
                    OSE_ADDRESS_ANONVAL_SIZE))
    {
        ose_pushString(vm_c, OSE_ADDRESS_ANONVAL);
        ose_push(vm_c);
        ose_swapStringToAddress(vm_c);
    }
    ose_countItems(vm_c);
    int32_t n = ose_popInt32(vm_c);
    for(int i = 0; i < n; i++)
    {
        ose_pop(vm_c);
        ose_swap(vm_c);
    }
    ose_drop(vm_c);
}

void osevm_preInput(ose_bundle osevm)
{
}

void osevm_postInput(ose_bundle osevm)
{
}

void osevm_postControl(ose_bundle osevm)
{
}

char osevm_step(ose_bundle osevm)
{
    ose_bundle vm_i = OSEVM_INPUT(osevm);
    ose_bundle vm_c = OSEVM_CONTROL(osevm);
    ose_bundle vm_d = OSEVM_DUMP(osevm);
    if(!ose_bundleIsEmpty(vm_c))
    {
        applyControl(osevm, ose_peekAddress(vm_c));
        if(ose_bundleIsEmpty(vm_c))
        {
            OSEVM_POSTCONTROL(osevm);
        }
    }
    else if(!ose_bundleIsEmpty(vm_i))
    {
        OSEVM_POPINPUTTOCONTROL(osevm);
        if(!ose_bundleIsEmpty(vm_c))
        {
            popAllControl(osevm);
        }
    }
    else if(!ose_bundleIsEmpty(vm_d))
    {
        osevm_return(osevm);
    }
    if(!ose_bundleIsEmpty(vm_i)
       || !ose_bundleIsEmpty(vm_c))
    {
        return OSETT_TRUE;
    }
    else if(!ose_bundleIsEmpty(vm_d))
    {
        return OSETT_TRUE;
    }
    else
    {
        return OSETT_FALSE;
    }
}

void osevm_run(ose_bundle osevm)
{
    ose_bundle vm_i = OSEVM_INPUT(osevm);
    ose_bundle vm_s = OSEVM_STACK(osevm);
    ose_bundle vm_c = OSEVM_CONTROL(osevm);
    ose_bundle vm_d = OSEVM_DUMP(osevm);
    int32_t n = ose_getBundleElemCount(vm_d);
    OSEVM_PREINPUT(osevm);
    while(1)
    {
        while(1)
        {
            if(ose_bundleIsEmpty(vm_c))
            {
                if(ose_bundleIsEmpty(vm_i))
                {
                    break;
                }
                OSEVM_POPINPUTTOCONTROL(osevm);
                if(ose_bundleIsEmpty(vm_c))
                {
                    continue;
                }
                popAllControl(osevm);
            }
            while(1)
            {
                if(ose_bundleIsEmpty(vm_c))
                {
                    break;
                }
                applyControl(osevm, ose_peekAddress(vm_c));
                /* check status and drop into */
                /* debugger if necessary */
                enum ose_errno e = ose_errno_get(osevm);
                if(e)
                {
                    ose_errno_set(osevm, OSE_ERR_NONE);
                    ose_pushInt32(vm_s, e);
                    ose_pushString(vm_c, "/!/exception");
                    ose_pushString(vm_c, "");
                }
                if(ose_bundleHasAtLeastNElems(vm_c, 1))
                {
                    ose_drop(vm_c);
                }
            }
            OSEVM_POSTCONTROL(osevm);
        }
        if(!ose_bundleIsEmpty(vm_d)
           && ose_getBundleElemCount(vm_d) > n)
        {
            osevm_return(osevm);
        }
        else
        {
            break;
        }
    }
    OSEVM_POSTINPUT(osevm);
}

void osevm_inputMessages(ose_bundle osevm,
                         int32_t size, const char * const bundle)
{
    ose_bundle vm_i = OSEVM_INPUT(osevm);
    ose_pushMessage(vm_i, OSE_ADDRESS_ANONVAL,
                    OSE_ADDRESS_ANONVAL_LEN, 
                    1, OSETT_BLOB, size, bundle);
    ose_blobToElem(vm_i);
    ose_popAllDrop(vm_i);
}

void osevm_inputMessage(ose_bundle osevm,
                        int32_t size, const char * const message)
{
    ose_bundle vm_i = OSEVM_INPUT(osevm);
    ose_pushMessage(vm_i, OSE_ADDRESS_ANONVAL,
                    OSE_ADDRESS_ANONVAL_LEN, 
                    1, OSETT_BLOB, size, message);
    ose_blobToElem(vm_i);
}

#ifdef OSEVM_HAVE_SIZES
int32_t osevm_computeSizeReqs(int n, ...)
{
    va_list ap;
    va_start(ap, n);
    int32_t s = OSE_CONTEXT_MAX_OVERHEAD + OSEVM_CACHE_MSG_SIZE
        + OSEVM_INPUT_SIZE + OSE_CONTEXT_MESSAGE_OVERHEAD
        + OSEVM_STACK_SIZE + OSE_CONTEXT_MESSAGE_OVERHEAD
        + OSEVM_ENV_SIZE + OSE_CONTEXT_MESSAGE_OVERHEAD
        + OSEVM_CONTROL_SIZE + OSE_CONTEXT_MESSAGE_OVERHEAD
        + OSEVM_DUMP_SIZE + OSE_CONTEXT_MESSAGE_OVERHEAD;
    for(int i = 0; i < n; i++)
    {
        int32_t nn = va_arg(ap, int32_t);
        s += nn;
    }
    va_end(ap);
    return s;
}
#else
int32_t osevm_computeSizeReqs(int32_t input_size,
                              int32_t stack_size,
                              int32_t env_size,
                              int32_t control_size,
                              int32_t dump_size,
                              int n, ...)
{
    va_list ap;
    va_start(ap, n);
    int32_t s = OSE_CONTEXT_MAX_OVERHEAD + OSEVM_CACHE_MSG_SIZE
        + input_size + stack_size + env_size
        + control_size + dump_size;
    for(int i = 0; i < n; i++)
    {
        int32_t nn = va_arg(ap, int32_t);
        s += nn;
    }
    va_end(ap);
    return s;
}
#endif

int32_t osevm_callTypeHook(ose_bundle bundle,
                           const char typetag,
                           const int32_t msg_offset,
                           const int32_t item_offset,
                           const int32_t addrlen,
                           const char * const addr)
{
    /* 
       The bundle we get passed to us is not the VM!
    */
    ose_bundle osevm = ose_exit(bundle);
    ose_bundle vm_s = ose_enter(osevm, "/_s");
    char buf[addrlen];
    snprintf(buf, addrlen, addr, typetag);
    int32_t io = item_offset;
    int32_t msg_size = ose_readInt32(bundle, msg_offset);
    int32_t old_stack_size;
    if(ose_getBundlePtr(bundle) != ose_getBundlePtr(vm_s))
    {
        
        old_stack_size = ose_readSize(vm_s);
        ose_incSize(vm_s, msg_size + 4);
        memcpy(ose_getBundlePtr(vm_s) + old_stack_size,
               ose_getBundlePtr(bundle) + msg_offset,
               msg_size + 4);
        io = old_stack_size + (item_offset - msg_offset);
    }
    ose_pushInt32(vm_s, io);
    ose_pushInt32(vm_s, typetag);
    ose_pushString(vm_s, buf);
    OSEVM_LOOKUP(osevm);
    if(ose_peekMessageArgType(vm_s) == OSETT_BLOB)
    {
        int32_t val = 0;
        osevm_apply(osevm);
        val = ose_popInt32(vm_s);
        if(ose_getBundlePtr(bundle) != ose_getBundlePtr(vm_s))
        {
            if(ose_readSize(vm_s) > old_stack_size + msg_size + 4)
            {
                ose_moveElem(vm_s, bundle);
            }
            ose_drop(vm_s);
            ose_assert(ose_readSize(vm_s) == old_stack_size);
        }
        return val;
    }
    else
    {
        ose_drop(vm_s);
        ose_2drop(vm_s);
        return -1;
    }
}

int32_t osevm_getPayloadItemLength_hook(ose_bundle bundle,
                                        const char typetag,
                                        const int32_t msg_offset,
                                        const int32_t item_offset)
{
    return osevm_callTypeHook(bundle,
                              typetag,
                              msg_offset,
                              item_offset,
                              OSE_GETPAYLOADITEMLENGTH_ADDR_LEN,
                              OSE_GETPAYLOADITEMLENGTH_ADDR);
}

int32_t osevm_getPayloadItemSize_hook(ose_bundle bundle,
                                      const char typetag,
                                      const int32_t msg_offset,
                                      const int32_t item_offset)
{
    return osevm_callTypeHook(bundle,
                              typetag,
                              msg_offset,
                              item_offset,
                              OSE_GETPAYLOADITEMSIZE_ADDR_LEN,
                              OSE_GETPAYLOADITEMSIZE_ADDR);
}

int32_t osevm_pprintPayloadItem_hook(ose_bundle bundle,
                                     const char typetag,
                                     const int32_t msg_offset,
                                     const int32_t item_offset)
{
    return osevm_callTypeHook(bundle,
                              typetag,
                              msg_offset,
                              item_offset,
                              OSE_PPRINTPAYLOADITEM_ADDR_LEN,
                              OSE_PPRINTPAYLOADITEM_ADDR);
}
