/*
  Copyright (c) 2019-21 John MacCallum Permission is hereby granted,
  free of charge, to any person obtaining a copy of this software
  and associated documentation files (the "Software"), to deal in
  the Software without restriction, including without limitation the
  rights to use, copy, modify, merge, publish, distribute,
  sublicense, and/or sell copies of the Software, and to permit
  persons to whom the Software is furnished to do so, subject to the
  following conditions:

  The above copyright notice and this permission notice shall be
  included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
  DEALINGS IN THE SOFTWARE.
*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "ose.h"
#include "ose_util.h"
#include "ose_stackops.h"
#include "ose_assert.h"
#include "ose_print.h"

#define SEP ':'

#define INCP(bufp, amt) ((bufp) ? ((bufp) += (amt)) : (bufp))
#define INCL(bufp, bufl, amt) ((bufp) ? ((bufl) -= (amt)) : (bufl))

#define ose_snprintfi(bufp, bufl, n, total, fmt, ...)       \
	{                                                       \
		int32_t n = snprintf(bufp, bufl, fmt, __VA_ARGS__);	\
		if(bufp){                                           \
			bufp += n;                                      \
		}                                                   \
		if(bufl >= n){                                      \
			bufl -= n;                                      \
		}else{                                              \
			bufl = 0;                                       \
		}                                                   \
		total += n;                                         \
	}

static int32_t _ose_pprintBundle(ose_bundle bundle,
                                 int32_t offset,
                                 char *buf,
                                 int32_t buflen,
                                 int32_t indent);

/**************************************************
 * pretty printing
 **************************************************/

int32_t ose_pprintMessageAddr(ose_bundle bundle,
                              int32_t offset,
                              int32_t ao,
                              char *buf,
                              int32_t buflen)
{
	const char *addr = ose_readString(bundle, ao);
	return snprintf(buf, buflen, "%s ", addr);
}

int32_t ose_pprintPayloadItem_impl(ose_bundle bundle,
                                   const char typetag,
                                   const int32_t msg_offset,
                                   const int32_t item_offset,
                                   char *buf,
                                   int32_t buflen)
{
	const char sep = SEP;
	switch(typetag){
	case OSETT_INT32:
		return snprintf(buf, buflen,
                        "[i%c%d]",
                        sep,
                        ose_readInt32(bundle, item_offset));
	case OSETT_FLOAT:
		return snprintf(buf, buflen,
                        "[f%c%f]",
                        sep,
                        ose_readFloat(bundle, item_offset));
	case OSETT_STRING:
		return snprintf(buf, buflen,
                        "[s%c%s]",
                        sep,
                        ose_readString(bundle, item_offset));
	case OSETT_BLOB:
    {
		int32_t blobsize = ose_readInt32(bundle, item_offset);
		int32_t n =  snprintf(buf, buflen,
                              "[b:<%d:",
                              blobsize);
		int32_t nn = n;
		INCP(buf, n);
		INCL(buf, buflen, n);

        if(blobsize > 0)
        {
            char *b = ose_getBundlePtr(bundle);
            const uint8_t *p = (uint8_t *)(b + item_offset + 4);
            if(blobsize > 8){
                for(int i = 0; i < 4; i++){
                    n = snprintf(buf, buflen, "%02X", p[i]);
                    nn += n;
                    INCP(buf, n);
                    INCL(buf, buflen, n);
                }
                n = snprintf(buf, buflen, "..");
                nn += n;
                INCP(buf, n);
                INCL(buf, buflen, n);
                for(int j = blobsize - 4; j < blobsize; j++)
                {
                    n = snprintf(buf, buflen, "%02X", p[j]);
                    nn += n;
                    INCP(buf, n);
                    INCL(buf, buflen, n);
                }
            }
            else
            {
                for(int k = 0; k < blobsize; k++)
                {
                    n = snprintf(buf, buflen, "%02X", p[k]);
                    nn += n;
                    INCP(buf, n);
                    INCL(buf, buflen, n);
                }
            }
        }
        else
        {}
		

		n = snprintf(buf, buflen, ">]");
		nn += n;
		INCP(buf, n);
		INCL(buf, buflen, n);
		return nn;
	}
#ifdef OSE_PROVIDE_TYPE_SYMBOL
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_DOUBLE
    case OSETT_DOUBLE:
		return snprintf(buf, buflen,
                        "[d%c%f]",
                        sep,
                        ose_readDouble(bundle, item_offset));
        break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT8p
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INT16
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT16
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
    case OSETT_TIMETAG:
        return snprintf(buf, buflen, "[t%c%u.%u]",
                        sep,
                        ose_readInt32(bundle, item_offset),
                        ose_readInt32(bundle, item_offset + 4));
        break;
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_FALSE
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_NULL
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
#warning NOT IMPLEMENTED
#endif
	default: {
		return snprintf(buf, buflen, "[%c%c<>]", typetag, sep);
	}
	}
}

int32_t ose_pprintPayloadItem_hook(ose_bundle bundle,
                                   const char typetag,
                                   const int32_t msg_offset,
                                   const int32_t item_offset)
{
    char buf[4];
    int32_t ret = snprintf(buf, 4, "<>");
    ose_pushString(bundle, buf);
    return ret;
}

static int32_t _pprintPayloadItem(ose_bundle bundle,
                                  const char typetag,
                                  const int32_t msg_offset,
                                  const int32_t item_offset,
                                  char *buf,
                                  int32_t buflen)
{
    if(ose_isKnownTypetag(typetag))
    {
        return ose_pprintPayloadItem_impl(bundle,
                                          typetag,
                                          msg_offset,
                                          item_offset,
                                          buf, buflen);
    }
    else
    {
        int32_t ret = OSE_PPRINTPAYLOADITEM_HOOK(bundle,
                                                 typetag,
                                                 msg_offset,
                                                 item_offset);
        char sep = SEP;
        int32_t len;
        if(ret < 0)
        {
            len = snprintf(buf, buflen, "[%c%c<>]",
                           typetag, sep);
        }
        else
        {
            len = snprintf(buf, buflen, "[%c%c%s]",
                           typetag, sep,
                           ose_peekString(bundle));
            ose_drop(bundle);
        }
        return len;
    }
}

int32_t ose_pprintBundleElem_msg(ose_bundle bundle,
                                 int32_t offset,
                                 char *buf,
                                 int32_t buflen,
                                 int32_t indent)
{
	char *b = ose_getBundlePtr(bundle);
	int32_t s = ose_readInt32(bundle, offset);
	int32_t ao = offset + 4;
	int32_t tto = ao + ose_pstrlen(b + ao);
	int32_t plo = tto + ose_pstrlen(b + tto);
	tto++;
	int32_t n = 0;
	int32_t nn = 0;
	char *bufp = buf;
	int32_t bufl = buflen;
	{
		/* address */
		n = ose_pprintMessageAddr(bundle,
                                  offset,
                                  ao,
                                  bufp,
                                  bufl);
		nn += n;
		INCP(bufp, n);
		INCL(bufp, bufl, n);
	}
	/* payload */
	while(plo < (offset + 4 + s) && ose_readByte(bundle, tto))
    {
		char tt = ose_readByte(bundle, tto);
		n = _pprintPayloadItem(bundle,
                               ose_readByte(bundle, tto),
                               offset,
                               plo,
                               bufp,
                               bufl);
		nn += n;
		INCP(bufp, n);
		INCL(bufp, bufl, n);
        int32_t payload_item_size =
            ose_getPayloadItemSize(bundle, tt, offset, plo);
        if(payload_item_size < 0)
        {
            /* skip the rest of the message */
            plo = offset + s + 4;
        }
        else
        {
            plo += payload_item_size;
        }
		/* if(ose_isKnownTypetag(tt)) */
        /* { */
        /*     plo += ose_getPayloadItemSize(bundle, tt, offset, plo); */
		/* } */
        /* else */
        /* { */
		/* 	/\* if(ose_readByte(bundle, tto + 1) == 0) *\/ */
        /*     { */
        /*         /\* this is an unknown typetag, skip the rest */
        /*            of the message, as per the spec *\/ */
		/* 		plo = offset + s + 4; */
		/* 	} */
		/* } */
		tto++;
	}
	return nn;
}

int32_t ose_pprintBundleElem(ose_bundle bundle,
                             int32_t offset,
                             char *buf,
                             int32_t buflen,
                             int32_t indent)
{
	int32_t nn = 0;
	char *bufp = buf;
	int32_t bufl = buflen;
	int n = 0;
	char betype = ose_getBundleElemType(bundle, offset);
	if(betype == OSETT_MESSAGE)
    {
		n = ose_pprintBundleElem_msg(bundle,
                                     offset,
                                     bufp,
                                     bufl,
                                     indent);
		return n;
	}
    else if(betype == OSETT_BUNDLE)
    {
		if(ose_getBundleElemElemCount(bundle, offset) == 0)
        {
			n = snprintf(bufp, bufl, "#bundle");
		}
        else
        {
			n = snprintf(bufp, bufl, "#bundle\r\n");
		}
		nn += n;
		INCP(bufp, n);
		INCL(bufp, bufl, n);
		n = _ose_pprintBundle(bundle,
                              offset + 4,
                              bufp,
                              bufl,
                              indent + 1);
		nn += n;
		INCP(bufp, n);
		INCL(buf, bufl, n);
		return nn;
	}
    else
    {
		ose_assert(0 &&
                   "bundle elem is neither a message nor a bundle");
	}
	return 0;
}

static int32_t _ose_pprintBundle(ose_bundle bundle,
                                 int32_t offset,
                                 char *buf,
                                 int32_t buflen,
                                 int32_t indent)
{
	ose_assert(ose_isBundle(bundle));
	int32_t nn = 0;
    /* it's possible that offset will be 0, so don't use
       ose_readInt32() */
	int32_t ss = ose_ntohl(*((int32_t *)(ose_getBundlePtr(bundle) +
                                         (offset - 4))));
	char *bufp = buf;
	int32_t bufl = buflen;
	int32_t o = OSE_BUNDLE_HEADER_LEN;
	offset += OSE_BUNDLE_HEADER_LEN;
	char indentstr[indent * 2 + 1];
	memset(indentstr, 0, indent * 2 + 1);
	for(int i = 0; i < indent; i++)
    {
		indentstr[i] = ' ';
	}
	for(int j = indent; j < indent * 2; j++)
    {
		indentstr[j] = '#';
	}
	while(o < ss)
    {
		int n = 0;
		n = snprintf(bufp, bufl, "%s", indentstr);
		nn += n;
		INCP(bufp, n);
		INCL(bufp, bufl, n);

		int32_t s = ose_readInt32(bundle, offset);
		n = ose_pprintBundleElem(bundle,
                                 offset,
                                 bufp,
                                 bufl,
                                 indent);
		nn += n;
		INCP(bufp, n);
		INCL(bufp, bufl, n);
		o += s + 4;
		offset += s + 4;
		if(o < ss)
        {
			n = snprintf(bufp, bufl, "\r\n");
			INCP(bufp, n);
			INCL(bufp, bufl, n);
			nn += n;
		}
	}
	return nn;
}

int32_t ose_pprintBundle(ose_bundle bundle,
                         char *buf,
                         int32_t buflen)
{
	return _ose_pprintBundle(bundle,
                             0,
                             buf,
                             buflen,
                             0);
}

static const int cols = 80;
static int32_t ose_pprintFullBundle_r(ose_constbundle bundle,
                                      char *buf, int32_t buflen,
                                      int32_t o,
                                      int32_t s,
                                      int32_t to,
                                      int32_t indent)
{
	int32_t nn = 0;
	ose_snprintfi(buf, buflen, n, nn, "%08x ", to);
	for(int i = 0; i < indent - 1; i++)
    {
		ose_snprintfi(buf, buflen, n, nn, "%s", "|");
	}
	ose_snprintfi(buf, buflen, n, nn, "%s", OSE_BUNDLE_ID);
	for(int j = 0; j < (cols / 2) - (9 + (indent - 1) + 7 + 15); j++)
    {
		ose_snprintfi(buf, buflen, n, nn, "%s", " ");
	}
	ose_snprintfi(buf, buflen, n, nn, "%08x.%08x\r\n",
                  ose_readInt32(bundle, OSE_BUNDLE_ID_LEN),
                  ose_readInt32(bundle, OSE_BUNDLE_ID_LEN + 4));
	while(o < s)
    {
		const int32_t ss = ose_readInt32(bundle, o);
		const char * const addr = ose_readString((ose_bundle)bundle,
                                                 o + 4);
		const int32_t addrlen = strlen(addr);
		if(!strncmp(addr, OSE_BUNDLE_ID, OSE_BUNDLE_ID_LEN))
        {
			int32_t oo = OSE_BUNDLE_HEADER_LEN;
			ose_constbundle subbundle =
                ose_makeBundle(ose_getBundlePtr(bundle) + o + 4);
			int n = ose_pprintFullBundle_r(subbundle,
                                           buf, buflen,
                                           oo, ss, to + o,
                                           indent + 1);
			nn += n;
			if(buf && (buflen > n))
            {
				buf += n;
				buflen -= n;
			}
		}
        else
        {
			ose_snprintfi(buf, buflen, n, nn, "%08x ", o + to);
			for(int i = 0; i < indent; i++)
            {
				ose_snprintfi(buf, buflen, n, nn, "%s", "|");
			}
			ose_snprintfi(buf, buflen, n, nn, "%s", addr);
			for(int j = 0;
			    j < (cols / 2) - (9 + indent + strlen(addr));
			    j++)
            {
				ose_snprintfi(buf, buflen, n, nn, "%s", " ");
			}

			int32_t to = o + 4 + ose_pnbytes(addrlen);
			const char * const ttstr =
                ose_readString((ose_bundle)bundle, to);
			const int32_t ttstrlen = strlen(ttstr);
			int32_t po = to + ose_pnbytes(ttstrlen);
			for(int ii = 0; ii < ttstrlen; ii++)
            {
				char tt = ose_readByte(bundle, to);
				if(ii > 1)
                {
					for(int j1 = 0; j1 < cols / 2 + 1; j1++)
                    {
						ose_snprintfi(buf, buflen, n, nn, "%s", " ");
					}
					ose_snprintfi(buf, buflen, n, nn, "%c ", tt);
				}
                else if(ii == 0)
                {
					ose_snprintfi(buf, buflen, n, nn, "%c", tt);
				}
                else
                {
					ose_snprintfi(buf, buflen, n, nn, "%c ", tt);
				}
				
				switch(tt)
                {
				case OSETT_ID:
					break;
				case OSETT_INT32:
					ose_snprintfi(buf, buflen, n, nn, "%d",
                                  ose_readInt32(bundle, po));
					po += 4;
					break;
				case OSETT_FLOAT:
					ose_snprintfi(buf, buflen, n, nn, "%f",
                                  ose_readFloat(bundle, po));
					po += 4;
					break;
				case OSETT_STRING:
                {
					const char * const st =
						ose_readString((ose_bundle)bundle,
                                       po);
					ose_snprintfi(buf, buflen, n, nn, "%s", st);
					po += ose_pstrlen(st);
				}
                break;
				case OSETT_BLOB:
                {
					int32_t bs = ose_getPaddedBlobSize(bundle, po);
					po += 4;
					if(bs == 4)
                    {
						ose_snprintfi(buf, buflen, n, nn,
                                      "%02x %02x %02x %02x",
                                      ose_readByte(bundle, po),
                                      ose_readByte(bundle, po + 1),
                                      ose_readByte(bundle, po + 2),
                                      ose_readByte(bundle, po + 3));
						po += 4;
					}
                    else
                    {
						for(int j2 = 0; j2 < bs; j2 += 8)
                        {
							if(bs - j2 == 4)
                            {
								ose_snprintfi(buf, buflen, n, nn,
                                              "%02x %02x %02x %02x",
                                              ose_readByte(bundle,
                                                           po),
                                              ose_readByte(bundle,
                                                           po + 1),
                                              ose_readByte(bundle,
                                                           po + 2),
                                              ose_readByte(bundle,
                                                           po + 3));
								po += 4;
							}
                            else
                            {
								ose_snprintfi(buf, buflen, n, nn,
                                              "%02x %02x %02x %02x "
                                              "%02x %02x %02x %02x",
                                              0xff & ose_readByte(bundle, po),
                                              0xff & ose_readByte(bundle, po + 1),
                                              0xff & ose_readByte(bundle, po + 2),
                                              0xff & ose_readByte(bundle, po + 3),
                                              0xff & ose_readByte(bundle, po + 4),
                                              0xff & ose_readByte(bundle, po + 5),
                                              0xff & ose_readByte(bundle, po + 6),
                                              0xff & ose_readByte(bundle, po + 7));
								po += 8;
							}
							if(bs - j2 > 8)
                            {
								ose_snprintfi(buf, buflen, n, nn,
                                              "%s", "\r\n");
								for(int j3 = 0;
								    j3 < cols / 2 + 3;
								    j3++)
                                {
									ose_snprintfi(buf, buflen, n, nn,
                                                  "%s", " ");
								}
							}
						}
					}
				}
                break;
#ifdef OSE_PROVIDE_TYPE_SYMBOL
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_DOUBLE
                case OSETT_DOUBLE:
					ose_snprintfi(buf, buflen, n, nn, "%f",
                                  ose_readDouble(bundle, po));
					po += 8;
					break;
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INT16
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT16
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
                case OSETT_TIMETAG:
					ose_snprintfi(buf, buflen, n, nn, "%u.%u",
                                  ose_readInt32(bundle, po),
                                  ose_readInt32(bundle, po + 4));
					po += OSE_TIMETAG_LEN;
					break;
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_FALSE
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_NULL
#warning NOT IMPLEMENTED
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
#warning NOT IMPLEMENTED
#endif
				}
				to++;
				if(ii > 0 || (ii == 0 && ttstrlen == 1)){
					ose_snprintfi(buf, buflen, n, nn, "%s", "\r\n");
				}
			}
		}
		o += 4 + ss;
	}
	return nn;
}

int32_t ose_pprintFullBundle_impl(ose_constbundle bundle,
                                  char *buf, int32_t buflen,
                                  const char * const name)
{
	int32_t o = OSE_BUNDLE_HEADER_LEN;
	const int32_t s = ose_readSize(bundle);
	int32_t nn = 0;
	if(name)
    {
		const int namelen = strlen(name);
		ose_snprintfi(buf, buflen, n, nn, "%s", name);
		for(int i = 0; i < cols - namelen; i++)
        {
			ose_snprintfi(buf, buflen, n, nn, "%s", "_");
		}
		ose_snprintfi(buf, buflen, n, nn, "%s", "\r\n");
	}
	ose_snprintfi(buf, buflen, n, nn, "%s", "OFFSET   ADDRESS");
	for(int i = 0; i < (cols / 2) - 16; i++)
    {
		ose_snprintfi(buf, buflen, n, nn, "%s", " ");
	}
	ose_snprintfi(buf, buflen, n, nn, "%s", "TT DATA\r\n");
	nn += ose_pprintFullBundle_r(bundle,
                                 buf, buflen,
                                 o, s, 0, 1);
	return nn;
}

void ose_pprintFullBundle(ose_constbundle src,
                          ose_bundle dest,
                          const char * const name)
{
	int32_t o = ose_getLastBundleElemOffset(dest);
	if(o < ose_readSize(dest))
    {
		o += ose_readInt32(dest, o) + 4;
	}
	int32_t s = ose_readInt32(dest, o);
	ose_writeInt32(dest, o, 0);
	char *p = ose_getBundlePtr(dest);
	int32_t n = ose_pprintFullBundle_impl(src,
                                          p + o + 12,
                                          s - 12,
                                          name);
	int32_t pn = ose_pnbytes(n);
	ose_writeInt32(dest, o, pn + 8);
	ose_writeByte(dest, o + 8, OSETT_ID);
	ose_writeByte(dest, o + 9, OSETT_STRING);
	ose_addToSize(dest, pn + 12);
}
