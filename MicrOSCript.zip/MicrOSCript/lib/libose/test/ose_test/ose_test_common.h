/*
  Copyright (c) 2020-23 John MacCallum Permission is hereby granted,
  free of charge, to any person obtaining a copy of this software
  and associated documentation files (the "Software"), to deal in
  the Software without restriction, including without limitation the
  rights to use, copy, modify, merge, publish, distribute,
  sublicense, and/or sell copies of the Software, and to permit
  persons to whom the Software is furnished to do so, subject to the
  following conditions:

  The above copyright notice and this permission notice shall be
  included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
  DEALINGS IN THE SOFTWARE.
*/

/**
 * @file ose_test_common.h
 *
 * @brief provides utility functions and global variables for
 * testing
 */

/**
 * @page testing Testing
 * @tableofcontents
 * @brief describes the test suite
 *
 * Testing is done by writing a program that consists of a number of
 * _test functions_, each of which may consist of any number of
 * _tests_.
 *
 * @code{.c}
 * void function1(void)
 * {
 *     // test 1
 *     // test 2
 *     // ...
 * }
 *
 * void function2(void)
 * {
 *     // test 1
 *     // test 2
 *     // ...
 * }
 *
 * int main(int ac, char **av)
 * {
 *     init();
 *     // test function1
 *     // test function2
 *     finalize();
 * }
 * @endcode
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdarg.h>
#include <signal.h>
#include <setjmp.h>
#include <time.h>

#include "ose.h"
#include "ose_util.h"
#include "ose_context.h"
#include "ose_print.h"


/**
 * @cond DOXYGEN_SKIP
 * Used for printing
 */
#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_YELLOW  "\x1b[33m"
#define ANSI_COLOR_BLUE    "\x1b[34m"
#define ANSI_COLOR_MAGENTA "\x1b[35m"
#define ANSI_COLOR_CYAN    "\x1b[36m"
#define ANSI_COLOR_RESET   "\x1b[0m"
/** @endcond */ // DOXYGEN_SKIP

/**
 * @brief The return code for a failed assertion.
 *
 * @details Test functions may intentionally call functions
 * with conditions that will cause an assertion to fail, in
 * which case this will be returned and compared to the
 * test's expected_result.
 */
const int32_t ASSERTION_FAILED = 0x66666666;

/**
 * @brief The return code for a passed assertion.
 *
 * @note This is currently unused.
 */
const int32_t ASSERTION_PASSED = 0x33333333;

/**
 * @internal
 * @brief jmp_buf for returning to the point before code was
 * entered that triggered an assertion.
 *
 * @details Tests can be written that intentionally cause an
 * assertion to fail. `setjmp` is called before entering test code,
 * so when an assertion fails, control will jump back to the point
 * before the test code was entered, and a value of
 * #ASSERTION_FAILED will be produced as the result of the test,
 * which can be compared with an expected result.
 */
jmp_buf env;

/**
 * @internal
 * @brief Keeps track of the total number of failed test functions.
 */
int grand_total_failctr;

/**
 * @internal
 * @brief Keeps track of the total number of test functions.
 */
int grand_total_testctr;

/**
 * @internal
 * @brief Keeps track of the total number of test functions skipped.
 */
int test_functions_skipped;

/**
 * @internal
 * @brief Keeps track of the number of failed tests per test function.
 */
int failctr;

/**
 * @internal
 * @brief Keeps track of the number of tests per test function.
 */
int testctr;

/**
 * @internal
 * @brief Keeps track of the number of tests skipped per test function.
 */
int tests_skipped;

/**
 * @brief Enable / disable verbosity.
 *
 * @details Use this flag to enable extra printing to the
 * console during testing. It may be switched on and off as
 * desired, for example when verbosity is needed only for a
 * specific test function.
 */
int verbose = 0;

/**
 * @brief The size of a simple bundle.
 */
#define MAX_BNDLSIZE 1024

/**
 * @brief Perform a byte-for-byte comparison of two bundles.
 */
#define COMPARE_BUNDLES(refbndl, testbndl)                  \
    memcmp(refbndl, testbndl, 4 + ntohl(*((int32_t *)refbndl)))

/** @cond DOXYGEN_SKIP */
void sighandler(int signo)
{
	if(signo == SIGABRT){
		longjmp(env, ASSERTION_FAILED);
	}
}
/** @endcond */ // DOXYGEN_SKIP

/**
 * @internal
 * @brief Align a pointer to a 4-byte boundary.
 */
static char *align(char *p)
{
	while((long)p % 4){
		p++;
	}
	return p;
}

/**
 * @brief Format and print the contents of a bundle to stderr.
 *
 * @details This function is mainly useful for debugging in
 * gdb or llvm when the debugger is paused and you want to
 * see the contents of a bundle. `stderr` is used so that
 * the output can be redirected to another tty.
 *
 * @param bundle the bundle to print
 * @param str an identifier for the bundle---useful when
 * printing many different bundles in the same session
 */
static void pbndl(ose_bundle bundle, const char * const str)
{
    char buf[65536];
    memset(buf, 0, 65536);
    ose_pprintBundle(bundle, buf, 65536);
    fprintf(stderr, "\n\r%s>>>>>\n\r%s\n\r%s<<<<<\n\r",
            str, buf, str);
}

/**
 * @brief Print each byte of a bundle on a separate line to stderr.
 *
 * @details This function is mainly useful for debugging in
 * gdb or llvm when the debugger is paused and you want to
 * see the contents of a bundle. `stderr` is used so that
 * the output can be redirected to another tty.
 *
 * @param bundle the bundle to print
 * @param start the index of the first byte to print (-4 to
 * start with the size field of the bundle)
 * @param end the index of the last byte to print
 */
static void pbytes(ose_bundle bundle, int32_t start, int32_t end)
{
    char *b = ose_getBundlePtr(bundle);
    for(int32_t i = start; i < end; i++){
        fprintf(stderr, "%d: %c %d\n\r", i,
                (unsigned char)b[i],
                (unsigned char)b[i]);
    }
}

/**
 * @brief Print a message indicating that the current test passed.
 */
static void print_passed(const char * const fname)
{
	printf(ANSI_COLOR_GREEN "%d / %d tests PASSED" ANSI_COLOR_RESET "\n",
	       testctr - tests_skipped, testctr);
	if(tests_skipped){
		printf(ANSI_COLOR_YELLOW "%d tests SKIPPED" ANSI_COLOR_RESET "\n",
		       tests_skipped);
	}
}

/**
 * @brief Print a message indicating that the current test failed.
 */
static void print_failed(const char * const fname)
{
	printf(ANSI_COLOR_RED "...%d of %d tests FAILED" ANSI_COLOR_RESET "\n",
	       failctr, testctr);
}

/**
 * @brief Print the results of the current test.
 */
static void print_results(const char * const fname)
{
	if(!testctr){
		printf(ANSI_COLOR_RED
		       "NO TESTS PERFORMED for this unit"
		       ANSI_COLOR_RESET
		       "\n");
		return;
	}
	if(!failctr){
		print_passed(fname);
	}else{
		print_failed(fname);
	}
}

/**
 * @brief Initialize global variables and print a preamble
 * for a test.
 */
static void print_startTest(const char * const fname)
{
	failctr = 0;
	testctr = 0;
	printf(ANSI_COLOR_CYAN
	       "Testing %s..."
	       ANSI_COLOR_RESET
	       "\n",
	       fname);
}

/**
 * @brief Test a function.
 *
 * @details This is the basic macro that test functions of
 * any sort (unit, etc.) should use to perform their
 * tests. It handles any global variables, results printing,
 * etc. 
 *
 * @param pfx the prefix for the type of test (ut_, etc.)
 * @param fn the function under test
 */
#define TEST_FUNCTION(pfx, fn)					\
	{                                           \
		tests_skipped = 0;                      \
		grand_total_testctr++;                  \
		print_startTest(#fn);                   \
		int fc = failctr;                       \
		pfx ## fn();                            \
		print_results(#fn);                     \
		if(fc != failctr){                      \
			grand_total_failctr++;              \
		}                                       \
	}

/**
 * @brief Skip a test function.
 *
 * @details This function allows a test function to be
 * disabled by placing the `SKIP_` prefix in front of
 * `TEST_FUNCTION`, and will keep track of any skipped test
 * functions to note their existence at the end of the run.
 *
 * @param fn the function under test (being skipped)
 */
#define SKIP_TEST_FUNCTION(fn)                  \
	test_functions_skipped++;                   \
	grand_total_testctr++;                      \
	printf(ANSI_COLOR_YELLOW                    \
	       "SKIPPING %s : "                     \
	       ANSI_COLOR_RESET                     \
	       "\n",                                \
	       #fn)

/**
 * @brief Skip an individual test.
 *
 * @details This function allows a single test to be
 * disabled. It will keep track of any skipped tests to note
 * their existence at the end of the run.
 *
 * @param test the test being skipped
 * @param expected_result the expected result of the test
 * being skipped
 */
#define SKIP_TEST(test, expected_result)        \
	{                                           \
		tests_skipped++;                        \
		testctr++;                              \
		printf(ANSI_COLOR_YELLOW                \
		       "\nSKIPPING test %s"             \
		       ANSI_COLOR_RESET                 \
		       "\n",                            \
		       #test);                          \
	}

/**
 * @brief Initialize the testing system.
 *
 * @details This should be called before running any test
 * functions in a particular file (i.e. in `main`).
 */
static void init(void)
{
	signal(SIGABRT, sighandler);
    /* memset(true256, OSETT_TRUE, 256); */
	/* memset(false256, OSETT_FALSE, 256); */
	srand(time(NULL));
	grand_total_testctr = grand_total_failctr = 0;
	test_functions_skipped = tests_skipped = 0;
}

/**
 * @brief Finalize the testing system.
 *
 * @details This should be called after finishing all test
 * functions in a particular file (i.e. in `main`).
 */
static void finalize(void)
{
	printf("\n**************************************************\n");
	if(!grand_total_failctr){
		printf(ANSI_COLOR_GREEN
		       "%d / %d TESTS PASSED"
		       ANSI_COLOR_RESET
		       "\n",
		       grand_total_testctr - test_functions_skipped,
		       grand_total_testctr);
		if(test_functions_skipped){
			printf(ANSI_COLOR_YELLOW
			       "%d TESTS SKIPPED"
			       ANSI_COLOR_RESET
			       "\n",
			       test_functions_skipped);
		}
	}else{
		printf(ANSI_COLOR_RED
		       "%d / %d TESTS FAILED"
		       ANSI_COLOR_RESET
		       "\n",
		       grand_total_failctr,
		       grand_total_testctr);
	}
	printf("**************************************************\n");
}
