/*
  Copyright (c) 2020-23 John MacCallum Permission is hereby granted,
  free of charge, to any person obtaining a copy of this software
  and associated documentation files (the "Software"), to deal in
  the Software without restriction, including without limitation the
  rights to use, copy, modify, merge, publish, distribute,
  sublicense, and/or sell copies of the Software, and to permit
  persons to whom the Software is furnished to do so, subject to the
  following conditions:

  The above copyright notice and this permission notice shall be
  included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
  DEALINGS IN THE SOFTWARE.
*/

/**
 * @file ose_test_unit.h
 *
 * @brief provides unit testing functions for OSE/OSC bundles.
 */

/**
 * @page testing Testing
 *
 * @section sec_test_unit Unit Testing
 *
 * @code{.c}
 * void ut_function1(void)
 * {
 *		UNIT_TEST_BUNDLE_TRANSFORM(...);
 *		UNIT_TEST_BUNDLE_TRANSFORM(...);
 *		// additional tests
 * }
 *
 * void ut_function2(void)
 * {
 *		UNIT_TEST_BUNDLE_TRANSFORM(...);
 *		UNIT_TEST_BUNDLE_TRANSFORM(...);
 *		// additional tests
 * }
 *
 * int main(int ac, char **av)
 * {
 *     init();
 *     UNIT_TEST_FUNCTION(function1);
 *     UNIT_TEST_FUNCTION(function2);
 *     finalize();
 * }
 * @endcode
 */

#include "ose_test_bundleLiteral.h"

/**
 * @brief Run a unit test for a function.
 *
 * @details This is the basic macro that executes a unit test
 * function. `fn` is the function under test, and this macro will
 * execute a function with the name of `fn` with the prefix `ut_`
 * prepended to it.
 *
 * @param fn the function under test
 */
#define UNIT_TEST_FUNCTION(fn) TEST_FUNCTION(ut_, fn)

/**
 * @brief Skip a unit test function.
 *
 * @details This allows a test function to be skipped by simply
 * prepending `SKIP_` to the #UNIT_TEST_FUNCTION
 * macro. Additionally, all skipped functions will be counted and
 * reported as such.
 *
 * @param fn the function under test that is being skipped
 */
#define SKIP_UNIT_TEST_FUNCTION(fn) SKIP_TEST_FUNCTION(fn)

/**
 * @brief Print each byte of a bundle.
 *
 * @details This is a utility function that prints each byte of a
 * bundle, using hex representation for unprintable characters.
 *
 * @param b the bundle to print
 */
void printb(const char * const b)
{
	if(b){
		// prevent load of misaligned address runtime error
		char buf[8];
		char *p = align(buf);
		for(int i = 0; i < 4; i++){
			p[i] = b[i];
		}
		int32_t s = htonl(*((int32_t *)p));
		for(int32_t i = 0; i < s + 4; i++){
			if(b[i] <= 32 || b[i] > 127){
				printf("\\x%02x", b[i]);
			}else{
				printf("%c", b[i]);
			}
		}
	}else{
		printf("NULL");
	}
}

/**
 * @brief Execute a unit test.
 *
 * @details This function executes a unit test, and prints the
 * results. It is intended to be wrapped by another macro that
 * provides the file name, function name, and line number (see
 * #UNIT_TEST).
 *
 * @param test the test to execute
 * @param expected_result the expected result
 * @param desc a description of the test
 * @param file the name of the file in which the test is taking place
 * @param func the test function
 * @param line the line number of the test
 *
 * @see UNIT_TEST
 * @see UNIT_TEST_WITH_SIMPLE_BUNDLE
 */
#define UNIT_TEST_IMPL(test,                            \
                       expected_result,                 \
                       desc,                            \
                       file,                            \
                       func,                            \
                       line)                            \
	{                                                   \
		testctr++;                                      \
		int32_t r = ASSERTION_FAILED;                   \
		if(!setjmp(env)){                               \
			r = test;                                   \
		}                                               \
		if(r != expected_result){                       \
			printf(ANSI_COLOR_RED                       \
			       "TEST %d FAILED: "                   \
			       ANSI_COLOR_RESET                     \
			       "%s:%s:%d:\n"                        \
			       "expected %d, but got %d\n",         \
			       testctr,                             \
			       file, func, line,                    \
			       expected_result, r);                 \
            failctr++;                                  \
		}else if(verbose){                              \
			printf(ANSI_COLOR_GREEN                     \
			       "TEST %d PASSED:\n"                  \
			       ANSI_COLOR_RESET                     \
			       "%s = %d\n",                         \
			       testctr, #test, expected_result);    \
		}                                               \
	}                                                   \

/**
 * @brief Execute a unit test.
 *
 * @details This is the basic unit test macro. It executes `test`
 * and compares the result with `expected_result` and prints the
 * result.
 *
 * @param test the test to execute
 * @param expected_result the expected result
 * @param desc a description of the test
 */
#define UNIT_TEST(test, expected_result, desc)		\
	UNIT_TEST_IMPL(test, expected_result, desc,     \
                   __FILE__, __func__, __LINE__);
	
/**
 * @brief Execute a unit test that requires a bundle.
 *
 * @details This macro executes `test`, which may include reference
 * to an #ose_bundle called `bundle`.
 *
 * @param b an OSC bundle whose contents will be copied into a fresh
 * #ose_bundle.
 * @param test the test to execute
 * @param expected_result the expected result
 * @param desc a description of the test
 */
#define UNIT_TEST_WITH_SIMPLE_BUNDLE(b,                         \
                                     test,                      \
                                     expected_result,           \
                                     desc)                      \
	{                                                           \
        char buf[MAX_BNDLSIZE] __attribute__ ((aligned (16)));  \
		char *p = NULL;                                         \
		ose_bundle bundle;                                      \
		if(b){                                                  \
			p = buf;                                            \
			memcpy(p, b, sizeof(b));                            \
			bundle = ose_makeBundle(p + 4);                     \
		}else{                                                  \
            /* for testing NULL pointer input */                \
			bundle = ose_makeBundle(p);                         \
		}                                                       \
		if(verbose){                                            \
			printf("bundle = ");                                \
			printb(b);                                          \
			printf("\n");                                       \
		}                                                       \
		UNIT_TEST(test, expected_result, desc);                 \
	}

#define UNIT_TEST_WITH_CONTEXT_BUNDLE_IMPL(testbndl,                    \
                                           bundle_literal,              \
                                           bundle_literal_size,         \
                                           copy_offset,                 \
                                           call_offset,                 \
                                           test,                        \
                                           expected_result,             \
                                           desc)                        \
    {                                                                   \
        ose_bundle bundle = (ose_bundle){NULL};                         \
        char buf[bundle_literal_size + 4]                           \
                __attribute__ ((aligned (16)));                         \
        if(testbndl){                                                   \
            memcpy(buf, bundle_literal, bundle_literal_size + 4);       \
            char *p = buf + copy_offset;                                \
            bundle.b = buf + call_offset;                               \
            int32_t sizeofb = sizeof(testbndl);                         \
            int32_t size1 = ose_ntohl(*((int32_t *)(p - 4)));           \
            int32_t size2 = ose_ntohl(*((int32_t *)(p + size1)));       \
            *((int32_t *)(p + size1)) = 0;                              \
            memcpy(p - 4, testbndl, sizeofb);                           \
            *((int32_t *)(p + (sizeofb - 4)))                           \
                = ose_htonl(size2 - (sizeofb - 20));                    \
        }else{                                                          \
        }                                                               \
        UNIT_TEST(test, expected_result, desc);                         \
        if(verbose){                                                    \
            printf("result bundle = ");                                 \
            printb(bundle.b + ose_test_bundle_context_message_workingbundle_size_offset); \
            printf("\n");                                               \
        }                                                               \
    }

/**
 * @brief Execute a unit test that requires a context bundle.
 *
 * @details This macro executes a unit test that can refer to a
 * context bundle present in an #ose_bundle called `bundle`.
 *
 * @param testbndl an OSC bundle whose contents will be copied into
 * a context bundle inside a fresh #ose_bundle
 * @param test the test to execute
 * @param expected_result the expected result
 * @param desc a description of the test
 */
#define UNIT_TEST_WITH_CONTEXT_BUNDLE(testbndl,                         \
                                      test,                             \
                                      expected_result,                  \
                                      desc)                             \
    UNIT_TEST_WITH_CONTEXT_BUNDLE_IMPL(testbndl,                        \
                                       ose_test_bundle,                 \
                                       ose_test_bundle_main_bundle_size, \
                                       ose_test_bundle_context_message_workingbundle_id_offset, \
                                       ose_test_bundle_context_message_workingbundle_id_offset, \
                                       test,                            \
                                       expected_result,                 \
                                       desc)

/**
 * @brief Execute a unit test that requires the VM.
 *
 * @details This macro executes a test that may refer to a VM called
 * bundle. The contents of `testbndl` will be copied onto the stack
 * of a freshly created VM.
 *
 * @param testbndl the OSC bundle that will be copied onto the stack
 * of a VM.
 * @param test the test to execute
 * @param expected_result the expected result
 * @param desc a description of the test
 */
#define UNIT_TEST_WITH_VM(testbndl,                                     \
                          test,                                         \
                          expected_result,                              \
                          desc)                                         \
    UNIT_TEST_WITH_CONTEXT_BUNDLE_IMPL(testbndl,                        \
                                       ose_test_vm,                     \
                                       ose_test_vm_main_bundle_size,    \
                                       ose_test_vm_stack_message_workingbundle_id_offset, \
                                       ose_test_vm_context_message_workingbundle_id_offset, \
                                       test,                            \
                                       expected_result,                 \
                                       desc)

/**
 * @brief Execute a test that transforms the contents of a bundle.
 *
 * @details This macro executes a test that transforms the contents
 * of an #ose_bundle called `bundle`.
 *
 * @param testfn the function to test
 * @param testbndl an OSC bundle that will be copied into a fresh
 * #ose_bundle called `bundle`
 * @param resultbndl an OSC bundle that `testbndl` will be compared
 * to after `testfn` has been called on it
 * @param desc a description of the test
 */
#define UNIT_TEST_BUNDLE_TRANSFORM(testfn,                  \
                                   testbndl,                \
                                   resultbndl,              \
                                   desc)                    \
    if(verbose){                                            \
        printf("test bundle = ");                           \
        printb(testbndl);                                   \
        printf("\n");                                       \
        printf("expected result = ");                       \
        printb(resultbndl);                                 \
        printf("\n");                                       \
    }                                                       \
    UNIT_TEST_WITH_CONTEXT_BUNDLE(                          \
        testbndl,                                           \
        (testfn(bundle),                                    \
         COMPARE_BUNDLES(resultbndl,                        \
                         ose_getBundlePtr(bundle) - 4)),    \
        0,                                                  \
        desc);                                              
    
/**
 * @brief Execute a test that transforms the contents of a bundle,
 * where the test function takes one or more arguments in addition
 * to a bundle.
 *
 * @details This macro is identical to #UNIT_TEST_BUNDLE_TRANSFORM,
 * except that `testfn` takes one or more arguments in addition to
 * an #ose_bundle.
 *
 * @param testfn the function to test
 * @param testbndl an OSC bundle that will be copied into a fresh
 * #ose_bundle called `bundle`
 * @param resultbndl an OSC bundle that `testbndl` will be compared
 * to after `testfn` has been called on it
 * @param desc a description of the test
 * @param ... additional arguments to pass to `testfn`
 */
#define UNIT_TEST_BUNDLE_TRANSFORM_ARGS(testfn,             \
                                        testbndl,           \
                                        resultbndl,         \
                                        desc,               \
                                        ...)                \
    UNIT_TEST_WITH_CONTEXT_BUNDLE(                          \
        testbndl,                                           \
        (testfn(bundle, __VA_ARGS__),                       \
         COMPARE_BUNDLES(resultbndl,                        \
                         ose_getBundlePtr(bundle) - 4)),    \
        0,                                                  \
        desc);

/**
 * @brief Execute a test that should fail with a triggered assertion.
 *
 * @details This macro is similar to #UNIT_TEST_BUNDLE_TRANSFORM and
 * #UNIT_TEST_BUNDLE_TRANSFORM_ARGS, except that it expects an
 * assertion to fail, and thus does not take a `resultbndl`
 * parameter, since no transformation of `testbndl` is actually
 * performed.
 *
 * @param testfn the function to test
 * @param testbndl an OSC bundle that will be copied into a fresh
 * #ose_bundle called `bundle`
 * @param desc a description of the test
 */
#define UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(testfn,    \
                                                     testbndl,  \
                                                     desc)      \
    UNIT_TEST_WITH_CONTEXT_BUNDLE(testbndl,                     \
                                  (testfn(bundle), 0),          \
                                  ASSERTION_FAILED,             \
                                  desc);

/**
 * @brief Execute a test that should fail with a triggered assertion.
 *
 * @details This macro is similar to #UNIT_TEST_BUNDLE_TRANSFORM and
 * #UNIT_TEST_BUNDLE_TRANSFORM_ARGS, except that it expects an
 * assertion to fail, and thus does not take a `resultbndl`
 * parameter, since no transformation of `testbndl` is actually
 * performed.
 *
 * @param testfn the function to test
 * @param testbndl an OSC bundle that will be copied into a fresh
 * #ose_bundle called `bundle`
 * @param desc a description of the test
 * @param ... additional arguments to be passed to `testfn`
 */
#define UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION_ARGS(testfn,   \
                                                          testbndl, \
                                                          desc,     \
                                                          ...)      \
    UNIT_TEST_WITH_CONTEXT_BUNDLE(testbndl,                         \
                                  (testfn(bundle, __VA_ARGS__), 0), \
                                  ASSERTION_FAILED,                 \
                                  desc);

/**
 * @brief Execute a test that runs the VM and results in a
 * particular error code being set.
 *
 * @details This function creates a fresh VM and places the contents
 * of `testbndl` on the stack, then calls `testfn` and checks the
 * error code of the VM, which should be the same as `errno`.
 *
 * @param testfn the function under test
 * @param testbndl the bundle that will be placed on the stack of a
 * fresh VM
 * @param errno the error code that should be set
 * @param desc a description of the test
 */
#define UNIT_TEST_VM_ERRNO(testfn,              \
                           testbndl,            \
                           errno,               \
                           desc)                \
    UNIT_TEST_WITH_VM(testbndl,                 \
                      (testfn(bundle),          \
                       ose_errno_get(bundle)),  \
                      errno,                    \
                      desc)

/**
 * @brief Execute a test that runs the VM and compare the contents
 * of the stack with a bundle.
 *
 * @details This function creates a fresh VM and copies the contents
 * of `testbndl` onto the stack. It then runs `testfn` and compares
 * the stack to `resultbndl`, which should be the same.
 *
 * @param testfn the function under test
 * @param testbndl the bundle that will be placed on the stack of a
 * fresh VM
 * @param resultbndl the expected result bundle
 * @param desc a description of the test
 */
#define UNIT_TEST_VM_STACK_COMPARE(testfn,                              \
                                   testbndl,                            \
                                   resultbndl,                          \
                                   desc)                                \
    UNIT_TEST_WITH_VM(testbndl,                                         \
                      (testfn(bundle),                                  \
        ose_errno_get(bundle) == OSE_ERR_NONE \
                       && !COMPARE_BUNDLES(resultbndl,                   \
                                          buf + ose_test_vm_stack_message_workingbundle_size_offset)), \
                      1,                                                \
                      desc)

/**
 * @brief Skip the execution of a unit test.
 *
 * @param b the bundle
 * @param test the test to be skipped
 * @param expected_result the expected reselt
 */
#define SKIP_UNIT_TEST_WITH_BUNDLE(b, test, expected_result)	\
	SKIP_TEST(test, expected_result)

/**
 * @brief Skip the execution of a unit test.
 *
 * @param test the test to be skipped
 * @param expected_result the expected result
 */
#define SKIP_UNIT_TEST(test, expected_result)	\
	SKIP_TEST(test, expected_result)
