#include "ose_test_common.h"
#include "ose_test_unit.h"
#include "ose_test_ctosc.h"
#include "../ose_stackops.h"

void ut_ose_pushInt32(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION_ARGS(ose_pushInt32,
                                                      NULL,
                                                      "NULL bundle",
                                                      10);
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(ose_pushInt32,
                                    B(),
                                    B(BE_M(A(0, ""),
                                           T(1, "i"),
                                           Di(10))),
                                    "push int into empty bundle",
                                    10);
}

void ut_ose_pushFloat(void)
{
	UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION_ARGS(ose_pushFloat,
                                                      NULL,
                                                      "NULL bundle",
                                                      10.);
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(ose_pushFloat,
                                    B(),
                                    B(BE_M(A(0, ""),
                                           T(1, "f"),
                                           Df(10.))),
                                    "push float into empty bundle",
                                    10.);
}

void ut_ose_pushString(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION_ARGS(
        ose_pushString,
        NULL,
        "NULL bundle",
        "foo");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION_ARGS(
        ose_pushString,
        B(),
        "NULL string",
        NULL);
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushString,
        B(),
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(0, ""))),
        "push empty string into empty bundle",
        "");
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushString,
        B(),
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(1, "a"))),
        "push 1 char string into empty bundle",
        "a");
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushString,
        B(),
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(2, "ab"))),
        "push 2 char string into empty bundle",
        "ab");
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushString,
        B(),
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(3, "abc"))),
        "push empty string into empty bundle",
        "abc");
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushString,
        B(),
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(4, "abcd"))),
        "push 4 char string into empty bundle",
        "abcd");
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushString,
        B(),
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(5, "abcde"))),
        "push 5 char string into empty bundle",
        "abcde");
    char *str = NULL;
	UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(),
        (
            str = (char[]){'f', 'o', 'o', 0},
            ose_pushString(bundle, str),
            str[0] = 0,
            COMPARE_BUNDLES(B(BE_M(A(0, ""),
                                   T(1, "s"),
                                   Ds(3, "foo"))),
                            ose_getBundlePtr(bundle) - 4)
            ),
        0,
        "test that ose_pushString makes a copy of its arg");
}

void ut_ose_pushBlob(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION_ARGS(
        ose_pushBlob,
        NULL,
        "NULL bundle",
        0, NULL);
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION_ARGS(
        ose_pushBlob,
        NULL,
        "negative size",
        -4, NULL);
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushBlob,
        B(),
        B(BE_M(A(0, ""),
               T(1, "b"),
               Db(0, ""))),
        "NULL blob, zero length",
        0, NULL);
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushBlob,
        B(),
        B(BE_M(A(0, ""),
               T(1, "b"),
               Db(2, "\0\0"))),
        "NULL blob, nonzero length",
        2, NULL);
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushBlob,
        B(),
        B(BE_M(A(0, ""),
               T(1, "b"),
               Db(1, "\x01"))),
        "1 char blob",
        1, "\x01");
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushBlob,
        B(),
        B(BE_M(A(0, ""),
               T(1, "b"),
               Db(2, "\x01\x02"))),
        "2 char blob",
        2, "\x01\x02");
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushBlob,
        B(),
        B(BE_M(A(0, ""),
               T(1, "b"),
               Db(3, "\x01\x02\x03"))),
        "3 char blob",
        3, "\x01\x02\x03");
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushBlob,
        B(),
        B(BE_M(A(0, ""),
               T(1, "b"),
               Db(4, "\x01\x02\x03\x04"))),
        "4 char blob",
        4, "\x01\x02\x03\x04");
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushBlob,
        B(),
        B(BE_M(A(0, ""),
               T(1, "b"),
               Db(5, "\x01\x02\x03\x04\x05"))),
        "5 char blob",
        5, "\x01\x02\x03\x04\x05");
    
    char *str = NULL;
	UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(),
        (
            str = (char[]){'f', 'o', 'o'},
            ose_pushBlob(bundle, 3, str),
            str[0] = 0,
            COMPARE_BUNDLES(B(BE_M(A(0, ""),
                                   T(1, "b"),
                                   Db(3, "foo"))),
                            ose_getBundlePtr(bundle) - 4)
            ),
        0,
        "test that ose_pushBlob makes a copy of its arg");
}

void ut_ose_pushSymbol(void)
{

}

void ut_ose_pushDouble(void)
{

}

void ut_ose_pushInt8(void)
{

}

void ut_ose_pushUInt8(void)
{

}

void ut_ose_pushUInt32(void)
{

}

void ut_ose_pushInt64(void)
{

}

void ut_ose_pushUInt64(void)
{

}

void ut_ose_pushTimetag(void)
{

}

void ut_ose_pushTrue(void)
{

}

void ut_ose_pushFalse(void)
{

}

void ut_ose_pushNull(void)
{

}

void ut_ose_pushInfinitum(void)
{

}

#define ALIGNEDPTR_MAGIC 0x06660000
int32_t alignedPtrFn(int32_t v)
{
    return ALIGNEDPTR_MAGIC + v;
}

void ut_ose_pushAlignedPtr(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION_ARGS(
        ose_pushAlignedPtr,
        NULL,
        "NULL bundle",
        alignedPtrFn);

    int32_t (*f)(int32_t);
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(),
        (ose_pushAlignedPtr(bundle, alignedPtrFn),
         f = ose_peekAlignedPtr(bundle),
         f(32)),
        32 + ALIGNEDPTR_MAGIC,
        "push, peek, and call aligned ptr fn");
         
}

void ut_ose_pushMessage(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION_ARGS(
        ose_pushMessage,
        NULL,
        "NULL bundle",
        OSE_ADDRESS_ANONVAL, OSE_ADDRESS_ANONVAL_LEN, 0);
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION_ARGS(
        ose_pushMessage,
        NULL,
        "NULL address",
        NULL, 0, 0);
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION_ARGS(
        ose_pushMessage,
        NULL,
        "negative address len",
        "/bad", -4, 0);
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION_ARGS(
        ose_pushMessage,
        NULL,
        "negative n",
        "/bad", 4, -2);
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushMessage,
        B(),
        B(BE_M(A(0, ""),
               T(0, ""))),
        "anonval address, no args",
        OSE_ADDRESS_ANONVAL, OSE_ADDRESS_ANONVAL_LEN, 0);
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushMessage,
        B(),
        B(BE_M(A(2, "/x"),
               T(0, ""))),
        "address, no args",
        "/x", 2, 0);
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushMessage,
        B(),
        B(BE_M(A(2, "/x"),
               T(1, "i"),
               Di(10))),
        "address, int",
        "/x", 2, 1, OSETT_INT32, 10);
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushMessage,
        B(),
        B(BE_M(A(2, "/x"),
               T(1, "f"),
               Df(10.))),
        "address, float",
        "/x", 2, 1, OSETT_FLOAT, 10.);
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushMessage,
        B(),
        B(BE_M(A(2, "/x"),
               T(1, "s"),
               Ds(3, "foo"))),
        "address, string",
        "/x", 2, 1, OSETT_STRING, "foo");
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushMessage,
        B(),
        B(BE_M(A(2, "/x"),
               T(1, "b"),
               Db(3, "\x01\x02\x03"))),
        "address, blob",
        "/x", 2, 1, OSETT_BLOB, 3, "\x01\x02\x03");
    UNIT_TEST_BUNDLE_TRANSFORM_ARGS(
        ose_pushMessage,
        B(),
        B(BE_M(A(4, "/foo"),
               T(4, "ifsb"),
               Di(10),
               Df(20.),
               Ds(6, "thirty"),
               Db(2, "40"))),
        "address, ifsb",
        "/foo", 4, 4,
        OSETT_INT32, 10,
        OSETT_FLOAT, 20.,
        OSETT_STRING, "thirty",
        OSETT_BLOB, 2, "40");
}

void ut_ose_peekAddress(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_peekAddress,
        NULL,
        "NULL bundle");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(B(),
                                  (ose_peekAddress(bundle), 0),
                                  ASSERTION_FAILED,
                                  "empty bundle");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(B(BE_M(A(0, ""),
                                         T(1, "i"),
                                         Di(10))),
                                  strcmp(ose_peekAddress(bundle), ""),
                                  0,
                                  "1 message, empty address");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(B(BE_M(A(1, "x"),
                                         T(1, "i"),
                                         Di(10))),
                                  strcmp(ose_peekAddress(bundle),
                                         "x"),
                                  0,
                                  "1 message, 1 char address");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(B(BE_M(A(4, "/foo"),
                                         T(1, "i"),
                                         Di(10))),
                                  strcmp(ose_peekAddress(bundle),
                                         "/foo"),
                                  0,
                                  "1 message, 4 char address");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(B(BE_M(A(5, "/fool"),
                                         T(1, "i"),
                                         Di(10))),
                                  strcmp(ose_peekAddress(bundle),
                                         "/fool"),
                                  0,
                                  "1 message, 5 char address");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(B(BE_B(BE_M(A(5, "/fool"),
                                              T(1, "i"),
                                              Di(10)))),
                                  strcmp(ose_peekAddress(bundle),
                                         "#bundle"),
                                  0,
                                  "1 bundle");

	UNIT_TEST_WITH_CONTEXT_BUNDLE(B(BE_M(A(0, ""),
                                         T(1, "f"),
                                         Df(33.3)),
                                    BE_M(A(0, ""),
                                         T(1, "i"),
                                         Di(10))),
                                  strcmp(ose_peekAddress(bundle), ""),
                                  0,
                                  "2 messages, empty address");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(B(BE_M(A(0, ""),
                                         T(1, "f"),
                                         Df(33.3)),
                                    BE_M(A(1, "x"),
                                         T(1, "i"),
                                         Di(10))),
                                  strcmp(ose_peekAddress(bundle),
                                         "x"),
                                  0,
                                  "2 messages, 1 char address");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(B(BE_M(A(0, ""),
                                         T(1, "f"),
                                         Df(33.3)),
                                    BE_M(A(4, "/foo"),
                                         T(1, "i"),
                                         Di(10))),
                                  strcmp(ose_peekAddress(bundle),
                                         "/foo"),
                                  0,
                                  "2 messages, 4 char address");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(B(BE_M(A(0, ""),
                                         T(1, "f"),
                                         Df(33.3)),
                                    BE_M(A(5, "/fool"),
                                         T(1, "i"),
                                         Di(10))),
                                  strcmp(ose_peekAddress(bundle),
                                         "/fool"),
                                  0,
                                  "2 messages, 5 char address");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(B(BE_M(A(0, ""),
                                         T(1, "f"),
                                         Df(33.3)),
                                    BE_B(BE_M(A(5, "/fool"),
                                              T(1, "i"),
                                              Di(10)))),
                                  strcmp(ose_peekAddress(bundle),
                                         "#bundle"),
                                  0,
                                  "1 message, 1 bundle");
}

void ut_ose_peekMessageArgType(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_peekMessageArgType,
        NULL,
        "NULL bundle");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(),
        (ose_peekMessageArgType(bundle), 0),
        ASSERTION_FAILED,
        "empty bundle");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_B0()),
        (ose_peekMessageArgType(bundle), 0),
        ASSERTION_FAILED,
        "bundle, not message");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(10))),
        ose_peekMessageArgType(bundle),
        OSETT_INT32,
        "1 message, 1 int arg");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(2, "if"),
               Di(10), Df(22.))),
        ose_peekMessageArgType(bundle),
        OSETT_FLOAT,
        "1 message, 2 args");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(3, "ifs"),
               Di(10), Df(22.), Ds(3, "foo"))),
        ose_peekMessageArgType(bundle),
        OSETT_STRING,
        "1 message, 3 args");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(0, ""))),
        ose_peekMessageArgType(bundle),
        OSETT_NOTYPETAG,
        "1 message, no args");
}

void ut_ose_peekType(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_peekType,
        NULL,
        "NULL bundle");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(),
        (ose_peekType(bundle), 0),
        ASSERTION_FAILED,
        "empty bundle");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(33))),
        ose_peekType(bundle),
        OSETT_MESSAGE,
        "message with empty address");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(4, "/foo"),
               T(1, "i"),
               Di(33))),
        ose_peekType(bundle),
        OSETT_MESSAGE,
        "message with address");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_B0()),
        ose_peekType(bundle),
        OSETT_BUNDLE,
        "empty bundle");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_B(BE_M(A(0, ""),
                    T(1, "f"),
                    Df(33.3)))),
        ose_peekType(bundle),
        OSETT_BUNDLE,
        "bundle with message");
}

void ut_ose_peekInt32(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_peekInt32,
        NULL,
        "NULL bundle");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(),
        (ose_peekInt32(bundle), 0),
        ASSERTION_FAILED,
        "empty bundle");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(0, ""))),
        (ose_peekInt32(bundle), 0),
        ASSERTION_FAILED,
        "bundle with one message but no data");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(33))),
        ose_peekInt32(bundle),
        33,
        "bundle with one message and one int");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(2, "ii"),
               Di(33), Di(44))),
        ose_peekInt32(bundle),
        44,
        "bundle with one message and two ints");
}

void ut_ose_peekFloat(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_peekFloat,
        NULL,
        "NULL bundle");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(),
        (ose_peekFloat(bundle), 0),
        ASSERTION_FAILED,
        "empty bundle");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(0, ""))),
        (ose_peekFloat(bundle), 0),
        ASSERTION_FAILED,
        "bundle with one message but no data");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(1, "f"),
               Df(33.))),
        (ose_peekFloat(bundle) == 33.),
        1,
        "bundle with one message and one float");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(2, "ff"),
               Df(33.), Df(44.))),
        (ose_peekFloat(bundle) == 44.),
        1,
        "bundle with one message and two floats");
}

void ut_ose_peekString(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_peekString,
        NULL,
        "NULL bundle");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(),
        (ose_peekString(bundle), 0),
        ASSERTION_FAILED,
        "empty bundle");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(0, ""))),
        (ose_peekString(bundle), 0),
        ASSERTION_FAILED,
        "bundle with one message but no data");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(6, "string"))),
        strcmp(ose_peekString(bundle), "string"),
        0,
        "bundle with one message and one string");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(2, "ss"),
               Ds(4, "here"), Ds(5, "there"))),
        strcmp(ose_peekString(bundle), "there"),
        0,
        "bundle with one message and two strings");
}

void ut_ose_peekBlob(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_peekBlob,
        NULL,
        "NULL bundle");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(),
        (ose_peekBlob(bundle), 0),
        ASSERTION_FAILED,
        "empty bundle");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(0, ""))),
        (ose_peekBlob(bundle), 0),
        ASSERTION_FAILED,
        "bundle with one message but no data");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(1, "b"),
               Db(4, "blob"))),
        memcmp(ose_peekBlob(bundle), "\0\0\0\x04""blob", 8),
        0,
        "bundle with one message and one blobs");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(2, "bb"),
               Db(4, "blob") Db(5, "\0\0\0\0\x99"))),
        memcmp(ose_peekBlob(bundle), "\0\0\0\x05\0\0\0\0\x99", 9),
        0,
        "bundle with one message and two blobs");
}

void ut_ose_peekSymbol(void)
{

}

void ut_ose_peekDouble(void)
{

}

void ut_ose_peekInt8(void)
{

}

void ut_ose_peekUInt8(void)
{

}

void ut_ose_peekUInt32(void)
{

}

void ut_ose_peekInt64(void)
{

}

void ut_ose_peekUInt64(void)
{

}

void ut_ose_peekTimetag(void)
{

}

void ut_ose_peekTrue(void)
{

}

void ut_ose_peekFalse(void)
{

}

void ut_ose_peekNull(void)
{

}

void ut_ose_peekInfinitum(void)
{

}

/* not necessary--covered by ut_ose_pushAlignedPtr() */
/* void ut_ose_peekAlignedPtr(void) */
/* { */

/* } */

void ut_ose_popInt32(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_popInt32,
        NULL,
        "NULL bundle");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(),
        (ose_popInt32(bundle), 0),
        ASSERTION_FAILED,
        "empty bundle");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(0, ""))),
        (ose_popInt32(bundle), 0),
        ASSERTION_FAILED,
        "bundle with one message but no data");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(33))),
        (ose_popInt32(bundle) == 33
         && !COMPARE_BUNDLES(B(), bundle.b - 4)),
        1,
        "bundle with one message and one int");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(2, "ii"),
               Di(33), Di(44))),
        (ose_popInt32(bundle) == 44
         && !COMPARE_BUNDLES(B(), bundle.b - 4)),
        1,
        "bundle with one message and two ints");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(2, "/x"),
               T(1, "s"),
               Ds(3, "foo")),
          BE_M(A(0, ""),
               T(2, "ii"),
               Di(33), Di(44))),
        (ose_popInt32(bundle) == 44
         && !COMPARE_BUNDLES(B(BE_M(A(2, "/x"),
                                    T(1, "s"),
                                    Ds(3, "foo"))),
                             bundle.b - 4)),
        1,
        "bundle with two messages, the last with two ints");
}

void ut_ose_popFloat(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_popFloat,
        NULL,
        "NULL bundle");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(),
        (ose_popFloat(bundle), 0),
        ASSERTION_FAILED,
        "empty bundle");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(0, ""))),
        (ose_popFloat(bundle), 0),
        ASSERTION_FAILED,
        "bundle with one message but no data");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(1, "f"),
               Df(33.))),
        (ose_popFloat(bundle) == 33.
         && !COMPARE_BUNDLES(B(), bundle.b - 4)),
        1,
        "bundle with one message and one float");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(2, "ff"),
               Df(33.), Df(44.))),
        (ose_popFloat(bundle) == 44.
         && !COMPARE_BUNDLES(B(), bundle.b - 4)),
        1,
        "bundle with one message and two floats");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(2, "/x"),
               T(1, "s"),
               Ds(3, "foo")),
          BE_M(A(0, ""),
               T(2, "ff"),
               Df(33.), Df(44.))),
        (ose_popFloat(bundle) == 44.
         && !COMPARE_BUNDLES(B(BE_M(A(2, "/x"),
                                    T(1, "s"),
                                    Ds(3, "foo"))),
                             bundle.b - 4)),
        1,
        "bundle with two messages, the last with two floats");
}

void ut_ose_popString(void)
{
    char str[8];
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        NULL,
        (ose_popString(bundle, str), 0),
        ASSERTION_FAILED,
        "NULL bundle");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(),
        (ose_popString(bundle, str), 0),
        ASSERTION_FAILED,
        "empty bundle");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(0, ""))),
        (ose_popString(bundle, str), 0),
        ASSERTION_FAILED,
        "bundle with one message but no data");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(6, "string"))),
        (memset(str, 0, sizeof(str)),
         ose_popString(bundle, str) == 6
         && !strcmp(str, "string")
         && !COMPARE_BUNDLES(B(), bundle.b - 4)),
        1,
        "bundle with one message and one string");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(2, "ss"),
               Ds(4, "here"), Ds(5, "there"))),
        (memset(str, 0, sizeof(str)),
         ose_popString(bundle, str) == 5
         && !strcmp(str, "there")
         && !COMPARE_BUNDLES(B(), bundle.b - 4)),
        1,
        "bundle with one message and two strings");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(2, "/x"),
               T(1, "s"),
               Ds(3, "foo")),
          BE_M(A(0, ""),
               T(2, "ss"),
               Ds(4, "here"), Ds(5, "there"))),
        (memset(buf, 0, sizeof(str)),
         ose_popString(bundle, str) == 5
         && !strcmp(str, "there")
         && !COMPARE_BUNDLES(B(BE_M(A(2, "/x"),
                                    T(1, "s"),
                                    Ds(3, "foo"))),
                             bundle.b - 4)),
        1,
        "bundle with two messages, the last with two strings");
}

void ut_ose_popBlob(void)
{
    char blob[8];
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        NULL,
        (ose_popBlob(bundle, blob), 0),
        ASSERTION_FAILED,
        "NULL bundle");
	UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(),
        (ose_popBlob(bundle, blob), 0),
        ASSERTION_FAILED,
        "empty bundle");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(0, ""))),
        (ose_popBlob(bundle, blob), 0),
        ASSERTION_FAILED,
        "bundle with one message but no data");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(1, "b"),
               Db(4, "blob"))),
        (memset(blob, 0, sizeof(blob)),
         ose_popBlob(bundle, blob) == 4
         && !memcmp(blob, "blob", 4)
         && !COMPARE_BUNDLES(B(), bundle.b - 4)),
        1,
        "bundle with one message and one blob");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(0, ""),
               T(2, "bb"),
               Db(6, "\0\0here"), Db(7, "\0\0there"))),
        (memset(blob, 0, sizeof(blob)),
         ose_popBlob(bundle, blob) == 7
         && !memcmp(blob, "\0\0there", 7)
         && !COMPARE_BUNDLES(B(), bundle.b - 4)),
        1,
        "bundle with one message and two blobs");
    UNIT_TEST_WITH_CONTEXT_BUNDLE(
        B(BE_M(A(2, "/x"),
               T(1, "s"),
               Ds(3, "foo")),
          BE_M(A(0, ""),
               T(2, "bb"),
               Db(6, "\0\0here"), Db(7, "\0\0there"))),
        (memset(buf, 0, sizeof(blob)),
         ose_popBlob(bundle, blob) == 7
         && !memcmp(blob, "\0\0there", 7)
         && !COMPARE_BUNDLES(B(BE_M(A(2, "/x"),
                                    T(1, "s"),
                                    Ds(3, "foo"))),
                             bundle.b - 4)),
        1,
        "bundle with two messages, the last with two blobs");
}

void ut_ose_popSymbol(void)
{

}

void ut_ose_popDouble(void)
{

}

void ut_ose_popInt8(void)
{

}

void ut_ose_popUInt8(void)
{

}

void ut_ose_popUInt32(void)
{

}

void ut_ose_popInt64(void)
{

}

void ut_ose_popUInt64(void)
{

}

void ut_ose_popTimetag(void)
{

}

/**************************************************
 * Stack Operations
 **************************************************/
void ut_ose_2drop(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_2drop,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_2drop,
                                                 B(),
                                                 "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_2drop,
                                B(BE_M(A(0, ""),
                                       T(1, "i"),
                                       Di(32))),
                                "bundle with only one message");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_2drop,
                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(3.14))),
                               B(),
                               "bundle with 2 messages");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_2drop,
                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_B0()),
                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(32))),
                               "bundle with 3 elems");
}

void ut_ose_2dup(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_2dup,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_2dup,
                                                 B(),
                                                 "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_2dup,
                                B(BE_M(A(2, "/x"),
                                       T(2, "if"),
                                       Di(33),
                                       Df(3.14))),
                                "bundle with only one message");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_2dup,
                               
                               B(BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14))),
                               
                               B(BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14))),
                               
                               "bundle with 2 messages");

    UNIT_TEST_BUNDLE_TRANSFORM(ose_2dup,

                               B(BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/z"),
                                      T(1, "s"),
                                      Ds(3, "foo"))),
                               
                               B(BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/z"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/z"),
                                      T(1, "s"),
                                      Ds(3, "foo"))),
                               
                               "bundle with 2 messages");
}

void ut_ose_2over(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_2over,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_2over,
                                                 B(),
                                                 "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_2over,
                                B(BE_M(A(2, "/x"),
                                       T(2, "if"),
                                       Di(33),
                                       Df(3.14))),
                                "bundle with only one message");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_2over,
                                B(BE_M(A(2, "/x"),
                                       T(1, "i"),
                                       Di(32)),
                                  BE_M(A(2, "/y"),
                                       T(1, "f"),
                                       Df(3.14))),
                                "bundle with only two messages");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_2over,
                                B(BE_M(A(2, "/x"),
                                       T(1, "i"),
                                       Di(32)),
                                  BE_M(A(2, "/y"),
                                       T(1, "f"),
                                       Df(3.14)),
                                  BE_M(A(2, "/z"),
                                       T(1, "s"),
                                       Ds(3, "foo"))),
                                "bundle with only three messages");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_2over,

                               B(BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/z"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(2, "/a"),
                                      T(1, "i"),
                                      Ds(3, "10"))),
                               
                               B(BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/z"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(2, "/a"),
                                      T(1, "i"),
                                      Ds(3, "10")),
                                 BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14))),

                               "bundle with four messages");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_2over,

                               B(BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/z"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(2, "/a"),
                                      T(1, "i"),
                                      Ds(3, "10")),
                                 BE_M(A(2, "/b"),
                                      T(1, "f"),
                                      Ds(3, "22.8"))),

                               B(BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/z"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(2, "/a"),
                                      T(1, "i"),
                                      Ds(3, "10")),
                                 BE_M(A(2, "/b"),
                                      T(1, "f"),
                                      Ds(3, "22.8")),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/z"),
                                      T(1, "s"),
                                      Ds(3, "foo"))),

                               "bundle with five messages");
}

void ut_ose_2swap(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_2swap,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_2swap,
                                                 B(),
                                                 "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_2swap,
                                B(BE_M(A(2, "/x"),
                                       T(2, "if"),
                                       Di(33),
                                       Df(3.14))),
                                "bundle with only one message");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_2swap,
                                B(BE_M(A(2, "/x"),
                                       T(1, "i"),
                                       Di(32)),
                                  BE_M(A(2, "/y"),
                                       T(1, "f"),
                                       Df(3.14))),
                                "bundle with only two messages");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_2swap,
                                B(BE_M(A(2, "/x"),
                                       T(1, "i"),
                                       Di(32)),
                                  BE_M(A(2, "/y"),
                                       T(1, "f"),
                                       Df(3.14)),
                                  BE_M(A(2, "/z"),
                                       T(1, "s"),
                                       Ds(3, "foo"))),
                                "bundle with only three messages");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_2swap,
                               
                               B(BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/z"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(2, "/a"),
                                      T(1, "i"),
                                      Di(10))),

                                   B(BE_M(A(2, "/z"),
                                          T(1, "s"),
                                          Ds(3, "foo")),
                                     BE_M(A(2, "/a"),
                                          T(1, "i"),
                                          Di(10)),
                                     BE_M(A(2, "/x"),
                                          T(1, "i"),
                                          Di(32)),
                                     BE_M(A(2, "/y"),
                                          T(1, "f"),
                                          Df(3.14))),
                               "bundle with four messages");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_2swap,
                               
                               B(BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/z"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(2, "/a"),
                                      T(1, "i"),
                                      Di(10)),
                                 BE_M(A(2, "/b"),
                                      T(1, "f"),
                                      Df(22.8))),

                               B(BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/a"),
                                      T(1, "i"),
                                      Di(10)),
                                 BE_M(A(2, "/b"),
                                      T(1, "f"),
                                      Df(22.8)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/z"),
                                      T(1, "s"),
                                      Ds(3, "foo"))),

                               "bundle with 5 messages");
}

void ut_ose_drop(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_drop,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_drop,
                                                 B(),
                                                 "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_drop,

                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23))),

                               B(),

                               "bundle with 1 message");
	UNIT_TEST_BUNDLE_TRANSFORM(ose_drop,
                               
                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_B0()),

                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23))),

                               "bundle with 2 messages");
}

void ut_ose_dup(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_dup,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_dup,
                                                 B(),
                                                 "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_dup,

                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23))),

                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23))),

                               "bundle with 1 message");
	UNIT_TEST_BUNDLE_TRANSFORM(ose_dup,
                               
                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               "bundle with 2 messages");
}
void ut_ose_nip(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_nip,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_nip,
                                                 B(),
                                                 "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_nip,

                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23))),

                               "bundle with only 1 message");
	UNIT_TEST_BUNDLE_TRANSFORM(ose_nip,
                               
                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               B(BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               "bundle with 2 messages");

    UNIT_TEST_BUNDLE_TRANSFORM(ose_nip,
                               
                               B(BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               B(BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               "bundle with 3 messages");
}
void ut_ose_rrot(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_rrot,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_rrot,
                                                 B(),
                                                 "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_rrot,

                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23))),

                               "bundle with only 1 message");
	UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_rrot,
                               
                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               "bundle with 2 messages");

    UNIT_TEST_BUNDLE_TRANSFORM(ose_rrot,
                               
                               B(BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               B(BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3)),
                                 BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23))),

                               "bundle with 3 messages");

    UNIT_TEST_BUNDLE_TRANSFORM(ose_rrot,
                               
                               B(BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(99))),

                               B(BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(99)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               "bundle with 4 messages");

}
void ut_ose_over(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_over,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_over,
                                                 B(),
                                                 "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_over,

                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23))),

                               "bundle with only 1 message");
	UNIT_TEST_BUNDLE_TRANSFORM(ose_over,
                               
                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23))),

                               "bundle with 2 messages");

    UNIT_TEST_BUNDLE_TRANSFORM(ose_over,
                               
                               B(BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               B(BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23))),

                               "bundle with 3 messages");
}
void ut_ose_pick(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_pick,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_pick,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_pick,
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(0))),
        "bundle with only one message");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_pick,
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(0)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(1))),
        "bundle with two messages, but index out of range");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_pick,
        B(BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10)),
          BE_M(A(2, "/b"),
               T(1, "f"),
               Df(20.)),
          BE_M(A(2, "/c"),
               T(1, "s"),
               Ds(3, "foo")),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(0))),
        B(BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10)),
          BE_M(A(2, "/b"),
               T(1, "f"),
               Df(20.)),
          BE_M(A(2, "/c"),
               T(1, "s"),
               Ds(3, "foo")),
          BE_M(A(2, "/c"),
               T(1, "s"),
               Ds(3, "foo"))),
        "bundle with three messages and one index, pick 0");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_pick,
        B(BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10)),
          BE_M(A(2, "/b"),
               T(1, "f"),
               Df(20.)),
          BE_M(A(2, "/c"),
               T(1, "s"),
               Ds(3, "foo")),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(1))),
        B(BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10)),
          BE_M(A(2, "/b"),
               T(1, "f"),
               Df(20.)),
          BE_M(A(2, "/c"),
               T(1, "s"),
               Ds(3, "foo")),
          BE_M(A(2, "/b"),
               T(1, "f"),
               Df(20.))),
        "bundle with three messages and one index, pick 1");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_pick,
        B(BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10)),
          BE_M(A(2, "/b"),
               T(1, "f"),
               Df(20.)),
          BE_M(A(2, "/c"),
               T(1, "s"),
               Ds(3, "foo")),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(2))),
        B(BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10)),
          BE_M(A(2, "/b"),
               T(1, "f"),
               Df(20.)),
          BE_M(A(2, "/c"),
               T(1, "s"),
               Ds(3, "foo")),
          BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10))),
        "bundle with three messages and one index, pick 2");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_pick,
        B(BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10)),
          BE_M(A(2, "/b"),
               T(1, "f"),
               Df(20.)),
          BE_M(A(2, "/c"),
               T(1, "s"),
               Ds(3, "foo")),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(3))),
        "bundle with three messages and one index, pick 3, out of range");
}

void ut_ose_pickBottom(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_pickBottom,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_pickBottom,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_pickBottom,
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(0))),
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(0)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(0))),
        "bundle with one message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_pickBottom,
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(0)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(1))),
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(0)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(1)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(0))),
        "bundle with two messages");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_pickBottom,
        B(BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10)),
          BE_M(A(2, "/b"),
               T(1, "f"),
               Df(20.)),
          BE_M(A(2, "/c"),
               T(1, "s"),
               Ds(3, "foo"))),
        B(BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10)),
          BE_M(A(2, "/b"),
               T(1, "f"),
               Df(20.)),
          BE_M(A(2, "/c"),
               T(1, "s"),
               Ds(3, "foo")),
          BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10))),
        "bundle with three messages");
}

void ut_ose_pickMatch(void)
{

}
void ut_ose_roll(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_roll,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_roll,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_roll,
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(0))),
        "bundle with only one message");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_roll,
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(0)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(1))),
        "bundle with two messages, but index out of range");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_roll,
        B(BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10)),
          BE_M(A(2, "/b"),
               T(1, "f"),
               Df(20.)),
          BE_M(A(2, "/c"),
               T(1, "s"),
               Ds(3, "foo")),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(0))),
        B(BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10)),
          BE_M(A(2, "/b"),
               T(1, "f"),
               Df(20.)),
          BE_M(A(2, "/c"),
               T(1, "s"),
               Ds(3, "foo"))),
        "bundle with three messages and one index, roll 0");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_roll,
        B(BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10)),
          BE_M(A(2, "/b"),
               T(1, "f"),
               Df(20.)),
          BE_M(A(2, "/c"),
               T(1, "s"),
               Ds(3, "foo")),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(1))),
        B(BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10)),
          BE_M(A(2, "/c"),
               T(1, "s"),
               Ds(3, "foo")),
          BE_M(A(2, "/b"),
               T(1, "f"),
               Df(20.))),
        "bundle with three messages and one index, roll 1");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_roll,
        B(BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10)),
          BE_M(A(2, "/b"),
               T(1, "f"),
               Df(20.)),
          BE_M(A(2, "/c"),
               T(1, "s"),
               Ds(3, "foo")),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(2))),
        B(BE_M(A(2, "/b"),
               T(1, "f"),
               Df(20.)),
          BE_M(A(2, "/c"),
               T(1, "s"),
               Ds(3, "foo")),
          BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10))),
        "bundle with three messages and one index, roll 2");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_roll,
        B(BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10)),
          BE_M(A(2, "/b"),
               T(1, "f"),
               Df(20.)),
          BE_M(A(2, "/c"),
               T(1, "s"),
               Ds(3, "foo")),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(3))),
        "bundle with three messages and one index, roll 3, out of range");
}
void ut_ose_rollBottom(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_rollBottom,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_rollBottom,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_rollBottom,
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(0))),
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(0))),
        "bundle with one message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_rollBottom,
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(0)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(1))),
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(1)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(0))),
        "bundle with two messages");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_rollBottom,
        B(BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10)),
          BE_M(A(2, "/b"),
               T(1, "f"),
               Df(20.)),
          BE_M(A(2, "/c"),
               T(1, "s"),
               Ds(3, "foo"))),
        B(BE_M(A(2, "/b"),
               T(1, "f"),
               Df(20.)),
          BE_M(A(2, "/c"),
               T(1, "s"),
               Ds(3, "foo")),
          BE_M(A(2, "/a"),
               T(1, "i"),
               Di(10))),
        "bundle with three messages");
}
void ut_ose_rollMatch(void)
{

}
void ut_ose_rot(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_rot,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_rot,
                                                 B(),
                                                 "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_rot,

                                                 B(BE_M(A(0, ""),
                                                        T(1, "i"),
                                                        Di(23))),

                                                 "bundle with only 1 message");
	UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_rot,
                               
                                                 B(BE_M(A(0, ""),
                                                        T(1, "i"),
                                                        Di(23)),
                                                   BE_M(A(0, ""),
                                                        T(1, "f"),
                                                        Df(2.3))),

                                                 "bundle with 2 messages");

    UNIT_TEST_BUNDLE_TRANSFORM(ose_rot,
                               
                               B(BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3)),
                                   BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo"))),

                               "bundle with 3 messages");

    UNIT_TEST_BUNDLE_TRANSFORM(ose_rot,
                               
                               B(BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(99))),

                               B(BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(99)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23))),

                               "bundle with 4 messages");
	
}
void ut_ose_swap(void)
{
	UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_swap,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_swap,
                                                 B(),
                                                 "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_swap,

        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(23))),

        "bundle with only 1 message");

    UNIT_TEST_BUNDLE_TRANSFORM(ose_swap,
                               
                               B(BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               B(BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3)),
                                   BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo"))),

                               "bundle with 2 messages");

    UNIT_TEST_BUNDLE_TRANSFORM(ose_swap,
                               
                               B(BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               B(BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23))),

                               "bundle with 3 messages");

    UNIT_TEST_BUNDLE_TRANSFORM(ose_swap,
                               
                               B(BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(99))),

                               B(BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(99)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               "bundle with 4 messages");
    
}
void ut_ose_tuck(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_tuck,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_tuck,
                                                 B(),
                                                 "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_tuck,

        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(23))),

        "bundle with only 1 message");
	UNIT_TEST_BUNDLE_TRANSFORM(ose_tuck,
                               
                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               B(BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               "bundle with 2 messages");

    UNIT_TEST_BUNDLE_TRANSFORM(ose_tuck,
                               
                               B(BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               B(BE_M(A(3, "/xx"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               "bundle with 3 messages");	
}

/**************************************************
 * Grouping / Ungrouping
 **************************************************/
void ut_ose_bundleAll(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_bundleAll,
                                                 NULL,
                                                 "NULL bundle");

    UNIT_TEST_BUNDLE_TRANSFORM(ose_bundleAll,
                               
                               B(),

                               B(BE_B0()),

                               "bundle with 0 elements");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_bundleAll,
                               
                               B(BE_B0()),

                               B(BE_B(BE_B0())),

                               "bundle with 1 element");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_bundleAll,
                               
                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               B(BE_B(BE_M(A(0, ""),
                                           T(1, "i"),
                                           Di(23)),
                                      BE_M(A(0, ""),
                                           T(1, "f"),
                                           Df(2.3)))),

                               "bundle with 2 messages");
}

void ut_ose_bundleFromBottom(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_bundleFromBottom,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_bundleFromBottom,
                                                 B(),
                                                 "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_bundleFromBottom,
                                                 B(BE_B0()),
                                                 "no int message");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_bundleFromBottom,
                                                 B(BE_B0(),
                                                   BE_M(A(0, ""),
                                                        T(1, "f"),
                                                        Df(3.14))),
                                                 "wrong type");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_bundleFromBottom,
                                                 B(BE_B0(),
                                                   BE_M(A(0, ""),
                                                        T(1, "s"),
                                                        Ds(3, "foo"))),
                                                 "wrong type");
    
    UNIT_TEST_BUNDLE_TRANSFORM(ose_bundleFromBottom,
                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(0))),
                               B(BE_B0()),
                               "empty bundle, n = 0");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_bundleFromBottom,
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22), Df(33.), Ds(5, "ffour")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(0))),
                               B(BE_B0(),
                                 BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22),
                                      Df(33.),
                                      Ds(5, "ffour"))),
                               "one message, n = 0");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_bundleFromBottom,
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22), Df(33.), Ds(5, "ffour")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(1))),
                               B(BE_B(BE_M(A(0, ""),
                                           T(3, "ifs"),
                                           Di(22),
                                           Df(33.),
                                           Ds(5, "ffour")))),
                               "two messages, n = 1");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_bundleFromBottom,
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22), Df(33.), Ds(5, "ffour")),
                                 BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(33)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(1))),
                               B(BE_B(BE_M(A(0, ""),
                                           T(3, "ifs"),
                                           Di(22),
                                           Df(33.),
                                           Ds(5, "ffour"))),
                                 BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(33))),
                               "three messages, n = 1");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_bundleFromBottom,
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22), Df(33.), Ds(5, "ffour")),
                                 BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(33)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(2))),
                               B(BE_B(BE_M(A(0, ""),
                                           T(3, "ifs"),
                                           Di(22),
                                           Df(33.),
                                           Ds(5, "ffour")),
                                      BE_M(A(2, "/x"),
                                           T(1, "i"),
                                           Di(33)))),
                               "three messages, n = 2");
}

void ut_ose_bundleFromTop(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_bundleFromTop,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_bundleFromTop,
                                                 B(),
                                                 "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_bundleFromTop,
                                                 B(BE_B0()),
                                                 "no int message");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_bundleFromTop,
                                                 B(BE_B0(),
                                                   BE_M(A(0, ""),
                                                        T(1, "f"),
                                                        Df(3.14))),
                                                 "wrong type");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_bundleFromTop,
                                                 B(BE_B0(),
                                                   BE_M(A(0, ""),
                                                        T(1, "s"),
                                                        Ds(3, "foo"))),
                                                 "wrong type");
    
    UNIT_TEST_BUNDLE_TRANSFORM(ose_bundleFromTop,
                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(0))),
                               B(BE_B0()),
                               "empty bundle, n = 0");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_bundleFromTop,
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22), Df(33.), Ds(5, "ffour")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(0))),
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22),
                                      Df(33.),
                                      Ds(5, "ffour")),
                                 BE_B0()),
                               "one message, n = 0");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_bundleFromTop,
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22), Df(33.), Ds(5, "ffour")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(1))),
                               B(BE_B(BE_M(A(0, ""),
                                           T(3, "ifs"),
                                           Di(22),
                                           Df(33.),
                                           Ds(5, "ffour")))),
                               "two messages, n = 1");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_bundleFromTop,
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22), Df(33.), Ds(5, "ffour")),
                                 BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(33)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(1))),
                               B(BE_M(A(0, ""),
                                           T(3, "ifs"),
                                           Di(22),
                                           Df(33.),
                                      Ds(5, "ffour")),
                                 BE_B(BE_M(A(2, "/x"),
                                           T(1, "i"),
                                           Di(33)))),
                               "three messages, n = 1");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_bundleFromTop,
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22), Df(33.), Ds(5, "ffour")),
                                 BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(33)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(2))),
                               B(BE_B(BE_M(A(0, ""),
                                           T(3, "ifs"),
                                           Di(22),
                                           Df(33.),
                                           Ds(5, "ffour")),
                                      BE_M(A(2, "/x"),
                                           T(1, "i"),
                                           Di(33)))),
                               "three messages, n = 2");
}

void ut_ose_clear(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_clear,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_clear,
                               B(),
                               B(),
                               "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_clear,
                               B(BE_B0()),
                               B(),
                               "one elem");
    UNIT_TEST_BUNDLE_TRANSFORM(ose_clear,
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22), Df(33.), Ds(5, "ffour")),
                                 BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(33)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(2))),
                               B(),
                               "three elems");
}

void ut_ose_pop(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_pop,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_pop,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_pop,
        B(BE_M(A(0, ""),
               T(0, ""))),
        "empty message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_pop,
        B(BE_B0()),
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_pop,
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(10))),
        B(BE_M(A(0, ""),
               T(0, "")),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(10))),
        "message with one item");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_pop,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(22)))),
        B(BE_B0(),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(22))),
        "bundle with one message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_pop,
        B(BE_M(A(0, ""),
               T(2, "if"),
               Di(10), Df(11.))),
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(10)),
          BE_M(A(0, ""),
               T(1, "f"),
               Df(11.))),
        "message with two items");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_pop,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(22)),
               BE_M(A(0, ""),
                    T(1, "f"),
                    Df(23.)))),
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(22))),
          BE_M(A(0, ""),
               T(1, "f"),
               Df(23.))),
        "bundle with two messages");
}
void ut_ose_popAll(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_popAll,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_popAll,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAll,
        B(BE_M(A(0, ""),
               T(0, ""))),
        B(BE_M(A(0, ""),
               T(0, ""))),
        "empty message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAll,
        B(BE_B0()),
        B(BE_B0()),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAll,
        B(BE_M(A(2, "/x"),
               T(1, "i"),
               Di(10))),
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(10)),
          BE_M(A(2, "/x"),
               T(0, "")),
          ),
        "message with one item");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAll,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(22)))),
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(22)),
          BE_B0()),
        "bundle with one message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAll,
        B(BE_M(A(2, "/x"),
               T(2, "if"),
               Di(10), Df(11.))),
        B(BE_M(A(0, ""),
               T(1, "f"),
               Df(11.)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(10)),
          BE_M(A(2, "/x"),
               T(0, ""))),
        "message with two items");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAll,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(22)),
               BE_M(A(0, ""),
                    T(1, "f"),
                    Df(23.)))),
        B(BE_M(A(0, ""),
               T(1, "f"),
               Df(23.)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(22)),
          BE_B0()),
        "bundle with two messages");
}

void ut_ose_popAllDrop(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_popAllDrop,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_popAllDrop,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAllDrop,
        B(BE_M(A(0, ""),
               T(0, ""))),
        B(),
        "empty message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAllDrop,
        B(BE_B0()),
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAllDrop,
        B(BE_M(A(2, "/x"),
               T(1, "i"),
               Di(10))),
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(10))),
        "message with one item");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAllDrop,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(22)))),
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(22))),
        "bundle with one message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAllDrop,
        B(BE_M(A(2, "/x"),
               T(2, "if"),
               Di(10), Df(11.))),
        B(BE_M(A(0, ""),
               T(1, "f"),
               Df(11.)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(10))),
        "message with two items");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAllDrop,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(22)),
               BE_M(A(0, ""),
                    T(1, "f"),
                    Df(23.)))),
        B(BE_M(A(0, ""),
               T(1, "f"),
               Df(23.)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(22))),
        "bundle with two messages");
}

void ut_ose_popAllBundle(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_popAllBundle,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_popAllBundle,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAllBundle,
        B(BE_M(A(0, ""),
               T(0, ""))),
        B(BE_B(BE_M(A(0, ""),
                    T(0, "")))),
        "empty message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAllBundle,
        B(BE_B0()),
        B(BE_B(BE_B0())),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAllBundle,
        B(BE_M(A(2, "/x"),
               T(1, "i"),
               Di(10))),
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(10)),
               BE_M(A(2, "/x"),
                    T(0, "")))),
        "message with one item");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAllBundle,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(22)))),
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(22)),
               BE_B0())),
        "bundle with one message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAllBundle,
        B(BE_M(A(2, "/x"),
               T(2, "if"),
               Di(10), Df(11.))),
        B(BE_B(BE_M(A(0, ""),
                    T(1, "f"),
                    Df(11.)),
               BE_M(A(0, ""),
                    T(1, "i"),
                    Di(10)),
               BE_M(A(2, "/x"),
                    T(0, "")))),
        "message with two items");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAllBundle,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(22)),
               BE_M(A(0, ""),
                    T(1, "f"),
                    Df(23.)))),
        B(BE_B(BE_M(A(0, ""),
                    T(1, "f"),
                    Df(23.)),
               BE_M(A(0, ""),
                    T(1, "i"),
                    Di(22)),
               BE_B0())),
        "bundle with two messages");
}
void ut_ose_popAllDropBundle(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_popAllDropBundle,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_popAllDropBundle,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAllDropBundle,
        B(BE_M(A(0, ""),
               T(0, ""))),
        B(BE_B0()),
        "empty message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAllDropBundle,
        B(BE_B0()),
        B(BE_B0()),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAllDropBundle,
        B(BE_M(A(2, "/x"),
               T(1, "i"),
               Di(10))),
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(10)))),
        "message with one item");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAllDropBundle,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(22)))),
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(22)))),
        "bundle with one message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAllDropBundle,
        B(BE_M(A(2, "/x"),
               T(2, "if"),
               Di(10), Df(11.))),
        B(BE_B(BE_M(A(0, ""),
                    T(1, "f"),
                    Df(11.)),
               BE_M(A(0, ""),
                    T(1, "i"),
                    Di(10)))),
        "message with two items");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_popAllDropBundle,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(22)),
               BE_M(A(0, ""),
                    T(1, "f"),
                    Df(23.)))),
        B(BE_B(BE_M(A(0, ""),
                    T(1, "f"),
                    Df(23.)),
               BE_M(A(0, ""),
                    T(1, "i"),
                    Di(22)))),
        "bundle with two messages");
}
void ut_ose_push(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_push,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_push,
        B(),
        B(BE_B0()),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_push,
        B(BE_B0()),
        B(BE_B(BE_B0())),
        "single bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_push,
        B(BE_M(A(2, "/x"),
               T(1, "i"),
               Di(10))),
        B(BE_B(BE_M(A(2, "/x"),
                    T(1, "i"),
                    Di(10)))),
        "single message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_push,
        B(BE_M(A(2, "/x"),
               T(1, "i"),
               Di(10)),
          BE_M(A(3, "/yz"),
               T(3, "fsf"),
               Df(11.), Ds(3, "foo"), Df(12.))),
        B(BE_M(A(2, "/x"),
               T(4, "ifsf"),
               Di(10), Df(11.), Ds(3, "foo"), Df(12.))),
        "push message onto message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_push,
        B(BE_B(BE_M(A(2, "/x"),
                    T(1, "i"),
                    Di(10))),
          BE_M(A(3, "/yz"),
               T(3, "fsf"),
               Df(11.), Ds(3, "foo"), Df(12.))),
        B(BE_B(BE_M(A(2, "/x"),
                    T(1, "i"),
                    Di(10)),
               BE_M(A(3, "/yz"),
                    T(3, "fsf"),
                    Df(11.), Ds(3, "foo"), Df(12.)))),
        "push message onto bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_push,
        B(BE_B(BE_M(A(2, "/x"),
                    T(1, "i"),
                    Di(10))),
          BE_B(BE_M(A(3, "/yz"),
                    T(3, "fsf"),
                    Df(11.), Ds(3, "foo"), Df(12.)))),
        B(BE_B(BE_M(A(2, "/x"),
                    T(1, "i"),
                    Di(10)),
               BE_B(BE_M(A(3, "/yz"),
                         T(3, "fsf"),
                         Df(11.), Ds(3, "foo"), Df(12.))))),
        "push bundle onto bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_push,
        B(BE_M(A(2, "/x"),
               T(1, "i"),
               Di(10)),
          BE_B(BE_M(A(3, "/yz"),
                    T(1, "i"),
                    Di(11)))),
        B(BE_M(A(2, "/x"),
               T(2, "ib"),
               Di(10),
               '\0', '\0', '\0', '\x20', '\x23', '\x62', '\x75', '\x6e', '\x64', '\x6c', '\x65', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\x0c', '/', 'y', 'z', '\0', ',', 'i', '\0', '\0', '\0', '\0', '\0', '\x0b')),
        "push bundle onto message");
}

void ut_ose_decatenateElemFromEnd(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_decatenateElemFromEnd,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_decatenateElemFromEnd,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_decatenateElemFromEnd,
        B(BE_B0()),
        "bundle with no index");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_decatenateElemFromEnd,
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(0))),
        "bundle with index but no elem to decatenate");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_decatenateElemFromEnd,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(10))),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(0))),
        "bundle with 0 index");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_decatenateElemFromEnd,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(10))),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(1))),
        B(BE_B0(),
          BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(10)))),
        "bundle with 1 index and bundle of length 1");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_decatenateElemFromEnd,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(10)),
               BE_M(A(0, ""),
                    T(1, "i"),
                    Di(11)),
               BE_M(A(0, ""),
                    T(1, "i"),
                    Di(12))),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(1))),
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(10)),
               BE_M(A(0, ""),
                    T(1, "i"),
                    Di(11))),
          BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(12)))),
        "bundle with 1 index and bundle of length 3");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_decatenateElemFromEnd,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(10)),
               BE_M(A(0, ""),
                    T(1, "i"),
                    Di(11)),
               BE_M(A(0, ""),
                    T(1, "i"),
                    Di(12))),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(2))),
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(10))),
          BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(11)),
               BE_M(A(0, ""),
                    T(1, "i"),
                    Di(12)))),
        "bundle with 2 index and bundle of length 3");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_decatenateElemFromEnd,
        B(BE_M(A(0, "/list"),
               T(4, "iiii"),
               Di(1), Di(2), Di(3), Di(4)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(1))),
        B(BE_M(A(0, "/list"),
               T(3, "iii"),
               Di(1), Di(2), Di(3)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(4))),
        "one message, 4 items, index 1");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_decatenateElemFromEnd,
        B(BE_M(A(0, "/list"),
               T(4, "iiii"),
               Di(1), Di(2), Di(3), Di(4)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(2))),
        B(BE_M(A(0, "/list"),
               T(2, "ii"),
               Di(1), Di(2)),
          BE_M(A(0, ""),
               T(2, "ii"),
               Di(3), Di(4))),
        "one message, 4 items, index 2");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_decatenateElemFromEnd,
        B(BE_M(A(0, "/list"),
               T(4, "iiii"),
               Di(1), Di(2), Di(3), Di(4)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(3))),
        B(BE_M(A(0, "/list"),
               T(1, "i"),
               Di(1)),
          BE_M(A(0, ""),
               T(3, "iii"),
               Di(2), Di(3), Di(4))),
        "one message, 4 items, index 3");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_decatenateElemFromEnd,
        B(BE_M(A(0, "/list"),
               T(4, "iiii"),
               Di(1), Di(2), Di(3), Di(4)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(4))),
        B(BE_M(A(0, "/list"),
               T(0, "")),
          BE_M(A(0, ""),
               T(4, "iiii"),
               Di(1), Di(2), Di(3), Di(4))),
        "one message, 4 items, index 4");
}

void ut_ose_decatenateElemFromStart(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_decatenateElemFromStart,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_decatenateElemFromStart,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_decatenateElemFromStart,
        B(BE_B0()),
        "bundle with no index");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_decatenateElemFromStart,
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(0))),
        "bundle with index but no elem to decatenate");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_decatenateElemFromStart,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(10))),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(0))),
        B(BE_B0(),
          BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(10)))),
        "bundle with 0 index");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_decatenateElemFromStart,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(10))),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(1))),
        /* B(BE_B(BE_M(A(0, ""), */
        /*             T(1, "i"), */
        /*             Di(10))), */
        /*   BE_B0()), */
        "bundle with 1 index and bundle of length 1");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_decatenateElemFromStart,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(10)),
               BE_M(A(0, ""),
                    T(1, "i"),
                    Di(11)),
               BE_M(A(0, ""),
                    T(1, "i"),
                    Di(12))),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(1))),
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(10))),
          BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(11)),
               BE_M(A(0, ""),
                    T(1, "i"),
                    Di(12)))),
        "bundle with 1 index and bundle of length 3");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_decatenateElemFromStart,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(10)),
               BE_M(A(0, ""),
                    T(1, "i"),
                    Di(11)),
               BE_M(A(0, ""),
                    T(1, "i"),
                    Di(12))),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(2))),
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(10)),
               BE_M(A(0, ""),
                    T(1, "i"),
                    Di(11))),
          BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(12)))),
        "bundle with 2 index and bundle of length 3");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_decatenateElemFromStart,
        B(BE_M(A(0, "/list"),
               T(4, "iiii"),
               Di(1), Di(2), Di(3), Di(4)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(1))),
        B(BE_M(A(0, "/list"),
               T(1, "i"),
               Di(1)),
          BE_M(A(0, ""),
               T(3, "iii"),
               Di(2), Di(3), Di(4))),
        "one message, 4 items, index 1");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_decatenateElemFromStart,
        B(BE_M(A(0, "/list"),
               T(4, "iiii"),
               Di(1), Di(2), Di(3), Di(4)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(2))),
        B(BE_M(A(0, "/list"),
               T(2, "ii"),
               Di(1), Di(2)),
          BE_M(A(0, ""),
               T(2, "ii"),
               Di(3), Di(4))),
        "one message, 4 items, index 2");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_decatenateElemFromStart,
        B(BE_M(A(0, "/list"),
               T(4, "iiii"),
               Di(1), Di(2), Di(3), Di(4)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(3))),
        B(BE_M(A(0, "/list"),
               T(3, "iii"),
               Di(1), Di(2), Di(3)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(4))),
        "one message, 4 items, index 3");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_decatenateElemFromStart,
        B(BE_M(A(0, "/list"),
               T(4, "iiii"),
               Di(1), Di(2), Di(3), Di(4)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(4))),
        B(BE_M(A(0, "/list"),
               T(4, "iiii"),
               Di(1), Di(2), Di(3), Di(4)),
          BE_M(A(0, ""),
               T(0, ""))),
        "one message, 4 items, index 4");
}

void ut_ose_concatenateElems(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_concatenateElems,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_concatenateElems,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_concatenateElems,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_concatenateElems,
        B(BE_B0()),
        "only one elem");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_concatenateElems,
        B(BE_B0(), BE_B0()),
        B(BE_B0()),
        "two empty bundles");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_concatenateElems,
        B(BE_B(BE_M(A(4, "/foo"),
                    T(2, "ii"),
                    Di(33), Di(44))),
          BE_B(BE_M(A(4, "/bar"),
                    T(2, "ff"),
                    Df(55.), Df(66.)))),
        B(BE_B(BE_M(A(4, "/foo"),
                    T(2, "ii"),
                    Di(33), Di(44)),
               BE_M(A(4, "/bar"),
                    T(2, "ff"),
                    Df(55.), Df(66.)))),
        "two bundles");

    /* these are identical to ose_push */
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_concatenateElems,
        B(BE_M(A(2, "/x"),
               T(1, "i"),
               Di(10)),
          BE_M(A(3, "/yz"),
               T(3, "fsf"),
               Df(11.), Ds(3, "foo"), Df(12.))),
        B(BE_M(A(2, "/x"),
               T(4, "ifsf"),
               Di(10), Df(11.), Ds(3, "foo"), Df(12.))),
        "push message onto message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_concatenateElems,
        B(BE_B(BE_M(A(2, "/x"),
                    T(1, "i"),
                    Di(10))),
          BE_M(A(3, "/yz"),
               T(3, "fsf"),
               Df(11.), Ds(3, "foo"), Df(12.))),
        B(BE_B(BE_M(A(2, "/x"),
                    T(1, "i"),
                    Di(10)),
               BE_M(A(3, "/yz"),
                    T(3, "fsf"),
                    Df(11.), Ds(3, "foo"), Df(12.)))),
        "push message onto bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_concatenateElems,
        B(BE_M(A(2, "/x"),
               T(1, "i"),
               Di(10)),
          BE_B(BE_M(A(3, "/yz"),
                    T(1, "i"),
                    Di(11)))),
        B(BE_M(A(2, "/x"),
               T(2, "ib"),
               Di(10),
               '\0', '\0', '\0', '\x20', '\x23', '\x62', '\x75', '\x6e', '\x64', '\x6c', '\x65', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\x0c', '/', 'y', 'z', '\0', ',', 'i', '\0', '\0', '\0', '\0', '\0', '\x0b')),
        "push bundle onto message");
}

void ut_ose_unpack(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_unpack,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_unpack,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_unpack,
        B(BE_B0()),
        B(BE_B0()),
        "1 elem, empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_unpack,
        B(BE_M(A(0, ""), T(0, ""))),
        B(BE_M(A(0, ""), T(0, ""))),
        "1 elem, empty message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_unpack,
        B(BE_B(BE_M(A(0, ""), T(1, "i"), Di(33)))),
        B(BE_B0(),
          BE_M(A(0, ""), T(1, "i"), Di(33))),
        "1 elem, bundle with 1 message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_unpack,
        B(BE_B(BE_M(A(0, ""), T(1, "i"), Di(33)),
               BE_M(A(2, "/x"), T(1, "i"), Di(44)))),
        B(BE_B0(),
          BE_M(A(0, ""), T(1, "i"), Di(33)),
          BE_M(A(2, "/x"), T(1, "i"), Di(44))),
        "1 elem, bundle with 2 messages");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_unpack,
        B(BE_M(A(2, "/x"), T(1, "i"), Di(44))),
        B(BE_M(A(2, "/x"), T(0, "")),
          BE_M(A(0, ""), T(1, "i"), Di(44))),
        "1 elem, message with 1 item");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_unpack,
        B(BE_M(A(2, "/x"), T(2, "if"), Di(44), Df(33))),
        B(BE_M(A(2, "/x"), T(0, "")),
          BE_M(A(0, ""), T(1, "i"), Di(44)),
          BE_M(A(0, ""), T(1, "f"), Df(33))),
        "1 elem, message with 2 items");
}

void ut_ose_unpackDrop(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_unpackDrop,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_unpackDrop,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_unpackDrop,
        B(BE_B0()),
        B(),
        "1 elem, empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_unpackDrop,
        B(BE_M(A(0, ""), T(0, ""))),
        B(),
        "1 elem, empty message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_unpackDrop,
        B(BE_B(BE_M(A(0, ""), T(1, "i"), Di(33)))),
        B(BE_M(A(0, ""), T(1, "i"), Di(33))),
        "1 elem, bundle with 1 message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_unpackDrop,
        B(BE_B(BE_M(A(0, ""), T(1, "i"), Di(33)),
               BE_M(A(2, "/x"), T(1, "i"), Di(44)))),
        B(BE_M(A(0, ""), T(1, "i"), Di(33)),
          BE_M(A(2, "/x"), T(1, "i"), Di(44))),
        "1 elem, bundle with 2 messages");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_unpackDrop,
        B(BE_M(A(2, "/x"), T(1, "i"), Di(44))),
        B(BE_M(A(0, ""), T(1, "i"), Di(44))),
        "1 elem, message with 1 item");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_unpackDrop,
        B(BE_M(A(2, "/x"), T(2, "if"), Di(44), Df(33))),
        B(BE_M(A(0, ""), T(1, "i"), Di(44)),
          BE_M(A(0, ""), T(1, "f"), Df(33))),
        "1 elem, message with 2 items");
}


/**************************************************
 * Queries
 **************************************************/

void ut_ose_countElems(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_countElems,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_countElems,
        B(),
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(0))),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_countElems,
        B(BE_B0()),
        B(BE_B0(),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(1))),
        "bundle with 1 element");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_countElems,
        B(BE_B0(),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(33))),
        B(BE_B0(),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(33)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(2))),
        "bundle with 2 element");
}

void ut_ose_countItems(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_countItems,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_countItems,
        B(),
        "empty top-level bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_countItems,
        B(BE_B0()),
        B(BE_B0(),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(0))),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_countItems,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(33)))),
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(33))),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(1))),
        "bundle with 1 message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_countItems,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(33)),
               BE_M(A(0, ""),
                    T(1, "f"),
                    Df(22.)))),
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(33)),
               BE_M(A(0, ""),
                    T(1, "f"),
                    Df(22.))),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(2))),
          "bundle with 2 elems");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_countItems,
        B(BE_M(A(0, ""),
               T(3, "ifs"),
               Di(33), Df(44.), Ds(3, "foo"))),
        B(BE_M(A(0, ""),
               T(3, "ifs"),
               Di(33), Df(44.), Ds(3, "foo")),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(3))),
        "message with 3 elems");
}

void ut_ose_lengthItem(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_lengthItem,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_lengthItem,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_lengthItem,
        B(BE_B0()),
        "empty bundle elem");
    /* this triggers an assertion, but it shouldn't */
    /* UNIT_TEST_BUNDLE_TRANSFORM( */
    /*     ose_lengthItem, */
    /*     B(BE_B(BE_B0())), */
    /*     B(BE_B(BE_B0()) */
    /*       BE_M(A(0, ""), */
    /*            T(1, "i"), */
    /*            Di(16))), */
    /*     "bundle with empty bundle"); */
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_lengthItem,
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(33))),
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(33)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(4))),
        "message with one int");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_lengthItem,
        B(BE_M(A(0, ""),
               T(2, "if"),
               Di(33), Df(44.))),
        B(BE_M(A(0, ""),
               T(2, "if"),
               Di(33), Df(44.)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(4))),
        "message with int and float");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_lengthItem,
        B(BE_M(A(0, ""),
               T(3, "ifs"),
               Di(33), Df(44.), Ds(3, "foo"))),
        B(BE_M(A(0, ""),
               T(3, "ifs"),
               Di(33), Df(44.), Ds(3, "foo")),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(3))),
        "message with int, float, and string");
}

void ut_ose_lengthsItems(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_lengthsItems,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_lengthsItems,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_lengthsItems,
        B(BE_B0()),
        "empty bundle elem");
    /* this triggers an assertion, but it shouldn't */
    /* UNIT_TEST_BUNDLE_TRANSFORM( */
    /*     ose_lengthsItems, */
    /*     B(BE_B(BE_B0())), */
    /*     B(BE_B(BE_B0()) */
    /*       BE_M(A(0, ""), */
    /*            T(1, "i"), */
    /*            Di(16))), */
    /*     "bundle with empty bundle"); */
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_lengthsItems,
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(33))),
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(33)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(4))),
        "message with one int");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_lengthsItems,
        B(BE_M(A(0, ""),
               T(2, "if"),
               Di(33), Df(44.))),
        B(BE_M(A(0, ""),
               T(2, "if"),
               Di(33), Df(44.)),
          BE_M(A(0, ""),
               T(2, "ii"),
               Di(4), Di(4))),
        "message with int and float");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_lengthsItems,
        B(BE_M(A(0, ""),
               T(3, "ifs"),
               Di(33), Df(44.), Ds(3, "foo"))),
        B(BE_M(A(0, ""),
               T(3, "ifs"),
               Di(33), Df(44.), Ds(3, "foo")),
          BE_M(A(0, ""),
               T(3, "iii"),
               Di(4), Di(4), Di(3))),
        "message with int, float, and 3 char string");
}

void ut_ose_sizeElem(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_sizeElem,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_sizeElem,
        B(),
        "empty top-level bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_sizeElem,
        B(BE_B0()),
        B(BE_B0(),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(16))),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_sizeElem,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(33)))),
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(33))),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(32))),
        "bundle with 1 message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_sizeElem,
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(33)),
               BE_M(A(0, ""),
                    T(1, "f"),
                    Df(22.)))),
        B(BE_B(BE_M(A(0, ""),
                    T(1, "i"),
                    Di(33)),
               BE_M(A(0, ""),
                    T(1, "f"),
                    Df(22.))),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(48))),
        "bundle with 2 elems");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_sizeElem,
        B(BE_M(A(0, ""),
               T(3, "ifs"),
               Di(33), Df(44.), Ds(3, "foo"))),
        B(BE_M(A(0, ""),
               T(3, "ifs"),
               Di(33), Df(44.), Ds(3, "foo")),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(24))),
        "message with 3 elems");
}

void ut_ose_sizeItem(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_sizeItem,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_sizeItem,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_sizeItem,
        B(BE_B0()),
        "empty bundle elem");
    /* this triggers an assertion, but it shouldn't */
    /* UNIT_TEST_BUNDLE_TRANSFORM( */
    /*     ose_sizeItem, */
    /*     B(BE_B(BE_B0())), */
    /*     B(BE_B(BE_B0()) */
    /*       BE_M(A(0, ""), */
    /*            T(1, "i"), */
    /*            Di(16))), */
    /*     "bundle with empty bundle"); */
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_sizeItem,
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(33))),
        B(BE_M(A(0, ""),
               T(1, "i"),
               Di(33)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(4))),
        "message with one int");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_sizeItem,
        B(BE_M(A(0, ""),
               T(2, "if"),
               Di(33), Df(44.))),
        B(BE_M(A(0, ""),
               T(2, "if"),
               Di(33), Df(44.)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(4))),
        "message with int and float");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_sizeItem,
        B(BE_M(A(0, ""),
               T(3, "ifs"),
               Di(33), Df(44.), Ds(3, "foo"))),
        B(BE_M(A(0, ""),
               T(3, "ifs"),
               Di(33), Df(44.), Ds(3, "foo")),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(4))),
        "message with int, float, and string");
}

void ut_ose_sizesElems(void)
{
    /* not implemented */
}

void ut_ose_sizesItems(void)
{
    /* not implemented */
}

void ut_ose_getAddresses(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_getAddresses,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_getAddresses,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_getAddresses,
        B(BE_B0()),
        B(BE_B0(),
          BE_M(A(0, ""),
               T(0, ""))),
        "bundle with 1 bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_getAddresses,
        B(BE_B(BE_B0())),
        B(BE_B(BE_B0()),
          BE_M(A(0, ""),
               T(1, "s"),
               Ds(7, "#bundle"))),
        "bundle with 1 bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_getAddresses,
        B(BE_B(BE_B0(),
               BE_M(A(2, "/x"),
                    T(1, "i"),
                    Di(33)),
               BE_M(A(4, "/foo"),
                    T(3, "ifs"),
                    Di(33), Df(44.), Ds(3, "bar")))),
        B(BE_B(BE_B0(),
               BE_M(A(2, "/x"),
                    T(1, "i"),
                    Di(33)),
               BE_M(A(4, "/foo"),
                    T(3, "ifs"),
                    Di(33), Df(44.), Ds(3, "bar"))),
          BE_M(A(0, ""),
               T(3, "sss"),
               Ds(7, "#bundle"),
               Ds(2, "/x"),
               Ds(4, "/foo"))),
        "bundle with 1 bundle and 2 messages");
}

void ut_ose_elemIsBundle(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_elemIsBundle,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_elemIsBundle,
        B(),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_elemIsBundle,
        B(BE_B0()),
        B(BE_B0(),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(1))),
        "bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_elemIsBundle,
        B(BE_B0(),
          BE_M(A(2, "/x"),
               T(1, "f"),
               Df(77.))),
        B(BE_B0(),
          BE_M(A(2, "/x"),
               T(1, "f"),
               Df(77.)),
          BE_M(A(0, ""),
               T(1, "i"),
               Di(0))),
        "message");
}

void ut_ose_typeof0(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_typeof0,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_typeof0,
        B(),
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(1, "/"))),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_typeof0,
        B(BE_B0()),
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(2, "/"OSETTSTR_BUNDLE))),
        "bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_typeof0,
        B(BE_B0(),
          BE_M(A(2, "/x"),
               T(1, "f"),
               Df(77.))),
        B(BE_B0(),
          BE_M(A(0, ""),
               T(1, "s"),
               Ds(2, "/"OSETTSTR_MESSAGE))),
        "message");
}

void ut_ose_typeof1(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_typeof1,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_typeof1,
        B(),
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(1, "/"))),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_typeof1,
        B(BE_B0()),
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(3, "/"OSETTSTR_BUNDLE"/"))),
        "bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_typeof1,
        B(BE_B0(),
          BE_M(A(2, "/x"),
               T(1, "f"),
               Df(77.))),
        B(BE_B0(),
          BE_M(A(0, ""),
               T(1, "s"),
               Ds(4, "/"OSETTSTR_MESSAGE"/"OSETTSTR_FLOAT))),
        "message with 1 float");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_typeof1,
        B(BE_B0(),
          BE_M(A(2, "/x"),
               T(3, "ifs"),
               Di(22), Df(77.), Ds(3, "foo"))),
        B(BE_B0(),
          BE_M(A(0, ""),
               T(1, "s"),
               Ds(6, "/"OSETTSTR_MESSAGE"/"
                  OSETTSTR_INT32 OSETTSTR_FLOAT OSETTSTR_STRING))),
        "message with 1 int, 1 float, and 1 string");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_typeof1,
        B(BE_B(BE_M(A(2, "/x"),
                    T(3, "ifs"),
                    Di(22), Df(77.), Ds(3, "foo")))),
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(4, "/"OSETTSTR_BUNDLE"/"OSETTSTR_MESSAGE))),
        "bundle with 1 message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_typeof1,
        B(BE_B(BE_M(A(2, "/x"),
                    T(3, "ifs"),
                    Di(22), Df(77.), Ds(3, "foo")),
               BE_B0(),
               BE_M(A(0, ""),
                    T(1, "i"),
                    Di(33)))),
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(6, "/"OSETTSTR_BUNDLE"/"
                  OSETTSTR_MESSAGE OSETTSTR_BUNDLE OSETTSTR_MESSAGE))),
        "bundle with messages and bundles");
}
void ut_ose_typeof2(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(
        ose_typeof2,
        NULL,
        "NULL bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_typeof2,
        B(),
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(1, "/"))),
        "empty bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_typeof2,
        B(BE_B0()),
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(2, "/"OSETTSTR_BUNDLE))),
        "bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_typeof2,
        B(BE_B(BE_B0())),
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(5, "/"OSETTSTR_BUNDLE"/"OSETTSTR_BUNDLE"/"))),
        "bundle");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_typeof2,
        B(BE_B(BE_B0(),
               BE_M(A(0, ""),
                    T(1, "s"),
                    Ds(4, "barf")))),
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(9, "/"OSETTSTR_BUNDLE"/"OSETTSTR_BUNDLE"//"
                  OSETTSTR_MESSAGE"/"OSETTSTR_STRING))),
        "bundle and 1 message");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_typeof2,
        B(BE_B(BE_B0(),
               BE_M(A(0, ""),
                    T(1, "s"),
                    Ds(4, "barf")),
               BE_M(A(2, "/x"),
                    T(3, "ifs"),
                    Di(22), Df(77.), Ds(3, "foo")))),
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(15, "/"OSETTSTR_BUNDLE"/"OSETTSTR_BUNDLE"//"
                  OSETTSTR_MESSAGE"/"OSETTSTR_STRING"/"
                  OSETTSTR_MESSAGE"/"OSETTSTR_INT32 OSETTSTR_FLOAT
                  OSETTSTR_STRING))),
        "bundle and 2 messages");
    UNIT_TEST_BUNDLE_TRANSFORM(
        ose_typeof2,
        B(BE_B(BE_B0(),
               BE_M(A(0, ""),
                    T(1, "s"),
                    Ds(4, "barf")),
               BE_M(A(2, "/x"),
                    T(1, "i"),
                    Di(22)),
               BE_B0())),
        B(BE_M(A(0, ""),
               T(1, "s"),
               Ds(16, "/"OSETTSTR_BUNDLE"/"OSETTSTR_BUNDLE"//"
                  OSETTSTR_MESSAGE"/"OSETTSTR_STRING"/"
                  OSETTSTR_MESSAGE"/"OSETTSTR_INT32
                  "/"OSETTSTR_BUNDLE"/"))),
        "bundle");
}

/**************************************************
 * Operations on Bundle Elements and Items
 **************************************************/
void ut_ose_setTypetag(void)
{

}
void ut_ose_blobToElem(void)
{

}
void ut_ose_blobToType(void)
{

}
void ut_ose_concatenateBlobs(void)
{

}
void ut_ose_concatenateStrings(void)
{

}
void ut_ose_copyAddressToString(void)
{

}
void ut_ose_copyPayloadToBlob(void)
{

}
void ut_ose_swapStringToAddress(void)
{

}
void ut_ose_copyTTToBlob(void)
{

}
void ut_ose_decatenateBlob(void)
{

}
void ut_ose_decatenateString(void)
{

}
void ut_ose_elemToBlob(void)
{

}
void ut_ose_itemToBlob(void)
{

}
void ut_ose_joinBlobs(void)
{

}
void ut_ose_joinStrings(void)
{

}
void ut_ose_moveStringToAddress(void)
{

}
void ut_ose_splitBlobFromEnd(void)
{

}
void ut_ose_splitBlobFromStart(void)
{

}
void ut_ose_splitStringFromEnd(void)
{

}
void ut_ose_splitStringFromStart(void)
{

}
void ut_ose_swap4Bytes(void)
{

}
void ut_ose_swap8Bytes(void)
{

}
void ut_ose_swapNBytes(void)
{

}
void ut_ose_trimBlob(void)
{

}
void ut_ose_trimString(void)
{

}
void ut_ose_match(void)
{

}
void ut_ose_pmatch(void)
{

}

/**************************************************
 * Creatio Ex Nihilo
 **************************************************/
void ut_ose_makeBlob(void)
{

}
void ut_ose_pushBundle(void)
{

}

/**************************************************
 * Arithmetic
 **************************************************/
void ut_ose_add(void)
{

}
void ut_ose_sub(void)
{

}
void ut_ose_mul(void)
{

}
void ut_ose_div(void)
{

}
void ut_ose_mod(void)
{

}
void ut_ose_neg(void)
{

}
void ut_ose_eql(void)
{

}
void ut_ose_lte(void)
{

}
void ut_ose_lt(void)
{

}
void ut_ose_and(void)
{

}
void ut_ose_or(void)
{

}

int main(int ac, char **av)
{
	init();
	
	UNIT_TEST_FUNCTION(ose_pushInt32);
	UNIT_TEST_FUNCTION(ose_pushFloat);
	UNIT_TEST_FUNCTION(ose_pushString);
	UNIT_TEST_FUNCTION(ose_pushBlob);
	SKIP_UNIT_TEST_FUNCTION(ose_pushSymbol);
	SKIP_UNIT_TEST_FUNCTION(ose_pushDouble);
	SKIP_UNIT_TEST_FUNCTION(ose_pushInt8);
	SKIP_UNIT_TEST_FUNCTION(ose_pushUInt8);
	SKIP_UNIT_TEST_FUNCTION(ose_pushUInt32);
	SKIP_UNIT_TEST_FUNCTION(ose_pushInt64);
	SKIP_UNIT_TEST_FUNCTION(ose_pushUInt64);
	SKIP_UNIT_TEST_FUNCTION(ose_pushTimetag);
	SKIP_UNIT_TEST_FUNCTION(ose_pushTrue);
	SKIP_UNIT_TEST_FUNCTION(ose_pushFalse);
	SKIP_UNIT_TEST_FUNCTION(ose_pushNULL);
	SKIP_UNIT_TEST_FUNCTION(ose_pushInfinitum);
	UNIT_TEST_FUNCTION(ose_pushAlignedPtr);
	UNIT_TEST_FUNCTION(ose_pushMessage);

	UNIT_TEST_FUNCTION(ose_peekAddress);
	UNIT_TEST_FUNCTION(ose_peekMessageArgType);
	UNIT_TEST_FUNCTION(ose_peekType);

	UNIT_TEST_FUNCTION(ose_peekInt32);
	UNIT_TEST_FUNCTION(ose_peekFloat);
	UNIT_TEST_FUNCTION(ose_peekString);
	UNIT_TEST_FUNCTION(ose_peekBlob);
	SKIP_UNIT_TEST_FUNCTION(ose_peekSymbol);
	SKIP_UNIT_TEST_FUNCTION(ose_peekDouble);
	SKIP_UNIT_TEST_FUNCTION(ose_peekInt8);
	SKIP_UNIT_TEST_FUNCTION(ose_peekUInt8);
	SKIP_UNIT_TEST_FUNCTION(ose_peekUInt32);
	SKIP_UNIT_TEST_FUNCTION(ose_peekInt64);
	SKIP_UNIT_TEST_FUNCTION(ose_peekUInt64);
	SKIP_UNIT_TEST_FUNCTION(ose_peekTimetag);
	SKIP_UNIT_TEST_FUNCTION(ose_peekTrue);
	SKIP_UNIT_TEST_FUNCTION(ose_peekFalse);
	SKIP_UNIT_TEST_FUNCTION(ose_peekNULL);
	SKIP_UNIT_TEST_FUNCTION(ose_peekInfinitum);

	UNIT_TEST_FUNCTION(ose_popInt32);
	UNIT_TEST_FUNCTION(ose_popFloat);
	UNIT_TEST_FUNCTION(ose_popString);
	UNIT_TEST_FUNCTION(ose_popBlob);
	SKIP_UNIT_TEST_FUNCTION(ose_popSymbol);
	SKIP_UNIT_TEST_FUNCTION(ose_popDouble);
	SKIP_UNIT_TEST_FUNCTION(ose_popInt8);
	SKIP_UNIT_TEST_FUNCTION(ose_popUInt8);
	SKIP_UNIT_TEST_FUNCTION(ose_popUInt32);
	SKIP_UNIT_TEST_FUNCTION(ose_popInt64);
	SKIP_UNIT_TEST_FUNCTION(ose_popUInt64);
	SKIP_UNIT_TEST_FUNCTION(ose_popTimetag);

	/**************************************************
	 * Stack Operations
	 **************************************************/
	UNIT_TEST_FUNCTION(ose_2drop);
	UNIT_TEST_FUNCTION(ose_2dup);
	UNIT_TEST_FUNCTION(ose_2over);
	UNIT_TEST_FUNCTION(ose_2swap);
	UNIT_TEST_FUNCTION(ose_drop);
	UNIT_TEST_FUNCTION(ose_dup);
	UNIT_TEST_FUNCTION(ose_nip);
	UNIT_TEST_FUNCTION(ose_rrot);
	UNIT_TEST_FUNCTION(ose_over);
	UNIT_TEST_FUNCTION(ose_pick);
	UNIT_TEST_FUNCTION(ose_pickBottom);
	UNIT_TEST_FUNCTION(ose_pickMatch);
	UNIT_TEST_FUNCTION(ose_roll);
	UNIT_TEST_FUNCTION(ose_rollBottom);
	UNIT_TEST_FUNCTION(ose_rollMatch);
	UNIT_TEST_FUNCTION(ose_rot);
	UNIT_TEST_FUNCTION(ose_swap);
	UNIT_TEST_FUNCTION(ose_tuck);

	/**************************************************
	 * Grouping / Ungrouping
	 **************************************************/
	UNIT_TEST_FUNCTION(ose_bundleAll);
	UNIT_TEST_FUNCTION(ose_bundleFromBottom);
	UNIT_TEST_FUNCTION(ose_bundleFromTop);
	UNIT_TEST_FUNCTION(ose_clear);
	UNIT_TEST_FUNCTION(ose_pop);
	UNIT_TEST_FUNCTION(ose_popAll);
	UNIT_TEST_FUNCTION(ose_popAllDrop);
	UNIT_TEST_FUNCTION(ose_popAllBundle);
	UNIT_TEST_FUNCTION(ose_popAllDropBundle);
	UNIT_TEST_FUNCTION(ose_push);
    UNIT_TEST_FUNCTION(ose_decatenateElemFromEnd);
    UNIT_TEST_FUNCTION(ose_decatenateElemFromStart);
    UNIT_TEST_FUNCTION(ose_concatenateElems);
	UNIT_TEST_FUNCTION(ose_unpack);
	UNIT_TEST_FUNCTION(ose_unpackDrop);


	/**************************************************
	 * Queries
	 **************************************************/
	UNIT_TEST_FUNCTION(ose_countElems);
	UNIT_TEST_FUNCTION(ose_countItems);
	UNIT_TEST_FUNCTION(ose_lengthItem);
	SKIP_UNIT_TEST_FUNCTION(ose_lengthsItems);
	UNIT_TEST_FUNCTION(ose_sizeElem);
	UNIT_TEST_FUNCTION(ose_sizeItem);
	SKIP_UNIT_TEST_FUNCTION(ose_sizesElems);
	SKIP_UNIT_TEST_FUNCTION(ose_sizesItems);
	UNIT_TEST_FUNCTION(ose_getAddresses);
    UNIT_TEST_FUNCTION(ose_elemIsBundle);
    UNIT_TEST_FUNCTION(ose_typeof0);
    UNIT_TEST_FUNCTION(ose_typeof1);
    UNIT_TEST_FUNCTION(ose_typeof2);

	/**************************************************
	 * Operations on Bundle Elements and Items
	 **************************************************/
	SKIP_UNIT_TEST_FUNCTION(ose_blobToElem);
	SKIP_UNIT_TEST_FUNCTION(ose_blobToType);
	SKIP_UNIT_TEST_FUNCTION(ose_concatenateBlobs);
	SKIP_UNIT_TEST_FUNCTION(ose_concatenateStrings);
	SKIP_UNIT_TEST_FUNCTION(ose_copyAddressToString);
	SKIP_UNIT_TEST_FUNCTION(ose_copyPayloadToBlob);
	SKIP_UNIT_TEST_FUNCTION(ose_swapStringToAddress);
	SKIP_UNIT_TEST_FUNCTION(ose_copyTTToBlob);
	SKIP_UNIT_TEST_FUNCTION(ose_decatenateBlob);
	SKIP_UNIT_TEST_FUNCTION(ose_decatenateString);
	SKIP_UNIT_TEST_FUNCTION(ose_elemToBlob);
	SKIP_UNIT_TEST_FUNCTION(ose_itemToBlob);
	SKIP_UNIT_TEST_FUNCTION(ose_joinBlobs);
	SKIP_UNIT_TEST_FUNCTION(ose_joinStrings);
	SKIP_UNIT_TEST_FUNCTION(ose_moveStringToAddress);
	SKIP_UNIT_TEST_FUNCTION(ose_splitBlobFromEnd);
	SKIP_UNIT_TEST_FUNCTION(ose_splitBlobFromStart);
	SKIP_UNIT_TEST_FUNCTION(ose_splitStringFromEnd);
	SKIP_UNIT_TEST_FUNCTION(ose_splitStringFromStart);
	SKIP_UNIT_TEST_FUNCTION(ose_swap4Bytes);
	SKIP_UNIT_TEST_FUNCTION(ose_swap8Bytes);
	SKIP_UNIT_TEST_FUNCTION(ose_swapNBytes);
	SKIP_UNIT_TEST_FUNCTION(ose_trimBlob);
	SKIP_UNIT_TEST_FUNCTION(ose_trimString);
	SKIP_UNIT_TEST_FUNCTION(ose_match);
	SKIP_UNIT_TEST_FUNCTION(ose_pmatch);

	/**************************************************
	 * Creatio Ex Nihilo
	 **************************************************/
	SKIP_UNIT_TEST_FUNCTION(ose_makeBlob);
	SKIP_UNIT_TEST_FUNCTION(ose_pushBundle);

	/**************************************************
	 * Arithmetic
	 **************************************************/
	SKIP_UNIT_TEST_FUNCTION(ose_add);
	SKIP_UNIT_TEST_FUNCTION(ose_sub);
	SKIP_UNIT_TEST_FUNCTION(ose_mul);
	SKIP_UNIT_TEST_FUNCTION(ose_div);
	SKIP_UNIT_TEST_FUNCTION(ose_mod);
	SKIP_UNIT_TEST_FUNCTION(ose_neg);
	SKIP_UNIT_TEST_FUNCTION(ose_eql);
	SKIP_UNIT_TEST_FUNCTION(ose_lte);
	SKIP_UNIT_TEST_FUNCTION(ose_lt);
	SKIP_UNIT_TEST_FUNCTION(ose_and);
	SKIP_UNIT_TEST_FUNCTION(ose_or);
	
	finalize();
	return 0;
}
