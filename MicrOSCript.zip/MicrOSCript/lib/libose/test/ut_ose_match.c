#include "ose_test_common.h"
#include "ose_test_unit.h"
#include "ose_test_ctosc.h"
#include "ose_match.h"

#define RET_FULLMATCH                           \
    OSE_MATCH_PATTERN_COMPLETE                  \
    | OSE_MATCH_ADDRESS_COMPLETE

#define MATCH_PATTERN(test)                                     \
    (                                                           \
        (test.debug) ? raise(SIGTRAP) : 0,                      \
        test.ret = ose_match_pattern(test.pattern,              \
                                     test.address,              \
                                     &(test.po),                \
                                     &(test.ao)),               \
        printf("ret = %d, eret = %d\n", test.ret, test.eret),   \
        printf("po = %d, epo = %d\n", test.po, test.epo),       \
        printf("ao = %d, eao = %d\n", test.ao, test.eao),       \
        (test.ret == test.eret                                  \
         && test.po == test.epo                                 \
         && test.ao == test.eao)                                \
        )

#define FULLMATCH(desc, p, o)                                       \
    {desc, p, o, RET_FULLMATCH, strlen(p), strlen(o), 0, 0, 0, 0}

#define FAIL(desc, p, o)                                \
    {desc, p, o, OSE_MATCH_NOMATCH, 0, 0, 0, 0, 0, 0}

#define FAIL_ERROR(desc, p, o, errorcode)       \
    {desc, p, o, errorcode, 0, 0, 0, 0, 0, 0}

#define FULLMATCH_DEBUG(desc, p, o)                                 \
    {desc, p, o, RET_FULLMATCH, strlen(p), strlen(o), 0, 0, 0, 1}

#define FAIL_DEBUG(desc, p, o)                          \
    {desc, p, o, OSE_MATCH_NOMATCH, 0, 0, 0, 0, 0, 1}

struct match_test
{
    const char * const desc;
    const char * const pattern;
    const char * const address;
    int eret, epo, eao;
    int ret, po, ao;
    int debug;
} match_test_arr[] =
{
    FULLMATCH("simple match", "/wessel", "/wessel"),
    
	/**************************************************/
    /* question mark */
    /**************************************************/
    FULLMATCH("question mark", "/wesse?", "/wessel"),
    FULLMATCH("question mark", "/wes?el", "/wessel"),
    FULLMATCH("question mark", "/?essel", "/wessel"),
    FULLMATCH("question mark", "/?e?se?", "/wessel"),
    FULLMATCH("question mark", "/??????", "/wessel"),

    /**************************************************/
    /* star */
    /**************************************************/
    FULLMATCH("star", "/*", "/wessel"),
    FULLMATCH("star", "/w*", "/wessel"),
    FULLMATCH("star", "/*sel", "/wessel"),
    FULLMATCH("star", "/*ss*", "/wessel"),
    FULLMATCH("star", "/*ss*l", "/wessel"),
    FULLMATCH("star", "/*ss**l", "/wessel"),
    FULLMATCH("star", "/*ss***l", "/wessel"),
    FULLMATCH("star", "/****l", "/wessel"),

    FAIL("star", "/*x", "/wessel"),

    /**************************************************/
    /* character class */
    /**************************************************/
    FULLMATCH("character class", "/we[as]sel", "/wessel"),
    FULLMATCH("character class", "/we[as]sel", "/weasel"),
    FULLMATCH("character class", "/we[a-z]sel", "/wessel"),
    FULLMATCH("character class", "/[wv]e[as]sel", "/wessel"),
    FULLMATCH("character class", "/[wv]e[as]sel", "/weasel"),
    FULLMATCH("character class", "/[wv]e[as]sel", "/vessel"),
    FULLMATCH("character class", "/[!a-uxyz]e[as]sel", "/wessel"),
    FULLMATCH("character class", "/[wv-]e[as]sel", "/-essel"),
    FULLMATCH("character class", "/[-wv]e[as]sel", "/-essel"),
    FULLMATCH("character class", "/[wv]e[as]se[l!]", "/vesse!"),
    FULLMATCH("character class", "/[wv]e[[]ss[]]el", "/we[ss]el"),
    FULLMATCH("character class",
              "/[a-zA-Z][a-zA-Z][a-zA-Z][a-zA-Z][a-zA-Z][a-zA-Z]",
              "/WeSsEl"),
    
    FAIL("character class", "/[!a-uxyz]e[as]sel", "/kessel"),

    /**************************************************/
    /* alternatives */
    /**************************************************/
    FULLMATCH("alternatives", "/{w,v}e{a,s}sel", "/wessel"),
    FULLMATCH("alternatives", "/{w,v}e{a,s}sel", "/weasel"),
    FULLMATCH("alternatives", "/{w,v}e{a,s}sel", "/vessel"),
    FULLMATCH("alternatives", "/{wes,wea,ves}sel", "/wessel"),
    FULLMATCH("alternatives", "/{wes,wea,ves}sel", "/weasel"),
    FULLMATCH("alternatives", "/{wes,wea,ves}sel", "/vessel"),
    FULLMATCH("alternatives", "/{wessel,weasel,vessel}", "/wessel"),
    FULLMATCH("alternatives", "/{wessel,weasel,vessel}", "/weasel"),
    FULLMATCH("alternatives", "/{wessel,weasel,vessel}", "/vessel"),

    /**************************************************/
    /* question mark + star */
    /**************************************************/
    FULLMATCH("question mark + star", "/*?*l", "/wessel"),
    FULLMATCH("question mark + star", "/**l", "/l"),
    FULLMATCH("question mark + star", "/*e?*l", "/wessel"),
    FAIL("question mark + star", "/*?*l", "/l"),
    FAIL("question mark + star", "/?**l", "/l"),
    FAIL("question mark + star", "/**?l", "/l"),
    FAIL("question mark + star", "/?*l", "/l"),
    FAIL("question mark + star", "/*?l", "/l"),

    /**************************************************/
    /* question mark + star + character class */
    /**************************************************/
    FULLMATCH("question mark + star + character class",
              "/[wv]*?",
              "/wessel"),
    FULLMATCH("question mark + star + character class",
              "/[wv]*?",
              "/wl"),
    /* ? and * are not wildcards inside of [] */
    FULLMATCH("question mark + star + character class",
              "/w[?]s[*]el",
              "/w?s*el"),
    FAIL("question mark + star + character class",
         "/w[?]s[*]el",
         "/w?s*eel"),
    FAIL("question mark + star + character class",
         "/[wv]*?",
         "/w"),

    /**************************************************/
    /* question mark + star + alternatives */
    /**************************************************/
    FULLMATCH("question mark + star + alternatives",
              "/{w,v}*{a,s}s*?",
              "/wessel"),
    FULLMATCH("question mark + star + alternatives",
              "/*{wes,wea}?*",
              "/wessel"),
    FULLMATCH("question mark + star + alternatives",
              "/*{wes,wea}???*",
              "/wessel"),
    FULLMATCH("question mark + star + alternatives",
              "/*{wes,wea}*???*",
              "/wessel"),
    FAIL("question mark + star + alternatives",
         "/?{wes,wea}???*",
         "/wessel"),
    FAIL("question mark + star + alternatives",
         "/*{wess,weas}???*",
         "/wessel"),

    /**************************************************/
    /* question mark + star + character class + alternatives */
    /**************************************************/
    FULLMATCH("question mark + star + character class + alternatives",
              "/*{wea,wes}[sS]*?*",
              "/wessel"),
    FULLMATCH("question mark + star + character class + alternatives",
              "/*{wea,wes}[k-uK-U]*?*",
              "/wessel"),
    FULLMATCH("question mark + star + character class + alternatives",
              "/*{wea,wes}[k-uK-U]*?*",
              "/weaSel"),
    FAIL("question mark + star + character class + alternatives",
         "/*{wea,wes}[k-uK-U]*?*",
         "/weavel"),
    FAIL("question mark + star + character class + alternatives",
         "/*{wea,wes}[!k-uK-U]*?*",
         "/weaSel"),

    /**************************************************/
    /* multiple containers, full match */
    /**************************************************/
    FULLMATCH("multiple containers, full match",
              "/*/?/wessel",
              "/david/l/wessel"),
    FULLMATCH("multiple containers, full match",
              "/*/*/wessel",
              "/david/l/wessel"),
    FULLMATCH("multiple containers, full match",
              "/*/**/wessel",
              "/david/l/wessel"),
    FULLMATCH("multiple containers, full match",
              "/*/?/*",
              "/david/l/wessel"),
    FULLMATCH("multiple containers, full match",
              "/*/l/{wes,wea,ves}[sS]??",
              "/david/l/weaSel"),
    FAIL("multiple containers, full match",
         "/*/l/{wes,wea,ves}[sS]??",
         "/david/k/weaSel"),
    /* patterns don't match slashes in addresses */
    FAIL("multiple containers, full match",
         "/david???wessel",
         "/david/l/wessel"),
    FAIL("multiple containers, full match",
         "/david*wessel",
         "/david/l/wessel"),
    FAIL("multiple containers, full match",
         "/david[/]?[/]wessel",
         "/david/l/wessel"),

    /**************************************************/
    /* partial pattern, full address */
    /**************************************************/
    /**************************************************/
    /* full pattern, partial address */
    /**************************************************/
    /**************************************************/
    /* partial pattern, partial address */
    /**************************************************/

    /**************************************************/
    /* descendants */
    /**************************************************/
    FULLMATCH("descendants", "//wessel", "/david/l/wessel"),
    FULLMATCH("descendants", "/david//wessel", "/david/l/wessel"),
    /* cannot end with a // */
    FAIL("descendants", "/david/l//", "/david/l/wessel"),
    FULLMATCH("descendants",
              "//wessel//berkeley",
              "/david/l/wessel/director/cnmat/uc/berkeley"),
    FULLMATCH("descendants",
              "/david//wessel//berkeley",
              "/david/l/wessel/director/cnmat/uc/berkeley"),
    /* // is not optional */
    FAIL("descendants",
         "/david/l//wessel//berkeley",
         "/david/l/wessel/director/cnmat/uc/berkeley"),
    FULLMATCH("descendants",
              "//wessel//berkeley",
              "/david/l/wessel/berkeley/director/cnmat/uc/berkeley"),
    FULLMATCH("descendants",
              "//berkeley",
              "/david/l/wessel/berkeley/director/cnmat/uc/berkeley"),
    FULLMATCH("descendants",
              "////berkeley",
              "/david/l/wessel/berkeley/director/cnmat/uc/berkeley"),
    FULLMATCH("descendants",
              "////wessel////berkeley",
              "/david/l/wessel/berkeley/director/cnmat/uc/berkeley"),
    FULLMATCH("descendants",
              "/david//wessel",
              "/david//wessel"),
    FULLMATCH("descendants",
              "/david//wessel//berkeley",
              "/david//wessel/director/cnmat/uc/berkeley"),
    FAIL("descendants",
         "///wessel//berkeley",
         "/david/l/wessel/berkeley/director/cnmat/uc/berkeley"),
    FAIL("descendants",
         "////wessel/////berkeley",
         "/david/l/wessel/berkeley/director/cnmat/uc/berkeley"),
    /* should be partial match */
    /* FULLMATCH("descendants", */
    /*           "//wessel//berkeley", */
    /*           "/david/l/wessel/berkeley/director/cnmat/uc"), */

    /**************************************************/
    /* repetition */
    /**************************************************/
    FULLMATCH("repetition",
              "/david/l/wes#el",
              "/david/l/wessel"),
    FULLMATCH("repetition",
              "/david/l/wes##el",
              "/david/l/wessel"),
    FULLMATCH("repetition",
              "/david/l#/wessel",
              "/david/l/wessel"),
    FAIL("repetition",
         "/david/l##/wessel",
         "/david/l/wessel"),
    FAIL_ERROR("repetition",
               "/#david/l/wessel",
               "/david/l/wessel",
               OSE_MATCH_ERROR_INVALID_REPETITION),
    FAIL_ERROR("repetition",
               "/##david/l/wessel",
               "/david/l/wessel",
               OSE_MATCH_ERROR_INVALID_REPETITION),
    FAIL_ERROR("repetition",
               "/david/#l/wessel",
               "/david/l/wessel",
               OSE_MATCH_ERROR_INVALID_REPETITION),
    FAIL_ERROR("repetition",
               "/david/##l/wessel",
               "/david/l/wessel",
               OSE_MATCH_ERROR_INVALID_REPETITION),

    FULLMATCH("repetition",
              "/david/l/?##el",
              "/david/l/wessel"),
    FULLMATCH("repetition",
              "/david/l/wessel#",
              "/david/l/wessel"),
    
    FULLMATCH("repetition",
              "/david/l/we[sS]#el",
              "/david/l/wessel"),
    FULLMATCH("repetition",
              "/david/l/we[sS]##el",
              "/david/l/wessel"),

    FULLMATCH("repetition",
              "/david/l/{wessel,weasel,vessel}##",
              "/david/l/wesselvesselweasel"),
    FULLMATCH("repetition",
              "/[david]##/l/wessel",
              "/david/l/wessel"),
    FULLMATCH("repetition",
              "/[a-v]##/l/wessel",
              "/david/l/wessel"),

    FULLMATCH("repetition",
              "/*#/l/wessel",
              "/david/l/wessel"),
    FULLMATCH("repetition",
              "/david/l/we*#",
              "/david/l/wessel"),
    FULLMATCH("repetition",
              "/david/l/we*#l",
              "/david/l/wessel"),
    FULLMATCH("repetition",
              "/david/l/we*#?",
              "/david/l/wessel"),
    FULLMATCH("repetition",
              "/david/l/we*#?#",
              "/david/l/wessel"),
};

void ut_ose_match_pattern(void)
{
    for(int i = 0;
        i < sizeof(match_test_arr)
            / sizeof(struct match_test);
        ++i)
    {
        struct match_test test = match_test_arr[i];
        printf("%s %s\n", test.pattern, test.address);
        UNIT_TEST(MATCH_PATTERN(test),
                  1,
                  test.desc);
        printf("********************\n");
    }              
}

int main(int ac, char **av)
{
    init();
    UNIT_TEST_FUNCTION(ose_match_pattern);
    finalize();
    return 0;
}
