/*
  Copyright (c) 2019-23 John MacCallum Permission is hereby granted,
  free of charge, to any person obtaining a copy of this software
  and associated documentation files (the "Software"), to deal in
  the Software without restriction, including without limitation the
  rights to use, copy, modify, merge, publish, distribute,
  sublicense, and/or sell copies of the Software, and to permit
  persons to whom the Software is furnished to do so, subject to the
  following conditions:

  The above copyright notice and this permission notice shall be
  included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
  DEALINGS IN THE SOFTWARE.
*/

#ifndef OSE_ERRNO
#define OSE_ERRNO

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @file ose_errno.h
 * 
 * @brief Status codes for context bundles.
 */
enum ose_errno
{
    OSE_ERR_NONE = 0,           /**< No error */
    OSE_ERR_TYPE,               /**< Generic type-related error */
    OSE_ERR_ELEM_TYPE,          /**< Wrong type of element encountered */
    OSE_ERR_ITEM_TYPE,          /**< Wrong type of item encountered */
    OSE_ERR_ELEM_COUNT,         /**< Bundle has the wrong number of elements */
    OSE_ERR_ITEM_COUNT,         /**< An element has the wrong number of items */
    OSE_ERR_RANGE,              /**< Range error */
    OSE_ERR_UNKNOWN_TYPETAG,    /**< Unknown typetag */
    OSE_ERR_UNKNOWN_CONTEXT_BUNDLE /**< Unknown context bundle referred to */
};

/**
 * @brief Set the errno value of \p b to \p e.
 */
#define ose_errno_set(b, e) ose_context_set_status(b, e)

/**
 * @brief Get the errno for bundle \p b.
 */
#define ose_errno_get(b) ose_context_get_status(b)

#ifdef __cplusplus
}
#endif

#endif
