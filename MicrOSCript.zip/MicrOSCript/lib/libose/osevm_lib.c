/*
  Copyright (c) 2019-23 John MacCallum Permission is hereby
  granted, free of charge, to any person obtaining a copy of this
  software and associated documentation files (the "Software"), to
  deal in the Software without restriction, including without
  limitation the rights to use, copy, modify, merge, publish,
  distribute, sublicense, and/or sell copies of the Software, and
  to permit persons to whom the Software is furnished to do so,
  subject to the following conditions:

  The above copyright notice and this permission notice shall be
  included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
  OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
  OTHER DEALINGS IN THE SOFTWARE.
*/

#include <string.h>

#include "ose.h"
#include "ose_context.h"
#include "ose_stackops.h"
#include "ose_util.h"
#include "ose_assert.h"
#include "ose_errno.h"
#include "ose_vm.h"
#include "osevm_lib.h"

void osevm_exec1(ose_bundle osevm)
{
    ose_bundle vm_i = OSEVM_INPUT(osevm);
    ose_bundle vm_s = OSEVM_STACK(osevm);
    ose_bundle vm_e = OSEVM_ENV(osevm);
    ose_bundle vm_c = OSEVM_CONTROL(osevm);
    ose_bundle vm_d = OSEVM_DUMP(osevm);

    /* move input to dump */
    ose_copyBundle(vm_i, vm_d);
    ose_clear(vm_i);

    /* copy env to dump  */
    ose_copyBundle(vm_e, vm_d);
    /* ose_replaceBundle(vm_s, vm_e); */

    /* put topmost stack element into input */
    ose_moveElem(vm_s, vm_i);
    if(ose_peekType(vm_i) == OSETT_BUNDLE)
    {
    	ose_popAllDrop(vm_i);
    }
    ose_pushBundle(vm_d);
    /* ose_copyBundle(vm_s, vm_d); */
    /* ose_clear(vm_s); */

    /* move topmost bundle to env */
    /* ose_replaceBundle(vm_s, vm_e); */

    /* move control to dump */
    ose_drop(vm_c);             /* drop our own exec command */
    ose_copyBundle(vm_c, vm_d);
    ose_clear(vm_c);
}

void osevm_exec2(ose_bundle osevm)
{
    ose_bundle vm_i = OSEVM_INPUT(osevm);
    ose_bundle vm_s = OSEVM_STACK(osevm);
    ose_bundle vm_e = OSEVM_ENV(osevm);
    ose_bundle vm_c = OSEVM_CONTROL(osevm);
    ose_bundle vm_d = OSEVM_DUMP(osevm);

    /* move input to dump */
    ose_copyBundle(vm_i, vm_d);
    ose_clear(vm_i);

    /* move env to dump  */
    ose_copyBundle(vm_e, vm_d);
    /* ose_replaceBundle(vm_s, vm_e); */

    /* put topmost stack element into input */
    ose_moveElem(vm_s, vm_i);
    if(ose_peekType(vm_i) == OSETT_BUNDLE)
    {
    	ose_popAllDrop(vm_i);
    }
    ose_pushBundle(vm_d);
    /* ose_copyBundle(vm_s, vm_d); */
    /* ose_clear(vm_s); */

    /* move topmost bundle to env */
    ose_replaceBundle(vm_s, vm_e);

    /* move control to dump */
    ose_drop(vm_c);             /* drop our own exec command */
    ose_copyBundle(vm_c, vm_d);
    ose_clear(vm_c);
}

void osevm_exec3(ose_bundle osevm)
{
    ose_bundle vm_i = OSEVM_INPUT(osevm);
    ose_bundle vm_s = OSEVM_STACK(osevm);
    ose_bundle vm_e = OSEVM_ENV(osevm);
    ose_bundle vm_c = OSEVM_CONTROL(osevm);
    ose_bundle vm_d = OSEVM_DUMP(osevm);

    /* move input to dump */
    ose_copyBundle(vm_i, vm_d);
    ose_clear(vm_i);

    /* move env to dump  */
    ose_copyBundle(vm_e, vm_d);
    /* ose_replaceBundle(vm_s, vm_e); */

    /* put topmost stack element into input */
    ose_moveElem(vm_s, vm_i);
    if(ose_peekType(vm_i) == OSETT_BUNDLE)
    {
    	ose_popAllDrop(vm_i);
    }
    ose_pushBundle(vm_d);

    /* move topmost bundle to env */
    ose_replaceBundle(vm_s, vm_e);

    /* unpack topmost bundle onto stack */
    ose_unpackDrop(vm_s);

    /* ose_copyBundle(vm_s, vm_d); */
    /* ose_clear(vm_s); */

    /* move control to dump */
    ose_drop(vm_c);             /* drop our own exec command */
    ose_copyBundle(vm_c, vm_d);
    ose_clear(vm_c);
}

void osevm_exec(ose_bundle osevm)
{
    osevm_exec2(osevm);    
}

void osevm_if(ose_bundle osevm)
{
    ose_bundle vm_s = OSEVM_STACK(osevm);
    ose_bundle vm_e = OSEVM_ENV(osevm);
    ose_bundle vm_c = OSEVM_CONTROL(osevm);
    ose_pushInt32(vm_s, 0);
    ose_neq(vm_s);
    ose_roll(vm_s);
    ose_drop(vm_s);
    ose_copyBundle(vm_e, vm_s);
    ose_swap(vm_s);
    ose_pushString(vm_c, "/!/exec");
    ose_swap(vm_c);
}

void osevm_dotimes(ose_bundle osevm)
{
    ose_bundle vm_c = OSEVM_CONTROL(osevm);
    ose_bundle vm_s = OSEVM_STACK(osevm);
    /* Just in case we're being called from apply or something */
    ose_drop(vm_c);
    ose_pushString(vm_c, "/!/dotimes");
    int32_t n = ose_popInt32(vm_s);
    if(n > 0)
    {
        ose_pushInt32(vm_c, n - 1);
        ose_copyElem(vm_s, vm_c);
        ose_pushString(vm_c, "/!/drop");
        ose_pushString(vm_c, "/!/exec1");
        ose_pushString(vm_c, "/!/dotimes");
    }
    else
    {
        ose_drop(vm_s);
    }
}

static enum ose_errno getRegsFromAddr(ose_bundle osevm,
                                      ose_bundle *req,
                                      ose_bundle *opt)
{
    ose_bundle vm_s = OSEVM_STACK(osevm);
    if(ose_peekType(vm_s) != OSETT_MESSAGE)
    {
        ose_errno_set(osevm, OSE_ERR_ELEM_TYPE);
        return OSE_ERR_ELEM_TYPE;
    }
    if(!ose_isStringType(ose_peekMessageArgType(vm_s)))
    {
        ose_errno_set(osevm, OSE_ERR_ITEM_TYPE);
        return OSE_ERR_ITEM_TYPE;
    }
    const char * const str = ose_peekString(vm_s);
    const int32_t len = strlen(str);
    if(len == 3)
    {
        *opt = vm_s;
        *req = ose_enter(osevm, str);
    }
    else if(len == 6)
    {
        char buf[4];
        for(int i = 0; i < 3; ++i)
        {
            buf[i] = str[i];
        }
        buf[3] = 0;
        *opt = ose_enter(osevm, str + 3);
        *req = ose_enter(osevm, buf);
    }
    else
    {
        ose_errno_set(osevm, OSE_ERR_ITEM_COUNT);
        return OSE_ERR_ITEM_COUNT;
    }
    return OSE_ERR_NONE;
}

void osevm_copyRegisterToElem(ose_bundle osevm)
{
    ose_bundle vm_s = OSEVM_STACK(osevm);
    ose_bundle src, dest;
    getRegsFromAddr(osevm, &src, &dest);
    ose_drop(vm_s);
    ose_copyBundle(src, dest);
}

void osevm_appendElemToRegister(ose_bundle osevm)
{
    ose_bundle vm_s = OSEVM_STACK(osevm);
    ose_bundle src, dest;
    getRegsFromAddr(osevm, &dest, &src);
    ose_drop(vm_s);
    ose_appendBundle(src, dest);
}

void osevm_replaceRegisterWithElem(ose_bundle osevm)
{
    ose_bundle vm_s = OSEVM_STACK(osevm);
    ose_bundle src, dest;
    getRegsFromAddr(osevm, &dest, &src);
    ose_drop(vm_s);
    ose_replaceBundle(src, dest);
}

void osevm_moveElemToRegister(ose_bundle osevm)
{
    ose_bundle vm_s = OSEVM_STACK(osevm);
    ose_bundle src, dest;
    getRegsFromAddr(osevm, &dest, &src);
    ose_drop(vm_s);
    ose_moveElem(src, dest);
}

void osevm_copyElemToRegister(ose_bundle osevm)
{
    ose_bundle vm_s = OSEVM_STACK(osevm);
    ose_bundle src, dest;
    getRegsFromAddr(osevm, &dest, &src);
    ose_drop(vm_s);
    ose_copyElem(src, dest);
}


void osevm_apply(ose_bundle osevm)
{
    ose_bundle vm_i = OSEVM_INPUT(osevm);
    ose_bundle vm_s = OSEVM_STACK(osevm);
    ose_bundle vm_e = OSEVM_ENV(osevm);
    ose_bundle vm_c = OSEVM_CONTROL(osevm);
    ose_bundle vm_d = OSEVM_DUMP(osevm);

    ose_assert(ose_bundleHasAtLeastNElems(vm_s, 1));
    while(1)
    {
        char elemtype = ose_peekType(vm_s);
        if(elemtype == OSETT_BUNDLE)
        {
            /* move input to dump */
            ose_copyBundle(vm_i, vm_d);
            ose_clear(vm_i);
            {
                /* move the contents of the bundle on the stack to
                   the input, and unpack it in reverse order */
                char *sp = ose_getBundlePtr(vm_s);
                char *ip = ose_getBundlePtr(vm_i);
                int32_t stackoffset = OSE_BUNDLE_HEADER_LEN;
                int32_t stacksize = ose_readSize(vm_s);
                ose_assert(stackoffset < stacksize);
                int32_t s = ose_readInt32(vm_s, stackoffset);
                while(stackoffset + s + 4 < stacksize)
                {
                    stackoffset += s + 4;
                    s = ose_readInt32(vm_s, stackoffset);
                }

                int32_t o1, o2;
                o1 = stackoffset + 4 + OSE_BUNDLE_HEADER_LEN;
                ose_incSize(vm_i, s - OSE_BUNDLE_HEADER_LEN);
                o2 = ose_readSize(vm_i);
                int32_t end = o1 + s - OSE_BUNDLE_HEADER_LEN;;
                while(o1 < end)
                {
                    int32_t ss = ose_readInt32(vm_s, o1);
                    o2 -= ss + 4;
                    memcpy(ip + o2, sp + o1, ss + 4);
                    o1 += ss + 4;
                }
                ose_dropAtOffset(vm_s, stackoffset);
            }

            /* copy environment to dump */
            ose_copyBundle(vm_e, vm_d);

            /* move stack to dump */
            ose_pushBundle(vm_d);

            /* move control to dump */
            ose_drop(vm_c);
            /* ose_return leaves the env on the stack */
            /* ose_pushString(vm_c, "/!/drop"); */
            ose_pushString(vm_c, "/</_e");
            ose_copyBundle(vm_c, vm_d);
            ose_clear(vm_c);
            break;
        }
        else if(elemtype == OSETT_MESSAGE)
        {
            int32_t o = ose_getLastBundleElemOffset(vm_s);
            int32_t to, ntt, lto, po, lpo;
            ose_getNthPayloadItem(vm_s, 1, o,
                                  &to, &ntt, &lto, &po, &lpo);
            char itemtype = ose_getBundlePtr(vm_s)[lto];
            const char * const p = ose_getBundlePtr(vm_s) + lpo;
            if(itemtype == OSETT_BLOB)
            {
                int32_t len = ose_ntohl(*((int32_t *)p));
                if(len >= OSE_BUNDLE_HEADER_LEN
                   && !strncmp(OSE_BUNDLE_ID,
                               p + 4,
                               OSE_BUNDLE_ID_LEN))
                {
                    /* blob is a bundle */
                    ose_blobToElem(vm_s);
                    continue;
                }
                else
                {
                    /* blob is not a bundle */
                    int32_t o = p - ose_getBundlePtr(vm_s);
                    ose_alignPtr(vm_s, o + 4);
                    ose_fn f = (ose_fn)ose_readAlignedPtr(vm_s, o + 4);
                    if(f)
                    {
                        ose_drop(vm_s);
                        f(osevm);
                        break;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            else
            {
                /* 
                   If there's a message that contains something
                   other than a blob (which might contain a bundle
                   or a function pointer), we just leave it on the
                   stack. Effectively, this means that "application"
                   of a string, int, float, etc. means that the
                   object takes no arguments and returns itself.
                */
                break;
            }
        }
        else
        {
            ose_assert(0 && "encountered unknown element type!");
            break;
        }
    }
}

void osevm_map(ose_bundle osevm)
{
    ose_bundle vm_s = OSEVM_STACK(osevm);
    ose_bundle vm_c = OSEVM_CONTROL(osevm);
    ose_assert(ose_bundleHasAtLeastNElems(vm_s, 2));
    /* Just in case we're being called from apply or something */
    ose_drop(vm_c);
    ose_pushString(vm_c, "/!/map");
    ose_swap(vm_s);
    char t = ose_peekType(vm_s);
    if(t == OSETT_BUNDLE)
    {
        ose_countItems(vm_s);
        int32_t n = ose_popInt32(vm_s);
        ose_popAll(vm_s);
        int i = 0;//, j = -1;
        ose_pushBundle(vm_s);
        /* ENm1 ... E0 B B - */
        /* B1 => items */
        /* B0 => elems */
        for(i = 0; i < n; i++)
        {
            /* ENm1 ... E0 B1 B0 - */
            ose_rot(vm_s);
            /* ENm1 ... B1 B0 E0 - */
            ose_countItems(vm_s);
            int nitems = ose_popInt32(vm_s);
            if(nitems == 0)
            {
                for(i = 0; i < n + 3; i++)
                {
                    ose_drop(vm_s);
                }
                return;
            }
            else
            {                     /* ENm1 ...    B1 B0 E0 - */
                ose_pop(vm_s);    /* ENm1 ... B1 B0 E0 I0 - */
                ose_rrot(vm_s); /* ENm1 ... B1 I0 B0 E0 - */
                ose_push(vm_s);   /* ENm1 ...    B1 I0 B0 - */
                ose_rrot(vm_s); /* ENm1 ...    B0 B1 I0 - */
                ose_push(vm_s);   /* ENm1 ...       B0 B1 - */
                ose_swap(vm_s);   /* ENm1 ...       B1 B0 - */
            }
        }
        /* B1 B0 - */
        ose_copyElem(vm_s, vm_c);
        ose_drop(vm_s);
        ose_swap(vm_s);
        ose_copyElem(vm_s, vm_c);
        ose_swap(vm_c);
        ose_pushString(vm_c, "/!/apply");
        ose_pushString(vm_c, "/!/map");
        ose_push(vm_s);
        ose_unpackDrop(vm_s);
    }
    else
    {
        ose_countItems(vm_s);
        if(ose_popInt32(vm_s) > 0)
        {
            ose_swap(vm_s);
            ose_copyElem(vm_s, vm_c);
            ose_swap(vm_s);
            ose_pop(vm_s);
            ose_swap(vm_s);
            ose_copyElem(vm_s, vm_c);
            ose_drop(vm_s);
            ose_swap(vm_s);
            ose_pushString(vm_c, "/!/apply");
            ose_pushString(vm_c, "/!/map");
        }
        else
        {
            ose_2drop(vm_s);
        }
    }
}

void osevm_return(ose_bundle osevm)
{
    ose_bundle vm_i = OSEVM_INPUT(osevm);
    ose_bundle vm_s = OSEVM_STACK(osevm);
    ose_bundle vm_e = OSEVM_ENV(osevm);
    ose_bundle vm_c = OSEVM_CONTROL(osevm);
    ose_bundle vm_d = OSEVM_DUMP(osevm);

    /* restore control */
    ose_replaceBundle(vm_d, vm_c);

    ose_bundleAll(vm_s);
    ose_moveElem(vm_d, vm_s);
    ose_swap(vm_s);
    ose_push(vm_s);
    ose_unpackDrop(vm_s);
    ose_unpackDrop(vm_s);

    /* put the env on the stack */
    ose_copyBundle(vm_e, vm_s);
    
    /* restore env */
    /*ose_copyBundle(vm_e, vm_s); */
    ose_replaceBundle(vm_d, vm_e);

    /* restore input */
    ose_replaceBundle(vm_d, vm_i);
}

void osevm_version(ose_bundle osevm)
{
    ose_bundle vm_s = OSEVM_STACK(osevm);
    ose_pushString(vm_s, ose_version_string);
#ifdef OSE_DEBUG
    ose_pushString(vm_s, ose_debug_string);
#endif
    ose_pushString(vm_s, ose_date_compiled_string);
}

void osevm_assignStackToRegister(ose_bundle osevm)
{
    ose_bundle vm_s = OSEVM_STACK(osevm);
    if(strcmp(ose_getBundlePtr(vm_s) + OSE_BUNDLE_HEADER_LEN + 4,
              OSE_BUNDLE_ID))
    {
        ose_errno_set(vm_s, OSE_ERR_ELEM_TYPE);
        return;
    }
    if(ose_getBundleElemCount(vm_s) == 2)
    {
        if(ose_peekType(vm_s) == OSETT_MESSAGE
           && ose_peekMessageArgType(vm_s) == OSETT_STRING)
        {
            ose_moveStringToAddress(vm_s);
        }
        ose_push(vm_s);
        return;
    }
    if(ose_peekType(vm_s) != OSETT_MESSAGE)
    {
        ose_errno_set(vm_s, OSE_ERR_ELEM_TYPE);
        return;
    }
    if(ose_peekMessageArgType(vm_s) != OSETT_STRING)
    {
        ose_errno_set(vm_s, OSE_ERR_ITEM_TYPE);
        return;
    }
    while(1)
    {
        int32_t n = ose_getBundleElemCount(vm_s);
        if(n == 2)
        {
            break;
        }
        ose_swap(vm_s);
        if(ose_peekType(vm_s) == OSETT_BUNDLE)
        {
            ose_elemToBlob(vm_s);
        }
        ose_swap(vm_s);
        ose_push(vm_s);
    }
    ose_moveStringToAddress(vm_s);
    ose_push(vm_s);
}

void osevm_assignStackToEnv_impl(ose_bundle osevm,
                                       ose_bundle env,
                                       int replace,
                                       int new_msg_first,
                                       char bundle_typetag)
{
    int32_t nelems = 0;
    int32_t nitems = 0;
    int32_t payload_bytes = 0;
    int32_t addr_offset = 0;
    int32_t addr_pbytes = 0;

    int32_t new_msg_size = 0;
    int32_t new_msg_offset = 0;
    int32_t new_msg_ao = 0;
    int32_t new_msg_tto = 0;
    int32_t new_msg_plo = 0;

    {
        /* 
           First pass: collect the number of elems, items in each
           elem, and find the address. 

           Nothing gets modified
        */
        ose_constbundle vm_s = OSEVM_STACK(osevm);
        const char * const bs = ose_getBundlePtr(vm_s);
        
        int32_t o = OSE_BUNDLE_HEADER_LEN;
        int32_t s = ose_readSize(vm_s);
        while(o < s)
        {
            int32_t es = ose_readInt32(vm_s, o);
            if(o + es + 4 >= s)
            {
                /* next one is the message with the address */
                break;
            }
            ++nelems;
            if(bs[o + 4] == '#'
               && !strcmp(bs + o + 4, OSE_BUNDLE_ID))
            {
                /* this is a bundle, so will become a blob */
                ++nitems;
                payload_bytes += es + 4;
            }
            else
            {
                int32_t ao = o + 4;
                int32_t tto = ao + ose_pstrlen(bs + ao);
                int32_t ntt = strlen(bs + tto);
                int32_t plo = tto + ose_pnbytes(ntt);
                int32_t pls = es - (plo - ao);
                
                nitems += (ntt - 1);
                payload_bytes += pls;
            }

            o += es + 4;
        }
        if(bs[o + 4] == '#'
           && !strcmp(bs + o + 4, OSE_BUNDLE_ID))
        {
            /* this should be an address */
            ose_errno_set(osevm, OSE_ERR_ELEM_TYPE);
            return;
        }
        int32_t es = ose_readInt32(vm_s, o);
        int32_t ao = o + 4;
        int32_t tto = ao + ose_pstrlen(bs + ao);
        int32_t ntt = strlen(bs + tto);
        int32_t plo = tto + ose_pnbytes(ntt);
        int32_t pls = es - (plo - ao);
        addr_offset = plo;
        addr_pbytes = pls;
    }

    /* 
       Modification of the env begins here
    */
    {
        /* 
           Remove any messages in the env with the same address as
           our new one, then write the skeleton of our new
           message at the end of the bundle.
        */
        ose_constbundle vm_s = OSEVM_STACK(osevm);
        const char * const bs = ose_getBundlePtr(vm_s);
        ose_bundle vm_e = env; /* OSEVM_ENV(osevm); */
        char *be = ose_getBundlePtr(vm_e);
        const char * const addr = bs + addr_offset;
        int32_t o = OSE_BUNDLE_HEADER_LEN;
        int32_t s = ose_readSize(vm_e);
        if(replace)
        {
            while(o < s)
            {
                int32_t es = ose_readInt32(vm_e, o);
                if(!strcmp(be + o + 4, addr))
                {
                    memmove(be + o,
                            be + o + es + 4,
                            s - o);
                    memset(be + (s - (es + 4)), 0, s - o);
                    ose_decSize(vm_e, es + 4);
                    s -= es + 4;
                }
                else
                {
                    o += es + 4;
                }
            }
        }

        if(new_msg_first)
        {
            new_msg_offset = OSE_BUNDLE_HEADER_LEN;
            new_msg_ao = new_msg_offset + 4;
            new_msg_tto = new_msg_ao + addr_pbytes;
            new_msg_plo = new_msg_tto + ose_pnbytes(nitems + 1);
            
            new_msg_size = addr_pbytes
                + (new_msg_plo - new_msg_tto)
                + payload_bytes;
        
            ose_incSize(vm_e, new_msg_size + 4);
            memset(be + s, 0, new_msg_size + 4);
            memmove(be + new_msg_offset + new_msg_size + 4,
                    be + new_msg_offset,
                    s);
            memset(be + new_msg_offset, 0, new_msg_size + 4);
            ose_writeInt32(vm_e, new_msg_offset, new_msg_size);

            /* write the address */
            memcpy(be + new_msg_offset + 4, addr, addr_pbytes);
            /* write the typetag id */
            be[new_msg_tto] = OSETT_ID;
        }
        else
        {
            new_msg_offset = o;
            new_msg_ao = new_msg_offset + 4;
            new_msg_tto = new_msg_ao + addr_pbytes;
            new_msg_plo = new_msg_tto + ose_pnbytes(nitems + 1);
            
            new_msg_size = addr_pbytes
                + (new_msg_plo - new_msg_tto)
                + payload_bytes;
        
            ose_incSize(vm_e, new_msg_size + 4);
            ose_writeInt32(vm_e, new_msg_offset, new_msg_size);

            /* write the address */
            memcpy(be + new_msg_offset + 4, addr, addr_pbytes);
            /* write the typetag id */
            be[new_msg_tto] = OSETT_ID;
        }
    }

    {
        /* 
           Second pass: copy the typetags and data into the new
           message in the env
 		*/
        ose_constbundle vm_s = OSEVM_STACK(osevm);
        const char * const bs = ose_getBundlePtr(vm_s);
        ose_bundle vm_e = env; /* OSEVM_ENV(osevm); */
        char *be = ose_getBundlePtr(vm_e);
        int32_t o = OSE_BUNDLE_HEADER_LEN;
        int32_t s = ose_readSize(vm_s);
        int32_t nm_tto = new_msg_tto + 1;
        int32_t nm_plo = new_msg_plo;
        while(o < s)
        {
            int32_t es = ose_readInt32(vm_s, o);
            if(o + es + 4 >= s)
            {
                break;
            }
            if(bs[o + 4] == '#'
               && !strcmp(bs + o + 4, OSE_BUNDLE_ID))
            {
                /* this is a bundle, so will become a blob */
                be[nm_tto] = bundle_typetag;
                ++nm_tto;
                memcpy(be + nm_plo,
                       bs + o,
                       es + 4);
                nm_plo += es + 4;
            }
            else
            {
                int32_t ao = o + 4;
                int32_t tto = ao + ose_pstrlen(bs + ao);
                int32_t ntt = strlen(bs + tto);
                int32_t plo = tto + ose_pnbytes(ntt);
                int32_t pls = es - (plo - ao);
                
                memcpy(be + nm_tto,
                       bs + tto + 1,
                       ntt - 1);
                nm_tto += ntt - 1;
                memcpy(be + nm_plo,
                       bs + plo,
                       pls);
                nm_plo += pls;
            }
            o += es + 4;
        }
    }
    {
        ose_bundle vm_s = OSEVM_STACK(osevm);
    	ose_clear(vm_s);
    }

    /* 
       This is the canonical (slow) version that does the same as
       above, with no support for setting whether the new message is
       first, or which context bundle to assign to
    */
    /* const char * const str = ose_peekString(vm_s); */
    /* if((OSE_ADDRESS_ANONVAL_LEN > 0 */
    /*     && !strcmp(str, OSE_ADDRESS_ANONVAL)) */
    /*    || strlen(str) == 0) */
    /* { */
    /*     /\* if there's nothing in the env, and this is the empty */
    /*        string, rollMatch_impl will crash, because the string */
    /*        will match itself *\/ */
    /* } */
    /* else */
    /* { */
    /*     ose_pushString(vm_e, str); */
    /*     while(ose_rollMatch_impl(vm_e)) */
    /*     { */
    /*         ose_drop(vm_e); */
    /*         ose_pushString(vm_e, ose_peekString(vm_s)); */
    /*     } */
    /*     ose_drop(vm_e); */
    /* } */
    /* while(1) */
    /* { */
    /*     int32_t n = ose_getBundleElemCount(vm_s); */
    /*     if(n == 1) */
    /*     { */
    /*         break; */
    /*     } */
    /*     ose_swap(vm_s); */
    /*     if(ose_peekType(vm_s) == OSETT_BUNDLE) */
    /*     { */
    /*         ose_elemToBlob(vm_s); */
    /*     } */
    /*     ose_swap(vm_s); */
    /*     ose_push(vm_s); */
    /* } */
    /* ose_moveStringToAddress(vm_s); */
    /* ose_moveElem(vm_s, vm_e); */
    /* ose_clear(vm_s); */
}

void osevm_assignStackToEnv(ose_bundle osevm)
{
    ose_bundle vm_s = OSEVM_STACK(osevm);
    ose_bundle vm_e = OSEVM_ENV(osevm);
    ose_bundle bndlenv = vm_e;

    {
        const char * const address = ose_peekString(vm_s);
        if(address[3] == '/')
        {
            const char buf[4] = {
                address[0],
                address[1],
                address[2],
                                0
            };
            int32_t o = ose_getContextMessageOffset(osevm, buf);
            if(o >= 0)
            {
                bndlenv = ose_enterBundleAtOffset(osevm, o);
                ose_pushString(vm_s, address + 3);
                ose_nip(vm_s);
            }
        }
    }
    osevm_assignStackToEnv_impl(osevm,
                                bndlenv,
                                1,
                                0,
                                OSETT_BLOB);
}

/* 
   This function is the default used by OSEVM_LOOKUP, which can
   be changed with a #define at compile time
*/
void osevm_lookupInEnv_impl(ose_bundle osevm)
{
    ose_bundle vm_s = OSEVM_STACK(osevm);
    ose_bundle vm_e = OSEVM_ENV(osevm);
    ose_bundle bndlenv = vm_e;
    int explicitbndl = 0;
    
    const char * const address = ose_peekString(vm_s);
    if(address[3] == '/')
    {
        const char buf[4] = {
            address[0],
            address[1],
            address[2],
            0
        };
        int32_t o = ose_getContextMessageOffset(osevm, buf);
        if(o >= 0)
        {
            bndlenv = ose_enterBundleAtOffset(osevm, o);
            explicitbndl = 1;
        }
    }

    if(explicitbndl)
    {
        int32_t mo = ose_getFirstOffsetForMatch(bndlenv,
                                                address + 3);
        if(mo >= OSE_BUNDLE_HEADER_LEN)
        {
            ose_drop(vm_s);
            ose_copyElemAtOffset(mo, bndlenv, vm_s);
            return;
        }
    }
    else
    {
        int32_t mo = ose_getFirstOffsetForMatch(vm_e, address);
        if(mo >= OSE_BUNDLE_HEADER_LEN)
        {
            ose_drop(vm_s);
            ose_copyElemAtOffset(mo, vm_e, vm_s);
            return;
        }
    }
}

/* 
   This is bound into the environment
*/
void osevm_lookupInEnv(ose_bundle osevm)
{
    OSEVM_LOOKUP(osevm);
}

/**
 * @todo Implement.
 */
void osevm_plookupInEnv_impl(ose_bundle osevm)
{
}

/**
 * @todo Implement.
 */
void osevm_plookupInEnv(ose_bundle osevm)
{
}

void osevm_funcall(ose_bundle osevm)
{
    OSEVM_LOOKUP(osevm);
    osevm_apply(osevm);
}

void osevm_makeRegister(ose_bundle osevm)
{
    ose_bundle vm_s = OSEVM_STACK(osevm);
    ose_swap(vm_s);
    int32_t nbytes = ose_popInt32(vm_s);
    const char * const str = ose_peekString(vm_s);
    ose_pushContextMessage(osevm, nbytes, str);
    ose_drop(vm_s);
}

void osevm_quote(ose_bundle osevm)
{}

OSEVM_WRAP_DEFN(toType)
OSEVM_WRAP_DEFN(toInt32)
OSEVM_WRAP_DEFN(toFloat)
OSEVM_WRAP_DEFN(toString)
OSEVM_WRAP_DEFN(toBlob)
OSEVM_WRAP_DEFN(appendByte)
#ifdef OSE_PROVIDE_TYPE_SYMBOL
OSEVM_WRAP_DEFN(toSymbol)
#endif
#ifdef OSE_PROVIDE_TYPE_DOUBLE
OSEVM_WRAP_DEFN(toDouble)
#endif
#ifdef OSE_PROVIDE_TYPE_INT8
OSEVM_WRAP_DEFN(toInt8)
#endif
#ifdef OSE_PROVIDE_TYPE_UINT8
OSEVM_WRAP_DEFN(toUInt8)
#endif
#ifdef OSE_PROVIDE_TYPE_INT16
OSEVM_WRAP_DEFN(toInt16)
#endif
#ifdef OSE_PROVIDE_TYPE_UINT16
OSEVM_WRAP_DEFN(toUInt16)
#endif
#ifdef OSE_PROVIDE_TYPE_UINT32
OSEVM_WRAP_DEFN(toUInt32)
#endif
#ifdef OSE_PROVIDE_TYPE_INT64
OSEVM_WRAP_DEFN(toInt64)
#endif
#ifdef OSE_PROVIDE_TYPE_UINT64
OSEVM_WRAP_DEFN(toUInt64)
#endif
#ifdef OSE_PROVIDE_TYPE_TIMETAG
OSEVM_WRAP_DEFN(toTimetag)
#endif
#ifdef OSE_PROVIDE_TYPE_TRUE
OSEVM_WRAP_DEFN(toTrue)
#endif
#ifdef OSE_PROVIDE_TYPE_FALSE
OSEVM_WRAP_DEFN(toFalse)
#endif
#ifdef OSE_PROVIDE_TYPE_NULL
OSEVM_WRAP_DEFN(toNull)
#endif
#ifdef OSE_PROVIDE_TYPE_INFINITUM
OSEVM_WRAP_DEFN(toInfinitum)
#endif
