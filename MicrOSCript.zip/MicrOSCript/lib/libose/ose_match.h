/*
Written by John MacCallum, The Center for New Music and Audio
Technologies, University of California, Berkeley.  Copyright (c)
2009, The Regents of the University of California (Regents).
Permission to use, copy, modify, distribute, and distribute
modified versions of this software and its documentation without
fee and without a signed licensing agreement, is hereby granted,
provided that the above copyright notice, this paragraph and the
following two paragraphs appear in all copies, modifications, and
distributions.

IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT,
INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE
AND ITS DOCUMENTATION, EVEN IF REGENTS HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.

REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE. THE SOFTWARE AND ACCOMPANYING
DOCUMENTATION, IF ANY, PROVIDED HEREUNDER IS PROVIDED "AS
IS". REGENTS HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT,
UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
*/

/**
 * @file ose_match.h
 *
 * @brief Pattern matching functions.
 */

#ifndef OSE_MATCH_H
#define OSE_MATCH_H

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Set this to control the number of backtracking
 * branches.
 */
#define OSE_MATCH_BACKTRACK_LIMIT 100

/**
 * @brief Switch this off to disable matching against a
 * pattern with 2 stars.
 */
#define OSE_MATCH_ENABLE_2STARS		1

/**
 * @brief Switch this off to disable matching against a
 * pattern with more than 2 stars which will be done
 * recursively.
 */
#define OSE_MATCH_ENABLE_NSTARS		1

/**
 * @brief Allow the star wildcard in addresses.
 *
 * @details Wildcards are only allowed in patterns since
 * matching patterns against patterns can be ambiguous and
 * confusing. One exception is the star wildcard, which, if
 * enabled here and found in an address, simply skips that
 * address container.
 *
 * @note Use of the star wildcard in an address is
 * restricted: an address container that contains a star,
 * may _only_ contain that star.
 */
#define OSE_MATCH_ALLOW_STAR_IN_ADDRESS

#define OSE_MATCH_DESCENDANTS

/**
 * @brief Pattern matching return codes.
 */
enum ose_match_retval
{
    OSE_MATCH_NOMATCH = 0,
    OSE_MATCH_ADDRESS_COMPLETE,
    OSE_MATCH_PATTERN_COMPLETE,
    OSE_MATCH_BOTH_COMPLETE,
    OSE_MATCH_ERROR_UNMATCHED_LEFT_SQUARE_BRACKET,
    OSE_MATCH_ERROR_UNMATCHED_RIGHT_SQUARE_BRACKET,
    OSE_MATCH_ERROR_UNMATCHED_LEFT_CURLY_BRACE,
    OSE_MATCH_ERROR_UNMATCHED_RIGHT_CURLY_BRACE,
    OSE_MATCH_ERROR_PATTERN_NO_LEADING_SLASH,
    OSE_MATCH_ERROR_ADDRESS_NO_LEADING_SLASH,
    OSE_MATCH_ERROR_INVALID_CHARACTER_CLASS,
    OSE_MATCH_ERROR_BACKTRACK_LIMIT_EXCEEDED,
    OSE_MATCH_ERROR_INVALID_REPETITION
};

/**
 * @brief Match an address against a pattern.
 *
 * @param pattern the pattern to match
 * @param address the address to match
 * @param pattern_offset the number of bytes into the pattern
 * that were matched successfully
 * @param address_offset the number of bytes into the address
 * that were matched successfully
 * @retval #ose_match_retval
 */
enum ose_match_retval ose_match_pattern(const char * const pattern,
                                        const char * const address,
                                        int32_t *pattern_offset,
                                        int32_t *address_offset);

#ifdef __cplusplus
}
#endif

#endif /* OSE_MATCH_H */
