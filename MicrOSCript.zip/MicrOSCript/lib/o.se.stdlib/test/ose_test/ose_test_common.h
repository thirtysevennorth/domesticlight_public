/**
 * @file ose_test_common.h
 *
 * @brief provides utility functions and global variables for
 * testing.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdarg.h>
#include <signal.h>
#include <setjmp.h>
#include <time.h>

#include "ose.h"
#include "ose_util.h"
#include "ose_context.h"
#include "ose_print.h"


/**
 * @cond DOXYGEN_SKIP
 * Used for printing
 */
#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_YELLOW  "\x1b[33m"
#define ANSI_COLOR_BLUE    "\x1b[34m"
#define ANSI_COLOR_MAGENTA "\x1b[35m"
#define ANSI_COLOR_CYAN    "\x1b[36m"
#define ANSI_COLOR_RESET   "\x1b[0m"
/** @endcond */ // DOXYGEN_SKIP

/**
 * @brief The return code for a failed assertion.
 *
 * @details Test functions may intentionally call functions
 * with conditions that will cause an assertion to fail, in
 * which case this will be returned and compared to the
 * test's expected_result.
 */
const int32_t ASSERTION_FAILED = 0x66666666;

/**
 * @brief The return code for a passed assertion.
 *
 * @note This is currently unused.
 */
const int32_t ASSERTION_PASSED = 0x33333333;

/**
 * @cond DOXYGEN_SKIP
 * Global variables used by the system.
 */
jmp_buf env;
int grand_total_failctr;
int grand_total_testctr;
int test_functions_skipped;
int failctr;
int testctr;
int tests_skipped;
/** @endcond */ // DOXYGEN_SKIP

/**
 * @brief Enable / disable verbosity.
 *
 * @details Use this flag to enable extra printing to the
 * console during testing. It may be switched on and off as
 * desired, for example when verbosity is needed only for a
 * specific test function.
 */
int verbose = 0;

/**
 * @brief The size of a simple bundle.
 */
#define MAX_BNDLSIZE 1024

/**
 * @brief Perform a byte-for-byte comparison of two bundles.
 */
#define COMPARE_BUNDLES(refbndl, testbndl)                  \
    memcmp(refbndl, testbndl, 4 + ntohl(*((int32_t *)refbndl)))

/** @cond DOXYGEN_SKIP */
void sighandler(int signo)
{
	if(signo == SIGABRT){
		longjmp(env, ASSERTION_FAILED);
	}
}
/** @endcond */ // DOXYGEN_SKIP

/** @cond DOXYGEN_SKIP */
char *align(char *p)
{
	while((long)p % 4){
		p++;
	}
	return p;
}
/** @endcond */ // DOXYGEN_SKIP

void pbndl(ose_bundle bundle, const char * const str)
{
    char buf[65536];
    memset(buf, 0, 65536);
    ose_pprintBundle(bundle, buf, 65536);
    fprintf(stderr, "\n\r%s>>>>>\n\r%s\n\r%s<<<<<\n\r",
            str, buf, str);
}

void pbytes(ose_bundle bundle, int32_t start, int32_t end)
{
    char *b = ose_getBundlePtr(bundle);
    for(int32_t i = start; i < end; i++){
        fprintf(stderr, "%d: %c %d\n\r", i,
                (unsigned char)b[i],
                (unsigned char)b[i]);
    }
}

void print_passed(const char * const fname)
{
	printf(ANSI_COLOR_GREEN "%d / %d tests PASSED" ANSI_COLOR_RESET "\n",
	       testctr - tests_skipped, testctr);
	if(tests_skipped){
		printf(ANSI_COLOR_YELLOW "%d tests SKIPPED" ANSI_COLOR_RESET "\n",
		       tests_skipped);
	}
}

void print_failed(const char * const fname)
{
	printf(ANSI_COLOR_RED "...%d of %d tests FAILED" ANSI_COLOR_RESET "\n",
	       failctr, testctr);
}

void print_results(const char * const fname)
{
	if(!testctr){
		printf(ANSI_COLOR_RED
		       "NO TESTS PERFORMED for this unit"
		       ANSI_COLOR_RESET
		       "\n");
		return;
	}
	if(!failctr){
		print_passed(fname);
	}else{
		print_failed(fname);
	}
}

void print_startTest(const char * const fname)
{
	failctr = 0;
	testctr = 0;
	printf(ANSI_COLOR_CYAN
	       "Testing %s..."
	       ANSI_COLOR_RESET
	       "\n",
	       fname);
}

#define TEST_FUNCTION(pfx, fn)					\
	{                                           \
		tests_skipped = 0;                      \
		grand_total_testctr++;                  \
		print_startTest(#fn);                   \
		int fc = failctr;                       \
		pfx ## fn();                            \
		print_results(#fn);                     \
		if(fc != failctr){                      \
			grand_total_failctr++;              \
		}                                       \
	}

#define SKIP_TEST_FUNCTION(fn)                  \
	test_functions_skipped++;                   \
	grand_total_testctr++;                      \
	printf(ANSI_COLOR_YELLOW                    \
	       "SKIPPING %s : "                     \
	       ANSI_COLOR_RESET                     \
	       "\n",                                \
	       #fn)

#define SKIP_TEST(test, expected_result)        \
	{                                           \
		tests_skipped++;                        \
		testctr++;                              \
		printf(ANSI_COLOR_YELLOW                \
		       "\nSKIPPING test %s"             \
		       ANSI_COLOR_RESET                 \
		       "\n",                            \
		       #test);                          \
	}

void init(void)
{
	signal(SIGABRT, sighandler);
    /* memset(true256, OSETT_TRUE, 256); */
	/* memset(false256, OSETT_FALSE, 256); */
	srand(time(NULL));
	grand_total_testctr = grand_total_failctr = 0;
	test_functions_skipped = tests_skipped = 0;
}

void finalize(void)
{
	printf("\n**************************************************\n");
	if(!grand_total_failctr){
		printf(ANSI_COLOR_GREEN
		       "%d / %d TESTS PASSED"
		       ANSI_COLOR_RESET
		       "\n",
		       grand_total_testctr - test_functions_skipped,
		       grand_total_testctr);
		if(test_functions_skipped){
			printf(ANSI_COLOR_YELLOW
			       "%d TESTS SKIPPED"
			       ANSI_COLOR_RESET
			       "\n",
			       test_functions_skipped);
		}
	}else{
		printf(ANSI_COLOR_RED
		       "%d / %d TESTS FAILED"
		       ANSI_COLOR_RESET
		       "\n",
		       grand_total_failctr,
		       grand_total_testctr);
	}
	printf("**************************************************\n");
}
