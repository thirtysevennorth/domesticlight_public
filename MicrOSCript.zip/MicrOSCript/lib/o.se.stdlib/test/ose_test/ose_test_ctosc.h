/**
 * @file ose_test_ctosc.h
 *
 * @brief provides a compile-time OSC implementation.
 */

/* zero or more zeros for padding */
#define Z0
#define Z1 0
#define Z2 0, 0
#define Z3 0, 0, 0
#define Z4 0, 0, 0, 0

/* unpack a string into a comma separated list of chars */
#define STOC1(s) s[0]
#define STOC2(s) s[0], STOC1((s + 1))
#define STOC3(s) s[0], STOC2((s + 1))
#define STOC4(s) s[0], STOC3((s + 1))

/* NULL padded strings */
#define S0N(s, z) z
#define S1N(s, z) STOC1(s), z
#define S2N(s, z) STOC2(s), z
#define S3N(s, z) STOC3(s), z
#define S4N(s, z) STOC4(s), z
#define S5N(s, z) STOC4(s), STOC1((s + 4)), z
#define S6N(s, z) STOC4(s), STOC2((s + 4)), z
#define S7N(s, z) STOC4(s), STOC3((s + 4)), z
#define S8N(s, z) STOC4(s), STOC4((s + 4)), z
#define S9N(s, z) STOC4(s), STOC4((s + 4)), STOC1((s + 8)), z
#define S10N(s, z) STOC4(s), STOC4((s + 4)), STOC2((s + 8)), z
#define S11N(s, z) STOC4(s), STOC4((s + 4)), STOC3((s + 8)), z
#define S12N(s, z) STOC4(s), STOC4((s + 4)), STOC4((s + 8)), z
#define S13N(s, z) STOC4(s), STOC4((s + 4)), STOC4((s + 8)),    \
        STOC1((s + 12)), z
#define S14N(s, z) STOC4(s), STOC4((s + 4)), STOC4((s + 8)),    \
        STOC2((s + 12)), z
#define S15N(s, z) STOC4(s), STOC4((s + 4)), STOC4((s + 8)),    \
        STOC3((s + 12)), z
#define S16N(s, z) STOC4(s), STOC4((s + 4)), STOC4((s + 8)),    \
        STOC4((s + 12)), z

/* general string type, used for addresses and strings */
#define S0(s) S0N(s, Z4)
#define S1(s) S1N(s, Z3)
#define S2(s) S2N(s, Z2)
#define S3(s) S3N(s, Z1)
#define S4(s) S4N(s, Z4)
#define S5(s) S5N(s, Z3)
#define S6(s) S6N(s, Z2)
#define S7(s) S7N(s, Z1)
#define S8(s) S8N(s, Z4)
#define S9(s) S9N(s, Z3)
#define S10(s) S10N(s, Z2)
#define S11(s) S11N(s, Z1)
#define S12(s) S12N(s, Z4)
#define S13(s) S13N(s, Z3)
#define S14(s) S14N(s, Z2)
#define S15(s) S15N(s, Z1)
#define S16(s) S16N(s, Z4)

/* address */
#define A(n, a) S ## n (a)

/* typetags */
#define T0(s) S0N(s, Z3)
#define T1(s) S1N(s, Z2)
#define T2(s) S2N(s, Z1)
#define T3(s) S3N(s, Z4)
#define T4(s) S4N(s, Z3)
#define T5(s) S5N(s, Z2)
#define T6(s) S6N(s, Z1)
#define T7(s) S7N(s, Z4)
#define T8(s) S8N(s, Z3)
#define T9(s) S9N(s, Z2)
#define T10(s) S10N(s, Z1)
#define T11(s) S11N(s, Z4)
#define T12(s) S12N(s, Z3)
#define T13(s) S13N(s, Z2)
#define T14(s) S14N(s, Z1)
#define T15(s) S15N(s, Z4)
#define T16(s) S16N(s, Z3)

#define T(n, s) ',', T ## n (s)

/* data: int32 */
#define Di(i)                                   \
    ((i & 0xFF000000) >> 24),                   \
        ((i & 0x00FF0000) >> 16),               \
        ((i & 0x0000FF00) >> 8),                \
        (i & 0x000000FF)

/* data: float32 */
union flint
{
    int32_t i;
    float f;
};

#define Df(ff) \
    (((union flint){.f = ff}.i & 0xFF000000) >> 24),   \
        (((union flint){.f = ff}.i & 0x00FF0000) >> 16),   \
        (((union flint){.f = ff}.i & 0x0000FF00) >> 8),    \
        ((union flint){.f = ff}.i & 0x000000FF)

/* data: string */
#define Ds(n, s) S ## n (s)

/* data: blob */
#define BS(i) 0, 0, 0, i,

#define B0(b) Z4
#define B1(b) BS(1) S1N(b, Z3)
#define B2(b) BS(2) S2N(b, Z2)
#define B3(b) BS(3) S3N(b, Z1)
#define B4(b) BS(4) S4N(b, Z0)
#define B5(b) BS(5) S5N(b, Z3)
#define B6(b) BS(6) S6N(b, Z2)
#define B7(b) BS(7) S7N(b, Z1)
#define B8(b) BS(8) S8N(b, Z0)
#define B9(b) BS(9) S9N(b, Z3)
#define B10(b) BS(10) S10N(b, Z2)
#define B11(b) BS(11) S11N(b, Z1)
#define B12(b) BS(12) S12N(b, Z0)
#define B13(b) BS(13) S9N(b, Z3)
#define B14(b) BS(14) S10N(b, Z2)
#define B15(b) BS(15) S11N(b, Z1)
#define B16(b) BS(16) S12N(b, Z0)

#define Db(n, b) B ## n (b)

/* bundle elements */
#define BE_SIZE(...)                                    \
    (sizeof((char []){__VA_ARGS__}) & 0xFF000000),      \
        (sizeof((char []){__VA_ARGS__}) & 0x00FF0000),  \
        (sizeof((char []){__VA_ARGS__}) & 0x0000FF00),  \
        (sizeof((char []){__VA_ARGS__}) & 0x000000FF),  \
        
/* bundle element: message */
#define BE_M(...)                               \
    BE_SIZE(__VA_ARGS__)                        \
        __VA_ARGS__

/* bundle element: bundle */
#define BE_B(...)                               \
    BE_SIZE('#', 'b', 'u', 'n', 'd', 'l', 'e', 0,   \
            0, 0, 0, 0, 0, 0, 0, 0,             \
            __VA_ARGS__)                        \
        '#', 'b', 'u', 'n', 'd', 'l', 'e', 0,   \
            0, 0, 0, 0, 0, 0, 0, 0,             \
        __VA_ARGS__

/* bundle element: empty bundle */
/* necessary in order to avoid a trailing comma */
#define BE_B0()                                     \
    BE_SIZE('#', 'b', 'u', 'n', 'd', 'l', 'e', 0,   \
            0, 0, 0, 0, 0, 0, 0, 0)                 \
    '#', 'b', 'u', 'n', 'd', 'l', 'e', 0,           \
        0, 0, 0, 0, 0, 0, 0, 0

/* message */
/* #define M(...) ((char []){ __VA_ARGS__ }) */
#define M(...) ((char []){ BE_M(__VA_ARGS__) })

/* bundle */
/* #define B(...) ((char []){                      \ */
/*         '#', 'b', 'u', 'n', 'd', 'l', 'e', 0,   \ */
/*             0, 0, 0, 0, 0, 0, 0, 0,             \ */
/*             __VA_ARGS__                         \ */
/*         }) */
#define B(...) ((char []){ BE_B(__VA_ARGS__) })

/* 
Example:

char b[] = B(BE_M(A(0, ""), T(0, "")),
                 BE_B(BE_M(A(2, "/x"),
                           T(2, "ii"),
                           Di(33),
                           Di(44)),
                      BE_M(A(8, "/foo/bar"),
                           T(4, "ifsb"),
                           Di(10),
                           Df(3.14159),
                           Ds(3, "foo"),
                           Db(3, "\x0\x1\x2"))));
 */
