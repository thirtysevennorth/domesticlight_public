#define UT_NEW_BUNDLE
#include "common.h"
#include "ut_common.h"
#include "ose_stdlib.h"

#include "../ose_stdlib.c"


void ut_ose_stdlib_2drop(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_stdlib_2drop,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_VM_ERRNO(ose_stdlib_2drop,
                       B(),
                       OSE_ERR_TYPE,
                       "empty bundle");
    UNIT_TEST_VM_ERRNO(ose_stdlib_2drop,
                       B(BE_M(A(0, ""),
                              T(1, "i"),
                              Di(32))),
                       OSE_ERR_TYPE,
                       "bundle with only one message");
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_2drop,
                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(3.14))),
                               B(),
                               "bundle with 2 messages");
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_2drop,
                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_B()),
                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(32))),
                               "bundle with 3 elems");
}

void ut_ose_stdlib_2dup(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_stdlib_2dup,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_VM_ERRNO(ose_stdlib_2dup,
                       B(),
                       OSE_ERR_TYPE,
                       "empty bundle");
    UNIT_TEST_VM_ERRNO(ose_stdlib_2dup,
                       B(BE_M(A(2, "/x"),
                              T(2, "if"),
                              Di(33),
                              Df(3.14))),
                       OSE_ERR_TYPE,
                       "bundle with only one message");
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_2dup,

                               B(BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14))),

                               B(BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14))),

                               "bundle with 2 messages");

    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_2dup,

                               B(BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/z"),
                                      T(1, "s"),
                                      Ds(3, "foo"))),

                               B(BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/z"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/z"),
                                      T(1, "s"),
                                      Ds(3, "foo"))),

                               "bundle with 2 messages");
}

void ut_ose_stdlib_2over(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_stdlib_2over,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_VM_ERRNO(ose_stdlib_2over,
                       B(),
                       OSE_ERR_TYPE,
                       "empty bundle");
    UNIT_TEST_VM_ERRNO(ose_stdlib_2over,
                       B(BE_M(A(2, "/x"),
                              T(2, "if"),
                              Di(33),
                              Df(3.14))),
                       OSE_ERR_TYPE,
                       "bundle with only one message");
    UNIT_TEST_VM_ERRNO(ose_stdlib_2over,
                       B(BE_M(A(2, "/x"),
                              T(1, "i"),
                              Di(32)),
                         BE_M(A(2, "/y"),
                              T(1, "f"),
                              Df(3.14))),
                       OSE_ERR_TYPE,
                       "bundle with only two messages");
    UNIT_TEST_VM_ERRNO(ose_stdlib_2over,
                       B(BE_M(A(2, "/x"),
                              T(1, "i"),
                              Di(32)),
                         BE_M(A(2, "/y"),
                              T(1, "f"),
                              Df(3.14)),
                         BE_M(A(2, "/z"),
                              T(1, "s"),
                              Ds(3, "foo"))),
                       OSE_ERR_TYPE,
                       "bundle with only three messages");
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_2over,

                               B(BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/z"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(2, "/a"),
                                      T(1, "i"),
                                      Ds(3, "10"))),
                               
                               B(BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/z"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(2, "/a"),
                                      T(1, "i"),
                                      Ds(3, "10")),
                                 BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14))),

                               "bundle with four messages");
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_2over,

                               B(BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/z"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(2, "/a"),
                                      T(1, "i"),
                                      Ds(3, "10")),
                                 BE_M(A(2, "/b"),
                                      T(1, "f"),
                                      Ds(3, "22.8"))),

                               B(BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(32)),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/z"),
                                      T(1, "s"),
                                      Ds(3, "foo")),
                                 BE_M(A(2, "/a"),
                                      T(1, "i"),
                                      Ds(3, "10")),
                                 BE_M(A(2, "/b"),
                                      T(1, "f"),
                                      Ds(3, "22.8")),
                                 BE_M(A(2, "/y"),
                                      T(1, "f"),
                                      Df(3.14)),
                                 BE_M(A(2, "/z"),
                                      T(1, "s"),
                                      Ds(3, "foo"))),

                               "bundle with five messages");
}

void ut_ose_stdlib_bundleAll(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_stdlib_bundleAll,
                                                 NULL,
                                                 "NULL bundle");

    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_bundleAll,
                               
                               B(),

                               B(BE_B()),

                               "bundle with 0 elements");
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_bundleAll,
                               
                               B(BE_B()),

                               B(BE_B(BE_B())),

                               "bundle with 1 element");
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_bundleAll,
                               
                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(23)),
                                 BE_M(A(0, ""),
                                      T(1, "f"),
                                      Df(2.3))),

                               B(BE_B(BE_M(A(0, ""),
                                           T(1, "i"),
                                           Di(23)),
                                      BE_M(A(0, ""),
                                           T(1, "f"),
                                           Df(2.3)))),

                               "bundle with 2 messages");
}

void ut_ose_stdlib_bundleFromBottom(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_stdlib_bundleFromBottom,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_VM_ERRNO(ose_stdlib_bundleFromBottom,
                       B(),
                       OSE_ERR_TYPE,
                       "empty bundle");
    UNIT_TEST_VM_ERRNO(ose_stdlib_bundleFromBottom,
                       B(BE_B()),
                       OSE_ERR_TYPE,
                       "no int message");
    UNIT_TEST_VM_ERRNO(ose_stdlib_bundleFromBottom,
                       B(BE_B()
                         BE_M(A(0, ""),
                              T(1, "f"),
                              Df(3.14))),
                       OSE_ERR_TYPE,
                       "wrong type");
    UNIT_TEST_VM_ERRNO(ose_stdlib_bundleFromBottom,
                       B(BE_B()
                         BE_M(A(0, ""),
                              T(1, "s"),
                              Ds(3, "foo"))),
                       OSE_ERR_TYPE,
                       "wrong type");
    
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_bundleFromBottom,
                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(0))),
                               B(BE_B()),
                               "empty bundle, n = 0");
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_bundleFromBottom,
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22), Df(33.), Ds(5, "ffour")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(0))),
                               B(BE_B()
                                 BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22),
                                      Df(33.),
                                      Ds(5, "ffour"))),
                               "one message, n = 0");
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_bundleFromBottom,
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22), Df(33.), Ds(5, "ffour")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(1))),
                               B(BE_B(BE_M(A(0, ""),
                                           T(3, "ifs"),
                                           Di(22),
                                           Df(33.),
                                           Ds(5, "ffour")))),
                               "two messages, n = 1");
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_bundleFromBottom,
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22), Df(33.), Ds(5, "ffour")),
                                 BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(33)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(1))),
                               B(BE_B(BE_M(A(0, ""),
                                           T(3, "ifs"),
                                           Di(22),
                                           Df(33.),
                                           Ds(5, "ffour"))),
                                 BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(33))),
                               "three messages, n = 1");
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_bundleFromBottom,
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22), Df(33.), Ds(5, "ffour")),
                                 BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(33)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(2))),
                               B(BE_B(BE_M(A(0, ""),
                                           T(3, "ifs"),
                                           Di(22),
                                           Df(33.),
                                           Ds(5, "ffour")),
                                      BE_M(A(2, "/x"),
                                           T(1, "i"),
                                           Di(33)))),
                               "three messages, n = 2");
}

void ut_ose_stdlib_bundleFromTop(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_stdlib_bundleFromTop,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_VM_ERRNO(ose_stdlib_bundleFromTop,
                       B(),
                       OSE_ERR_TYPE,
                       "empty bundle");
    UNIT_TEST_VM_ERRNO(ose_stdlib_bundleFromTop,
                       B(BE_B()),
                       OSE_ERR_TYPE,
                       "no int message");
    UNIT_TEST_VM_ERRNO(ose_stdlib_bundleFromTop,
                       B(BE_B()
                         BE_M(A(0, ""),
                              T(1, "f"),
                              Df(3.14))),
                       OSE_ERR_TYPE,
                       "wrong type");
    UNIT_TEST_VM_ERRNO(ose_stdlib_bundleFromTop,
                       B(BE_B()
                         BE_M(A(0, ""),
                              T(1, "s"),
                              Ds(3, "foo"))),
                       OSE_ERR_TYPE,
                       "wrong type");
    
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_bundleFromTop,
                               B(BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(0))),
                               B(BE_B()),
                               "empty bundle, n = 0");
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_bundleFromTop,
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22), Df(33.), Ds(5, "ffour")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(0))),
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22),
                                      Df(33.),
                                      Ds(5, "ffour")),
                                 BE_B()),
                               "one message, n = 0");
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_bundleFromTop,
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22), Df(33.), Ds(5, "ffour")),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(1))),
                               B(BE_B(BE_M(A(0, ""),
                                           T(3, "ifs"),
                                           Di(22),
                                           Df(33.),
                                           Ds(5, "ffour")))),
                               "two messages, n = 1");
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_bundleFromTop,
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22), Df(33.), Ds(5, "ffour")),
                                 BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(33)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(1))),
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22),
                                      Df(33.),
                                      Ds(5, "ffour")),
                                 BE_B(BE_M(A(2, "/x"),
                                           T(1, "i"),
                                           Di(33)))),
                               "three messages, n = 1");
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_bundleFromTop,
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22), Df(33.), Ds(5, "ffour")),
                                 BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(33)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(2))),
                               B(BE_B(BE_M(A(0, ""),
                                           T(3, "ifs"),
                                           Di(22),
                                           Df(33.),
                                           Ds(5, "ffour")),
                                      BE_M(A(2, "/x"),
                                           T(1, "i"),
                                           Di(33)))),
                               "three messages, n = 2");
}

void ut_ose_stdlib_clear(void)
{
    UNIT_TEST_BUNDLE_TRANSFORM_TRIGGER_ASSERTION(ose_stdlib_clear,
                                                 NULL,
                                                 "NULL bundle");
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_clear,
                               B(),
                               B(),
                               "empty bundle");
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_clear,
                               B(BE_B()),
                               B(),
                               "one elem");
    UNIT_TEST_VM_STACK_COMPARE(ose_stdlib_clear,
                               B(BE_M(A(0, ""),
                                      T(3, "ifs"),
                                      Di(22), Df(33.), Ds(5, "ffour")),
                                 BE_M(A(2, "/x"),
                                      T(1, "i"),
                                      Di(33)),
                                 BE_M(A(0, ""),
                                      T(1, "i"),
                                      Di(2))),
                               B(),
                               "three elems");
}

void ut_ose_stdlib_decatenateElemFromEnd(void)
{
    UNIT_TEST_VM_ERRNO(ose_stdlib_decatenateElemFromEnd,
                       B(BE_M(A(2, "/x"),
                              T(1, "f"),
                              Df(33.3))),
                       OSE_ERR_TYPE,
                       "bundle with one elem");
    UNIT_TEST_VM_ERRNO(ose_stdlib_decatenateElemFromEnd,
                       B(BE_M(A(2, "/a"),
                              T(2, "if"),
                              Di(22), Df(33)),
                         BE_M(A(2, "/x"),
                              T(1, "f"),
                              Df(33.3))),
                       OSE_ERR_TYPE,
                       "wrong type for index");
}

int main(int ac, char **av)
{
    init();
    UNIT_TEST_FUNCTION(ose_stdlib_2drop);
    UNIT_TEST_FUNCTION(ose_stdlib_2dup);
    UNIT_TEST_FUNCTION(ose_stdlib_2over);

    UNIT_TEST_FUNCTION(ose_stdlib_bundleAll);
    UNIT_TEST_FUNCTION(ose_stdlib_bundleFromBottom);
    UNIT_TEST_FUNCTION(ose_stdlib_bundleFromTop);
    UNIT_TEST_FUNCTION(ose_stdlib_clear);

    UNIT_TEST_FUNCTION(ose_stdlib_decatenateElemFromEnd);
    finalize();
    return 0;
}
