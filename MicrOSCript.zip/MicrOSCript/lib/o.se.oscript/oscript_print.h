#include "libose/ose.h"

#ifndef OSCRIPT_PRINT_H
#define OSCRIPT_PRINT_H

#ifdef __cplusplus
extern "C" {
#endif

void oscript_print_load(ose_bundle);

#ifdef __cplusplus
}
#endif

#endif
