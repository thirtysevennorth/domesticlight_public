#include "libose/ose.h"

#ifndef OSCRIPT_LIB_H
#define OSCRIPT_LIB_H

#ifdef __cplusplus
extern "C" {
#endif

void oscript_lib_load(ose_bundle);

#ifdef __cplusplus
}
#endif

#endif
