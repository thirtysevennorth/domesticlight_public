#include "libose/ose.h"

#ifndef OSCRIPT_EXEC_H
#define OSCRIPT_EXEC_H

#ifdef __cplusplus
extern "C" {
#endif

void oscript_exec_load(ose_bundle);

#ifdef __cplusplus
}
#endif

#endif
