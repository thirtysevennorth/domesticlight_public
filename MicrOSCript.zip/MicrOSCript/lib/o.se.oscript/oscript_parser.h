#include "libose/ose.h"

#ifndef OSCRIPT_PARSER_H
#define OSCRIPT_PARSER_H

#ifdef __cplusplus
extern "C" {
#endif

void oscript_parser_load(ose_bundle);

#ifdef __cplusplus
}
#endif

#endif
