# Dart target for ANTLR 4

Dart runtime libraries for ANTLR 4

This runtime is available through [pub](https://pub.dev). The package name is 'antlr4'.

See www.antlr.org for more information on ANTLR.

See https://github.com/antlr/antlr4/blob/master/doc/dart-target.md for more information on using ANTLR in Dart.


