#!/bin/bash

set -euo pipefail

# use v14 and check
echo node version: $(node --version)

