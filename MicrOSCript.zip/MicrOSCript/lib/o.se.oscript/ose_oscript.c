/*
  Copyright (c) 2019-23 John MacCallum Permission is hereby
  granted, free of charge, to any person obtaining a copy of this
  software and associated documentation files (the "Software"), to
  deal in the Software without restriction, including without
  limitation the rights to use, copy, modify, merge, publish,
  distribute, sublicense, and/or sell copies of the Software, and
  to permit persons to whom the Software is furnished to do so,
  subject to the following conditions:

  The above copyright notice and this permission notice shall be
  included in all copies or substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
  OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
  OTHER DEALINGS IN THE SOFTWARE.
*/

#include "libose/ose.h"
#include "libose/ose_context.h"
#include "libose/ose_util.h"
#include "libose/ose_stackops.h"
#include "libose/ose_assert.h"
#include "libose/ose_vm.h"
#include "libose/ose_print.h"
#include "libose/ose_errno.h"

#include "oscript_exec.h"
#include "oscript_lib.h"
#include "oscript_types.h"
#include "oscript_parser.h"
#include "oscript_print.h"

__attribute__((visibility("default")))
#ifdef OSE_LINK_MODULES
void ose_oscript_init(ose_bundle osevm)
#else
void ose_main(ose_bundle osevm)
#endif
{
	ose_bundle vm_s = OSEVM_STACK(osevm);
    
    OSE_START_BUNDLE(vm_s);
#ifndef OSCRIPT_NORUNTIME
    oscript_exec_load(vm_s);
    oscript_lib_load(vm_s);
    oscript_types_load(vm_s);
    oscript_print_load(vm_s);
#endif
#ifndef OSCRIPT_NOPARSER
    oscript_parser_load(vm_s);
#endif
    OSE_END_BUNDLE(vm_s);
}

#ifdef __cplusplus
}
#endif
